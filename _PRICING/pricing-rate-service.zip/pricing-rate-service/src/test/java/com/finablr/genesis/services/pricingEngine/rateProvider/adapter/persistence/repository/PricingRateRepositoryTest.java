package com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository;

import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = SpringProfiles.DEVELOPMENT)
@Commit
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@Ignore
public class PricingRateRepositoryTest {

    // @Autowired
    // private PricingRateRepository providedRateRepository;

    @Test
    public void testGetLatestProvidedExchangeRate() {
        // Optional<ProvidedRate> latestProvidedRate = providedRateRepository
        // .findLatestProvidedRate(ApplicationConstants.THOMSON_RATE_PROVIDER_ID, "sdjhsb34223", "INR=");
        // System.out.println(latestProvidedRate);
    }

}
