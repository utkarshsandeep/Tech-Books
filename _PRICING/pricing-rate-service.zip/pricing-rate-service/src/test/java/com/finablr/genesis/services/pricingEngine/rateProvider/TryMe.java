package com.finablr.genesis.services.pricingEngine.rateProvider;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

public class TryMe {


    @Test
    public void testStringMaking() {
        
        String user = "LO4_03_RHB_AE71394";
//                     LOXXXXXXXXXXXXXXXXX002
        
        String maskStr = StringUtils.repeat("*", user.length() - 5);
        
        System.out.println("maskStr --->>" + maskStr);
        
        System.out.println("Masked result --->>" + StringUtils.overlay(user, maskStr, 2, user.length() - 3));
    }
}
