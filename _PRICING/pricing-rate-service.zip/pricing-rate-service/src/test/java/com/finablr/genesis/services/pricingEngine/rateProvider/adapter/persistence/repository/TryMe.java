package com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository;

import java.time.ZoneId;
import java.util.TimeZone;

public class TryMe {

    public final static ZoneId ZONE_ID_UTC = ZoneId.of("UTC");

    public final static ZoneId ZONE_ID_INDIA = ZoneId.of("Asia/Kolkata");

    public final static ZoneId ZONE_ID_UAE = ZoneId.of("Asia/Dubai");

    public final static TimeZone TIME_ZONE_UTC = TimeZone.getTimeZone(ZONE_ID_UTC);

    public final static TimeZone TIME_ZONE_INDIA = TimeZone.getTimeZone(ZONE_ID_INDIA);

    public final static TimeZone TIME_ZONE_UAE = TimeZone.getTimeZone(ZONE_ID_UAE);

    // @Test
    public void tryIt() {
        System.out.println("ZONE_ID_UTC -> " + ZONE_ID_UTC);
        System.out.println("ZONE_ID_INDIA -> " + ZONE_ID_INDIA);
        System.out.println("ZONE_ID_UAE -> " + ZONE_ID_UAE);
        System.out.println("TIME_ZONE_UTC -> " + TIME_ZONE_UTC);
        System.out.println("TIME_ZONE_INDIA -> " + TIME_ZONE_INDIA);
        System.out.println("TIME_ZONE_UAE -> " + TIME_ZONE_UAE);
    }
}
