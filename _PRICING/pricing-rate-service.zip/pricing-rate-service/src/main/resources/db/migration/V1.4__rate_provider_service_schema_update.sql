--------------------------------------------------------
--  File created - Thursday-August-22-2019   
--------------------------------------------------------

--------------------------------------------------------
--  DDL for changes in Table THOMSON_STREAMS
--------------------------------------------------------

DELETE FROM THOMSON_STREAMS;
COMMIT;

ALTER TABLE "THOMSON_STREAMS" ADD 
	(
		"STATE" VARCHAR2(20 CHAR),
		"DESCRIPTION" VARCHAR2(255 CHAR),
        "CREATED_ON" TIMESTAMP (6) WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        "UPDATED_ON" TIMESTAMP (6) WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

--------------------------------------------------------
--  Constraints for Table THOMSON_STREAMS for newly added columns
--------------------------------------------------------

  ALTER TABLE "THOMSON_STREAMS" MODIFY ("STATE" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("CREATED_ON" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("UPDATED_ON" NOT NULL ENABLE);
