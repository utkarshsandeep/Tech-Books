--------------------------------------------------------
--  File created - Friday-July-12-2019   
--------------------------------------------------------

--------------------------------------------------------
--  DDL for changes in Table THOMSON_STREAMS
--------------------------------------------------------

--------------------------------------------------------
--  DDL for dropping table THOMSON_STREAMS;
--------------------------------------------------------

  DROP TABLE "THOMSON_STREAMS" CASCADE CONSTRAINTS;

--------------------------------------------------------
--  DDL for creating table THOMSON_STREAMS;
--------------------------------------------------------

  CREATE TABLE "THOMSON_STREAMS" 
   (	
	"RIC_ID" VARCHAR2(10 CHAR), 
	"VERSION" NUMBER(19,0), 
	"STREAM_ID" NUMBER(19,0), 
	"ENABLED" CHAR(1 CHAR)
   ) ;

--------------------------------------------------------
--  DDL for Index SYS_C0078979
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0078979" ON "THOMSON_STREAMS" ("RIC_ID") 
  ;

--------------------------------------------------------
--  Constraints for Table THOMSON_STREAMS
--------------------------------------------------------

  ALTER TABLE "THOMSON_STREAMS" MODIFY ("RIC_ID" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("VERSION" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("STREAM_ID" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("ENABLED" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" ADD PRIMARY KEY ("RIC_ID")
  USING INDEX  ENABLE;
