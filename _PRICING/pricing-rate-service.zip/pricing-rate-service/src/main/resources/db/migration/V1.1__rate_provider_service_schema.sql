--------------------------------------------------------
--  File created - Sunday-June-23-2019   
--------------------------------------------------------

--------------------------------------------------------
--  DDL for Sequence GLOBAL_SEQUENCE
--------------------------------------------------------

CREATE SEQUENCE "GLOBAL_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000 CACHE 50 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;

--------------------------------------------------------
--  DDL for Table PROVIDED_RATES
--------------------------------------------------------

  CREATE TABLE "PROVIDED_RATES" 
   (	"ID" NUMBER(19,0), 
	"CREATED_ON" TIMESTAMP (6) WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, 
	"CURRENCY" VARCHAR2(3 CHAR), 
	"ASK_VALUE" NUMBER(*,10), 
	"BID_VALUE" NUMBER(*,10), 
	"RATE_PROVIDER_ID" NUMBER(10,0), 
	"RIC_ID" VARCHAR2(20 CHAR), 
	"UPDATED_ON" TIMESTAMP (6) WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, 
	"VERSION" NUMBER(19,0)
   ) ;
--------------------------------------------------------
--  DDL for Table RATE_META_DATA
--------------------------------------------------------

  CREATE TABLE "RATE_META_DATA" 
   (	"RATE_ID" VARCHAR2(36 CHAR), 
	"FREQUENCY" VARCHAR2(15 CHAR), 
	"PUBLISHED_ON" TIMESTAMP (6) WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, 
	"RATE_PROVIDER_ID" NUMBER(10,0), 
	"RIC_ID" VARCHAR2(10 CHAR), 
	"VERSION" NUMBER(19,0)
   ) ;
--------------------------------------------------------
--  DDL for Table THOMSON_STREAMS
--------------------------------------------------------

  CREATE TABLE "THOMSON_STREAMS" 
   (	"ID" NUMBER(19,0), 
	"ENABLED" CHAR(1 CHAR), 
	"RIC_ID" VARCHAR2(10 CHAR), 
	"STREAM_ID" NUMBER(19,0), 
	"VERSION" NUMBER(19,0)
   ) ;
--------------------------------------------------------
--  DDL for Index SYS_C0078966
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0078966" ON "PROVIDED_RATES" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_PROVIDED_RATES_RIC_ID
--------------------------------------------------------

  CREATE INDEX "IDX_PROVIDED_RATES_RIC_ID" ON "PROVIDED_RATES" ("RIC_ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_PROVIDED_RATES_RATE_PROVIDER_ID
--------------------------------------------------------

  CREATE INDEX "IDX_PROVIDED_RATES_RATE_PROVIDER_ID" ON "PROVIDED_RATES" ("RATE_PROVIDER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_PROVIDED_RATES_UPDATED_ON
--------------------------------------------------------

  CREATE INDEX "IDX_PROVIDED_RATES_UPDATED_ON" ON "PROVIDED_RATES" (SYS_EXTRACT_UTC("UPDATED_ON")) 
  ;
--------------------------------------------------------
--  DDL for Index UNQ_RATE_PROVIDER_ID_RIC_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "UNQ_RATE_PROVIDER_ID_RIC_ID" ON "PROVIDED_RATES" ("RIC_ID", "RATE_PROVIDER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index SYS_C0078973
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0078973" ON "RATE_META_DATA" ("RATE_ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_RATE_META_DATA_RIC_ID
--------------------------------------------------------

  CREATE INDEX "IDX_RATE_META_DATA_RIC_ID" ON "RATE_META_DATA" ("RIC_ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_RATE_META_DATA_RATE_PROVIDER_ID
--------------------------------------------------------

  CREATE INDEX "IDX_RATE_META_DATA_RATE_PROVIDER_ID" ON "RATE_META_DATA" ("RATE_PROVIDER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_RATE_META_DATA_PUBLISHED_ON
--------------------------------------------------------

  CREATE INDEX "IDX_RATE_META_DATA_PUBLISHED_ON" ON "RATE_META_DATA" (SYS_EXTRACT_UTC("PUBLISHED_ON")) 
  ;
--------------------------------------------------------
--  DDL for Index SYS_C0078979
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0078979" ON "THOMSON_STREAMS" ("ID") 
  ;
--------------------------------------------------------
--  Constraints for Table PROVIDED_RATES
--------------------------------------------------------

  ALTER TABLE "PROVIDED_RATES" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "PROVIDED_RATES" MODIFY ("CREATED_ON" NOT NULL ENABLE);
  ALTER TABLE "PROVIDED_RATES" MODIFY ("ASK_VALUE" NOT NULL ENABLE);
  ALTER TABLE "PROVIDED_RATES" MODIFY ("BID_VALUE" NOT NULL ENABLE);
  ALTER TABLE "PROVIDED_RATES" MODIFY ("RATE_PROVIDER_ID" NOT NULL ENABLE);
  ALTER TABLE "PROVIDED_RATES" MODIFY ("RIC_ID" NOT NULL ENABLE);
  ALTER TABLE "PROVIDED_RATES" MODIFY ("UPDATED_ON" NOT NULL ENABLE);
  ALTER TABLE "PROVIDED_RATES" MODIFY ("VERSION" NOT NULL ENABLE);
  ALTER TABLE "PROVIDED_RATES" ADD CHECK (rate_provider_id<=3 AND rate_provider_id>=2) ENABLE;
  ALTER TABLE "PROVIDED_RATES" ADD PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
  ALTER TABLE "PROVIDED_RATES" ADD CONSTRAINT "UNQ_RATE_PROVIDER_ID_RIC_ID" UNIQUE ("RIC_ID", "RATE_PROVIDER_ID")
  USING INDEX  ENABLE;
--------------------------------------------------------
--  Constraints for Table RATE_META_DATA
--------------------------------------------------------

  ALTER TABLE "RATE_META_DATA" MODIFY ("RATE_ID" NOT NULL ENABLE);
  ALTER TABLE "RATE_META_DATA" MODIFY ("FREQUENCY" NOT NULL ENABLE);
  ALTER TABLE "RATE_META_DATA" MODIFY ("RATE_PROVIDER_ID" NOT NULL ENABLE);
  ALTER TABLE "RATE_META_DATA" MODIFY ("RIC_ID" NOT NULL ENABLE);
  ALTER TABLE "RATE_META_DATA" MODIFY ("VERSION" NOT NULL ENABLE);
  ALTER TABLE "RATE_META_DATA" ADD CHECK (rate_provider_id<=3 AND rate_provider_id>=2) ENABLE;
  ALTER TABLE "RATE_META_DATA" ADD PRIMARY KEY ("RATE_ID")
  USING INDEX  ENABLE;
--------------------------------------------------------
--  Constraints for Table THOMSON_STREAMS
--------------------------------------------------------

  ALTER TABLE "THOMSON_STREAMS" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("ENABLED" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("RIC_ID" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("STREAM_ID" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" MODIFY ("VERSION" NOT NULL ENABLE);
  ALTER TABLE "THOMSON_STREAMS" ADD PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
