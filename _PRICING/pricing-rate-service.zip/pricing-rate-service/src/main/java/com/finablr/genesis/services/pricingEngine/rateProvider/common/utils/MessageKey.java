package com.finablr.genesis.services.pricingEngine.rateProvider.common.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public class MessageKey {

    private String messageCode;
    
    private String defaultMessage;
}
