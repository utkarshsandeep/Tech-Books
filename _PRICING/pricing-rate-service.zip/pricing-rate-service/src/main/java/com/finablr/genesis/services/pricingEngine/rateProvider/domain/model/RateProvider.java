package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import java.util.EnumSet;

import org.zalando.problem.Status;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException.RateProviderExceptionType;

import io.swagger.annotations.ApiModel;

@JsonFormat(shape = JsonFormat.Shape.OBJECT)
@ApiModel(value = "rateProvider", description = "Rate provider details")
public enum RateProvider {

    // @formatter:off  
    THOMSON_AND_REUTERS(2, "Thomson & Reuters", "T&R"),
    FUTURE_SOURCE(3, "Future Source", "F&S");
    // @formatter:on

    private final int id;
    
    private final String nickName;

    private final String label;

    private String description;

    private RateProvider(final int id, final String label, final String nickName) {
        this.id = id;
        this.label = label;
        this.nickName = nickName;
        this.description = "id: " + id + ", name: " + name() + ", label" + label + ", nick name: " + nickName;
    }

    private static final EnumSet<RateProvider> ALL_VALUES = EnumSet.allOf(RateProvider.class);

    public static RateProvider byId(final int id) {
        for (RateProvider e : ALL_VALUES)
            if (e.id() == id)
                return e;
        throw new RateProviderException(RateProviderExceptionType.INVALID_RATE_PROVIDER_ID, Status.BAD_REQUEST, id);
    }

    public static RateProvider byName(final String name) {
        return valueOf(name);
    }

    public static EnumSet<RateProvider> all() {
        return ALL_VALUES;
    }

    @JsonProperty(index = 1)
    public int id() {
        return this.id;
    }

    @JsonProperty(index = 2)
    public String code() {
        return this.name();
    }

    @JsonProperty(index = 3)
    public String label() {
        return this.label;
    }

    @JsonProperty(index = 4)
    public String nickName() {
        return this.nickName;
    }

    public String description() {
        return this.description;
    }

    @Override
    public String toString() {
        return this.nickName;
    }

    @JsonIgnore
    public boolean isThomsonAndReuters() {
        return this == THOMSON_AND_REUTERS;
    }

    @JsonIgnore
    public boolean isFutureSource() {
        return this == RateProvider.FUTURE_SOURCE;
    }
}
