package com.finablr.genesis.services.pricingEngine.rateProvider.application.health;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.stereotype.Component;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard.InfraHealth;

import reactor.core.publisher.Mono;

@Component
public class HealthIndicator {

    @Autowired
    private DBHealthIndicator dbHealthIndicator;

    @Autowired
    private JMSHealthIndicator jmsHealthIndicator;

    @Autowired
    private ElektronHealthIndicator elektronHealthIndicator;

    public Mono<Health> dataSourceHealth() {
        return Mono.just(this.dbHealthIndicator.health());
    }

    public Mono<Health> jmsHealth() {
        return this.jmsHealthIndicator.health();
    }

    public Mono<Health> elektronHealth() {
        return this.elektronHealthIndicator.health();
    }

    public Mono<InfraHealth> infraHealth() {
        return Mono.just(InfraHealth.of(this.dataSourceHealth().block(Duration.ofSeconds(5)),
                this.jmsHealth().block(Duration.ofSeconds(5)), this.elektronHealth().block(Duration.ofSeconds(5))));
    }
}
