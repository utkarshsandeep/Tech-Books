package com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

import com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.JPA;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RicRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TnRStream;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.RateChangeEvent;

public interface PricingRateRepositoryJPA extends JPA {

    public TnRStream saveTnRStream(final TnRStream tnrStream);

    public Optional<TnRStream> findTnRStreamByRicId(final String ricId, final boolean writeLock);

    public List<TnRStream> findAllTnRStreams();

    public void deleteTnRStreamByRicId(final String ricId);

    public void deleteAllTnRStreams();

    public List<String> findUniqueTnRRicIds();

    public List<RateMetaData> findAllRateMetaData(final RateProvider... rateProviders);

    public Optional<RateMetaData> findRateMetaDataById(final String rateId, final boolean writeLock);

    public void saveRateMetaData(final RateMetaData rateMetaData);

    public void deleteRateMetaData(final String rateId);

    public Optional<RicRate> findRicRateByRateKey(final RateKey rateKey);

    public RicRate saveRicRate(final RicRate ricRate);

    public List<RicRate> findAllRicRates();

    public long findRateMetaDataCountByRicId(final String ricId);

    public void updateRicRate(final RateChangeEvent rateChangeEvent, final ZonedDateTime updatedOn);

    public void updateRateMetaDataPublishedRate(final String rateId, final ExchangeRate exchangeRate,
            final ZonedDateTime publishedOn);

}
