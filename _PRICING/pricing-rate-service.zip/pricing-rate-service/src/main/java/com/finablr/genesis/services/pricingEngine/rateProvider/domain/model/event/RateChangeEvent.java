package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event;

import java.time.ZonedDateTime;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
@ToString
public class RateChangeEvent {

    private RateKey rateKey;

    private ExchangeRate exchangeRate;

    private ZonedDateTime updatedOn;

    public static RateChangeEvent ofThomsonAndReuters(final String ricId, final ExchangeRate newExchangeRate) {
        return of(RateKey.ofThomsonAndReuters(ricId), newExchangeRate, DateTimeHelper.nowZonedDateTimeUTC());
    }

    public static RateChangeEvent ofFutureSource(final String ricId, final ExchangeRate newExchangeRate) {
        return of(RateKey.ofFutureSource(ricId), newExchangeRate, DateTimeHelper.nowZonedDateTimeUTC());
    }
}
