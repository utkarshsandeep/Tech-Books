package com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData;

public interface PricingRateRepository extends JpaRepository<RateMetaData, String>, PricingRateRepositoryJPA {

}
