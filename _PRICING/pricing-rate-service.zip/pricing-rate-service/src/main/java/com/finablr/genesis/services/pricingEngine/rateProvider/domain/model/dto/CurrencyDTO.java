package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto;

import javax.money.CurrencyUnit;
import javax.validation.constraints.NotNull;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.CurrencyExchange;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
@ApiModel(value = "currency", description = "Pair of source and target currency")
public class CurrencyDTO {

    @NotNull
    @ApiModelProperty(name = "source", dataType = "String", value = "ISO Currency Code e.g. USD", allowEmptyValue = false, required = true, example = "INR")
    private CurrencyUnit source;

    @NotNull
    @ApiModelProperty(name = "target", dataType = "String", value = "ISO Currency Code e.g. USD", allowEmptyValue = false, required = true, example = "INR")
    private CurrencyUnit target;

    @ApiModelProperty(hidden = true)
    public String getCcy() {
        return this.source.getCurrencyCode() + this.target.getCurrencyCode();
    }

    public CurrencyExchange toModel() {
        return CurrencyExchange.of(this.source, this.target);
    }

    public static CurrencyDTO of(final CurrencyExchange currencyExchange) {
        return of(currencyExchange.source(), currencyExchange.target());
    }
}
