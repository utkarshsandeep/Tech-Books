package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler;

import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.QUARTZ_JOB_DETAILS_FREQUENCY_KEY;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.QUARTZ_JOB_DETAILS_RATE_PROVIDER_NAME;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.QUARTZ_JOB_DETAILS_RIC_ID_KEY;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.RATE_PUBLICATION_JOB_GROUP_ID;

import java.time.Duration;
import java.util.List;
import java.util.Optional;

import javax.sql.DataSource;

import org.quartz.JobDataMap;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository.PricingRateRepository;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.annotation.spring.Quartz;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateDisabledEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateEnabledEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateFrequencyChangedEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;

import lombok.extern.slf4j.Slf4j;

@Quartz
@Slf4j
@Service
public class SchedulerServiceImpl extends AbstractSchedulerService {

    @Autowired
    private PricingRateRepository pricingRateRepository;

    public SchedulerServiceImpl(final Scheduler scheduler, final DataSource datasource) {
        super(scheduler, datasource);
    }

    @Override
    public void scheduleNewRatePublicationJob(final PricingRateEnabledEvent jobInfo) {
        try {
            JobDataMap jobDataMap = new JobDataMap();

            jobDataMap.put(QUARTZ_JOB_DETAILS_RIC_ID_KEY, jobInfo.getRateKey().ricId());
            jobDataMap.put(QUARTZ_JOB_DETAILS_FREQUENCY_KEY, jobInfo.getFrequency().toMillis());
            jobDataMap.put(QUARTZ_JOB_DETAILS_RATE_PROVIDER_NAME, jobInfo.getRateKey().rateProvider().name());

            scheduleJob(RatePublisherJob.class, RATE_PUBLICATION_JOB_GROUP_ID, jobInfo.getRateId(), jobDataMap,
                    jobInfo.getFrequency().toMillis());

            log.info("New Job scheduled for rate id: {}, ric id: {} and repeat frequency:{}", jobInfo.getRateId(),
                    jobInfo.getRateKey().ricId(), jobInfo.getFrequency());
        }
        catch (SchedulerException e) {
            log.error("SchedulerException while scheduling job with id: " + jobInfo.getRateId(), e);
        }
    }

    @Override
    public void updateRatePublicationJobFrequency(final PricingRateFrequencyChangedEvent jobInfo) {
        try {
            reScheduleJob(RATE_PUBLICATION_JOB_GROUP_ID, jobInfo.getRateId(), jobInfo.getFrequency().toMillis());
        }
        catch (SchedulerException e) {
            log.error("SchedulerException while re-scheduling job with id: " + jobInfo.getRateId(), e);
        }
    }

    @Override
    public void deleteRatePublicationJob(final PricingRateDisabledEvent jobInfo) {
        try {
            deleteJob(RATE_PUBLICATION_JOB_GROUP_ID, jobInfo.getRateId());
        }
        catch (SchedulerException e) {
            log.error("SchedulerException while deleting job with id: " + jobInfo.getRateId(), e);
        }
    }

    @Transactional
    @Override
    public void validateScheduledJobs() {

        log.info("Validating Scheduled Jobs......");

        try {
            List<RateMetaData> allRateMetaData = this.pricingRateRepository.findAllRateMetaData();
            if (!SpringProfiles.isTnREnabled()) {
                log.info("As thomson is disabled now, so deleting its jobs");
            }
            if (allRateMetaData != null && !allRateMetaData.isEmpty()) {
                allRateMetaData.forEach(rateMetaData -> {
                    if (rateMetaData.isRateProviderFutureSource()) {
                        validateJob(rateMetaData);
                    }
                    else if (rateMetaData.isRateProviderThomsonAndReuters() && SpringProfiles.isTnREnabled()) {
                        validateJob(rateMetaData);
                    }
                    else {
                        try {
                            if (this.checkIfJobExists(rateMetaData.rateId()).isPresent()) {
                                this.deleteRatePublicationJob(rateMetaData.pricingRateDisabledEvent());
                            }
                        }
                        catch (Exception e) {
                            log.error("Exception while checking if Job already exists/deleting job", e);
                        }
                    }
                });
            }

            this.validateTriggerStates();
        }
        catch (Exception e) {
            log.error("Exception during validating scheduled jobs", e);
        }
    }

    private void validateJob(final RateMetaData rateMetaData) {
        Optional<Trigger> existingJob;
        try {
            existingJob = this.checkIfJobExists(rateMetaData.rateId());
            if (existingJob.isPresent()) {
                Duration jobFrequency = AbstractSchedulerService.getJobFrequency(existingJob.get());
                boolean isFrequencyChanged = !rateMetaData.isFrequencySameAs(jobFrequency);
                log.info(
                        "Job exists with repeat interval: {}, current rate update frequency: {}, isFrequencyChanged: {}",
                        jobFrequency, rateMetaData.frequency(), isFrequencyChanged);
                if (isFrequencyChanged) {
                    this.updateRatePublicationJobFrequency(rateMetaData.pricingRateFrequencyChangedEvent());
                }
            }
            else {
                PricingRateEnabledEvent pricingRateEnabledEvent = rateMetaData.pricingRateEnabledEvent();
                log.info("Job not found for rate id: {}, so creating new", pricingRateEnabledEvent.getRateId());
                this.scheduleNewRatePublicationJob(pricingRateEnabledEvent);
            }
        }
        catch (Exception e) {
            log.error("Exception while validating scheduled jobs", e);
        }
    }

    @Override
    public void startScheduler() throws SchedulerException {
        this.scheduler.start();
    }

    @Override
    public void startScheduler(int seconds) throws SchedulerException {
        this.scheduler.startDelayed(30);
    }
}