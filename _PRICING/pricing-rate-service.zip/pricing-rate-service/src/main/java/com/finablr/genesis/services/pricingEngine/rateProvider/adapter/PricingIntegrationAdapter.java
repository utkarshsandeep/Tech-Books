package com.finablr.genesis.services.pricingEngine.rateProvider.adapter;

import java.io.IOException;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler.SchedulerService;
import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr.TnRClient;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.annotation.spring.JmsIntegration;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateDisabledEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateEnabledEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateFrequencyChangedEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PublishRateEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.service.PricingRateService;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.service.RateProcessor;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;

import lombok.extern.slf4j.Slf4j;

@JmsIntegration
@Slf4j
@Component
public class PricingIntegrationAdapter {

    @Lazy
    @Autowired
    private SchedulerService schedulerService;

    @Lazy
    @Autowired
    private TnRClient tnrClient;

    @Autowired
    private PricingRateService pricingRateService;

    @Autowired
    private JmsTemplate jmsQueueTemplate;

    @Autowired
    private RateProcessor rateProcessor;

    private static final String NORMAL_BASE_RATE_CHANGE_EVENT_QUEUE = "PRICING.NORMAL_BASE_RATE_CHANGE_EVENTS";

    private static final String RATE_PROVIDER_RATE_CHANGE_QUEUE = "PRICING.RATE_PROVIDER_RATE_CHANGE_EVENTS";

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @JmsListener(destination = NORMAL_BASE_RATE_CHANGE_EVENT_QUEUE, containerFactory = "queueListenerFactory")
    public void onPricingRateEvent(final Message message) {

        log.debug("Queue: {} , \nReceived Message: {}", NORMAL_BASE_RATE_CHANGE_EVENT_QUEUE, message);
        try {
            String messageType = message.getStringProperty("_type");
            if (message instanceof TextMessage) {
                if (messageType.endsWith("ProvidedRateEnabledEvent")) {
                    PricingRateEnabledEvent event = new ObjectMapper()
                            .readValue(((ActiveMQTextMessage) message).getText(), PricingRateEnabledEvent.class);

                    handlePricingRateEnabledEvent(event);
                }
                else if (messageType.endsWith("ProvidedRateFrequencyChangedEvent")) {
                    PricingRateFrequencyChangedEvent event = new ObjectMapper().readValue(
                            ((ActiveMQTextMessage) message).getText(), PricingRateFrequencyChangedEvent.class);

                    handlePricingRateFrequencyChangedEvent(event);
                }
                else if (messageType.endsWith("ProvidedRateDisabledEvent")) {
                    PricingRateDisabledEvent event = new ObjectMapper()
                            .readValue(((ActiveMQTextMessage) message).getText(), PricingRateDisabledEvent.class);

                    handlePricingRateDisabledEvent(event);
                }
                else {
                    log.debug("Invalid message type: " + messageType);
                }
            }
            else {
                log.error("Message {} received from {} is not of type TextMessage", message,
                        NORMAL_BASE_RATE_CHANGE_EVENT_QUEUE);
            }
        }
        catch (IOException | JMSException e) {
            log.error("Exception occured in handlePricingRateEnabledEvent", e);
        }
    }

    public void handlePricingRateEnabledEvent(final PricingRateEnabledEvent event) {
        log.debug("Received PricingRateEnabledEvent for rateProviderId: {} " + "rateId: {}, ricId: {}",
                event.getRateKey().rateProvider(), event.getRateId(), event.getRateKey().ricId());

        Optional<RateMetaData> existingRate = this.pricingRateService.getRateMetaDataById(event.getRateId(), false);

        if (existingRate.isPresent()) {
            // Do nothing, ignore
            // handlePricingRateFrequencyChangedEvent(
            // PricingRateFrequencyChangedEvent.of(event.getRateId(), event.getFrequency(), event.getLive()));
        }
        else {
            RateMetaData rateMetaData = RateMetaData.of(event.getRateId(), event.getCurrency(), event.getRateKey(),
                    event.getFrequency(), event.getLive());
            this.pricingRateService.createRateMetaData(rateMetaData);
            if (event.isThomsonAndReuters()) {
                if (SpringProfiles.isTnREnabled()) {
                    this.rateProcessor.addProvidedRate(rateMetaData);
                    this.schedulerService.scheduleNewRatePublicationJob(event);
                    int i = 0;
                    while (i++ < 5) {
                        try {
                            if (this.tnrClient.openStream(event.getRateKey().ricId()).get(10,
                                    TimeUnit.SECONDS) != -1L) {
                                log.info("Created TnR stream, for ric ID: {}", event.getRateKey().ricId());
                                break;
                            }
                        }
                        catch (InterruptedException | ExecutionException | TimeoutException e) {
                            log.error("Exception while trying to open stream for ric ID: {}",
                                    event.getRateKey().ricId(), e);
                        }
                        if (i == 5) {
                            log.info("Failed to create TnR stream, for ric ID: {}, retry expired - retry manually",
                                    event.getRateKey().ricId());
                        }
                        else {
                            log.info("Failed to create TnR stream, for ric ID: {}, so gonna retry after 30 seconds",
                                    event.getRateKey().ricId());
                            try {
                                TimeUnit.SECONDS.sleep(30);
                            }
                            catch (InterruptedException e) {
                                // Do nothing
                            }
                        }
                    }
                }
                else {
                    log.debug(
                            "thomson profile is not enabled. So not creating Schedule and Stream, but saved meta data");
                }
            }
            else if (event.isFutureSource()) {
                this.rateProcessor.addProvidedRate(rateMetaData);
                this.schedulerService.scheduleNewRatePublicationJob(event);
            }
            else {
                log.error("Invalid rate provider id: " + event.getRateKey().rateProvider());
            }
        }
    }

    public void handlePricingRateFrequencyChangedEvent(final PricingRateFrequencyChangedEvent event) {
        log.debug("Received PricingRateFrequencyChangedEvent for " + "rateId: {}, New frequency: {}, live: {}",
                event.getRateId(), event.getFrequency(), event.getLive());

        Optional<RateMetaData> rateMetaData = this.pricingRateService.getRateMetaDataById(event.getRateId(), false);
        if (rateMetaData.isPresent()) {
            boolean isFrequencyChanged = this.pricingRateService.updateRateMetaDataFrequency(event.getRateId(),
                    event.getFrequency(), event.getLive());
            if (rateMetaData.get().isRateProviderThomsonAndReuters() && SpringProfiles.isTnREnabled()
                    && isFrequencyChanged) {
                this.rateProcessor.updateProvidedRate(event.getRateId(), event.getFrequency(), event.getLive());
                this.schedulerService.updateRatePublicationJobFrequency(event);
            }
            else if (rateMetaData.get().isRateProviderFutureSource() && isFrequencyChanged) {
                this.rateProcessor.updateProvidedRate(event.getRateId(), event.getFrequency(), event.getLive());
                this.schedulerService.updateRatePublicationJobFrequency(event);
            }
        }
    }

    public void handlePricingRateDisabledEvent(final PricingRateDisabledEvent event) {
        log.debug("Received PricingRateDisabledEvent for rateId: {}", event.getRateId());

        Optional<RateMetaData> rateMetaData = this.pricingRateService.getRateMetaDataById(event.getRateId(), false);
        if (rateMetaData.isPresent()) {
            this.pricingRateService.deleteRateMetaData(event.getRateId());
            this.schedulerService.deleteRatePublicationJob(event);
            if (rateMetaData.get().isRateProviderThomsonAndReuters() && SpringProfiles.isTnREnabled()) {
                this.rateProcessor.deleteProvidedRate(rateMetaData.get());
                this.tnrClient.closeStream(rateMetaData.get().rateKey().ricId());
            }
            else if (rateMetaData.get().isRateProviderFutureSource()) {
                this.rateProcessor.deleteProvidedRate(rateMetaData.get());
            }
        }
    }

    public void pushPublishRateEventToActiveMQ(final PublishRateEvent providedRateEvent) {
        log.debug("Pushing PublishRateEvent: {} to JMS topic : {} ", providedRateEvent,
                RATE_PROVIDER_RATE_CHANGE_QUEUE);
        this.jmsQueueTemplate.convertAndSend(RATE_PROVIDER_RATE_CHANGE_QUEUE, providedRateEvent);
    }
}
