package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.thomsonreuters.ema.access.ChannelInformation;

public interface TnRClient {

    public void initializeTnRStreams();

    public CompletableFuture<Long> openStream(final String ricId);

    public CompletableFuture<ExchangeRate> rateSnapshot(String ricId);

    public void closeStream(final String ricId);

    public void cleanTnRStreamsTable();

    public Optional<ChannelInformation> channelInformation();

    public void reInitializeOmmConsumer(final String ricId);
    
    public void reInitializeStream(final String ricId);
}
