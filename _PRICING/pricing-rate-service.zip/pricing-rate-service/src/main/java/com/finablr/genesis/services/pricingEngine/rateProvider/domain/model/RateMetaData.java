package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import java.time.Duration;
import java.time.ZonedDateTime;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateDisabledEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateEnabledEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateFrequencyChangedEvent;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@Entity
//@formatter:off
@Table(name = "RATE_META_DATA", indexes = {
        @Index(name = "IDX_RATE_META_DATA_RIC_ID", columnList = "RIC_ID"),
        @Index(name = "IDX_RATE_META_DATA_RATE_PROVIDER", columnList = "RATE_PROVIDER"),
        @Index(name = "IDX_RATE_META_DATA_PUBLISHED_ON", columnList = "PUBLISHED_ON")  
    }
)
//@formatter:on
@DynamicUpdate
@OptimisticLocking(type = OptimisticLockType.NONE)
public class RateMetaData {

    @Id
    @Access(AccessType.FIELD)
    @Column(name = "RATE_ID", updatable = false, nullable = false, length = 36)
    private String rateId;

    @Version
    @Access(AccessType.FIELD)
    @Column(name = "VERSION", nullable = false)
    private Long version;

    @NotNull
    private CurrencyExchange currency;

    @NotNull
    @Embedded
    private RateKey rateKey;

    @NotNull
    @Column(name = "FREQUENCY", nullable = true, length = 15)
    private Duration frequency;

    @NotNull
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "IS_LIVE", length = 1)
    private Boolean live = Boolean.FALSE;

    // @OptimisticLock(excluded = true)
    @Column(name = "PUBLISHED_ON", columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    private ZonedDateTime publishedOn;

    private ExchangeRate publishedRate;

    public void publishedNow() {
        this.publishedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public boolean updateFrequency(final Duration newFrequency, final Boolean live) {
        this.live = live;
        if (isFrequencySameAs(newFrequency)) {
            return false;
        }
        else {
            this.frequency = newFrequency;
            return true;
        }
    }

    public static RateMetaData of(final String rateId, final CurrencyExchange currency, final RateKey rateKey,
            final Duration frequency, final boolean live) {
        RateMetaData rateMetaData = new RateMetaData();

        rateMetaData.rateId = rateId;
        rateMetaData.currency = currency;
        rateMetaData.rateId = rateId;
        rateMetaData.rateKey = rateKey;
        rateMetaData.frequency = frequency;
        rateMetaData.live = live;
        rateMetaData.publishedRate = ExchangeRate.ZERO;

        return rateMetaData;
    }

    public boolean isFrequencySameAs(final Duration other) {
        return this.frequency.compareTo(other) == 0;
    }

    public PricingRateEnabledEvent pricingRateEnabledEvent() {
        return PricingRateEnabledEvent.of(this.rateId, this.rateKey, this.frequency);
    }

    public PricingRateDisabledEvent pricingRateDisabledEvent() {
        return PricingRateDisabledEvent.of(this.rateId);
    }

    public PricingRateFrequencyChangedEvent pricingRateFrequencyChangedEvent() {
        return PricingRateFrequencyChangedEvent.of(this.rateId, this.frequency, this.live);
    }

    public boolean isRateProviderThomsonAndReuters() {
        return this.rateKey.rateProvider().isThomsonAndReuters();
    }

    public boolean isRateProviderFutureSource() {
        return this.rateKey.rateProvider().isFutureSource();
    }

    public void publishRate(final ExchangeRate publishedRate, final ZonedDateTime publishedOn) {
        this.publishedRate = publishedRate;
        this.publishedOn = publishedOn;
    }
}
