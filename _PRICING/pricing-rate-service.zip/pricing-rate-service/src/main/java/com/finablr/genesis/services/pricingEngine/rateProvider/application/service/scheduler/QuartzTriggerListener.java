package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler;

import org.quartz.JobExecutionContext;
import org.quartz.Trigger;
import org.quartz.Trigger.CompletedExecutionInstruction;
import org.quartz.TriggerListener;

public class QuartzTriggerListener implements TriggerListener {

    private static final String TRIGGER_LISTENER_NAME = "QUARTZ_TRIGGER_LISTENER";
    
    @Override
    public String getName() {
        return TRIGGER_LISTENER_NAME;
    }

    @Override
    public void triggerFired(final Trigger trigger, final JobExecutionContext context) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public boolean vetoJobExecution(final Trigger trigger, final JobExecutionContext context) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void triggerMisfired(final Trigger trigger) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void triggerComplete(final Trigger trigger, final JobExecutionContext context,
            CompletedExecutionInstruction triggerInstructionCode) {
        // TODO Auto-generated method stub
        
    }

}
