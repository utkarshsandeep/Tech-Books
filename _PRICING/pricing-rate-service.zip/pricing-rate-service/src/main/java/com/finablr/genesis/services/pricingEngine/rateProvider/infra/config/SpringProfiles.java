package com.finablr.genesis.services.pricingEngine.rateProvider.infra.config;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public final class SpringProfiles {

    public static final String LOCAL = "local";

    public static final String DEVELOPMENT = "dev";

    public static final String SYSTEM_INTEGRATION = "sit";

    public static final String INTEGRATION = "int";

    public static final String UAT = "uat";

    public static final String PRODUCTION = "prod";

    public static final String TEST = "test";

    public static final String SWAGGER = "swagger";

    public static final String JMS = "jms";

    public static final String QUARTZ = "quartz";

    public static final String TnR = "thomson";

    public static final String NOT_TEST = "!test";

    private static final String SPRING_PROFILE_DEFAULT = "spring.profiles.default";

    private static List<String> ACTIVE_PROFILES;

    private static Environment environment;

    @Autowired
    public void setEnvironment(final Environment environment) {
        SpringProfiles.environment = environment;
    }

    /**
     * Set a default to use when no profile is configured.
     *
     * @param app the Spring application
     */
    public static void addDefaultProfile(final SpringApplication app) {
        Map<String, Object> defProperties = new HashMap<>(1);

        defProperties.put(SPRING_PROFILE_DEFAULT, SpringProfiles.DEVELOPMENT);
        app.setDefaultProperties(defProperties);
    }

    public static void addAdditionalProfiles(final SpringApplication app, final String[] additionalProfiles) {
        app.setAdditionalProfiles(additionalProfiles);
    }

    /**
     * Get the profiles that are applied else get default profiles.
     *
     * @return profiles
     */
    public static List<String> getActiveProfiles() {
        if (ACTIVE_PROFILES == null) {
            if (environment.getActiveProfiles().length == 0) {
                ACTIVE_PROFILES = Arrays.asList(environment.getDefaultProfiles());
                return ACTIVE_PROFILES;
            }
            else {
                ACTIVE_PROFILES = Arrays.asList(environment.getActiveProfiles());
                return ACTIVE_PROFILES;
            }
        }
        else {
            return ACTIVE_PROFILES;
        }
    }

    public static boolean isEnabled(final String profile) {
        return getActiveProfiles().contains(profile);
    }

    public static boolean isQuartzEnabled() {
        return isEnabled(QUARTZ);
    }

    public static boolean isJMSEnabled() {
        return isEnabled(JMS);
    }

    public static boolean isTnREnabled() {
        return isEnabled(TnR);
    }
}
