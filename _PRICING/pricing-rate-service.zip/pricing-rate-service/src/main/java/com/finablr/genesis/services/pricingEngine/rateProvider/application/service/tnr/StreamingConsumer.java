package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr;

import static com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr.ElektronMessageUtil.decodeExchangeRate;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.annotation.spring.TnR;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.RateChangeEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.StreamStatusEvent;
import com.thomsonreuters.ema.access.AckMsg;
import com.thomsonreuters.ema.access.GenericMsg;
import com.thomsonreuters.ema.access.Msg;
import com.thomsonreuters.ema.access.OmmConsumerClient;
import com.thomsonreuters.ema.access.OmmConsumerEvent;
import com.thomsonreuters.ema.access.RefreshMsg;
import com.thomsonreuters.ema.access.StatusMsg;
import com.thomsonreuters.ema.access.UpdateMsg;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.FluxSink;

@TnR
@Slf4j
@RequiredArgsConstructor
@Component
public class StreamingConsumer implements OmmConsumerClient {

    @NonNull
    private FluxSink<RateChangeEvent> rateSink;

    @NonNull
    private FluxSink<StreamStatusEvent> streamStatusSink;

    public void onRateChangeEvent(final RateChangeEvent rateChangeEvent) {
        log.debug("rateChangeEvent: {}", rateChangeEvent);
        this.rateSink.next(rateChangeEvent);
    }

    public void onStreamStatusEvent(final StreamStatusEvent streamStatusEvent) {
        this.streamStatusSink.next(streamStatusEvent);
    }

    @Override
    public void onUpdateMsg(final UpdateMsg updateMsg, final OmmConsumerEvent consumerEvent) {
        // log.debug("onUpdateMsg ricId: {}, payload: {} and statusCode: {}", updateMsg.name(), updateMsg.payload());
        Optional<ExchangeRate> newExchangeRate = decodeExchangeRate(updateMsg.payload());
        if (newExchangeRate.isPresent()) {
            this.onRateChangeEvent(RateChangeEvent.ofThomsonAndReuters(updateMsg.name(), newExchangeRate.get()));
        }
    }

    @Override
    public void onStatusMsg(final StatusMsg statusMsg, final OmmConsumerEvent consumerEvent) {
        log.info("onStatusMsg ricId: {}, status: {} and statusCode: {}", statusMsg.name(), statusMsg.state(),
                statusMsg.state().dataState());

        this.onStreamStatusEvent(StreamStatusEvent.of(statusMsg.name(), consumerEvent.handle(), statusMsg.state()));
    }

    @Override
    public void onRefreshMsg(final RefreshMsg refreshMsg, final OmmConsumerEvent consumerEvent) {
        log.info("onRefreshMsg ricId: {}, status: {} and statusCode: {}", refreshMsg.name(), refreshMsg.state(),
                refreshMsg.state().dataState());

        this.onStreamStatusEvent(StreamStatusEvent.of(refreshMsg.name(), consumerEvent.handle(), refreshMsg.state()));
        Optional<ExchangeRate> exchangeRate = decodeExchangeRate(refreshMsg.payload());
        if (exchangeRate.isPresent()) {
            this.onRateChangeEvent(RateChangeEvent.ofThomsonAndReuters(refreshMsg.name(), exchangeRate.get()));
        }
    }

    @Override
    public void onAllMsg(final Msg msg, final OmmConsumerEvent consumerEvent) {
        // log.debug("onAllMsg --->> msg: {} for consumerEvent: {}", msg, consumerEvent);
    }

    @Override
    public void onAckMsg(final AckMsg ackMsg, final OmmConsumerEvent consumerEvent) {
        // log.debug("onAckMsg --->> ackMsg: {} for consumerEvent: {}", ackMsg, consumerEvent);
    }

    @Override
    public void onGenericMsg(final GenericMsg genericMsg, final OmmConsumerEvent consumerEvent) {
        // log.debug("onAllMsg --->> genericMsg: {} for consumerEvent: {}", genericMsg, consumerEvent);
    }
}
