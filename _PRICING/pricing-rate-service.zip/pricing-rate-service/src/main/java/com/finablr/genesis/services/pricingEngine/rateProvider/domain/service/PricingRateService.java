package com.finablr.genesis.services.pricingEngine.rateProvider.domain.service;

import java.time.Duration;
import java.util.List;
import java.util.Optional;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RicRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.FutureSourceRateRequest;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.PushRateRequest;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.RateDTO;

public interface PricingRateService {

    public RateMetaData createProvidedRate(final RateMetaData providedRate);

    // public Optional<ProvidedRate> getLatestProvidedRate(final int rateProviderId, final String rateId,
    // final String ricId);

    public List<RicRate> createOrUpdateFutureSourceRates(final List<FutureSourceRateRequest> createRequests);

    public void createOrUpdateRicRates(final RateProvider rateProvider, final List<PushRateRequest> createRequests);

    public RateDTO getProvidedRateByRateKey(final RateKey rateKey);

    public Optional<RateMetaData> getRateMetaDataById(final String rateId, final boolean writeLock);

    public void createRateMetaData(final RateMetaData thomsonRatesMetaData);

    public void deleteRateMetaData(final String rateId);

    public boolean updateRateMetaDataFrequency(final String rateId, final Duration frequency, final Boolean live);
    
    public void cleanTnRStreamsTable();
}
