package com.finablr.genesis.services.pricingEngine.rateProvider.infra.config;

import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.javamoney.moneta.CurrencyUnitBuilder;
import org.springframework.boot.web.server.MimeMappings;
import org.springframework.boot.web.server.WebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Hooks;

/**
 * Configuration of web application with Servlet 3.0 APIs.
 */
@Configuration
@Slf4j
public class WebConfigurer
        implements ServletContextInitializer, WebServerFactoryCustomizer<WebServerFactory>, WebMvcConfigurer {

    private final Environment env;

    private final ApplicationProperties applicationProperties;

    public WebConfigurer(Environment env, ApplicationProperties applicationProperties) {
        this.env = env;
        this.applicationProperties = applicationProperties;
    }

    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        if (env.getActiveProfiles().length != 0) {
            log.info("Web application configuration, using profiles: {}", (Object[]) env.getActiveProfiles());
        }
        addCustomCurrencyUnits();
        initReactorDebug();
        log.info("Web application fully configured");
    }
    
    private void addCustomCurrencyUnits() {
        CurrencyUnitBuilder.of("All", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("SCP", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("SDP", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("JSY", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("SMG", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("ESC", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("ECS", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("ECV", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("AON", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("AOR", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("IOM", "None").setDefaultFractionDigits(2).build(true);
        CurrencyUnitBuilder.of("NIP", "None").setDefaultFractionDigits(2).build(true);
        log.info("Added custom currency units [All, ECS, ECV, ESC, IOM, JSY, NIP, SCP, SDP, SMG, AON, AOR] to Monetary singleton");
    }
    
    private void initReactorDebug() {
//        ReactorDebugAgent.init();
        Hooks.onOperatorDebug();
    }

    /**
     * Customize the Servlet engine: Mime types, the document root, the cache.
     */
    @Override
    public void customize(WebServerFactory server) {
        setMimeMappings(server);
    }

    private void setMimeMappings(WebServerFactory server) {
        if (server instanceof ConfigurableServletWebServerFactory) {
            MimeMappings mappings = new MimeMappings(MimeMappings.DEFAULT);
            mappings.add("html", MediaType.TEXT_HTML_VALUE + ";charset=" + StandardCharsets.UTF_8.name().toLowerCase());
            mappings.add("json", MediaType.TEXT_HTML_VALUE + ";charset=" + StandardCharsets.UTF_8.name().toLowerCase());
            ConfigurableServletWebServerFactory servletWebServer = (ConfigurableServletWebServerFactory) server;
            servletWebServer.setMimeMappings(mappings);
        }
    }

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = applicationProperties.getCors();
        if (config.getAllowedOrigins() != null && !config.getAllowedOrigins().isEmpty()) {
            log.debug("Registering CORS filter");
            source.registerCorsConfiguration("/api/**", config);
            source.registerCorsConfiguration("/v2/api-docs", config);
            source.registerCorsConfiguration("/management/**", config);
        }

        return new CorsFilter(source);
    }

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
        // Add any custom method argument resolvers
    }
}
