package com.finablr.genesis.services.pricingEngine.rateProvider.domain.service;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.finablr.genesis.services.pricingEngine.rateProvider.adapter.PricingIntegrationAdapter;
import com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository.PricingRateRepository;
import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler.SchedulerService;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.ImmutableCollectors;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.JobExecution;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ProvidedRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RicRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.StreamState;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TnRStream;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TriggerDetails;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard.RateRecord;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.RateChangeEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.StreamStatusEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.BeanFactory;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.EmitterProcessor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Slf4j
@Component
public class RateProcessor {

    private Map<String, ProvidedRate> rateDataMap;

    private MultiValueMap<RateKey, String> ricIdRateIdMapping = new LinkedMultiValueMap<>(200);

    private Map<String, StreamState> streamStateMap = new ConcurrentHashMap<>(200);

    @Autowired
    private SchedulerService schedulerService;

    @Autowired
    private PricingRateRepository pricingRateRepository;

    @Autowired
    private PlatformTransactionManager transactionManager;

    @Autowired
    private EmitterProcessor<RateChangeEvent> rateEmitter;

    @Autowired
    private FluxSink<RateRecord> dashboardSink;

    @Lazy
    @Autowired
    private PricingIntegrationAdapter pricingIntegrationAdapter;

    public void initialize() {

        this.setUpRateChangeProcessor();

        if (SpringProfiles.isTnREnabled()) {
            this.setUpStreamStatusProcessor();
        }

        if (SpringProfiles.isQuartzEnabled()) {
            this.setUpScheduleProcessor();
        }

        List<RateMetaData> rateRecords = null;
        if (!SpringProfiles.isTnREnabled()) {
            rateRecords = this.pricingRateRepository.findAllRateMetaData(RateProvider.FUTURE_SOURCE);
        }
        else {
            rateRecords = this.pricingRateRepository.findAllRateMetaData();
        }

        this.rateDataMap = rateRecords.stream().map(rateMetaData -> {
            this.ricIdRateIdMapping.add(rateMetaData.rateKey(), rateMetaData.rateId());
            return ProvidedRate.of(rateMetaData);
        }).collect(Collectors.toConcurrentMap(ProvidedRate::rateId, Function.identity()));

        log.info("Cached records count: " + this.rateDataMap.size());
    }

    private void setUpRateChangeProcessor() {
        log.info("Setting up Rate Change processor .. ");

        this.rateEmitter.doOnNext(event -> log.debug("rate flux -->" + event)).flatMap(this::updateInMemoryRicRate)
                .publishOn(Schedulers.newSingle("rate-worker")).subscribe(this::persistRicRateChange);
    }

    private void setUpStreamStatusProcessor() {
        log.info("Setting up Stream status processor ... ");
        BeanFactory.getStreamStatusEmitter().publishOn(Schedulers.newSingle("stream-status-worker"))
                .doOnNext(streamStatusEvent -> this.updateInMemoryStreamState(streamStatusEvent.ricId(),
                        streamStatusEvent.state()))
                .subscribe(this::persistStreamStatusChange);

    }

    private void setUpScheduleProcessor() {
        log.info("Setting up Schedule processor ... ");

        Flux<JobExecution> schedulePublisher = BeanFactory.getScheduleEmitter()
                .flatMap(jobExecution -> this.publishableRate(jobExecution)).filter(JobExecution::isPublished)
                .publishOn(Schedulers.newSingle("scheduler-worker"));

        schedulePublisher.flatMap(jobExecution -> {
            // log.debug("Sending updated rate to ActiveMQ .. " + jobExecution);
            // if (SpringProfiles.isJMSEnabled()) {
            // try {
            // this.pricingIntegrationAdapter.pushPublishRateEventToActiveMQ(jobExecution.publishRateEvent());
            return Mono.just(jobExecution);
            // }
            // catch (final Exception e) {
            // log.error("Exception while sending to rate changes to ActiveMQ", e);
            // return Mono.empty();
            // }
            // }
            // else {
            // log.error("JMS integration is disabled");
            // return Mono.empty();
            // }
        }).doOnNext(this::published)
                .doOnNext(jobExecution -> this.dashboardSink.next(RateRecord.onJobExecution(jobExecution)))
                .subscribe(jobExecution -> {
                    // log.debug("Updating published rate in DB .. " + jobExecution);
                    this.persistPublishedRate(jobExecution);
                });
    }

    private void updateInMemoryStreamState(final String ricId, final StreamState streamState) {
        this.streamStateMap.put(ricId, streamState);
        RateKey rateKey = RateKey.ofThomsonAndReuters(ricId);
        this.ricIdRateIdMapping.get(rateKey).forEach(
                rateId -> this.dashboardSink.next(RateRecord.onStreamStateChange(rateId, rateKey, streamState)));
    }

    public Mono<RateChangeEvent> updateInMemoryRicRate(final RateChangeEvent rateChangeEvent) {
        if (this.ricIdRateIdMapping.containsKey(rateChangeEvent.rateKey()) && this.ricIdRateIdMapping
                .get(rateChangeEvent.rateKey()).stream().map(this.rateDataMap::get).map(providedRate -> {
                    boolean updated = providedRate.updateRate(rateChangeEvent.exchangeRate(),
                            rateChangeEvent.updatedOn());
                    if (updated) {
                        this.dashboardSink.next(RateRecord.onRateChange(providedRate.rateId(), providedRate.rateKey(),
                                rateChangeEvent.exchangeRate(), rateChangeEvent.updatedOn()));
                    }
                    return updated;
                }).reduce(false, (a, b) -> a || b)) {
            return Mono.just(rateChangeEvent);
        }
        else {
            return Mono.empty();
        }
    }

    // @Transactional // This does not work in reactive stream
    private void persistStreamStatusChange(final StreamStatusEvent streamStatusEvent) {
        TransactionStatus ts = this.transactionManager.getTransaction(new DefaultTransactionDefinition());
        try {
            Optional<TnRStream> tnrStream = this.pricingRateRepository.findTnRStreamByRicId(streamStatusEvent.ricId(),
                    true);
            if (tnrStream.isPresent()) {
                if (streamStatusEvent.established()) {
                    tnrStream.get().enable(streamStatusEvent.streamId(), streamStatusEvent.state(),
                            streamStatusEvent.description());
                }
                else {
                    tnrStream.get().disable(streamStatusEvent.state(), streamStatusEvent.description());
                }
            }
            else {
                this.pricingRateRepository.saveTnRStream(TnRStream.of(streamStatusEvent.ricId(),
                        streamStatusEvent.streamId(), streamStatusEvent.established(), streamStatusEvent.state(),
                        streamStatusEvent.description()));
            }

            this.transactionManager.commit(ts);
        }
        catch (Exception e) {
            log.error("Exception occurred while handling stream state event: " + streamStatusEvent, e);
            this.transactionManager.rollback(ts);
        }
    }

    // @Transactional // This does not work in reactive stream
    private void persistRicRateChange(final RateChangeEvent rateChangeEvent) {
        TransactionStatus ts = this.transactionManager.getTransaction(new DefaultTransactionDefinition());
        try {
            Optional<RicRate> ricRate = this.pricingRateRepository.findRicRateByRateKey(rateChangeEvent.rateKey());
            if (ricRate.isPresent()) {
                ricRate.get().updateExchangeRate(rateChangeEvent.exchangeRate(), rateChangeEvent.updatedOn());
            }
            else {
                this.pricingRateRepository.saveRicRate(RicRate.of(rateChangeEvent.rateKey(),
                        rateChangeEvent.exchangeRate(), rateChangeEvent.updatedOn()));
            }
            this.transactionManager.commit(ts);
        }
        catch (Exception e) {
            log.error("Exception peristing RIC rate changes: " + rateChangeEvent, e);
            this.transactionManager.rollback(ts);
        }
    }

    private Mono<JobExecution> publishableRate(final JobExecution jobExecution) {
        if (this.rateDataMap.containsKey(jobExecution.getRateId())) {
            return this.rateDataMap.get(jobExecution.getRateId()).publishableRate(jobExecution);
        }
        else {
            return Mono.empty();
        }
    }

    private void published(final JobExecution jobExecution) {
        if (this.rateDataMap.containsKey(jobExecution.getRateId())) {
            this.rateDataMap.get(jobExecution.getRateId()).published(jobExecution);
        }
    }

    // @Transactional // This does not work in reactive stream
    private void persistPublishedRate(final JobExecution jobExecution) {
        TransactionStatus ts = this.transactionManager.getTransaction(new DefaultTransactionDefinition());
        try {
            this.pricingRateRepository.updateRateMetaDataPublishedRate(jobExecution.getRateId(),
                    jobExecution.getPublishedRate().exchangeRate(), jobExecution.getPublishedRate().publishedOn());
            this.transactionManager.commit(ts);
        }
        catch (Exception e) {
            log.error("Exception while peristing Published rate: " + jobExecution, e);
            this.transactionManager.rollback(ts);
        }
    }

    public List<String> currenciesList(final List<RateProvider> rateProviders) {
        return this.rateDataMap.values().stream().filter(providedRate -> {
            if (rateProviders != null && !rateProviders.isEmpty()
                    && !rateProviders.contains(providedRate.rateKey().rateProvider())) {
                return false;
            }
            else {
                return true;
            }
        }).map(ProvidedRate::ricId).distinct().sorted().collect(ImmutableCollectors.toImmutableList());
    }

    private Map<String, TriggerDetails> triggerDetailsMap = Collections.emptyMap();

    private Map<String, TriggerDetails> getAllTriggerDetailsMap() {
        return SpringProfiles.isQuartzEnabled() ? this.schedulerService.getAllTriggerDetails() : this.triggerDetailsMap;
    }

    public List<RateRecord> getAllRateRecords(final List<RateProvider> rateProviders, final List<String> ricIds) {
        Map<String, TriggerDetails> triggerDetailsMap = getAllTriggerDetailsMap();
        return this.rateDataMap.values().stream().filter(providedRate -> {
            if (rateProviders != null && !rateProviders.isEmpty()
                    && !rateProviders.contains(providedRate.rateKey().rateProvider())) {
                return false;
            }
            if (ricIds != null && !ricIds.isEmpty() && !ricIds.contains(providedRate.rateKey().ricId())) {
                return false;
            }
            return true;
        }).map(providedRate -> RateRecord.of(providedRate, this.streamStateMap.get(providedRate.rateKey().ricId()),
                triggerDetailsMap.get(providedRate.rateId()))).sorted().collect(Collectors.toList());
    }

    public void addProvidedRate(final RateMetaData rateMetaData) {
        this.rateDataMap.put(rateMetaData.rateId(), ProvidedRate.of(rateMetaData));
        MultiValueMap<RateKey, String> ricIdRateIdMappingTemp = new LinkedMultiValueMap<>(this.ricIdRateIdMapping);
        ricIdRateIdMappingTemp.add(rateMetaData.rateKey(), rateMetaData.rateId());
        this.ricIdRateIdMapping = ricIdRateIdMappingTemp;
    }

    public void updateProvidedRate(final String rateId, final Duration newFrequency, final Boolean live) {
        this.rateDataMap.get(rateId).updateFrequency(newFrequency, live);
    }

    public void deleteProvidedRate(final RateMetaData rateMetaData) {
        this.rateDataMap.remove(rateMetaData.rateId());
        MultiValueMap<RateKey, String> ricIdRateIdMappingTemp = new LinkedMultiValueMap<>(this.ricIdRateIdMapping);
        ricIdRateIdMappingTemp.remove(rateMetaData.rateKey(), rateMetaData.rateId());
    }
}
