package com.finablr.genesis.services.pricingEngine.rateProvider.infra.config;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.util.backoff.FixedBackOff;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.annotation.spring.JmsIntegration;

import io.opentracing.Tracer;
import io.opentracing.contrib.jms.spring.TracingJmsTemplate;

@JmsIntegration
@EnableJms
@Configuration
public class ActiveMQConfig {

    @Autowired
    private ApplicationProperties applicationProperties;

    @Bean
    public ConnectionFactory connectionFactory() {
        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
        connectionFactory.setBrokerURL(applicationProperties.getJmsConfig().getBrokerUrl());
        connectionFactory.setUserName(applicationProperties.getJmsConfig().getUsername());
        connectionFactory.setPassword(applicationProperties.getJmsConfig().getPassword());
        return connectionFactory;
    }

    /**
     * Creates a topic listener factory with pubsub enabled
     * 
     * @param connectionFactory
     * @return JmsListenerContainerFactory
     */
    @Bean
    public JmsListenerContainerFactory<DefaultMessageListenerContainer> topicListenerFactory(
            ConnectionFactory connectionFactory) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        factory.setMessageConverter(messageConverter());
        factory.setConnectionFactory(connectionFactory);
        factory.setConcurrency("1-1");
        FixedBackOff fbo = new FixedBackOff(); // or ExponentialBackOff
        if (applicationProperties.getJmsConfig().getMaxAttempts() > 0) {
            fbo.setMaxAttempts(applicationProperties.getJmsConfig().getMaxAttempts());
        } // Otherwise indefinite retries
        fbo.setInterval(applicationProperties.getJmsConfig().getInterval());
        factory.setBackOff(fbo);
        return factory;
    }

    /**
     * Creates a queue listener factory with pubsub disabled
     * 
     * @param connectionFactory
     * @return JmsListenerContainerFactory
     */
    @Bean
    public JmsListenerContainerFactory<DefaultMessageListenerContainer> queueListenerFactory(
            ConnectionFactory connectionFactory) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        factory.setMessageConverter(messageConverter());
        factory.setConnectionFactory(connectionFactory);
        factory.setConcurrency("1-1");
        FixedBackOff fbo = new FixedBackOff(); // or ExponentialBackOff
        if (applicationProperties.getJmsConfig().getMaxAttempts() > 0) {
            fbo.setMaxAttempts(applicationProperties.getJmsConfig().getMaxAttempts());
        } // Otherwise indefinite retries
        factory.setBackOff(fbo);
        return factory;
    }

    /**
     * Creates a MessageCovertor to Serialize message content to json using TextMessage
     * 
     * @return MessageConverter
     */
    @Bean
    public MessageConverter messageConverter() {
        MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
        converter.setTargetType(MessageType.TEXT);
        converter.setTypeIdPropertyName("_type");
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        converter.setObjectMapper(mapper);
        return converter;
    }

    /**
     * Used for sending Messages to Queues.
     * 
     * @param tracer jaeger tracer
     * @return JmsTemplate
     */
    @Bean
    public JmsTemplate jmsQueueTemplate(Tracer tracer) {
        JmsTemplate template = new TracingJmsTemplate(tracer);
        template.setConnectionFactory(connectionFactory());
        template.setMessageConverter(messageConverter());
        template.setDeliveryPersistent(true);
        return template;
    }

    /**
     * Used for sending Messages to Topic.
     * 
     * @param tracer jaeger tracer
     * @return JmsTemplate
     */
    @Bean
    public JmsTemplate jmsTopicTemplate(Tracer tracer) {
        JmsTemplate template = new TracingJmsTemplate(tracer);
        template.setConnectionFactory(connectionFactory());
        template.setMessageConverter(messageConverter());
        template.setPubSubDomain(true);
        template.setDeliveryPersistent(true);
        return template;
    }
}
