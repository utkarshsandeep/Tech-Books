package com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository;

import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.AbstractJPA;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate_;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey_;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData_;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RicRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RicRate_;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TnRStream;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TnRStream_;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.RateChangeEvent;

@Repository
public class PricingRateRepositoryImpl extends AbstractJPA implements PricingRateRepositoryJPA {

    @Override
    public TnRStream saveTnRStream(final TnRStream tnrStream) {
        return persist(tnrStream);
    }

    @Override
    public Optional<TnRStream> findTnRStreamByRicId(final String ricId, final boolean writeLock) {
        // return writeLock
        // ? Optional.ofNullable(entityManager().find(ThomsonStream.class, ricId, LockModeType.PESSIMISTIC_WRITE))
        // : findByIdSafely(ThomsonStream.class, ricId);
        return findByIdSafely(TnRStream.class, ricId);
    }

    @Override
    public List<TnRStream> findAllTnRStreams() {
        CriteriaQuery<TnRStream> query = criteriaQuery(TnRStream.class);
        Root<TnRStream> root = query.from(TnRStream.class);
        query.select(root);
        return getUnmodifiableResultList(query);
    }

    @Override
    public void deleteAllTnRStreams() {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaDelete<TnRStream> deleteQuery = criteriaBuilder.createCriteriaDelete(TnRStream.class);
        deleteQuery.from(TnRStream.class);

        entityManager().createQuery(deleteQuery).executeUpdate();
    }

    @Override
    public void deleteTnRStreamByRicId(String ricId) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaDelete<TnRStream> deleteQuery = criteriaBuilder.createCriteriaDelete(TnRStream.class);
        Root<TnRStream> tnrStream = deleteQuery.from(TnRStream.class);

        Predicate ricIdEqualsPredicate = criteriaBuilder
                .and(criteriaBuilder.equal(tnrStream.get(TnRStream_.ricId.getName()), ricId));
        deleteQuery.where(ricIdEqualsPredicate);

        entityManager().createQuery(deleteQuery).executeUpdate();
    }

    public List<String> findUniqueTnRRicIds() {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<String> query = criteriaQuery(String.class);
        Root<RateMetaData> root = query.from(RateMetaData.class);
        query.select(root.get(RateMetaData_.rateKey.getName()).get(RateKey_.ricId.getName())).distinct(true);
        query.where(
                criteriaBuilder.equal(root.get(RateMetaData_.rateKey.getName()).get(RateKey_.rateProvider.getName()),
                        RateProvider.THOMSON_AND_REUTERS));
        return getUnmodifiableResultList(query);
    }

    @Override
    public List<RateMetaData> findAllRateMetaData(final RateProvider... rateProviders) {
        CriteriaQuery<RateMetaData> query = criteriaQuery(RateMetaData.class);
        Root<RateMetaData> root = query.from(RateMetaData.class);
        query.select(root);
        if (rateProviders != null && rateProviders.length > 0) {
            query.where(root.get(RateMetaData_.rateKey.getName()).get(RateKey_.rateProvider.getName())
                    .in(Arrays.asList(rateProviders)));
        }
        return getUnmodifiableResultList(query);
    }

    @Override
    public List<RicRate> findAllRicRates() {
        CriteriaQuery<RicRate> query = criteriaQuery(RicRate.class);
        Root<RicRate> root = query.from(RicRate.class);
        query.select(root);
        return getUnmodifiableResultList(query);
    }

    @Override
    public Optional<RateMetaData> findRateMetaDataById(final String rateId, final boolean writeLock) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<RateMetaData> query = criteriaQuery(RateMetaData.class);
        Root<RateMetaData> root = query.from(RateMetaData.class);
        query.select(root);
        query.where(criteriaBuilder.equal(root.get(RateMetaData_.rateId.getName()), rateId));
        // if (writeLock) {
        // TypedQuery<RateMetaData> typedQuery = typedQuery(query);
        // typedQuery.setLockMode(LockModeType.PESSIMISTIC_WRITE);
        // return getSingleResultSafely(typedQuery);
        // }
        // else {
        return getSingleResultSafely(query);
        // }
    }

    @Override
    public void saveRateMetaData(final RateMetaData rateMetaData) {
        entityManager().persist(rateMetaData);
    }

    @Override
    public void deleteRateMetaData(final String rateId) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaDelete<RateMetaData> deleteQuery = criteriaBuilder.createCriteriaDelete(RateMetaData.class);
        Root<RateMetaData> root = deleteQuery.from(RateMetaData.class);

        Predicate ricIdEqualsPredicate = criteriaBuilder
                .and(criteriaBuilder.equal(root.get(RateMetaData_.rateId.getName()), rateId));
        deleteQuery.where(ricIdEqualsPredicate);

        entityManager().createQuery(deleteQuery).executeUpdate();
    }

    @Override
    public long findRateMetaDataCountByRicId(final String ricId) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<RateMetaData> tnrStream = query.from(RateMetaData.class);
        query.where(criteriaBuilder.and(criteriaBuilder
                .equal(tnrStream.get(RateMetaData_.rateKey.getName()).get(RateKey_.ricId.getName()), ricId)));

        query.select(criteriaBuilder.count(tnrStream));

        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public void updateRicRate(final RateChangeEvent rateChangeEvent, final ZonedDateTime updatedOn) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();

        CriteriaUpdate<RicRate> update = criteriaBuilder.createCriteriaUpdate(RicRate.class);
        Root<RicRate> root = update.from(RicRate.class);
        update.set(root.get("exchangeRate").get(ExchangeRate_.askValue.getName()),
                rateChangeEvent.exchangeRate().askValue());
        update.set(root.get("exchangeRate").get(ExchangeRate_.bidValue.getName()),
                rateChangeEvent.exchangeRate().bidValue());
        update.set(root.get(RicRate_.updatedOn.getName()), updatedOn);

        update.where(criteriaBuilder.equal(root.get(RicRate_.rateKey.getName()), rateChangeEvent.rateKey()));

        entityManager().createQuery(update).executeUpdate();
    }

    @Override
    public void updateRateMetaDataPublishedRate(final String rateId, final ExchangeRate exchangeRate,
            final ZonedDateTime publishedOn) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();

        CriteriaUpdate<RateMetaData> update = criteriaBuilder.createCriteriaUpdate(RateMetaData.class);
        Root<RateMetaData> root = update.from(RateMetaData.class);
        update.set(root.get(RateMetaData_.publishedRate.getName()).get(ExchangeRate_.askValue.getName()),
                exchangeRate.askValue());
        update.set(root.get(RateMetaData_.publishedRate.getName()).get(ExchangeRate_.bidValue.getName()),
                exchangeRate.bidValue());
        update.set(RateMetaData_.publishedOn.getName(), publishedOn);

        update.where(criteriaBuilder.equal(root.get(RateMetaData_.rateId.getName()), rateId));

        entityManager().createQuery(update).executeUpdate();
    }

    @Override
    public Optional<RicRate> findRicRateByRateKey(final RateKey rateKey) {
        return Optional.ofNullable(entityManager().find(RicRate.class, rateKey));
    }

    @Override
    public RicRate saveRicRate(final RicRate ricRate) {
        entityManager().persist(ricRate);
        return ricRate;
    }
}
