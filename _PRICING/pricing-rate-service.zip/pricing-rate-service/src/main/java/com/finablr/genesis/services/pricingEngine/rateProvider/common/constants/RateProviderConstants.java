package com.finablr.genesis.services.pricingEngine.rateProvider.common.constants;

public enum RateProviderConstants implements MessageCodeType {

    // @formatter:off
    FUTURE_SOURCE_RATE_CREATED_SUCCESSFULLY("future.source.rate.created.successfully", "{0} Rates created or updated for Future Source"),
	RATES_PUSHED_SUCCESSFULLY("rates.pushed.successfully", "{0} Rates pushed into the system successfully");
	// @formatter:on

    private String key;

    private String defaultMessage;

    private RateProviderConstants(final String messageCode, final String defaultMessage) {
        this.key = messageCode;
        this.defaultMessage = defaultMessage;
    }

    @Override
    public String key() {
        return this.key;
    }

    @Override
    public String defaultMessage() {
        return this.defaultMessage;
    }
}
