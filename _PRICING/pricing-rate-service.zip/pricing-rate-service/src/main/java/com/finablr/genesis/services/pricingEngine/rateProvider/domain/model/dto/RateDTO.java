package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto;

import java.math.BigDecimal;

import javax.validation.constraints.PositiveOrZero;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateValue;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
@ApiModel(value = "rate", description = "Rate Ask and Bid values")
public class RateDTO {

    @ApiModelProperty(name = "askValue", dataType = "BigDecimal", value = "Ask Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 1)
    @PositiveOrZero
    private BigDecimal askValue;

    @ApiModelProperty(name = "bidValue", dataType = "BigDecimal", value = "Bid Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 2)
    @PositiveOrZero
    private BigDecimal bidValue;

    public static RateDTO of(final ExchangeRate exchangeRate) {
        return of(exchangeRate.askValue(), exchangeRate.bidValue());
    }

    public ExchangeRate toModel() {
        return ExchangeRate.of(this.askValue, this.bidValue);
    }

    public static RateDTO zero() {
        return of(RateValue.ZERO, RateValue.ZERO);
    }
}
