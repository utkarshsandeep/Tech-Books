//@formatter:off
@TypeDefs({
//	@TypeDef(
//		name = TYPE_DEF_JADIRA_MONEY, 
//		defaultForType = Money.class, 
//		typeClass = org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency.class
//	),
	@TypeDef(
		name = TYPE_DEF_JADIRA_MONEY_CURRENCY_UNIT, 
		defaultForType = CurrencyUnit.class, 
		typeClass = org.jadira.usertype.moneyandcurrency.moneta.PersistentCurrencyUnit.class
	),
    @TypeDef(
    	name = TYPE_DEF_JADIRA_DURATION, 
        defaultForType = Duration.class,
        typeClass = org.jadira.usertype.dateandtime.threeten.PersistentDurationAsString.class
    ),
    @TypeDef(
    	name = TYPE_DEF_JADIRA_PERIOD, 
        defaultForType = Period.class,
        typeClass = org.jadira.usertype.dateandtime.threeten.PersistentPeriodAsString.class
    )
})
//@formatter:on

package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import static com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.PersistenceConstant.Hibernate.*;

import java.time.Duration;
import java.time.Period;

import javax.money.CurrencyUnit;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
