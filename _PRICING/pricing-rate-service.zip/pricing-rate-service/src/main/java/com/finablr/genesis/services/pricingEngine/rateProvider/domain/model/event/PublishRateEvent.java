package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.RateDTO;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@ToString
public class PublishRateEvent {

    private String rateId;

    private RateDTO rate;

    public static PublishRateEvent of(final String rateId, final ExchangeRate exchangeRate) {
        PublishRateEvent providedRate = new PublishRateEvent();
        providedRate.rateId = rateId;
        providedRate.rate = RateDTO.of(exchangeRate);
        return providedRate;
    }

    public static PublishRateEvent of(final String rateId, final RateDTO rate) {
        PublishRateEvent providedRate = new PublishRateEvent();
        providedRate.rateId = rateId;
        providedRate.rate = rate;
        return providedRate;
    }
}
