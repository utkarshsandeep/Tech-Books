package com.finablr.genesis.services.pricingEngine.rateProvider;

import javax.annotation.PreDestroy;

import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler.SchedulerService;
import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr.TnRClient;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.service.PricingRateService;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.service.RateProcessor;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ApplicationLifecycleHooks implements ApplicationRunner {

    @Lazy
    @Autowired
    private SchedulerService schedulerService;

    @Lazy
    @Autowired
    private TnRClient tnrClient;

    @Autowired
    private PricingRateService pricingRateService;

    @Autowired
    private RateProcessor rateProcessor;

    @Override
    public void run(final ApplicationArguments args) throws Exception {
        startUp();
    }

    public void startUp() {
        log.info(">>>>>>>>>>>>>>>>>> Application startup hook starts >>>>>>>>>>>>>>>>>>");

        this.rateProcessor.initialize();

        if (SpringProfiles.isTnREnabled()) {
            this.tnrClient.initializeTnRStreams();
            log.info("All TnR streams intialized ......");
        }
        else {
            log.info("Thomson is disabled, so cleaning up THOMSON_STREAMS table");
            this.pricingRateService.cleanTnRStreamsTable();
        }
        if (SpringProfiles.isQuartzEnabled()) {
            try {
                this.schedulerService.startScheduler();
                log.info("Staring scheduler, and then validating Quartz Schedules.......");
                // this.schedulerService.startScheduler(30);
                // log.info("Staring scheduler in 30 seconds, Then will validate Quartz Schedules.......");
                this.schedulerService.validateScheduledJobs();
            }
            catch (final SchedulerException e) {
                log.error("Could not start scheduler ", e);
                log.info(
                        "Abnormally terminating application !!!!!, hence it would be automatically restarted by OpenShift ?????");
                System.exit(1);
            }
        }
        else {
            log.info("As Quartz is disabled, so Scheduler is not started");
        }
        log.info(">>>>>>>>>>>>>>>>>> Application startup hook ends... >>>>>>>>>>>>>>>>>>");
    }

    @PreDestroy
    public void shutDown() {
        log.info("<<<<<<<<<<<<<<<<<< Application shutdown hook starts <<<<<<<<<<<<<<<<<");

        log.info("<<<<<<<<<<<<<<<<<< Application shutdown hook ends... <<<<<<<<<<<<<<<<<");
    }
}
