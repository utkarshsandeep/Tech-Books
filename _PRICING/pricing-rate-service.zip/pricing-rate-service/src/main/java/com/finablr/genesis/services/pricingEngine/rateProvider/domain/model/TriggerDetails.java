package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.Date;

import org.quartz.Trigger;
import org.quartz.Trigger.TriggerState;

import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler.AbstractSchedulerService;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of", access = AccessLevel.PRIVATE)
public class TriggerDetails {

    private ZonedDateTime fireTime;

    private ZonedDateTime nextFireTime;

    private Frequency repeatInterval;

    private TriggerState triggerState;

    public static TriggerDetails of(final Trigger trigger, final TriggerState triggerState) {
        Date fireDate = trigger.getPreviousFireTime();
        Date nextFireDate = trigger.getNextFireTime();
        ZonedDateTime fireTime = fireDate == null ? null
                : fireDate.toInstant().atZone(ApplicationConstants.ZONE_ID_UTC);
        ZonedDateTime nextFireTime = nextFireDate == null ? null
                : nextFireDate.toInstant().atZone(ApplicationConstants.ZONE_ID_UTC);
        Duration repeatInterval = AbstractSchedulerService.getJobFrequency(trigger);
        return of(fireTime, nextFireTime, repeatInterval == null ? null : Frequency.ofSchedule(repeatInterval),
                triggerState);
    }
}
