package com.finablr.genesis.services.pricingEngine.rateProvider.domain.service;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.zalando.problem.Status;

import com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository.PricingRateRepository;
import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler.SchedulerService;
import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr.TnRClient;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException.RateProviderExceptionType;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateMetaData;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RicRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.FutureSourceRateRequest;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.PushRateRequest;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.RateDTO;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.RateChangeEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.FluxSink;

@Slf4j
@Service
@DependsOn("springProfiles")
public class PricingRateServiceImpl implements PricingRateService {

    @Autowired
    private PricingRateRepository pricingRateRepository;

    @Lazy
    @Autowired
    private SchedulerService schedulerService;

    @Lazy
    @Autowired
    private TnRClient tnrClient;

    @Autowired
    private FluxSink<RateChangeEvent> rateSink;

    @Override
    @Transactional
    public RateMetaData createProvidedRate(final RateMetaData providedRate) {
        return this.pricingRateRepository.save(providedRate);
    }

    // @Override
    // @Transactional
    // public Optional<ProvidedRate> getLatestProvidedRate(final int rateProviderId, final String rateId,
    // final String ricId) {
    //// return this.providedRateRepository.findLatestProvidedRate(rateProviderId, rateId, ricId);
    // return Optional.empty();
    // }

    @Transactional
    @Override
    public List<RicRate> createOrUpdateFutureSourceRates(final List<FutureSourceRateRequest> createRequests) {
        final List<RicRate> results = new ArrayList<>(createRequests.size());
        createRequests.stream().forEach(req -> {
            Optional<RicRate> ricRate = this.pricingRateRepository.findRicRateByRateKey(req.rateKey());
            if (ricRate.isPresent()) {
                ricRate.get().updateExchangeRate(req.exchangeRate());
                results.add(ricRate.get());
            }
            else {
                results.add((this.pricingRateRepository.saveRicRate(RicRate.of(req.rateKey(), req.exchangeRate()))));
            }
        });
        return results;
    }

    // @Transactional
    // @Override
    // public List<RicRate> createOrUpdateRicRates(final RateProvider rateProvider,
    // final List<PushRateRequest> pushRequests) {
    // final List<RicRate> results = new ArrayList<>(pushRequests.size());
    // pushRequests.stream().forEach(req -> {
    // Optional<RicRate> ricRate = this.pricingRateRepository.findRicRateByRateKey(req.rateKey(rateProvider));
    // if (ricRate.isPresent()) {
    // ricRate.get().updateExchangeRate(req.exchangeRate());
    // results.add(ricRate.get());
    // }
    // else {
    // results.add((this.pricingRateRepository
    // .saveRicRate(RicRate.of(req.rateKey(rateProvider), req.exchangeRate()))));
    // }
    // });
    // return results;
    // }

    @Override
    public void createOrUpdateRicRates(final RateProvider rateProvider, final List<PushRateRequest> pushRequests) {
        pushRequests.stream().map(req -> req.rateChangeEvent(rateProvider)).forEach(this.rateSink::next);
    }

    @Transactional
    @Override
    public RateDTO getProvidedRateByRateKey(final RateKey rateKey) {
        if (rateKey.rateProvider().isThomsonAndReuters()) {
            if (SpringProfiles.isTnREnabled()) {
                try {
                    return RateDTO.of(this.tnrClient.rateSnapshot(rateKey.ricId()).get(10, TimeUnit.SECONDS));
                }
                catch (final ExecutionException e) {
                    log.error("Exception while trying to get rate snapshot for ric ID: " + rateKey.ricId()
                            + " from Thomson & Reuters", e);
                    throw e.getCause() instanceof RateProviderException ? (RateProviderException) e.getCause()
                            : new RuntimeException(e.getCause());
                }
                catch (final InterruptedException | TimeoutException e) {
                    log.error("Exception while trying to get rate snapshot for ric ID: " + rateKey.ricId()
                            + " from Thomson & Reuters", e);
                    throw new RateProviderException(RateProviderExceptionType.TnR_STREAM_CONNECTION_FAILURE,
                            Status.REQUEST_TIMEOUT);
                }
            }
            else {
                throw new RateProviderException(RateProviderExceptionType.THOMSON_PROFILE_DISABLED,
                        Status.PRECONDITION_FAILED);
            }
        }
        else {
            return this.pricingRateRepository.findRicRateByRateKey(rateKey)
                    .map(providedRate -> RateDTO.of(providedRate.exchangeRate()))
                    .orElseThrow(() -> new RateProviderException(RateProviderExceptionType.RATE_NOT_FOUND,
                            Status.NOT_FOUND));
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public Optional<RateMetaData> getRateMetaDataById(final String rateId, final boolean writeLock) {
        return this.pricingRateRepository.findRateMetaDataById(rateId, writeLock);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void createRateMetaData(final RateMetaData rateMetaData) {
        this.pricingRateRepository.save(rateMetaData);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void deleteRateMetaData(final String rateId) {
        this.pricingRateRepository.deleteById(rateId);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public boolean updateRateMetaDataFrequency(final String rateId, final Duration frequency, final Boolean live) {
        RateMetaData rateMetaData = this.pricingRateRepository.findRateMetaDataById(rateId, true)
                .orElseThrow(() -> new RateProviderException(RateProviderExceptionType.RATE_META_DATA_NOT_FOUND,
                        Status.BAD_REQUEST, rateId));
        return rateMetaData.updateFrequency(frequency, live);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void cleanTnRStreamsTable() {
        this.pricingRateRepository.deleteAllTnRStreams();
    }
}
