package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import javax.money.CurrencyUnit;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.springframework.util.Assert;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
@org.hibernate.annotations.Immutable
public class CurrencyExchange {

    @JsonProperty
    @ApiModelProperty(name = "source", dataType = "String", value = "ISO Currency Code e.g. USD", allowEmptyValue = false, required = true, example = "INR", position = 1)
    @NotNull
    @Column(name = "SOURCE_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit source;

    @JsonProperty
    @ApiModelProperty(name = "target", dataType = "String", value = "ISO Currency Code e.g. USD", allowEmptyValue = false, required = true, example = "INR", position = 2)
    @NotNull
    @Column(name = "TARGET_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit target;

    @Transient
    private static final String SEPERATOR = "/";

    public static CurrencyExchange of(final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency) {
        Assert.notNull(sourceCurrency, "sourceCurrency must not be null!");
        Assert.notNull(targetCurrency, "targetCurrency must not be null!");
        CurrencyExchange currencyExchange = new CurrencyExchange();
        currencyExchange.source = sourceCurrency;
        currencyExchange.target = targetCurrency;
        return currencyExchange;
    }

    @JsonProperty
    @ApiModelProperty(name = "ccy", dataType = "String", value = "Currency pair", allowEmptyValue = false, required = true, example = "INR", position = 3)
    public String ccy() {
        return ccy(SEPERATOR);
    }
    
    public String ccy(final String seperator) {
        return this.source.getCurrencyCode() + seperator + this.target.getCurrencyCode();
    }

    @JsonIgnore
    public boolean isContaining(final CurrencyUnit currency) {
        return this.source == currency || this.target == currency;
    }
}
