package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.StreamState;
import com.thomsonreuters.ema.access.OmmState;
import com.thomsonreuters.ema.access.OmmState.StatusCode;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@ToString
public class StreamStatusEvent {

    private String ricId;

    private boolean established;

    private long streamId;

    private StreamState state;

    private String description;

    public static StreamStatusEvent of(final String ricId, final long streamId, final OmmState ommState) {
        StreamState streamStatus = null;
        if (ommState.statusCode() == StatusCode.NOT_FOUND) {
            streamStatus = StreamState.INVALID_RIC;
        }
        else {
            streamStatus = StreamState.of(ommState.streamState());
        }

        StreamStatusEvent streamStatusEvent = new StreamStatusEvent();
        streamStatusEvent.ricId = ricId;
        streamStatusEvent.established = streamStatus.isOpen();
        streamStatusEvent.streamId = streamId;
        streamStatusEvent.state = streamStatus;
        streamStatusEvent.description = ommState.toString();
        return streamStatusEvent;
    }

    public boolean isOpen() {
        return this.established;
    }

    public boolean isClosed() {
        return !isOpen();
    }

    public boolean isRicIdInvalid() {
        return this.description.contains("Not found");
    }
}
