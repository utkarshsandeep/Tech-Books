package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto;

import java.math.BigDecimal;

import javax.money.CurrencyUnit;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "futureSourceRateRequest", description = "Request to create Exchange rates by Rate providers (Future Source)")
public class FutureSourceRateRequest {

    @NotNull
    @ApiModelProperty(name = "symbol", dataType = "String", value = "FIC (Future source Identifier) ID", allowEmptyValue = false, required = true, example = "USD=")
    private String symbol;
	
    @NotNull
    @ApiModelProperty(name = "currency", dataType = "String", value = "ISO Currency Code e.g. USD", allowEmptyValue = false, required = true, example = "INR")
    private CurrencyUnit currency;
    
    @ApiModelProperty(name = "askValue", dataType = "BigDecimal", value = "Ask Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 1)
    @Positive
    private BigDecimal askValue;

    @ApiModelProperty(name = "bidValue", dataType = "BigDecimal", value = "Bid Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 2)
    @Positive
    private BigDecimal bidValue;

	public ExchangeRate exchangeRate() {
		return ExchangeRate.of(askValue, bidValue);
	}
	
	public RateKey rateKey() {
	    return RateKey.ofFutureSource(this.symbol);
	}
}
