package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event;

import java.time.Duration;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class PricingRateFrequencyChangedEvent {

    private String rateId;

    private Duration frequency;

    private Boolean live;

    @JsonCreator
    public static PricingRateFrequencyChangedEvent of(final @JsonProperty("rateId") String rateId,
            final @JsonProperty("frequency") String frequency, final @JsonProperty("live") Boolean live) {
        
        PricingRateFrequencyChangedEvent providedRateFrequencyChangeEvent = new PricingRateFrequencyChangedEvent();
        providedRateFrequencyChangeEvent.rateId = rateId;
        providedRateFrequencyChangeEvent.frequency = Duration.parse(frequency);
        providedRateFrequencyChangeEvent.live = live;

        return providedRateFrequencyChangeEvent;
    }

    public static PricingRateFrequencyChangedEvent of(final String rateId, final Duration frequency,
            final Boolean live) {
        
        PricingRateFrequencyChangedEvent providedRateFrequencyChangeEvent = new PricingRateFrequencyChangedEvent();
        providedRateFrequencyChangeEvent.rateId = rateId;
        providedRateFrequencyChangeEvent.frequency = frequency;
        providedRateFrequencyChangeEvent.live = live;

        return providedRateFrequencyChangeEvent;
    }
}
