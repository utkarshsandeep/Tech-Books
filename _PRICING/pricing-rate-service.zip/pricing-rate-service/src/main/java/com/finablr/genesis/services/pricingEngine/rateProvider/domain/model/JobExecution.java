package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.quartz.Trigger.TriggerState;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard.PublishedRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PublishRateEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.BeanFactory;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@RequiredArgsConstructor(staticName = "fire")
@ToString
public class JobExecution {

    @JsonIgnore
    private final String rateId;

    @JsonIgnore
    private final RateKey rateKey;

    @JsonIgnore
    private final String fireInstanceId;

    @JsonProperty
    @Getter(value = AccessLevel.NONE)
    private final ZonedDateTime fireTime;

    @JsonProperty
    @Getter(value = AccessLevel.NONE)
    private final ZonedDateTime nextFireTime;

    @Getter(value = AccessLevel.NONE)
    private boolean isPublished = false;

    @JsonInclude(NON_NULL)
    @JsonProperty
    private Frequency repeatInterval;

    @JsonInclude(NON_NULL)
    @JsonProperty
    private JobState jobState;

    @JsonInclude(NON_NULL)
    @JsonProperty
    private PublishedRate publishedRate;

    @JsonIgnore
    @Getter(value = AccessLevel.NONE)
    private ZoneId zoneId;

    public static JobExecution of(final ZonedDateTime fireTime, final ZonedDateTime nextFireTime,
            final Frequency repeatInterval, final TriggerState triggerState, final ZonedDateTime publishedOn,
            final ExchangeRate publishedRate) {
        JobExecution jobExecution = fire(null, null, null, fireTime, nextFireTime);
        jobExecution.isPublished = publishedOn != null && fireTime != null && fireTime.equals(publishedOn) ? true
                : false;
        jobExecution.repeatInterval = repeatInterval;
        jobExecution.jobState = triggerState == TriggerState.ERROR ? JobState.ERROR
                : jobExecution.isPublished ? JobState.SUCCESS : JobState.MISFIRED;
        jobExecution.publishedRate = PublishedRate.of(publishedRate, publishedOn);
        return jobExecution;
    }

    public JobExecution publish(final ExchangeRate publishedRate) {
        this.isPublished = true;
        this.jobState = JobState.SUCCESS;
        this.publishedRate = PublishedRate.of(publishedRate, this.fireTime);
        return this;
    }

    public JobExecution misfire() {
        this.isPublished = false;
        this.jobState = JobState.MISFIRED;
        return this;
    }

    public PublishRateEvent publishRateEvent() {
        return PublishRateEvent.of(this.rateId, this.publishedRate.rate());
    }

    public String getFireTime() {
        return this.fireTime != null ? DateTimeHelper.convertAndFormatZonedDateTime(this.fireTime, this.zoneId,
                BeanFactory.applicationProperties().getDashboardDatetimeFormat()) : null;
    }

    public String getNextFireTime() {
        return this.nextFireTime != null ? DateTimeHelper.convertAndFormatZonedDateTime(this.nextFireTime, this.zoneId,
                BeanFactory.applicationProperties().getDashboardDatetimeFormat()) : null;
    }

    public boolean isPublished() {
        return this.isPublished;
    }

    public JobExecution conclude(final ZoneId zoneId) {
        this.zoneId = zoneId;
        if (this.publishedRate != null) {
            this.publishedRate.conclude(this.zoneId);
        }
        return this;
    }

    private static enum JobState {

        // @formatter:off  
        ERROR("Trigger is in error state, would not run anymore unless fixed"), 
        MISFIRED("Schedule executed successfully, but rate is not updated since last publication"), 
        SUCCESS("Rate published to Pricing Engine successfully");
        // @formatter:on

        private final String description;

        private JobState(final String description) {
            this.description = description;
        }

        @JsonValue
        private Pair<String, String> pair() {
            return ImmutablePair.of(this.name(), this.description);
        }
    }
}
