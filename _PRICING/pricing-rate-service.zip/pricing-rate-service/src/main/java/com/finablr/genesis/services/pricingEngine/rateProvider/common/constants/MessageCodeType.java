package com.finablr.genesis.services.pricingEngine.rateProvider.common.constants;

public interface MessageCodeType {

    public String key();

    public String defaultMessage();
}
