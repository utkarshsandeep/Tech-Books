package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard;

import org.springframework.boot.actuate.health.Health;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public class InfraHealth {

    private Health databaseHealth;

    private Health activeMQHealth;

    private Health elektronHealth;
}
