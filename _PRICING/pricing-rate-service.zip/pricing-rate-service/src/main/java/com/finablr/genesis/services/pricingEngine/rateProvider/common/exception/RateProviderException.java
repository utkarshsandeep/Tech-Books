package com.finablr.genesis.services.pricingEngine.rateProvider.common.exception;

import org.zalando.problem.Status;

public class RateProviderException extends PricingEngineException {

    private static final long serialVersionUID = 1L;

    private ErrorCodeType exceptionType;

    public enum RateProviderExceptionType implements ErrorCodeType {

        //@formatter:off
		RATE_PROVIDER_NOT_FOUND("rate.provider.not.found", RATE_PROVIDER_EXCEPTION_TITLE),
        INVALID_ASK_BID_VALUE("rate.invalid.ask.bid.value", RATE_PROVIDER_EXCEPTION_TITLE),
        TnR_STREAM_CONNECTION_FAILURE("tnr.stream.connection.failure", RATE_PROVIDER_EXCEPTION_TITLE),
        THOMSON_PROFILE_DISABLED("thomson.profile.disabled", RATE_PROVIDER_EXCEPTION_TITLE),
        INVALID_RATE_PROVIDER_ID("invalid.rate.provider.id", RATE_PROVIDER_EXCEPTION_TITLE),
        RATE_META_DATA_NOT_FOUND("rate.meta.data.not.found", RATE_PROVIDER_EXCEPTION_TITLE),
        RATE_NOT_FOUND("rate.not.found", RATE_PROVIDER_EXCEPTION_TITLE),
        INVALID_RIC_ID("invalid.ric.id", RATE_PROVIDER_EXCEPTION_TITLE),
        OMM_CONSUMER_INITIALIZATION_FAILED("omm.consumer.initialization.failed", RATE_PROVIDER_EXCEPTION_TITLE),
        OMM_CONSUMER_INITIALIZATION_ALREADY_IN_PROCESS("omm.consumer.initialization.already.in.process", RATE_PROVIDER_EXCEPTION_TITLE);
		//@formatter:on

        private final String errorCode;

        private final String title;

        private RateProviderExceptionType(final String errorCode, final String title) {
            this.errorCode = errorCode;
            this.title = title;
        }

        private RateProviderExceptionType(final String errorCode) {
            this.errorCode = errorCode;
            this.title = RATE_PROVIDER_EXCEPTION_TITLE;
        }

        @Override
        public String errorCode() {
            return this.errorCode;
        }

        @Override
        public String title() {
            return this.title;
        }
    }

    public RateProviderException(RateProviderExceptionType exceptionType, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), parameters);
        setExceptionType(exceptionType);
    }

    public RateProviderException(RateProviderExceptionType exceptionType, Status status, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), status, parameters);
        setExceptionType(exceptionType);
    }

    public RateProviderException(RateProviderExceptionType exceptionType, Status status, final Exception cause,
            Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), cause, status, parameters);
        setExceptionType(exceptionType);
    }

    private void setExceptionType(RateProviderExceptionType exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Override
    public ErrorCodeType exceptionType() {
        return this.exceptionType;
    }
}
