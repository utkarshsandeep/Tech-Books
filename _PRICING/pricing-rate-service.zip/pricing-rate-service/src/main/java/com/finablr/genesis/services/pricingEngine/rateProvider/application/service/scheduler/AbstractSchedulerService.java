package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler;

import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.QUARTZ_JOB_DETAILS_FREQUENCY_KEY;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.RATE_PUBLICATION_JOB_GROUP_ID;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.SIMPLE_TRIGGER_GROUP_ID;

import java.time.Duration;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.Trigger.TriggerState;
import org.quartz.TriggerKey;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TriggerDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractSchedulerService implements SchedulerService {

    protected Scheduler scheduler;

    protected static JdbcTemplate jdbcTemplate;

    protected AbstractSchedulerService(final Scheduler scheduler, final DataSource datasource) {
        this.scheduler = scheduler;
        AbstractSchedulerService.jdbcTemplate = new JdbcTemplate(datasource);
    }

    @Override
    public Optional<Trigger> checkIfJobExists(final String rateId) throws SchedulerException {
        return this.scheduler.checkExists(JobKey.jobKey(rateId, RATE_PUBLICATION_JOB_GROUP_ID))
                ? Optional.of(this.scheduler.getTrigger(TriggerKey.triggerKey(rateId, SIMPLE_TRIGGER_GROUP_ID)))
                : Optional.empty();
    }

    protected final boolean scheduleJob(Class<? extends QuartzJobBean> jobClass, String jobGroup, String jobName,
            JobDataMap jobDataMap, long frequency) throws SchedulerException {

        JobDetail jobDetail = JobBuilder.newJob(jobClass).withIdentity(jobName, jobGroup)
                .withDescription("Rate Publication Job").usingJobData(jobDataMap).storeDurably().build();

        if (!this.scheduler.checkExists(jobDetail.getKey())) {
            Trigger trigger = AbstractSchedulerService.createSimpleTrigger(jobName, new Date(), frequency,
                    SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);

            this.scheduler.scheduleJob(jobDetail, trigger);
            log.info("Job with name: {} and group: {} scheduled with frequency: {}", jobName, jobGroup,
                    Duration.ofMillis(frequency));
            return true;
        }
        else {
            log.info("Job with name: {} and group: {} already exists", jobName, jobGroup);
            return false;
        }
    }

    protected final void reScheduleJob(final String jobGroup, final String jobName, final long newFrequency)
            throws SchedulerException {
        Trigger newTrigger = AbstractSchedulerService.createSimpleTrigger(jobName, new Date(), newFrequency,
                SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);

        JobDetail newJobDetail = this.scheduler.getJobDetail(JobKey.jobKey(jobName, jobGroup));
        newJobDetail.getJobDataMap().put(QUARTZ_JOB_DETAILS_FREQUENCY_KEY, newFrequency);
        // scheduler.addJob(newJobDetail, true);

        Date firstFireTime = this.scheduler.rescheduleJob(TriggerKey.triggerKey(jobName, SIMPLE_TRIGGER_GROUP_ID),
                newTrigger);
        if (firstFireTime != null) {
            log.info("Job with name: {} and group: {} rescheduled with first fire time: {}", jobName, jobGroup,
                    firstFireTime);
        }
        else {
            log.info(
                    "Could not re-schedule the Job with name: {} and group: {}, as no trigger associated with it found",
                    jobName, jobGroup);
        }
    }

    protected final boolean deleteJob(final String jobGroup, final String jobName) throws SchedulerException {
        boolean deleted = this.scheduler.deleteJob(JobKey.jobKey(jobName, jobGroup));
        if (deleted) {
            log.info("Job with name: {} and group: {} deleted successfully", jobName, jobGroup);
        }
        else {
            log.info("Job with name: {} and group: {} could not be deleted, may be no trigger associated with it found",
                    jobName, jobGroup);
        }
        return deleted;
    }

    @Override
    public void validateTriggerStates() {
        Set<Trigger> allTriggers = new HashSet<>(200);
        try {
            for (JobKey jobKey : this.scheduler
                    .getJobKeys(GroupMatcher.jobGroupEquals(RATE_PUBLICATION_JOB_GROUP_ID))) {
                allTriggers.addAll(this.scheduler.getTriggersOfJob(jobKey));
            }
            // log.info("All Triggers --->>" + allTriggers);

            allTriggers.forEach(trigger -> {
                try {
                    if (this.scheduler.getTriggerState(trigger.getKey()) == TriggerState.ERROR) {
                        log.info("Trigger with Key: {} is in ERROR State, so recovering", trigger.getKey());
                        this.scheduler.resetTriggerFromErrorState(trigger.getKey());
                    }
                }
                catch (SchedulerException se) {
                    log.error("Exception while validating and fixing ERROR trigger STATE", se);
                }
            });
        }
        catch (SchedulerException e) {
            log.error("Exception while validating and fixing ERROR trigger STATE", e);
        }
    }

    public static SimpleTrigger createSimpleTrigger(String triggerName, Date startTime, long repeatTime,
            int misFireInstruction) {
        SimpleTriggerFactoryBean factoryBean = new SimpleTriggerFactoryBean();
        factoryBean.setName(triggerName);
        factoryBean.setGroup(SIMPLE_TRIGGER_GROUP_ID);
        factoryBean.setStartTime(startTime);
        factoryBean.setRepeatInterval(repeatTime);
        factoryBean.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
        factoryBean.setMisfireInstruction(misFireInstruction);
        factoryBean.afterPropertiesSet();
        return factoryBean.getObject();
    }

    public static Duration getJobFrequency(final Trigger trigger) {
        String query = "select REPEAT_INTERVAL from QRTZ_SIMPLE_TRIGGERS where TRIGGER_NAME = '"
                + trigger.getKey().getName() + "'";
        try {
            Long repeateInterval = jdbcTemplate.queryForObject(query, Long.class);
            return Duration.ofMillis(repeateInterval);
        }
        catch (Exception e) {
            log.error("Exception while getting repeate interval of Trigger: {}", trigger, e);
            return null;
        }
        // if (trigger.getPreviousFireTime() != null && trigger.getNextFireTime() != null) {
        // Instant lastFireTime = trigger.getPreviousFireTime().toInstant();
        // Instant nextFireTime = trigger.getNextFireTime().toInstant();
        // return Duration.between(lastFireTime, nextFireTime);
        // }
        // else {
        // return Duration.ofMillis(trigger.getJobDataMap().getLong(QUARTZ_JOB_DETAILS_FREQUENCY_KEY));
        // }
    }

    @Override
    public Optional<Trigger> getTrigger(final String triggerName) {
        try {
            return Optional.of(this.scheduler.getTrigger(TriggerKey.triggerKey(triggerName, SIMPLE_TRIGGER_GROUP_ID)));
        }
        catch (SchedulerException e) {
            log.error("Error while getting trigger for name: " + triggerName, e);
            return Optional.empty();
        }
    }

    @Override
    public Optional<TriggerState> getTriggerState(final Trigger trigger) {
        try {
            return Optional.of(this.scheduler.getTriggerState(trigger.getKey()));
        }
        catch (final SchedulerException e) {
            log.error("Error while getting trigger state for trigger: " + trigger, e);
            return Optional.empty();
        }
    }

    @Override
    public Set<Trigger> getAllTriggers() {
        try {
            return this.scheduler.getJobKeys(GroupMatcher.jobGroupEquals(RATE_PUBLICATION_JOB_GROUP_ID)).stream()
                    .map(t -> {
                        try {
                            return this.scheduler.getTriggersOfJob(t);
                        }
                        catch (final SchedulerException e) {
                            log.error("Error while getting all triggers", e);
                            return Collections.<Trigger> emptyList();
                        }
                    }).flatMap(x -> x.stream()).collect(Collectors.toSet());
        }
        catch (final SchedulerException e) {
            log.error("Error while getting all triggers", e);
        }
        return Collections.emptySet();
    }

    @Override
    public Map<String, TriggerDetails> getAllTriggerDetails() {
        return this.getAllTriggers().stream()
                .map(trigger -> ImmutablePair.of(trigger.getKey().getName(),
                        TriggerDetails.of(trigger, this.getTriggerState(trigger).orElse(null))))
                .collect(Collectors.toMap(Pair::getKey, Pair::getValue));
    }
}
