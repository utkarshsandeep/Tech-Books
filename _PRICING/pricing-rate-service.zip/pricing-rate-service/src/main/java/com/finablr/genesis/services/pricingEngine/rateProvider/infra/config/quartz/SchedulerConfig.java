package com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.quartz;

import java.util.Properties;
import java.util.concurrent.Executor;

import javax.sql.DataSource;

import org.quartz.Scheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.quartz.QuartzProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.annotation.spring.Quartz;

import lombok.extern.slf4j.Slf4j;

@Quartz
@Slf4j
@Configuration
@DependsOn("springProfiles")
public class SchedulerConfig {

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private DataSource dataSource;

    @Autowired
    private QuartzProperties quartzProperties;

    @Autowired
    private Executor taskExecutor;

    @Bean
    public SchedulerFactoryBean schedulerFactoryBean() {
        log.info("Starting to initialize SchedulerFactoryBean ...");
        AutoWiringSpringBeanJobFactory jobFactory = new AutoWiringSpringBeanJobFactory();
        jobFactory.setApplicationContext(this.applicationContext);

        Properties properties = new Properties();
        properties.putAll(this.quartzProperties.getProperties());

        SchedulerFactoryBean factory = new SchedulerFactoryBean();
        factory.setOverwriteExistingJobs(true);
        factory.setDataSource(this.dataSource);
        factory.setTaskExecutor(this.taskExecutor);
        factory.setJobFactory(jobFactory);
        factory.setQuartzProperties(properties);
        factory.setAutoStartup(false);

        return factory;
    }

    @Bean
    public Scheduler scheduler() {
        return schedulerFactoryBean().getScheduler();
    }
}