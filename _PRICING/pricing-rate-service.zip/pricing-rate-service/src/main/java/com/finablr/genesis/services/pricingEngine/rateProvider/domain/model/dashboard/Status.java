package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;

import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class Status<T> {

    @ApiModelProperty(name = "state", value = "State of respective resource", required = true, example = "", position = 1)
    private final T state;

    @Getter(value = AccessLevel.NONE)
    @ApiModelProperty(name = "updatedOn", value = "Last updated on timestamp", required = true, example = "", position = 2)
    private final ZonedDateTime updatedOn;

    @JsonIgnore
    @Getter(value = AccessLevel.NONE)
    private ZoneId zoneId;

    public static <T> Status<T> of(final T state, final ZonedDateTime updatedOn) {
        return new Status<T>(state, updatedOn);
    }

    public Status<T> conclude(final ZoneId zoneId) {
        this.zoneId = zoneId;
        return this;
    }

    public String getUpdatedOn() {
        return this.updatedOn != null ? DateTimeHelper.convertAndFormatZonedDateTime(this.updatedOn, this.zoneId)
                : null;
    }
}
