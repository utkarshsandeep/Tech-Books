package com.finablr.genesis.services.pricingEngine.rateProvider.common.constants;

public interface ApplicationDefaults {

    public int DEFAULT_PAGE_SIZE = 12;

    public String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";

    public String DEFAULT_DATE_TIME_FORMAT = "yyyy-MM-dd hh:mm a";

    public String DEFAULT_ZONED_DATE_TIME_FORMAT = "yyyy-MM-dd hh:mm:ssa (O)";

    public String DASHBOARD_DATE_TIME_FORMAT = "EEE HH:mm:ss.SSS";

    public int DOWNLOAD_CHUNK_SIZE = 100;

    interface Swagger {

        String title = "Application API";

        String description = "API documentation";

        String version = "0.0.1";

        String termsOfServiceUrl = null;

        String contactName = null;

        String contactUrl = null;

        String contactEmail = null;

        String license = null;

        String licenseUrl = null;

        String defaultIncludePattern = "/api/.*";

        String host = null;

        String[] protocols = {};

        boolean useDefaultResponseMessages = true;
    }

    interface Async {
        int corePoolSize = 20;

        int maxPoolSize = 50;

        int queueCapacity = 10000;
    }
}
