package com.finablr.genesis.services.pricingEngine.rateProvider.common.constants;

public interface RestConstants {

    public static String CURIE_NAMESPACE = "rate-provider";

    public static final String SLASH = "/";

    public static final String DOCS_DIR = SLASH + "docs";

    public static final String API = SLASH + "api";

    public static final String VERSION_v1 = "v1";

    public static final String VERSION_v2 = "v2";

    public static final String CURRENT_VERSION = VERSION_v1;

    public static final String PRICING_RATE_PROVIDER_API = API + SLASH + CURRENT_VERSION;

    public static final String PATH_VARIABLE_ID = "{id}";

    public static final String PROVIDED_RATES_URI = SLASH + "providedRates";

    public static final String FUTURE_SOURCE_RATE_URI = SLASH + "futureSource" + SLASH + "rates";

    public static final String PUSH_RATE_URI = SLASH + "rates";

    public static final String CURRENCIES_URI = SLASH + "currencies";

    public static final String RATE_PROVIDERS_URI = SLASH + "rateProviders";

    public static final String TIMEZONES_URI = SLASH + "timezones";

    public static final String DASHBOARD_URI = SLASH + "dashboard";

    public static final String INFRA_URI = SLASH + "infra";

    public static final String DB_HEALTH_CHECK_URI = INFRA_URI + SLASH + "database";

    public static final String JMS_HEALTH_CHECK_URI = INFRA_URI + SLASH + "jms";

    public static final String ELEKTRON_HEALTH_CHECK_URI = INFRA_URI + SLASH + "elektron";
}
