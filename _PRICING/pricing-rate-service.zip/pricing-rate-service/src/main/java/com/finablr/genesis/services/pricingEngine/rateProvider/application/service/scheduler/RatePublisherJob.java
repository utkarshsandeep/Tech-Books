package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler;

import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.QUARTZ_JOB_DETAILS_RATE_PROVIDER_NAME;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants.QUARTZ_JOB_DETAILS_RIC_ID_KEY;

import java.time.ZonedDateTime;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.annotation.spring.Quartz;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.JobExecution;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;

import reactor.core.publisher.FluxSink;

@Quartz
@Component
public class RatePublisherJob extends QuartzJobBean {

    @Autowired
    private FluxSink<JobExecution> scheduleSink;

    @Override
    protected void executeInternal(final JobExecutionContext jobExecutionContext) throws JobExecutionException {
        JobDataMap jobDataMap = jobExecutionContext.getMergedJobDataMap();
        String rateId = jobExecutionContext.getTrigger().getKey().getName();
        String ricId = jobDataMap.getString(QUARTZ_JOB_DETAILS_RIC_ID_KEY);
        // long frequency = jobDataMap.getLong(QUARTZ_JOB_DETAILS_FREQUENCY_KEY);
        String rateProviderName = jobDataMap.getString(QUARTZ_JOB_DETAILS_RATE_PROVIDER_NAME);
        String fireInstanceId = jobExecutionContext.getFireInstanceId();
        ZonedDateTime fireTime = jobExecutionContext.getFireTime().toInstant().atZone(ApplicationConstants.ZONE_ID_UTC);
        ZonedDateTime nextFireTime = jobExecutionContext.getNextFireTime().toInstant()
                .atZone(ApplicationConstants.ZONE_ID_UTC);

        this.scheduleSink.next(JobExecution.fire(rateId, RateKey.of(RateProvider.byName(rateProviderName), ricId),
                fireInstanceId, fireTime, nextFireTime));
    }
}
