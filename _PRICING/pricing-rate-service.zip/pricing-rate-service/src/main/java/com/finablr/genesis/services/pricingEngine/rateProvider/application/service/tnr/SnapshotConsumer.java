package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr;

import static com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr.ElektronMessageUtil.decodeExchangeRate;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.zalando.problem.Status;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException.RateProviderExceptionType;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.StreamStatusEvent;
import com.thomsonreuters.ema.access.AckMsg;
import com.thomsonreuters.ema.access.GenericMsg;
import com.thomsonreuters.ema.access.Msg;
import com.thomsonreuters.ema.access.OmmConsumerClient;
import com.thomsonreuters.ema.access.OmmConsumerEvent;
import com.thomsonreuters.ema.access.RefreshMsg;
import com.thomsonreuters.ema.access.StatusMsg;
import com.thomsonreuters.ema.access.UpdateMsg;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor(staticName = "callback")
public class SnapshotConsumer implements OmmConsumerClient {

    private CompletableFuture<ExchangeRate> resultCallback;

    public void onSnapshotEvent(final StreamStatusEvent streamStatusEvent, final ExchangeRate rateSnapshot) {
        log.debug("streamStatusEvent --->>" + streamStatusEvent);
        log.debug("rateSnapshot --->>" + rateSnapshot);
        if (streamStatusEvent.isRicIdInvalid()) {
            this.resultCallback.completeExceptionally(
                    new RateProviderException(RateProviderExceptionType.INVALID_RIC_ID, Status.BAD_REQUEST));
        }
        else {
            this.resultCallback.complete(rateSnapshot);
        }
    }

    @Override
    public void onUpdateMsg(final UpdateMsg updateMsg, final OmmConsumerEvent consumerEvent) {
        log.info("onUpdateMsg --->> updateMsg: {} for consumerEvent: {}", updateMsg, consumerEvent);
    }

    @Override
    public void onStatusMsg(final StatusMsg statusMsg, final OmmConsumerEvent consumerEvent) {
        log.info("onStatusMsg ricId: {}, status: {} and statusCode: {}", statusMsg.name(), statusMsg.state(),
                statusMsg.state().dataState());

        this.onSnapshotEvent(StreamStatusEvent.of(statusMsg.name(), consumerEvent.handle(), statusMsg.state()), null);
    }

    @Override
    public void onRefreshMsg(final RefreshMsg refreshMsg, final OmmConsumerEvent consumerEvent) {
        log.info("onRefreshMsg ricId: {}, status: {}, statusCode: {} and payload: {}", refreshMsg.name(),
                refreshMsg.state(), refreshMsg.state().dataState(), refreshMsg.payload());

        Optional<ExchangeRate> exchangeRate = decodeExchangeRate(refreshMsg.payload());
        this.onSnapshotEvent(StreamStatusEvent.of(refreshMsg.name(), consumerEvent.handle(), refreshMsg.state()),
                exchangeRate.get());
    }

    @Override
    public final void onAllMsg(final Msg msg, final OmmConsumerEvent consumerEvent) {
        log.info("onAllMsg --->> msg: {} for consumerEvent: {}", msg, consumerEvent);
    }

    @Override
    public final void onAckMsg(final AckMsg ackMsg, final OmmConsumerEvent consumerEvent) {
        log.info("onAckMsg --->> ackMsg: {} for consumerEvent: {}", ackMsg, consumerEvent);
    }

    @Override
    public final void onGenericMsg(final GenericMsg genericMsg, final OmmConsumerEvent consumerEvent) {
        log.info("onAllMsg --->> genericMsg: {} for consumerEvent: {}", genericMsg, consumerEvent);
    }
}
