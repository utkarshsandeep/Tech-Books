package com.finablr.genesis.services.pricingEngine.rateProvider.infra.config;

import java.time.ZoneId;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.web.cors.CorsConfiguration;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationDefaults;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Properties specific to pricing-service.
 * <p>
 * Properties are configured in the application.yml file.
 */
@Setter
@Getter
@NoArgsConstructor
@ToString
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {

    private String defaultDateFormat = ApplicationDefaults.DEFAULT_DATE_FORMAT;

    private String defaultDatetimeFormat = ApplicationDefaults.DEFAULT_DATE_TIME_FORMAT;

    private String defaultZonedDatetimeFormat = ApplicationDefaults.DEFAULT_ZONED_DATE_TIME_FORMAT;

    private ZoneId displayZoneId = ApplicationConstants.ZONE_ID_UTC;

    private String dashboardDatetimeFormat = ApplicationDefaults.DASHBOARD_DATE_TIME_FORMAT;

    private List<ZoneId> supportedTimeZones = ApplicationConstants.SUPPORTED_TIME_ZONES;

    private final CorsConfiguration cors = new CorsConfiguration();

    private final Swagger swagger = new Swagger();

    private final Async async = new Async();

    private final Thomson thomson = new Thomson();

    private final JmsConfig jmsConfig = new JmsConfig();

    @Getter
    @Setter
    public static class Swagger {

        private String title = ApplicationDefaults.Swagger.title;

        private String description = ApplicationDefaults.Swagger.description;

        private String version = ApplicationDefaults.Swagger.version;

        private String termsOfServiceUrl = ApplicationDefaults.Swagger.termsOfServiceUrl;

        private String contactName = ApplicationDefaults.Swagger.contactName;

        private String contactUrl = ApplicationDefaults.Swagger.contactUrl;

        private String contactEmail = ApplicationDefaults.Swagger.contactEmail;

        private String license = ApplicationDefaults.Swagger.license;

        private String licenseUrl = ApplicationDefaults.Swagger.licenseUrl;

        private String defaultIncludePattern = ApplicationDefaults.Swagger.defaultIncludePattern;

        private String host = ApplicationDefaults.Swagger.host;

        private String[] protocols = ApplicationDefaults.Swagger.protocols;

        private boolean useDefaultResponseMessages = ApplicationDefaults.Swagger.useDefaultResponseMessages;
    }

    @Getter
    @Setter
    public static class Async {

        private int corePoolSize = ApplicationDefaults.Async.corePoolSize;

        private int maxPoolSize = ApplicationDefaults.Async.maxPoolSize;

        private int queueCapacity = ApplicationDefaults.Async.queueCapacity;
    }

    @Getter
    @Setter
    public static class Thomson {

        private String serverA;

        private String serverB;

        private String username;

        private String serviceName;

        private int rsslPort;

        private int sslPort;
    }

    @Getter
    @Setter
    public static class JmsConfig {

        private String brokerUrl;

        private String username;

        private String password;

        private long maxAttempts;

        private long interval;
    }
}
