package com.finablr.genesis.services.pricingEngine.rateProvider.application.health;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.jdbc.DataSourceHealthIndicator;
import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.Measurement;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;

@Component
public class DBHealthIndicator extends DataSourceHealthIndicator {

    @Autowired
    private MeterRegistry registry;

    private static final List<String> HIKARI_METRICS_PARAMETERS = Arrays.asList("idle", "pending", "active", "max",
            "min");

    public DBHealthIndicator(final DataSource dataSource) {
        super(dataSource);
    }

    protected void doHealthCheck(Health.Builder builder) throws Exception {
        super.doHealthCheck(builder);
        Long idle = null;
        Long pending = null;
        Long active = null;
        Long max = null;
        Long min = null;
        for (Meter meter : this.registry.getMeters()) {
            if (meter.getId().getName().startsWith("hikaricp.connections.")) {
                Iterator<Measurement> itr = meter.measure().iterator();
                while (itr.hasNext()) {
                    Measurement measurement = itr.next();
                    if (meter.getId().getName().endsWith(HIKARI_METRICS_PARAMETERS.get(0))) {
                        idle = Math.round(measurement.getValue());
                    }
                    else if (meter.getId().getName().endsWith(HIKARI_METRICS_PARAMETERS.get(1))) {
                        pending = Math.round(measurement.getValue());
                    }
                    else if (meter.getId().getName().endsWith(HIKARI_METRICS_PARAMETERS.get(2))) {
                        active = Math.round(measurement.getValue());
                    }
                    else if (meter.getId().getName().endsWith(HIKARI_METRICS_PARAMETERS.get(3))) {
                        max = Math.round(measurement.getValue());
                    }
                    else if (meter.getId().getName().endsWith(HIKARI_METRICS_PARAMETERS.get(4))) {
                        min = Math.round(measurement.getValue());
                    }
                }
            }
        }
        Map<String, Long> hikariDetails = new LinkedHashMap<>(5);
        hikariDetails.put(HIKARI_METRICS_PARAMETERS.get(2), active);
        hikariDetails.put(HIKARI_METRICS_PARAMETERS.get(1), pending);
        hikariDetails.put(HIKARI_METRICS_PARAMETERS.get(0), idle);
        hikariDetails.put(HIKARI_METRICS_PARAMETERS.get(4), min);
        hikariDetails.put(HIKARI_METRICS_PARAMETERS.get(3), max);
        builder.withDetail("hikari.connections", hikariDetails);
    }
}
