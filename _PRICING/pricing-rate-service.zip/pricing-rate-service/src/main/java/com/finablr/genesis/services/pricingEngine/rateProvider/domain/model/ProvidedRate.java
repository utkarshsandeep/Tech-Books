package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import java.time.Duration;
import java.time.ZonedDateTime;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;

import lombok.Getter;
import lombok.experimental.Accessors;
import reactor.core.publisher.Mono;

@Getter
@Accessors(chain = true, fluent = true)
public class ProvidedRate {

    private String rateId;

    private RateKey rateKey;

    private CurrencyExchange currency;

    private Duration frequency;

    private Boolean live;

    private ExchangeRate currentRate;

    private ZonedDateTime updatedOn;

    private ExchangeRate publishedRate;

    private ZonedDateTime publishedOn;

    public static ProvidedRate of(final RateMetaData rateMetaData) {
        ProvidedRate providedRate = new ProvidedRate();

        providedRate.rateId = rateMetaData.rateId();
        providedRate.rateKey = rateMetaData.rateKey();
        providedRate.currency = rateMetaData.currency();
        providedRate.frequency = rateMetaData.frequency();
        providedRate.live = rateMetaData.live();
        providedRate.publishedRate = rateMetaData.publishedRate();
        providedRate.publishedOn = rateMetaData.publishedOn();

        return providedRate;
    }

    public boolean updateFrequency(final Duration newFrequency, final Boolean live) {
        this.live = live;
        if (isFrequencySameAs(newFrequency)) {
            return false;
        }
        else {
            this.frequency = newFrequency;
            return true;
        }
    }

    public boolean isFrequencySameAs(final Duration other) {
        return this.frequency.compareTo(other) == 0;
    }

    public boolean updateRate(final ExchangeRate newExchangeRate) {
        return updateRate(newExchangeRate, DateTimeHelper.nowZonedDateTimeUTC());
    }

    public boolean updateRate(final ExchangeRate newExchangeRate, final ZonedDateTime updatedOn) {
        if (newExchangeRate.equals(this.currentRate)) {
            return false;
        }
        else {
            this.currentRate = newExchangeRate;
            ZonedDateTime now = DateTimeHelper.nowZonedDateTimeUTC();
            this.updatedOn = now;
            return true;
        }
    }

    public Mono<JobExecution> publishableRate(final JobExecution jobExecution) {
        if (isPublishable()) {
            return Mono.just(jobExecution.publish(this.currentRate));
        }
        else {
            return Mono.just(jobExecution.misfire());
        }
    }

    public void published(final JobExecution jobExecution) {
        this.publishedRate = jobExecution.getPublishedRate().exchangeRate();
        this.publishedOn = jobExecution.getPublishedRate().publishedOn();
    }

    private boolean isPublishable() {
        return this.currentRate != null && this.updatedOn != null
                && (this.publishedOn == null || (this.publishedOn != null && this.updatedOn.isAfter(this.publishedOn)));
    }

    public void revertPublishedOn(final ZonedDateTime lastPublishedOn) {
        this.publishedOn = lastPublishedOn;
    }

    public String ricId() {
        return this.rateKey.ricId();
    }
}
