package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import java.time.ZonedDateTime;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@Entity
@Table(name = "TNR_STREAMS")
@OptimisticLocking(type = OptimisticLockType.NONE)
public class TnRStream {

    @Id
    @Column(name = "RIC_ID", nullable = false, length = 10)
    @Access(AccessType.FIELD)
    private String ricId;

    @Version
    @Access(AccessType.FIELD)
    @Column(name = "version", nullable = false)
    private Long version;

    @Column(name = "STREAM_ID", nullable = false, length = 50)
    private long streamId;

    @Getter(value = AccessLevel.NONE)
    @NotNull
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "ENABLED", length = 1)
    private boolean enabled;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "STATE", nullable = false, length = 20)
    private StreamState state;

    @NotNull
    @Column(name = "DESCRIPTION", nullable = false, length = 255)
    private String description;

    @NotNull
    @Column(name = "CREATED_ON", columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    private ZonedDateTime createdOn;

    @NotNull
    @Column(name = "UPDATED_ON", columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    private ZonedDateTime updatedOn;

    public static TnRStream waiting(final String ricId) {
        return of(ricId, 0, false, StreamState.WAITING, StreamState.WAITING.description());
    }

    public static TnRStream of(final String ricId, final long streamId, final boolean enabled, final StreamState state,
            final String description) {
        TnRStream tnrStream = new TnRStream();
        tnrStream.ricId = ricId;
        tnrStream.streamId = streamId;
        tnrStream.enabled = enabled;
        tnrStream.state = state;
        tnrStream.description = description;
        tnrStream.createdOn = DateTimeHelper.nowZonedDateTimeUTC();
        tnrStream.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
        return tnrStream;
    }

    public void isEnabled() {
        this.enabled = false;
    }

    public void enable(final long streamId, final StreamState state, final String description) {
        this.enabled = true;
        this.streamId = streamId;
        this.state = state;
        this.description = description;
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public void disable(final StreamState state, final String description) {
        this.enabled = false;
        this.state = state;
        this.description = description;
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }
    
    public void closeToRecover() {
        this.enabled = false;
        this.state = StreamState.CLOSED_RECOVER;
        this.description = "Stream closed to recover";
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    @Override
    public String toString() {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("RIC ID: ").append(this.ricId).append(", Stream ID: ").append(this.streamId)
                .append(", " + (this.enabled ? "Enabled" : "Disabled")).append(", State: ").append(this.state)
                .append(", Description: ").append(this.description)
                .append(", Created On: " + DateTimeHelper.formatZonedDateTime(this.createdOn))
                .append(", Updated On: " + DateTimeHelper.formatZonedDateTime(this.updatedOn));
        return strBuilder.toString();
    }
}
