package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import java.io.Serializable;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode
@Embeddable
@ToString
public class RateKey implements Serializable, Comparable<RateKey> {

    private static final long serialVersionUID = 1L;

    @JsonProperty
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RATE_PROVIDER", nullable = false)
    private RateProvider rateProvider;

    @JsonProperty
    @ApiModelProperty(name = "ricId", dataType = "String", value = "Ric Id e.g. USD=, INR=", allowEmptyValue = false, required = true, example = "INR=", position = 1)
    @NotNull
    @Column(name = "RIC_ID", nullable = true, updatable = false, length = 10)
    private String ricId;

    public static RateKey ofThomsonAndReuters(final String ricId) {
        return of(RateProvider.THOMSON_AND_REUTERS, ricId);
    }

    public static RateKey ofFutureSource(final String ricId) {
        return RateKey.of(RateProvider.FUTURE_SOURCE, ricId);
    }

    @Override
    public int compareTo(RateKey o) {
        return Comparator.comparing(RateKey::rateProvider).thenComparing(RateKey::ricId).compare(this, o);
    }
}
