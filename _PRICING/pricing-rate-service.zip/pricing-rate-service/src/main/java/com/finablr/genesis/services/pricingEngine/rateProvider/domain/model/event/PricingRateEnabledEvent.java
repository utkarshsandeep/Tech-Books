package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event;

import java.time.Duration;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.CurrencyExchange;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.CurrencyDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@ToString
public class PricingRateEnabledEvent {

    private String rateId;

    private RateKey rateKey;

    private CurrencyExchange currency;

    private Duration frequency;

    private Boolean live;

    @JsonCreator
    public static PricingRateEnabledEvent of(final @JsonProperty("rateId") String rateId,
            final @JsonProperty("rateProviderId") Integer rateProviderId, final @JsonProperty("ricId") String ricId,
            final @JsonProperty("currency") CurrencyDTO currency,
            final @JsonProperty("frequency") String frequency, final @JsonProperty("live") Boolean live) {

        PricingRateEnabledEvent providedRateEnabledEvent = new PricingRateEnabledEvent();
        providedRateEnabledEvent.rateId = rateId;
        providedRateEnabledEvent.rateKey = RateKey.of(RateProvider.byId(rateProviderId), ricId);
        providedRateEnabledEvent.currency = currency.toModel();
        providedRateEnabledEvent.frequency = Duration.parse(frequency);
        providedRateEnabledEvent.live = live;

        return providedRateEnabledEvent;
    }

    public static PricingRateEnabledEvent of(final String rateId, final RateKey rateKey, final Duration frequency) {

        PricingRateEnabledEvent providedRateEnabledEvent = new PricingRateEnabledEvent();
        providedRateEnabledEvent.rateId = rateId;
        providedRateEnabledEvent.rateKey = rateKey;
        providedRateEnabledEvent.frequency = frequency;

        return providedRateEnabledEvent;
    }

    @JsonIgnore
    public boolean isThomsonAndReuters() {
        return getRateKey().rateProvider().isThomsonAndReuters();
    }

    @JsonIgnore
    public boolean isFutureSource() {
        return getRateKey().rateProvider().isFutureSource();
    }

    @JsonIgnore
    public boolean isRateProviderSupported() {
        return isFutureSource() || isThomsonAndReuters();
    }
}
