package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr;

import static com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr.ElektronMessageUtil.snapshotRequest;
import static com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr.ElektronMessageUtil.streamingRequest;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.zalando.problem.Status;

import com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository.PricingRateRepository;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.annotation.spring.TnR;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException.RateProviderExceptionType;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TnRStream;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.ApplicationProperties;
import com.thomsonreuters.ema.access.ChannelInformation;
import com.thomsonreuters.ema.access.EmaFactory;
import com.thomsonreuters.ema.access.OmmConsumer;
import com.thomsonreuters.ema.access.OmmConsumerConfig;
import com.thomsonreuters.ema.access.OmmException;

import lombok.extern.slf4j.Slf4j;

@TnR
@Slf4j
@Configuration
public class ElektronClient implements TnRClient {

    @Autowired
    private PricingRateRepository pricingRateRepository;

    private OmmConsumer ommConsumer;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private PlatformTransactionManager transactionManager;

    @Autowired
    private StreamingConsumer streamingConsumer;

    private AtomicBoolean initializing = new AtomicBoolean();

    private String currentTnRHost;

    public String currentTnRHost() {
        return this.currentTnRHost;
    }

    @PostConstruct
    public boolean initializeChannel() {
        if (this.initializing.get()) {
            throw new RateProviderException(RateProviderExceptionType.OMM_CONSUMER_INITIALIZATION_FAILED,
                    Status.TOO_MANY_REQUESTS);
        }
        try {
            this.currentTnRHost = applicationProperties.getThomson().getServerA();
            this.initializing.set(true);
            this.initializeOmmConsumer(this.currentTnRHost);
        }
        catch (final Exception e1) {
            try {
                this.currentTnRHost = applicationProperties.getThomson().getServerB();
                this.initializeOmmConsumer(this.currentTnRHost);
            }
            catch (final Exception e2) {
                // Hence the container would fail to start
                log.error("Error while creating OmmConsumer, please contact technical team", e2);
                // System.exit(1);
                // throw new RuntimeException("Exception occurred in creating singleton instance");
                this.initializing.set(false);
                throw new RateProviderException(RateProviderExceptionType.OMM_CONSUMER_INITIALIZATION_FAILED,
                        Status.SERVICE_UNAVAILABLE);
            }
        }
        recreateTnRStreamsData();
        this.initializing.set(false);
        return true;
    }

    private void initializeOmmConsumer(final String host) {
        log.info("Starting to initialize TnR consumer");
        OmmConsumerConfig config = EmaFactory.createOmmConsumerConfig()
                .operationModel(OmmConsumerConfig.OperationModel.API_DISPATCH);
        this.ommConsumer = EmaFactory
                .createOmmConsumer(config.host(host + ":" + applicationProperties.getThomson().getRsslPort())
                        .username(applicationProperties.getThomson().getUsername()));
        log.info("TnR consumer created successfully: {}", ommConsumer.consumerName());

    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    private void recreateTnRStreamsData() {
        log.info("Cleaning up TnR streams");
        TransactionStatus ts = this.transactionManager.getTransaction(new DefaultTransactionDefinition());
        try {
            this.pricingRateRepository.deleteAllTnRStreams();
            final List<String> uniqueRicIds = this.pricingRateRepository.findUniqueTnRRicIds();
            uniqueRicIds.forEach(ricId -> {
                this.pricingRateRepository.saveTnRStream(TnRStream.waiting(ricId));
            });
            this.pricingRateRepository.flush();
            this.transactionManager.commit(ts);
        }
        catch (Exception e) {
            log.error("Exception occurred while cleaning up TnR streams: ", e);
            this.transactionManager.rollback(ts);
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @Override
    public void initializeTnRStreams() {

        log.info("Initializing TnR streams ......");

        try {
            log.info("TnR channel information: {}", this.channelInformation());

            final List<String> uniqueRicIds = this.pricingRateRepository.findUniqueTnRRicIds();

            List<String> failedStreams = uniqueRicIds.stream().map(ricId -> ImmutablePair.of(ricId, openStream(ricId)))
                    .filter(pair -> {
                        try {
                            if (pair.getValue().get(10, TimeUnit.SECONDS) == -1L) {
                                return true;
                            }
                            else {
                                return false;
                            }
                        }
                        catch (final InterruptedException | ExecutionException | TimeoutException e) {
                            log.error("Exception while trying to open stream for ric ID: {" + pair.getKey() + "}", e);
                            return true;
                        }
                    }).map(ImmutablePair::getKey).collect(Collectors.toList());

            if (failedStreams.isEmpty()) {
                log.info("Created all TnR streams");
            }
            else {
                log.info("Failed to create TnR streams for RIC IDs : " + failedStreams
                        + ", so gonna retry asynchronously for maximum 5 times");
                retryFailedStreams(failedStreams, 5);
            }
        }
        catch (Exception e) {
            log.error("Exception during resetThomsonStreams", e);
        }
    }

    @Async
    private void retryFailedStreams(final List<String> failedStreams, int retryCount) {
        int retryAttempt = 6 - retryCount;
        log.info("Retry attempt : {}, max attempts: {}", retryAttempt, 5);
        if (failedStreams.isEmpty() || retryCount == 0) {
            return;
        }
        else {
            List<String> failures = failedStreams.stream().map(ricId -> ImmutablePair.of(ricId, openStream(ricId)))
                    .filter(pair -> {
                        try {
                            if (pair.getValue().get(10, TimeUnit.SECONDS) == -1L) {
                                return true;
                            }
                            else {
                                return false;
                            }
                        }
                        catch (final InterruptedException | ExecutionException | TimeoutException e) {
                            log.error("Exception while trying to open stream for ric ID: {" + pair.getKey() + "}", e);
                            return true;
                        }
                    }).map(ImmutablePair::getKey).collect(Collectors.toList());

            if (failedStreams.isEmpty()) {
                log.info("Created all TnR streams, in retry attempt: {}", retryAttempt);
            }
            else {
                log.info("Failed to create TnR streams for RIC IDs : " + failedStreams
                        + ", in retry attempt: {}, so gonna retry after 5 minutes", retryAttempt);
                try {
                    TimeUnit.MINUTES.sleep(5);
                }
                catch (InterruptedException e) {
                    // Do nothing
                }
                retryFailedStreams(failures, --retryCount);
            }
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void cleanTnRStreamsTable() {
        this.pricingRateRepository.deleteAllTnRStreams();
    }

    /**
     * Connecting with T&R Rate Provider and opening the stream to receive the rate changes
     * 
     * @param ricId
     */
    @Override
    public CompletableFuture<Long> openStream(final String ricId) {
        try {
            return CompletableFuture.supplyAsync(
                    () -> this.ommConsumer.registerClient(streamingRequest(ricId), this.streamingConsumer));
        }
        catch (OmmException e) {
            log.error("Exception while creating TnR stream for ric id: " + ricId, e);
            return CompletableFuture.completedFuture(-1L);
        }
    }

    /**
     * Connecting with TnR Provider and opening the temporary stream to fetch the data using ricId
     * 
     * @param event
     * @throws ExecutionException
     * @throws InterruptedException
     */
    @Override
    public CompletableFuture<ExchangeRate> rateSnapshot(final String ricId) {
        log.info("Opening temp stream using ricId");
        CompletableFuture<ExchangeRate> rateFuture = new CompletableFuture<>();
        this.ommConsumer.registerClient(snapshotRequest(ricId), SnapshotConsumer.callback(rateFuture));
        return rateFuture;
    }

    /**
     * closing the open stream and deleting the stored stream data from table
     * 
     * @param event
     */
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void closeStream(final String ricId) {
        long rateMetaDataCount = this.pricingRateRepository.findRateMetaDataCountByRicId(ricId);

        if (rateMetaDataCount == 0) {
            Optional<TnRStream> tnrStream = this.pricingRateRepository.findTnRStreamByRicId(ricId, true);

            if (tnrStream.isPresent()) {
                this.ommConsumer.unregister(tnrStream.get().streamId());

                log.info("Stream closed with handle id: {} for ric id: {}", tnrStream.get().streamId(), ricId);

                this.pricingRateRepository.deleteTnRStreamByRicId(ricId);
            }
        }
        else {
            log.info("There are other active rate records with same RIC ID: {}, so not closing stream", ricId);
        }
    }

    @Override
    public Optional<ChannelInformation> channelInformation() {
        ChannelInformation channelInformation = EmaFactory.createChannelInformation();
        try {
            CompletableFuture.runAsync(() -> this.ommConsumer.channelInformation(channelInformation)).get(10,
                    TimeUnit.SECONDS);
        }
        catch (InterruptedException | ExecutionException | TimeoutException e) {
            log.error("Error while getting channel information", e);
            Optional.empty();
        }
        return Optional.of(channelInformation);
    }

    @PreDestroy
    public void uninitialize() {
        log.info("Uninitializing ommConsumer");
        this.ommConsumer.uninitialize();
    }

    @Override
    public void reInitializeOmmConsumer(String ricId) {
        this.uninitialize();
        this.initializeChannel();
        this.initializeTnRStreams();

    }

    @Override
    public void reInitializeStream(String ricId) {
        // TODO Auto-generated method stub

    }
}
