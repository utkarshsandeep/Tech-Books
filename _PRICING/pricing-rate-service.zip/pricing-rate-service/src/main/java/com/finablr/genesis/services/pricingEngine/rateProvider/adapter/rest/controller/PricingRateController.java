package com.finablr.genesis.services.pricingEngine.rateProvider.adapter.rest.controller;

import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RateProviderConstants.FUTURE_SOURCE_RATE_CREATED_SUCCESSFULLY;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RateProviderConstants.RATES_PUSHED_SUCCESSFULLY;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.CURRENCIES_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.DASHBOARD_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.DB_HEALTH_CHECK_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.ELEKTRON_HEALTH_CHECK_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.FUTURE_SOURCE_RATE_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.INFRA_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.JMS_HEALTH_CHECK_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.PRICING_RATE_PROVIDER_API;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.PROVIDED_RATES_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.PUSH_RATE_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.RATE_PROVIDERS_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.RestConstants.TIMEZONES_URI;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.HeaderUtil.addSuccess;
import static com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.MessageProvider.getMessage;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.time.ZoneId;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.zalando.problem.Status;

import com.finablr.genesis.services.pricingEngine.rateProvider.application.health.HealthIndicator;
import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler.SchedulerService;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.exception.RateProviderException.RateProviderExceptionType;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RicRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard.InfraHealth;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard.RateRecord;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.FutureSourceRateRequest;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.PushRateRequest;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto.RateDTO;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.service.PricingRateService;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.service.RateProcessor;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.ApplicationProperties;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import reactor.core.publisher.EmitterProcessor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Api(value = "RateProvider", description = "Rate Provider APIs", tags = "Rate Provider")
@RestController
@RequestMapping(PRICING_RATE_PROVIDER_API)
@Validated
public class PricingRateController {

    @Autowired
    private PricingRateService pricingRateService;

    @Lazy
    @Autowired
    private SchedulerService schedulerService;

    @Autowired
    private RateProcessor rateProcessor;

    @Autowired
    private EmitterProcessor<RateRecord> dashboardEmitter;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private HealthIndicator healthIndicator;

    @GetMapping(PROVIDED_RATES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-rate-provider-rate", 
        value = "Gets provided rate",
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = RateDTO.class,
        notes = "Gets the latest rate from the given <b>Rate Provider</b> for the given <b>RIC ID</b>."
                + " The success message is return in a header named <b>X-pricing-info</b> along with the number of records created or updated."
                + " Ex. 2 Rates created or updated for Future Source"
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 200, message = "Success: The latest provided rate is returned"),
            @ApiResponse(code = 404, message = "Not found: Rate not found for given request"),
            @ApiResponse(code = 412, message = "Precondition failed: Request to get rate from Thomson & Reuters rate provider "
                    + "but the same is disabled on respective environment"),
            @ApiResponse(code = 400, message = "Bad Request: Given Rate Provider ID or RIC ID is invalid"),
            @ApiResponse(code = 401, message = "Unauthorised: Security validation failed")
        }
    )
    @Valid
    public ResponseEntity<RateDTO> getProvidedRate(
            @ApiParam(value = "RIC ID such  as 'INR=' etc.", example = "INR=", required = true)
            @RequestParam(value = "ricId", required = true) @NotEmpty String ricId,
            @ApiParam(value = "Rate Provider id, For Thomson & Reuters : 2 and Future Source : 3", example = "2", allowableValues = "2,3", required = true)
            @RequestParam(value = "rateProviderId", required = true) @NotNull Integer rateProviderId) {
    // @formatter:on

        return ResponseEntity.ok(
                this.pricingRateService.getProvidedRateByRateKey(RateKey.of(RateProvider.byId(rateProviderId), ricId)));
    }

    @PostMapping(FUTURE_SOURCE_RATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "create-future-source-rate", 
        value = "Pushes Future Source rates - Deprecated now, would be removed soon. "
                + "Use another API to push rates for both rate providers", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = Void.class,
        notes = "Pushes the latest rates from <b>Future Source</b> rate provider into the system"
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 200, message = "Success: The given rates are pushed into the system successfully"),
            @ApiResponse(code = 400, message = "Bad Request: Given Ask or Bid value are invalid"),
            @ApiResponse(code = 401, message = "Unauthorised: Security validation failed")
        }
    )
    @Valid
    @Deprecated
    public ResponseEntity<Void> createOrUpdateFutureSourceRate(
            @RequestBody @Valid @NotEmpty final List<@Valid @NotNull FutureSourceRateRequest> createRequests) {
    // @formatter:on

        createRequests.forEach(req -> {
            if (req.getAskValue().compareTo(req.getBidValue()) < 0) {
                throw new RateProviderException(RateProviderExceptionType.INVALID_ASK_BID_VALUE, Status.BAD_REQUEST);
            }
        });
        List<RicRate> results = this.pricingRateService.createOrUpdateFutureSourceRates(createRequests);

        return ResponseEntity.created(null)
                .headers(addSuccess(getMessage(FUTURE_SOURCE_RATE_CREATED_SUCCESSFULLY, results.size()))).build();
    }

    @PostMapping(PUSH_RATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "push-rates", 
        value = "Push rates into the system", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = Void.class,
        notes = "Pushes the latest rates for given rate provider and RICs into the system."
                + "If rate already exists for given rate provider and ric id then its updated wih given values otherwise created"
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 200, message = "Success: The given rates are pushed into the system successfully"),
            @ApiResponse(code = 400, message = "Bad Request: Given Ask or Bid value are invalid"),
            @ApiResponse(code = 401, message = "Unauthorised: Security validation failed")
        }
    )
    @Valid
    public ResponseEntity<Void> pushRates(
            @ApiParam(value = "Rate Provider, For Thomson & Reuters : THOMSON_AND_REUTERS and Future Source : FUTURE_SOURCE", allowableValues = "THOMSON_AND_REUTERS,FUTURE_SOURCE", example = "FUTURE_SOURCE", required = true)
            @RequestParam(value = "rateProvider", required = true) @NotNull RateProvider rateProvider,
            @RequestBody @Valid @NotEmpty final List<@Valid @NotNull PushRateRequest> pushRequests) {
    // @formatter:on

        pushRequests.forEach(req -> {
            if (req.getAskValue().compareTo(req.getBidValue()) < 0) {
                throw new RateProviderException(RateProviderExceptionType.INVALID_ASK_BID_VALUE, Status.BAD_REQUEST);
            }
        });
        this.pricingRateService.createOrUpdateRicRates(rateProvider, pushRequests);

        return ResponseEntity.created(null)
                .headers(addSuccess(getMessage(RATES_PUSHED_SUCCESSFULLY, pushRequests.size()))).build();
    }

    @GetMapping(RATE_PROVIDERS_URI)
    // @formatter:off
    @ApiOperation(nickname = "rate-providers-list", 
        value = "Gets list of rate providers", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = RateProvider.class,
        responseContainer = "List",
        notes = ""
    )
    // @formatter:on
    public EnumSet<RateProvider> getRateProviders() {
        return RateProvider.all();
    }

    @GetMapping(CURRENCIES_URI)
    // @formatter:off
    @ApiOperation(nickname = "currencies-list", 
        value = "Gets list of Ric Ids", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = String.class,
        responseContainer = "List",
        notes = ""
    )
    // @formatter:on
    public List<String> getCurrenciesList(
            @ApiParam(value = "Rate Provider, For Thomson & Reuters : THOMSON_AND_REUTERS and Future Source : FUTURE_SOURCE", allowableValues = "THOMSON_AND_REUTERS,FUTURE_SOURCE", example = "FUTURE_SOURCE", required = false, allowMultiple = true)
            @RequestParam(value = "rateProvider", required = false)
            final List<@NotNull RateProvider> rateProviders) {
        return this.rateProcessor.currenciesList(rateProviders);
    }

    @GetMapping(TIMEZONES_URI)
    // @formatter:off
    @ApiOperation(nickname = "supported-time-zones", 
        value = "Gets list of supported ZoneIds", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = ZoneId.class,
        responseContainer = "List",
        notes = ""
    )
    // @formatter:on
    public List<ZoneId> getTimeZones() {
        return this.applicationProperties.getSupportedTimeZones();
    }

    @GetMapping(path = DASHBOARD_URI, produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "rate-records-stream", 
        value = "Gets list of supported ZoneIds", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = ZoneId.class,
        responseContainer = "List",
        notes = ""
    )
    public Flux<RateRecord> streamRateRecords(
            @ApiParam(value = "Rate Provider, For Thomson & Reuters : THOMSON_AND_REUTERS and Future Source : FUTURE_SOURCE", allowableValues = "THOMSON_AND_REUTERS,FUTURE_SOURCE", example = "FUTURE_SOURCE", required = false, allowMultiple = true)
            @RequestParam(value = "rateProvider", required = false) final List<@NotNull RateProvider> rateProviders,
            @ApiParam(value = "Ric Id e.g. USD=, INR=", example = "INR=", required = false)
            @RequestParam(value = "ricIds", required = false) final List<@NotEmpty String> ricIds,
            @ApiParam(value = "Zone of visible timestamps", allowableValues = "UTC,Asia/Kolkata,Asia/Dubai", example = "Asia/Kolkata", required = false)
            @RequestParam(value = "zoneId", required = false, defaultValue = "Asia/Kolkata") final ZoneId zoneId,
            @ApiParam(value = "Whether or not to get intial dump of records", example = "true", required = false)
            @RequestParam(value = "preliminary", required = false, defaultValue = "true") final boolean preliminary) {
        // @formatter:on

        return this.dashboardEmitter.startWith(
                preliminary ? this.rateProcessor.getAllRateRecords(rateProviders, ricIds) : Collections.emptyList())
                .filter(rateRecord -> {
                    if (rateProviders != null && !rateProviders.isEmpty()
                            && !rateProviders.contains(rateRecord.getRateKey().rateProvider())) {
                        return false;
                    }
                    if (ricIds != null && !ricIds.isEmpty() && !ricIds.contains(rateRecord.getRateKey().ricId())) {
                        return false;
                    }
                    return true;
                }).doOnNext(rateRecord -> rateRecord.conclude(zoneId));
    }

    @GetMapping(INFRA_URI)
    // @formatter:off
    @ApiOperation(nickname = "infra-health-check", 
        value = "Gets Infrastructure health", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = Health.class,
        responseContainer = "List",
        notes = ""
    )
    // @formatter:on
    public Mono<InfraHealth> getInfraHealth() {
        return this.healthIndicator.infraHealth();
    }

    @GetMapping(DB_HEALTH_CHECK_URI)
    // @formatter:off
    @ApiOperation(nickname = "db-health-check", 
        value = "Gets Database health", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = ZoneId.class,
        responseContainer = "List",
        notes = ""
    )
    // @formatter:on
    public Mono<Health> getDatabaseHealth() {
        return this.healthIndicator.dataSourceHealth();
    }

    @GetMapping(JMS_HEALTH_CHECK_URI)
    // @formatter:off
    @ApiOperation(nickname = "activemq-health-check", 
        value = "Gets JMS health", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = Health.class,
        responseContainer = "List",
        notes = ""
    )
    // @formatter:on
    public Mono<Health> getAciveMQHealth() {
        return this.healthIndicator.jmsHealth();
    }

    @GetMapping(ELEKTRON_HEALTH_CHECK_URI)
    // @formatter:off
    @ApiOperation(nickname = "elekron-health-check", 
        value = "Gets Elektron client health", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = Health.class,
        responseContainer = "List",
        notes = ""
    )
    // @formatter:on
    public Mono<Health> getElektronHealth() {
        return this.healthIndicator.elektronHealth();
    }
}
