package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.CurrencyExchange;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.Frequency;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.JobExecution;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ProvidedRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.StreamState;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TriggerDetails;

import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;

@Getter
public class RateRecord implements Comparable<RateRecord> {

    @ApiModelProperty(name = "rateId", value = "UUID of Rate record to correlate in Pricing Engine", example = "", position = 1)
    private String rateId;

    @JsonInclude(NON_NULL)
    private RateKey rateKey;

    @JsonInclude(NON_NULL)
    private CurrencyExchange currency;

    @JsonInclude(NON_NULL)
    private Frequency frequency;

    @JsonInclude(NON_NULL)
    private RateSnapshot currentRate;

    @JsonInclude(NON_NULL)
    private StreamState streamState;

    @JsonInclude(NON_NULL)
    private JobExecution jobExecution;

    @Getter(value = AccessLevel.NONE)
    private boolean preliminary;

    public static RateRecord of(final ProvidedRate providedRate, final StreamState streamState,
            final TriggerDetails triggerDetails) {
        RateRecord rateRecord = new RateRecord();
        rateRecord.rateId = providedRate.rateId();
        rateRecord.rateKey = providedRate.rateKey();
        rateRecord.currency = providedRate.currency();
        rateRecord.frequency = Frequency.ofRate(providedRate.frequency(), providedRate.live());
        rateRecord.currentRate = RateSnapshot.of(providedRate.currentRate(), providedRate.updatedOn());
        rateRecord.streamState = streamState;
        if (triggerDetails == null) {
            rateRecord.jobExecution = JobExecution.of(null, null, null, null, providedRate.publishedOn(),
                    providedRate.publishedRate());
        }
        else {
            rateRecord.jobExecution = JobExecution.of(triggerDetails.fireTime(), triggerDetails.nextFireTime(),
                    triggerDetails.repeatInterval(), triggerDetails.triggerState(), providedRate.publishedOn(),
                    providedRate.publishedRate());
        }
        rateRecord.preliminary = true;

        return rateRecord;
    }

    public static RateRecord onRateChange(final String rateId, final RateKey rateKey, final ExchangeRate currentRate,
            final ZonedDateTime updatedOn) {
        RateRecord rateRecord = new RateRecord();
        rateRecord.rateId = rateId;
        rateRecord.rateKey = rateKey;
        rateRecord.currentRate = RateSnapshot.of(currentRate, updatedOn);
        return rateRecord;
    }

    public static RateRecord onStreamStateChange(final String rateId, final RateKey rateKey,
            final StreamState streamState) {
        RateRecord rateRecord = new RateRecord();
        rateRecord.rateId = rateId;
        rateRecord.rateKey = rateKey;
        rateRecord.streamState = streamState;
        return rateRecord;
    }

    public static RateRecord onJobExecution(final JobExecution jobExecution) {
        RateRecord rateRecord = new RateRecord();
        rateRecord.rateId = jobExecution.getRateId();
        rateRecord.rateKey = jobExecution.getRateKey();
        rateRecord.jobExecution = jobExecution;
        return rateRecord;
    }

    public RateRecord conclude(final ZoneId zoneId) {
        if (!this.preliminary) {
            this.rateKey = null;
        }
        if (this.currentRate != null) {
            this.currentRate.conclude(zoneId);
        }
        if (this.jobExecution != null) {
            this.jobExecution.conclude(zoneId);
        }
        return this;
    }

    @Override
    public int compareTo(RateRecord o) {
        return this.rateKey.compareTo(o.rateKey);
    }
}
