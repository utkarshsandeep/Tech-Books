package com.finablr.genesis.services.pricingEngine.rateProvider.common.constants;

import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import lombok.Value;

/**
 * Application constants.
 */
@Value
public final class ApplicationConstants {

    public static final String REPOSITORY_PACKAGE = "com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository";

    public static final String CONTROLLER_PACKAGE = "com.finablr.genesis.services.pricingEngine.rateProvider.adapter.rest.controller";

    public static final String SYSTEM_USER = "SYSTEM";

    public final static Locale DEFAULT_LOCALE = Locale.getDefault();

    public final static ZoneId DEFAULT_ZONE_ID = ZoneId.systemDefault();

    public final static ZoneId ZONE_ID_UTC = ZoneId.of("UTC");

    public final static ZoneId ZONE_ID_INDIA = ZoneId.of("Asia/Kolkata");

    public final static ZoneId ZONE_ID_UAE = ZoneId.of("Asia/Dubai");

    public final static TimeZone TIME_ZONE_UTC = TimeZone.getTimeZone(ZONE_ID_UTC);

    public final static TimeZone TIME_ZONE_INDIA = TimeZone.getTimeZone(ZONE_ID_INDIA);

    public final static TimeZone TIME_ZONE_UAE = TimeZone.getTimeZone(ZONE_ID_UAE);

    public final static List<ZoneId> SUPPORTED_TIME_ZONES = Arrays.asList(ZONE_ID_UTC, ZONE_ID_INDIA, ZONE_ID_UAE);

    public final static String ALL_INSTRUMENTS = "All";

    public final static int MANUAL_RATE_PROVIDER_ID = 1;

    public final static int THOMSON_RATE_PROVIDER_ID = 2;

    public final static int FUTURE_SOURCE_RATE_PROVIDER_ID = 3;

    public static final String RATE_PUBLICATION_JOB_GROUP_ID = "RATE_PUBLICATION_JOB_GROUP";

    public static final String SIMPLE_TRIGGER_GROUP_ID = "SIMPLE_TRIGGER_GROUP";

    public static final String QUARTZ_JOB_DETAILS_RATE_KEY = "RATE_ID";

    public static final String QUARTZ_JOB_DETAILS_RIC_ID_KEY = "RIC_ID";

    public static final String QUARTZ_JOB_DETAILS_FREQUENCY_KEY = "FREQUENCY";

    public static final String QUARTZ_JOB_DETAILS_RATE_PROVIDER_NAME = "RATE_PROVIDER_NAME";
}
