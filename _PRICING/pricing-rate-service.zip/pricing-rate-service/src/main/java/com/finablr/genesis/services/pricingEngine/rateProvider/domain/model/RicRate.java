package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import java.time.ZonedDateTime;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;
import org.springframework.util.Assert;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(callSuper = true)
@Entity
// @formatter:off
@Table(name = "RIC_RATES", indexes = {
        @Index(name = "IDX_RIC_RATES_UPDATED_ON", columnList = "UPDATED_ON")  
    }
)
// @formatter:on
@DynamicUpdate
@OptimisticLocking(type = OptimisticLockType.NONE)
public class RicRate {

    @Access(AccessType.FIELD)
    @EmbeddedId
    private RateKey rateKey;

    @Version
    @Access(AccessType.FIELD)
    @Column(name = "version", nullable = false)
    private long version;

    @NotNull
    private ExchangeRate exchangeRate;

    @NotNull
    @Column(name = "UPDATED_ON", columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    private ZonedDateTime updatedOn;

    public boolean updateExchangeRate(final ExchangeRate newExchangeRate) {
        return updateExchangeRate(newExchangeRate, DateTimeHelper.nowZonedDateTimeUTC());
    }

    public boolean updateExchangeRate(final ExchangeRate newExchangeRate, final ZonedDateTime updatedOn) {
        if (this.exchangeRate.equals(newExchangeRate)) {
            return false;
        }
        else {
            this.exchangeRate = newExchangeRate;
            this.updatedOn = updatedOn;
            return true;
        }
    }

    public static RicRate of(final RateKey rateKey, final ExchangeRate exchangeRate) {
        return of(rateKey, exchangeRate, DateTimeHelper.nowZonedDateTimeUTC());
    }

    public static RicRate of(final RateKey rateKey, final ExchangeRate exchangeRate, final ZonedDateTime updatedOn) {
        Assert.notNull(rateKey, "rateKey must not be null!");
        Assert.notNull(exchangeRate, "exchangeRate must not be null!");
        Assert.notNull(updatedOn, "updatedOn must not be null!");
        RicRate ricRate = new RicRate();
        ricRate.rateKey = rateKey;
        ricRate.exchangeRate = exchangeRate;
        ricRate.updatedOn = updatedOn;
        return ricRate;
    }

    // For Thomson Reuters
    public static RicRate ofThomsonAndReuters(final String ricId, final ExchangeRate exchangeRate) {
        return of(RateKey.ofThomsonAndReuters(ricId), exchangeRate);
    }

    // For Future Source
    public static RicRate ofFutureSource(final String ricId, final ExchangeRate exchangeRate) {
        return of(RateKey.ofFutureSource(ricId), exchangeRate);
    }
}
