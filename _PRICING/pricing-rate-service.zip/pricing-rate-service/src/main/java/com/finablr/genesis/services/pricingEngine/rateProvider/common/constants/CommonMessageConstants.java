package com.finablr.genesis.services.pricingEngine.rateProvider.common.constants;

public enum CommonMessageConstants implements MessageCodeType {

    // @formatter:off
	NO_RECORDS_FOUND("no.records.found", "No records found matching selection criteria");
	// @formatter:on

    private String key;

    private String defaultMessage;

    private CommonMessageConstants(final String messageCode, final String defaultMessage) {
        this.key = messageCode;
        this.defaultMessage = defaultMessage;
    }

    @Override
    public String key() {
        return this.key;
    }

    @Override
    public String defaultMessage() {
        return this.defaultMessage;
    }
}
