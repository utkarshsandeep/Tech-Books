package com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence;

import lombok.Value;

@Value
public class PersistenceConstant {

    public static class Hibernate {

        // ID Generation strategies starts >>>
        public static final String GLOBAL_SEQ_ID_GENERATOR = "GLOBAL_SEQ_ID_GENERATOR";
        
        public static final String UUID2_GENERATOR = "UUID2_GENERATOR";
        
        // ID Generation strategies ends >>>

        public static final String GLOBAL_SEQ_NAME = "global_sequence";

        public static final String GLOBAL_SEQ_INITIAL_VALUE = "1000";
        
        public static final String TYPE_DEF_JADIRA_MONEY = "jadira_money";

        public static final String TYPE_DEF_JADIRA_MONEY_CURRENCY_UNIT = "jadira_money_currency_unit";

        public static final String TYPE_DEF_JADIRA_DURATION = "jadira_duration";

        public static final String TYPE_DEF_JADIRA_PERIOD = "jadira_period";

    }
}
