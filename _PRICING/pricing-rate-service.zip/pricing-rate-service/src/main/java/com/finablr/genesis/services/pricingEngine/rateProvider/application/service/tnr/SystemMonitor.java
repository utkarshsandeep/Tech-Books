package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.finablr.genesis.services.pricingEngine.rateProvider.adapter.persistence.repository.PricingRateRepository;
import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler.SchedulerService;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.annotation.spring.TnR;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TnRStream;
import com.thomsonreuters.ema.access.ChannelInformation;

import lombok.extern.slf4j.Slf4j;

@TnR
@Slf4j
//@Component
public class SystemMonitor {

    @Autowired
    private TnRClient tnrClient;

    @Lazy
    @Autowired
    private SchedulerService schedulerService;

    @Autowired
    private PricingRateRepository pricingRateRepository;

    /**
     * Runs in every 30 minutes to monitor the state of TnR channel and streams and possibly recover from any
     * disconnection
     */
    @Scheduled(cron = "0 0/30 * * * *")
    public void monitor() {
        log.info(
                "------------------------------- Monitoring TnR channel, streams and Quartz Schedules starts -------------------------------");

        Optional<ChannelInformation> channelInformation = this.tnrClient.channelInformation();
        if (channelInformation.isPresent()) {
            log.info("TnR channel information: {}", channelInformation);
        }
        log.info("Stream states ....................");
        List<TnRStream> allTnRstreams = this.pricingRateRepository.findAllTnRStreams();
        allTnRstreams.forEach(tnrStream -> {
            log.info(tnrStream.toString());
        });

        this.schedulerService.validateTriggerStates();

        // System.gc();

        log.info(
                "------------------------------- Monitoring TnR channel, streams and Quartz Schedules ends -------------------------------");
    }
}
