package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.BeanFactory;

import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class RateSnapshot {

    @ApiModelProperty(name = "askValue", dataType = "BigDecimal", value = "Ask Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 1)
    private final BigDecimal askValue;

    @ApiModelProperty(name = "bidValue", dataType = "BigDecimal", value = "Bid Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 2)
    private final BigDecimal bidValue;

    @Getter(value = AccessLevel.NONE)
    @ApiModelProperty(name = "updatedOn", value = "Last updated on timestamp", required = true, example = "", position = 3)
    private final ZonedDateTime updatedOn;

    @JsonIgnore
    @Getter(value = AccessLevel.NONE)
    private ZoneId zoneId;

    public static RateSnapshot of(final ExchangeRate rate, final ZonedDateTime updatedOn) {
        return rate != null ? new RateSnapshot(rate.askValue(), rate.bidValue(), updatedOn) : null;
    }

    public RateSnapshot conclude(final ZoneId zoneId) {
        this.zoneId = zoneId;
        return this;
    }

    public String getUpdatedOn() {
        return this.updatedOn != null ? DateTimeHelper.convertAndFormatZonedDateTime(this.updatedOn, this.zoneId,
                BeanFactory.applicationProperties().getDashboardDatetimeFormat()) : null;
    }
}
