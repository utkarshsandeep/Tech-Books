package com.finablr.genesis.services.pricingEngine.rateProvider.common.exception;

public interface ErrorCodeType {

    public String errorCode();

    public String title();
}
