package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr;

import java.math.BigDecimal;
import java.util.Optional;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.BeanFactory;
import com.thomsonreuters.ema.access.DataType;
import com.thomsonreuters.ema.access.ElementList;
import com.thomsonreuters.ema.access.EmaFactory;
import com.thomsonreuters.ema.access.FieldEntry;
import com.thomsonreuters.ema.access.OmmArray;
import com.thomsonreuters.ema.access.Payload;
import com.thomsonreuters.ema.access.ReqMsg;
import com.thomsonreuters.ema.rdm.EmaRdm;

public abstract class ElektronMessageUtil {

    public static ReqMsg streamingRequest(final String ricId) {
        ReqMsg reqMsg = EmaFactory.createReqMsg();
        ElementList view = EmaFactory.createElementList();
        OmmArray array = EmaFactory.createOmmArray();

        // For Limiting incoming DataPayload
        array.fixedWidth(2);
        array.add(EmaFactory.createOmmArrayEntry().intValue(22));
        array.add(EmaFactory.createOmmArrayEntry().intValue(25));

        view.add(EmaFactory.createElementEntry().uintValue(EmaRdm.ENAME_VIEW_TYPE, 1));
        view.add(EmaFactory.createElementEntry().array(EmaRdm.ENAME_VIEW_DATA, array));

        reqMsg.serviceName(BeanFactory.applicationProperties().getThomson().getServiceName()).payload(view).name(ricId);
        return reqMsg;
    }

    public static ReqMsg snapshotRequest(final String ricId) {
        return streamingRequest(ricId).interestAfterRefresh(false);
    }

    public static Optional<ExchangeRate> decodeExchangeRate(final Payload payload) {
        BigDecimal askValue = null;
        BigDecimal bidValue = null;

        switch (payload.dataType()) {
        // A level 1 message (MARKET_PRICE)is packaged as a field list
        case DataType.DataTypes.FIELD_LIST:
            for (FieldEntry fieldEntry : payload.fieldList()) {

                if (fieldEntry.fieldId() == 22) {
                    bidValue = new BigDecimal(fieldEntry.load().toString());
                }

                if (fieldEntry.fieldId() == 25) {
                    askValue = new BigDecimal(fieldEntry.load().toString());
                }
            }
            break;
        }
        return askValue == null || bidValue == null ? Optional.empty()
                : Optional.of(ExchangeRate.of(askValue, bidValue));
    }
}
