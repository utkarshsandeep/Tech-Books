package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dto;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.utils.DateTimeHelper;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.ExchangeRate;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateKey;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.RateProvider;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.RateChangeEvent;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "pushRateRequest", description = "Request to create or update rates for given rate provider")
public class PushRateRequest {

    @NotNull
    @ApiModelProperty(name = "ricId", dataType = "String", value = "Ric Id e.g. USD=, INR=", allowEmptyValue = false, required = true, example = "INR=", position = 1)
    private String ricId;

    @ApiModelProperty(name = "askValue", dataType = "BigDecimal", value = "Ask Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 2)
    @Positive
    private BigDecimal askValue;

    @ApiModelProperty(name = "bidValue", dataType = "BigDecimal", value = "Bid Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 3)
    @Positive
    private BigDecimal bidValue;

    public ExchangeRate exchangeRate() {
        return ExchangeRate.of(askValue, bidValue);
    }

    public RateKey rateKey(final RateProvider rateProvider) {
        return RateKey.of(rateProvider, this.ricId);
    }

    public RateChangeEvent rateChangeEvent(final RateProvider rateProvider) {
        return RateChangeEvent.of(this.rateKey(rateProvider), ExchangeRate.of(this.askValue, this.bidValue),
                DateTimeHelper.nowZonedDateTimeUTC());
    }
}
