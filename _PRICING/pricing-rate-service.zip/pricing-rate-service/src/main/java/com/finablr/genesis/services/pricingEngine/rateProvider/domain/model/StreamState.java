package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonValue;

public enum StreamState {

    // @formatter:off
    INVALID_RIC(-1, "Indicates the stream can not be opened as the requested RIC ID is invalid"),
    WAITING(0, "Indicates the stream is requested to open and application is waiting for response"),
    OPEN(1, "Indicates the stream is open and receiving rate changes"),
    NON_STREAMING(2, "Indicates the item will not incur interest after the final refresh"),
    CLOSED_RECOVER(3, "Indicates the stream is closed, "
            + "typically unobtainable or identity indeterminable due to a comms outage. "
            + "The item may be available in the future"),
    CLOSED(4, "Indicates the stream is closed and not receiving any rate changes"),
    CLOSED_REDIRECTED(5, "Indicates the stream is closed and has been renamed. "
            + "The stream is available with another name. "
            + "This stream state is only valid for refresh messages. "
            + "The new item name is in the Name get accessor methods.");
    // @formatter:on

    private final int code;

    private final String description;

    private Pair<String, String> info;

    private StreamState(final int code, final String description) {
        this.code = code;
        this.description = description;
        this.info = ImmutablePair.of(this.name(), description);
    }

    public static StreamState of(final int streamState) {
        if (streamState == -1) {
            return INVALID_RIC;
        }
        else if (streamState == 0) {
            return WAITING;
        }
        else if (streamState == com.thomsonreuters.ema.access.OmmState.StreamState.OPEN) {
            return OPEN;
        }
        else if (streamState == com.thomsonreuters.ema.access.OmmState.StreamState.NON_STREAMING) {
            return NON_STREAMING;
        }
        else if (streamState == com.thomsonreuters.ema.access.OmmState.StreamState.CLOSED_RECOVER) {
            return CLOSED_RECOVER;
        }
        else if (streamState == com.thomsonreuters.ema.access.OmmState.StreamState.CLOSED) {
            return CLOSED;
        }
        else if (streamState == com.thomsonreuters.ema.access.OmmState.StreamState.CLOSED_REDIRECTED) {
            return CLOSED_REDIRECTED;
        }
        else {
            throw new IllegalArgumentException("Illegal stream state code: " + streamState);
        }
    }

    public int code() {
        return this.code;
    }

    public String description() {
        return this.description;
    }

    @JsonIgnore
    public boolean isOpen() {
        return this == OPEN;
    }

    @JsonValue
    public Pair<String, String> info() {
        return this.info;
    }
}
