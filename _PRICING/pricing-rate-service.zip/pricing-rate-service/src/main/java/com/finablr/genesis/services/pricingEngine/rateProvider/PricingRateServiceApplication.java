package com.finablr.genesis.services.pricingEngine.rateProvider;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collection;
import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.activemq.ActiveMQAutoConfiguration;
import org.springframework.boot.autoconfigure.quartz.QuartzAutoConfiguration;
import org.springframework.boot.autoconfigure.quartz.QuartzProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.reactive.config.EnableWebFlux;

import com.finablr.genesis.services.pricingEngine.rateProvider.common.constants.ApplicationConstants;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.ApplicationProperties;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Configuration
@EnableJpaRepositories(ApplicationConstants.REPOSITORY_PACKAGE)
@EnableTransactionManagement
@EnableConfigurationProperties({ ApplicationProperties.class, QuartzProperties.class })
@EnableAutoConfiguration(exclude = { QuartzAutoConfiguration.class, ActiveMQAutoConfiguration.class })
@EnableWebFlux
@Slf4j
public class PricingRateServiceApplication {

    private final Environment env;

    public PricingRateServiceApplication(Environment env) {
        this.env = env;
    }

    /**
     * Initializes sample. Spring profiles can be configured with a program argument
     * --spring.profiles.active=your-active-profile
     */
    @PostConstruct
    public void initApplication() {
        Collection<String> activeProfiles = Arrays.asList(env.getActiveProfiles());
        if (activeProfiles.contains(SpringProfiles.DEVELOPMENT) && activeProfiles.contains(SpringProfiles.PRODUCTION)) {
            log.error("You have misconfigured your application! It should not run "
                    + "with both the 'dev' and 'prod' profiles at the same time.");
        }
    }

    public static void main(String[] args) {
        // ReactorDebugAgent.init();
        SpringApplication app = new SpringApplication(PricingRateServiceApplication.class);
        SpringProfiles.addDefaultProfile(app);
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        Environment env = app.run(args).getEnvironment();
        logApplicationStartup(env);
    }

    private static void logApplicationStartup(Environment env) {
        String protocol = "http";
        if (env.getProperty("server.ssl.key-store") != null) {
            protocol = "https";
        }
        String serverPort = env.getProperty("server.port") == null ? "" + 8080 : env.getProperty("server.port");
        String contextPath = env.getProperty("server.servlet.context-path");
        if (StringUtils.isBlank(contextPath)) {
            contextPath = "/";
        }
        String hostAddress = "localhost";
        try {
            hostAddress = InetAddress.getLocalHost().getHostAddress();
        }
        catch (UnknownHostException e) {
            log.warn("The host name could not be determined, using `localhost` as fallback");
        }
        log.info(
                "\n----------------------------------------------------------\n\t"
                        + "Application '{}' is running! Access URLs:\n\t" + "Local: \t\t{}://localhost:{}{}\n\t"
                        + "External: \t{}://{}:{}{}\n\t"
                        + "Profile(s): \t{}\n----------------------------------------------------------",
                env.getProperty("spring.application.name"), protocol, serverPort, contextPath, protocol, hostAddress,
                serverPort, contextPath, env.getActiveProfiles());
    }
}
