package com.finablr.genesis.services.pricingEngine.rateProvider.application.service.scheduler;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.Trigger.TriggerState;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.TriggerDetails;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateDisabledEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateEnabledEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.PricingRateFrequencyChangedEvent;

public interface SchedulerService {

    Optional<Trigger> checkIfJobExists(final String rateId) throws SchedulerException;

    void scheduleNewRatePublicationJob(final PricingRateEnabledEvent jobInfo);

    void updateRatePublicationJobFrequency(final PricingRateFrequencyChangedEvent jobInfo);

    void deleteRatePublicationJob(final PricingRateDisabledEvent jobInfo);

    Optional<Trigger> getTrigger(final String triggerName);

    Optional<TriggerState> getTriggerState(final Trigger trigger);

    Set<Trigger> getAllTriggers();

    Map<String, TriggerDetails> getAllTriggerDetails();

    void validateScheduledJobs();

    void validateTriggerStates();

    void startScheduler() throws SchedulerException;

    void startScheduler(int seconds) throws SchedulerException;
}
