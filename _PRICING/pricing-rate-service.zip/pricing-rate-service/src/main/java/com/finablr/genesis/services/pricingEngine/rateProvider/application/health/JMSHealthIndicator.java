package com.finablr.genesis.services.pricingEngine.rateProvider.application.health;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.AbstractReactiveHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Health.Builder;
import org.springframework.boot.actuate.health.Status;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;

import reactor.core.publisher.Mono;

@Component
public class JMSHealthIndicator extends AbstractReactiveHealthIndicator {

    @Lazy
    @Autowired
    private ConnectionFactory connectionFactory;

    @Override
    protected Mono<Health> doHealthCheck(Builder builder) {
        if (!SpringProfiles.isJMSEnabled()) {
            return Mono.just(
                    builder.status(new Status("DISABLED", "JMS Integration is disabled on this installation")).build());
        }
        try (final Connection connection = this.connectionFactory.createConnection()) {
            connection.start();
            return Mono
                    .just(builder.up().withDetail("provider", connection.getMetaData().getJMSProviderName()).build());
        }
        catch (final JMSException e) {
            return Mono.just(builder.down(e).withException(e).build());
        }
    }
}
