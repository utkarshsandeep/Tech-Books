package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model;

import java.math.BigDecimal;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import org.springframework.util.Assert;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
@Access(AccessType.FIELD)
public class ExchangeRate implements RateValue {

    @JsonProperty
    @ApiModelProperty(name = "askValue", dataType = "BigDecimal", value = "Ask Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 1)
    @NotNull
    // @formatter:off
    @Column(name = "ASK_VALUE",  
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE")
    //@formatter:on
    private BigDecimal askValue;

    @JsonProperty
    @ApiModelProperty(name = "bidValue", dataType = "BigDecimal", value = "Bid Value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 2)
    @NotNull
    // @formatter:off
    @Column(name = "BID_VALUE", 
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE")
    //@formatter:on
    private BigDecimal bidValue;

    public static ExchangeRate of(final BigDecimal askValue, final BigDecimal bidValue) {
        Assert.notNull(askValue, "askValue must not be null!");
        Assert.notNull(bidValue, "bidValue must not be null!");
        ExchangeRate exchangeRate = new ExchangeRate();
        exchangeRate.askValue = RateValue.preciseTo8Decimals(askValue);
        exchangeRate.bidValue = RateValue.preciseTo8Decimals(bidValue);
        return exchangeRate;
    }

    public static final ExchangeRate ZERO = ExchangeRate.of(RateValue.ZERO, RateValue.ZERO);

    public static final ExchangeRate ONE = ExchangeRate.of(RateValue.ONE, RateValue.ONE);
}
