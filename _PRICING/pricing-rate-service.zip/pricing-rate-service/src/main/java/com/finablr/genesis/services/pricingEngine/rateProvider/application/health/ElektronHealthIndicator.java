package com.finablr.genesis.services.pricingEngine.rateProvider.application.health;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.AbstractReactiveHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Health.Builder;
import org.springframework.boot.actuate.health.Status;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.finablr.genesis.services.pricingEngine.rateProvider.application.service.tnr.TnRClient;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.ApplicationProperties;
import com.finablr.genesis.services.pricingEngine.rateProvider.infra.config.SpringProfiles;
import com.thomsonreuters.ema.access.ChannelInformation;
import com.thomsonreuters.ema.access.ChannelInformation.ChannelState;

import reactor.core.publisher.Mono;

@Component
public class ElektronHealthIndicator extends AbstractReactiveHealthIndicator {

    @Lazy
    @Autowired
    private TnRClient tnrClient;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Override
    protected Mono<Health> doHealthCheck(final Builder builder) {
        if (!SpringProfiles.isTnREnabled()) {
            return Mono.just(builder.status(new Status("DISABLED", "Thomson & Reuters is disabled")).build());
        }
        else {
            Optional<ChannelInformation> channelInformation = this.tnrClient.channelInformation();
            if (!channelInformation.isPresent()) {
                return Mono.just(builder
                        .status(new Status("TIME_OUT", "Getting channel information is taking too long, retry later"))
                        .build());
            }
            else {
                return Mono.just(channelState(builder, channelInformation.get().channelState())
                        .withDetail("componentInformation", channelInformation.get().componentInformation())
                        .withDetail("hostname", channelInformation.get().hostname())
                        .withDetail("port", applicationProperties.getThomson().getRsslPort())
                        .withDetail("username", mask(applicationProperties.getThomson().getUsername())).build());
            }
        }
    }

    private Builder channelState(final Builder builder, int _channelState) {
        switch (_channelState) {
        case ChannelState.CLOSED:
            return builder.status(new Status("CLOSED", "Channel is closed, needs re-initialization"));
        case ChannelState.INACTIVE:
            return builder.status(new Status("INACTIVE", "Channel is inactive, needs re-initialization"));
        case ChannelState.INITIALIZING:
            return builder.status(new Status("INITIALIZING", "Channel is initializing, please wait for some time"));
        case ChannelState.ACTIVE:
            return builder.status(new Status("ACTIVE", "Channel is up and running"));
        default:
            return builder.status(new Status("UNKNOWN", "Channel state is unknown"));
        }
    }

    private static String mask(final String username) {
        String maskStr = StringUtils.repeat("*", username.length() - 5);
        return StringUtils.overlay(username, maskStr, 2, username.length() - 3);
    }
}
