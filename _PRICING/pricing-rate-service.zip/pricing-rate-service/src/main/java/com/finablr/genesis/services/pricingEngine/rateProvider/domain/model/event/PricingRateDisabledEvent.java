package com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@ToString
public class PricingRateDisabledEvent {

    private String rateId;

    @JsonCreator
    public static PricingRateDisabledEvent of(final @JsonProperty("rateId") String rateId) {
        PricingRateDisabledEvent providedRateDisableEvent = new PricingRateDisabledEvent();
        providedRateDisableEvent.rateId = rateId;
        return providedRateDisableEvent;
    }
}
