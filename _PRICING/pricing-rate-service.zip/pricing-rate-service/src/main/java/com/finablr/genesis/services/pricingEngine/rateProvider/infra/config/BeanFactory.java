package com.finablr.genesis.services.pricingEngine.rateProvider.infra.config;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.JobExecution;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.dashboard.RateRecord;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.RateChangeEvent;
import com.finablr.genesis.services.pricingEngine.rateProvider.domain.model.event.StreamStatusEvent;
import com.google.gson.Gson;

import reactor.core.publisher.EmitterProcessor;
import reactor.core.publisher.FluxSink;
import reactor.core.publisher.FluxSink.OverflowStrategy;

@Configuration
public class BeanFactory implements ApplicationContextAware {

    private static ApplicationContext applicationContext;

    @Override
    @Autowired
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        BeanFactory.applicationContext = applicationContext;
    }

    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    public static <T> T getBean(Class<T> requiredType) {
        return applicationContext.getBean(requiredType);
    }

    public static <T> T getBean(String name, Class<T> requiredType) {
        return applicationContext.getBean(name, requiredType);
    }

    public static ApplicationProperties applicationProperties() {
        return getBean(ApplicationProperties.class);
    }

    public static EmitterProcessor<JobExecution> getScheduleEmitter() {
        return getBean(BeanFactory.class).scheduleEmitter();
    }

    public static EmitterProcessor<StreamStatusEvent> getStreamStatusEmitter() {
        return getBean(BeanFactory.class).streamStatusEmitter();
    }

    @Bean
    public Gson gson() {
        return new Gson();
    }

    @Bean
    @Profile(SpringProfiles.TnR)
    public EmitterProcessor<StreamStatusEvent> streamStatusEmitter() {
        return EmitterProcessor.create();
    }

    @Bean
    @Profile(SpringProfiles.TnR)
    public FluxSink<StreamStatusEvent> streamStatusSink(final EmitterProcessor<StreamStatusEvent> streamStatusEmitter) {
        return streamStatusEmitter.sink();
    }

    @Bean
    @Profile(SpringProfiles.QUARTZ)
    public EmitterProcessor<JobExecution> scheduleEmitter() {
        return EmitterProcessor.create();
    }

    @Bean
    @Profile(SpringProfiles.QUARTZ)
    public FluxSink<JobExecution> scheduleSink(final EmitterProcessor<JobExecution> scheduleEmitter) {
        return scheduleEmitter.sink();
    }

    @Bean
    public EmitterProcessor<RateChangeEvent> rateEmitter() {
        return EmitterProcessor.create();
    }

    @Bean
    public FluxSink<RateChangeEvent> rateSink(final EmitterProcessor<RateChangeEvent> rateEmitter) {
//        return rateEmitter.sink(OverflowStrategy.LATEST);
        return rateEmitter.sink();
    }

    @Bean
    public EmitterProcessor<RateRecord> dashboardEmitter() {
        return EmitterProcessor.create(false);
    }

    @Bean
    public FluxSink<RateRecord> dashboardSink(final EmitterProcessor<RateRecord> dashboardEmitter) {
        return dashboardEmitter.sink(OverflowStrategy.DROP);
    }
}
