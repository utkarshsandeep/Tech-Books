package com.unimoni.pricingengine.domain.model.rate.base.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AgentOnboardResponse {
	private Integer id;
	private String name;
	private String displayName;
	private String code;
	
	
	public AgentOnboardResponse(@JsonProperty Integer id, @JsonProperty String name, 
				@JsonProperty String displayName,@JsonProperty String code) {
		this.id = id;
		this.name = name;
		this.displayName = displayName;
		this.code = code;
	}
}
