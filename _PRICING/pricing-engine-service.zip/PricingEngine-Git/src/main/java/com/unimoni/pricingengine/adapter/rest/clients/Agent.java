package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Agent {

    private String name;

    private String code;

    public Agent(@JsonProperty("name") String name, @JsonProperty("code") String code) {
        this.name = name;
        this.code = code;
    }

    public CodeLabelPair<String, String> agentItem() {
        return CodeLabelPair.of(this.code, this.name);
    }
}
