package com.unimoni.pricingengine.application.audit;

import org.hibernate.envers.RevisionListener;

import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.infra.advice.UserIdentityAdvice;

public class RevisionEntityListener implements RevisionListener {

    @Override
    public void newRevision(Object revisionEntity) {
        if (revisionEntity instanceof RevisionInfo) {
            RevisionInfo revisionInfo = (RevisionInfo) revisionEntity;
            // customRevisionEntity.setModifiedBy(SecurityUtils.getCurrentUserLogin().orElse(Constants.ANONYMOUS_USER));
//            revisionInfo.setUpdatedBy(ApplicationConstants.SYSTEM_USER);
            revisionInfo.setUpdatedBy(UserIdentityAdvice.getUserIdentity());
            revisionInfo.setUpdatedOn(DateTimeHelper.nowZonedDateTimeUTC());
        }
    }
}
