package com.unimoni.pricingengine.adapter.rest.controller.var;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addError;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.VAR_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.VAR_CREATION_FAILED;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.VAR_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.BANK_WISE_VAR_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.NORMAL_VAR_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_BANK_WISE_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_BANK_WISE_META_DATA_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_BANK_WISE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_CALCULATE_MARGIN_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_CALCULATE_SETTLEMENT_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_NORMAL_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_NORMAL_META_DATA_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_NORMAL_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Var.VAR_RM_TYPE_URI;
import static com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType.AT_LEAST_ONE_OF_MARGIN_ASK_OR_MARGIN_BID_REQUIRED;
import static com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType.AT_LEAST_ONE_OF_SETTLEMENT_SELL_OR_SETTLEMENT_BUY_REQUIRED;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.money.CurrencyUnit;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.base.dto.FormulaValue;
import com.unimoni.pricingengine.domain.model.rate.base.dto.UpdateRequest;
import com.unimoni.pricingengine.domain.model.rate.composable.Exchange;
import com.unimoni.pricingengine.domain.model.rate.composable.Margin;
import com.unimoni.pricingengine.domain.model.rate.composable.Settlement;
import com.unimoni.pricingengine.domain.model.rate.var.dto.CreateVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.SearchVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.UpdateVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRMetaData;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRResponse;
import com.unimoni.pricingengine.domain.service.var.VaRService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "VaR", description = "Volatility Margin (VaR Layer)", tags = "3rd Layer")
@RestController
@RequestMapping(PRICING_API)
public class VarController {

    @Autowired
    private VaRService varService;

    @Autowired
    private PaginatedResourceAssembler<VaRResponse, String> varPageAssembler;

    private final CopyOnWriteArrayList<SseEmitter> normalVAREmitters = new CopyOnWriteArrayList<>();

    private final CopyOnWriteArrayList<SseEmitter> bankWiseVAREmitters = new CopyOnWriteArrayList<>();

    @GetMapping(VAR_NORMAL_META_DATA_URI)
    // @formatter:off
    @ApiOperation( nickname = "get-meta-data-to-create-normal-vars", 
        value = "Checks if IBR rates exist, duplicate records exists "
                + "and accordingly return the meta data to create new VaR records", 
        notes = "", 
        response = VaRMetaData.class)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", required = true,
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public ResponseEntity<VaRMetaData> reviewCreateNormalVars(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", required = true, example = "AGNT00X1")
            @RequestParam(value = "agents", required = true) @NotEmpty final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", required = true, example = "UAE")
            @RequestParam(value = "serviceProviders", required = true) @NotEmpty final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", required = true, example = "Remittance")
            @RequestParam(value = "products", required = true) @NotEmpty final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", required = true, example = "Account Credit")
            @RequestParam(value = "subProducts", required = true) @NotEmpty final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", required = true, example = "Flash")
            @RequestParam(value = "serviceTypes", required = true) @NotEmpty final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> currencies) {
    // @formatter:on 
        return ResponseEntity.ok(varService.createVaRMetaData(RMType.NORMAL,
                VaRRequest.ofNormal(serviceProviders, products, subProducts, serviceTypes, currencies, agents)));
    }

    @GetMapping(VAR_BANK_WISE_META_DATA_URI)
    // @formatter:off
    @ApiOperation( nickname = "get-meta-data-to-create-bank-wise-vars", 
        value = "Checks if IBR rates exist, duplicate records exists "
                + "and accordingly return the meta data to create new VaR records", 
        notes = "", 
        response = VaRMetaData.class)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", required = true,
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public ResponseEntity<VaRMetaData> reviewCreateBankWiseVars(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", required = true, example = "HDFC")
            @RequestParam(value = "banks", required = true) @NotEmpty final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1etc.", required = true, example = "AGNT00X1")
            @RequestParam(value = "agents", required = true) @NotEmpty final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", required = true, example = "UAE")
            @RequestParam(value = "serviceProviders", required = true) @NotEmpty final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", required = true, example = "Remittance")
            @RequestParam(value = "products", required = true) @NotEmpty final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", required = true, example = "Account Credit")
            @RequestParam(value = "subProducts", required = true) @NotEmpty final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", required = true, example = "Flash")
            @RequestParam(value = "serviceTypes", required = true) @NotEmpty final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> currencies) {
    // @formatter:on 
        return ResponseEntity.ok(varService.createVaRMetaData(RMType.BANK_WISE, VaRRequest.ofBankWise(serviceProviders,
                products, subProducts, serviceTypes, currencies, banks, agents)));
    }

    @PostMapping(VAR_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "create-vars", 
        value = "Creates one or multiple new VaR records", 
        notes = "", 
        response = List.class
    )
    @ApiResponses(value = { 
            @ApiResponse(response = VaRResponse.class, responseContainer = "List", code = 201, 
                    message = "One or more records created successfully"),
            @ApiResponse(code = 400, message = "Could not create records for supplied input") 
        }
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    @Valid
    public ResponseEntity<List<VaRResponse>> createVaRs(
            final @PathVariable(name = "rmType", required = true) RMType rmType,
            @RequestBody @Valid @NotEmpty final List<@NotNull CreateVaRRequest> createRequests) {
        // @formatter:on 

        if (rmType.isBankWise()) {
            createRequests.forEach((createRequest) -> {
                if (!createRequest.getBank().isPresent()) {
                    throw new RateException(RateExceptionExceptionType.BANK_REQUIRED_FOR_BANK_WISE_REQUEST,
                            Status.BAD_REQUEST);
                }
                createRequest.getValueDateWises().values().forEach(x -> {
                    validatePositive(x.getSettlement().getSellValue(), "Settlement Sell Value");
                    validatePositive(x.getSettlement().getBuyValue(), "Settlement Buy Value");
                });
            });
        }
        List<VaRResponse> newVars = varService.createVaRs(rmType, createRequests);
        if (!newVars.isEmpty()) { // All created
            return ResponseEntity.status(HttpStatus.CREATED)
                    .headers(addSuccess(getMessage(VAR_CREATED_SUCCESSFULLY, newVars.size()))).body(newVars);
        }
        else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(addError(getMessage(VAR_CREATION_FAILED)))
                    .build();
        }
    }

    @PatchMapping(VAR_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-vars", 
        value = "Updates one or multiple VaR records", 
        notes = "Request should only contain the updated values "
                + "If a value is not changed the respective value should not be there in request", 
        response = VaRResponse.class,
        responseContainer = "List"
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<List<VaRResponse>> updateVars(final @PathVariable(name = "rmType", required = true) RMType rmType,
            @RequestBody @Valid @NotEmpty final UpdateRequest<@NotEmpty String, @NotNull UpdateVaRRequest> updateRequest) {
    // @formatter:on

        updateRequest.getUpdates().values().stream().filter(x -> x.getValueDateWises().isPresent()).map(x -> {
            return x.getValueDateWises().get().values();
        }).flatMap(x -> x.stream()).forEach(x -> {
            validatePositive(x.getSettlement().getSellValue(), "Settlement Sell Value");
            validatePositive(x.getSettlement().getBuyValue(), "Settlement Buy Value");
        });

        List<VaRResponse> results = varService.updateVaRs(rmType, updateRequest, Optional.of(true));
        return ResponseEntity.ok().headers(addSuccess(getMessage(VAR_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }

    @GetMapping(VAR_NORMAL_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-normal-vars", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Normal VaR records matching the selection filters and sort criteria", 
        notes = "",
        response = VaRResponse.class,
        responseContainer = "PaginatedResource")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Paginated
    @Valid
    public ResponseEntity<PaginatedResource<Resource<VaRResponse>>> getAllNormalVaRs(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @ApiIgnore @RequestParam Map<String, Object> requestParams) {
    // @formatter:on
        List<VaRResponse> results = varService.getAllVaRs(SearchVaRRequest.ofNormal(agents, serviceProviders, products,
                subProducts, serviceTypes, currencies, status, page));

        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(varPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(VAR_NORMAL_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-normal-vars", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Normal VaR records matching the selection filters and sort criteria", 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public void downloadNormalVaRs(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status,
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on

        FileDownloadHelper.downloadFile(
                SearchVaRRequest.ofNormalDownload(agents, serviceProviders, products, subProducts, serviceTypes,
                        currencies, status),
                varService::getAllVaRs, downloadFileType, fileName, DownloadContext.NORMAL_VAR, response);
    }

    @GetMapping(VAR_BANK_WISE_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-bank-wise-vars", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Bank wise VaR records matching the selection filters and sort criteria", 
        notes = "",
        response = VaRResponse.class,
        responseContainer = "PaginatedResource")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Paginated
    @Valid
    public ResponseEntity<PaginatedResource<Resource<VaRResponse>>> getAllBankWiseVaRs(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @ApiIgnore @RequestParam Map<String, Object> requestParams) {
    // @formatter:on

        List<VaRResponse> results = varService.getAllVaRs(SearchVaRRequest.ofBankWise(agents, banks, serviceProviders,
                products, subProducts, serviceTypes, currencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(varPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(VAR_BANK_WISE_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-bank-wise-vars", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Bank wise VaR records matching the selection filters and sort criteria", 
        notes = "",
        response = Void.class,
        responseContainer = "PaginatedResource"
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public void downloadBankWiseVaRs(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on

        FileDownloadHelper.downloadFile(
                SearchVaRRequest.ofBankWiseDownload(agents, banks, serviceProviders, products, subProducts,
                        serviceTypes, currencies, status),
                varService::getAllVaRs, downloadFileType, fileName, DownloadContext.BANK_WISE_VAR, response);
    }

    @GetMapping(VAR_CALCULATE_MARGIN_URI)
    // @formatter:off
    @ApiOperation(nickname = "calculate-margin", 
            value = "Calculates and returns Margin Ask value if given with Margin Buy value or "
                    + "Calculates and returns Margin Bid value if given with Margin Ask value "
                    + "for VaR of provided Value Date Wise"
                    + " as per following formulas: Exactly one of Margin Ask or Margin Buy value is mandatory", 
        notes = "<b>For scenario where From Currency = USD</b>" + 
                "        <ul><li>Ask margin = Settlement Buy - IBR Ask</li>" + 
                "        <li>Bid Margin = IBR Bid - Settlement Sell</li></ul>"
                + "<b>For scenario where To currency = USD</b>" + 
                "        <ul><li>Ask Margin = Settlement Sell – IBR Ask</li>" + 
                "        <li>Bid Margin = IBR Bid – Settlement Buy</li></ul>", 
        response = FormulaValue.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "sourceCurrency", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Source Currency Code in ISO format e.g. USD", allowMultiple = false, 
            example = "INR", required = true
        ),
        @ApiImplicitParam(name = "targetCurrency", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Target Currency Code in ISO format e.g. USD", allowMultiple = false, 
            example = "INR", required = true
        )
    })
    @Valid
    public ResponseEntity<FormulaValue> calculateMargin(
            @RequestParam(value = "sourceCurrency", required = true) @NotNull final CurrencyUnit sourceCurrency,
            @RequestParam(value = "targetCurrency", required = true) @NotNull final CurrencyUnit targetCurrency,
            @ApiParam(name = "ibrAskValue", value = "IBR ask value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "ibrAskValue", required = true) @NotNull final BigDecimal ibrAskValue,
            @ApiParam(name = "ibrBidValue", value = "IBR bid value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "ibrBidValue", required = true) @NotNull final BigDecimal ibrBidValue,
            @ApiParam(name = "settlementSell", value = "Settlement sell value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = false, example = "75.32560000")
            @RequestParam(value = "settlementSell", required = false) final Optional<BigDecimal> settlementSell,
            @ApiParam(name = "settlementBuy", value = "Settlement buy value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = false, example = "75.32560000")
            @RequestParam(value = "settlementBuy", required = false) final Optional<BigDecimal> settlementBuy) {
    // @formatter:on 

        if ((!settlementSell.isPresent() && !settlementBuy.isPresent())
                || (settlementSell.isPresent() && settlementBuy.isPresent())) {
            throw new RateException(AT_LEAST_ONE_OF_SETTLEMENT_SELL_OR_SETTLEMENT_BUY_REQUIRED);
        }
        return ResponseEntity.ok(Margin.byFormula(Exchange.of(sourceCurrency, targetCurrency, ibrAskValue, ibrBidValue),
                settlementSell, settlementBuy));
    }

    @GetMapping(VAR_CALCULATE_SETTLEMENT_URI)
    // @formatter:off
    @ApiOperation(nickname = "calculate-settlement", 
            value = "Calculates and returns Settlement Sell value if given with Settlement Buy value or "
                    + "Calculates and returns Settlement Buy value if given with Settlement Sell value "
                    + "for VaR of provided Value Date Wise"
                    + " as per following formulas: Exactly one of Settlement Buy or Settlement Sell value is mandatory", 
        notes = "<b>For scenario where From Currency = USD</b>" + 
                "        <ul><li>Settlement Sell = IBR Bid – Bid Margin</li>" + 
                "        <li>Settlement Buy = IBR Ask + Ask Margin</li></ul>"
                + "<b>For scenario To Currency = USD</b>\n" + 
                "        <ul><li>Settlement Sell = 1/(IBR Ask + Ask Margin)</li>" + 
                "        <li>Settlement Buy = 1/(IBR Bid – Bid Margin)</li></ul>", 
        response = FormulaValue.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "sourceCurrency", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Source Currency Code in ISO format e.g. USD", allowMultiple = false, 
            example = "INR", required = true
        ),
        @ApiImplicitParam(name = "targetCurrency", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Target Currency Code in ISO format e.g. USD", allowMultiple = false, 
            example = "INR", required = true
        )
    })
    @Valid
    public ResponseEntity<FormulaValue> calculateSettlement(
            @RequestParam(value = "sourceCurrency", required = true) @NotNull final CurrencyUnit sourceCurrency,
            @RequestParam(value = "targetCurrency", required = true) @NotNull final CurrencyUnit targetCurrency,
            @ApiParam(name = "ibrAskValue", value = "IBR ask value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "ibrAskValue", required = true) @NotNull final BigDecimal ibrAskValue,
            @ApiParam(name = "ibrBidValue", value = "IBR bid value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "ibrBidValue", required = true) @NotNull final BigDecimal ibrBidValue,
            @ApiParam(name = "marginAsk", value = "Margin ask value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = false, example = "75.32560000")
            @RequestParam(value = "marginAsk", required = false) final Optional<BigDecimal> marginAsk,
            @ApiParam(name = "marginBid", value = "Margin bid value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = false, example = "75.32560000")
            @RequestParam(value = "marginBid", required = false) final Optional<BigDecimal> marginBid) {
    // @formatter:on 

        if ((!marginAsk.isPresent() && !marginBid.isPresent()) || (marginAsk.isPresent() && marginBid.isPresent())) {
            throw new RateException(AT_LEAST_ONE_OF_MARGIN_ASK_OR_MARGIN_BID_REQUIRED);
        }
        return ResponseEntity.ok(Settlement.byFormula(
                Exchange.of(sourceCurrency, targetCurrency, ibrAskValue, ibrBidValue), marginAsk, marginBid));
    }

    // --------------------- Server Sent Events Code Start --------------------------

    @GetMapping(NORMAL_VAR_SERVER_SENT_EVENTS)
    public SseEmitter sendNormalVARSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.normalVAREmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.normalVAREmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.normalVAREmitters.remove(emitter);
        });

        return emitter;
    }

    @GetMapping(BANK_WISE_VAR_SERVER_SENT_EVENTS)
    public SseEmitter sendBankWiseVARSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.bankWiseVAREmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.bankWiseVAREmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.bankWiseVAREmitters.remove(emitter);
        });

        return emitter;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleServerSentEvents(VaRResponse varResponse) {
        List<SseEmitter> normalDeadEmitters = new ArrayList<>();
        List<SseEmitter> bankDeadEmitters = new ArrayList<>();

        if (varResponse.getBank() != null && !varResponse.getBank().isEmpty()) {
            this.bankWiseVAREmitters.forEach(emitter -> {
                try {
                    emitter.send(varResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    bankDeadEmitters.add(emitter);
                }
            });

            this.bankWiseVAREmitters.removeAll(bankDeadEmitters);
        }
        else {
            this.normalVAREmitters.forEach(emitter -> {
                try {
                    emitter.send(varResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    normalDeadEmitters.add(emitter);
                }
            });

            this.normalVAREmitters.removeAll(normalDeadEmitters);
        }
    }

    // --------------------- Server Sent Events Code Ends --------------------------
}
