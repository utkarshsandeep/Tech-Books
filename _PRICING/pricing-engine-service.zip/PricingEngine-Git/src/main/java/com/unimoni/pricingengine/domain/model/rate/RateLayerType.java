package com.unimoni.pricingengine.domain.model.rate;

import java.util.EnumSet;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;
import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "rateLayerType", description = "Rate Layer Type")
public enum RateLayerType {

    // @formatter:off
    IBM_MANAGEMENT("IBR Management"),
    INTER_BANK_RATES("Inter Bank Rates"),
    VOLATILITY_MARGIN("Volatility Margin"),
    SETTLEMENT_MARGIN("Settlement Margin");
    // @formatter:on

    private final String description;

    private static final EnumSet<RateLayerType> ALL_VALUES = EnumSet.allOf(RateLayerType.class);

    private RateLayerType(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }

    @JsonCreator
    public static RateLayerType of(final String name) {
        for (RateLayerType e : values())
            if (e.name().equals(name))
                return e;
        throw new IllegalArgumentException();
    }
    
    @JsonValue
    public Pair<String, String> toPairType() {
        return Pair.of(this.name(), this.description());
    }
    
    public CodeNamePair<String, String> toPair() {
        return CodeNamePair.of(this.name(), this.description());
    }

    public static EnumSet<RateLayerType> all() {
        return ALL_VALUES;
    }

    public static List<CodeNamePair<String, String>> listItems() {
        return ALL_VALUES.stream().map(RateLayerType::toPair).collect(ImmutableCollectors.toImmutableList());
    }
}
