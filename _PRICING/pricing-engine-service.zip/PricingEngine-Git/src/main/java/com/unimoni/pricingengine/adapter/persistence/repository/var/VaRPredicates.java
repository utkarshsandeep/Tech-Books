package com.unimoni.pricingengine.adapter.persistence.repository.var;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;
import static com.unimoni.pricingengine.common.constants.ApplicationConstants.CURRENCY_UNIT_USD;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.money.CurrencyUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments_;
import com.unimoni.pricingengine.domain.model.rate.composable.CurrencyExchange;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments_;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.domain.model.rate.var.VaR_;
import com.unimoni.pricingengine.domain.model.rate.var.dto.SearchVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRIdentity;

//This class is just as helper having static helper methods, never supposed to be instantiated, so marked abstract
public abstract class VaRPredicates {

    public static Predicate getVaRdentityPredicates(final Root<VaR> root, final CriteriaBuilder criteriaBuilder,
            final RMType rmType, final VaRIdentity varIdentity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(VaR_.rmType.getName()), rmType));
        predicates.add(
                criteriaBuilder.equal(root.get(VaR_.instruments.getName()), varIdentity.getInstruments().toModel()));
        predicates.add(criteriaBuilder.equal(root.get(VaR_.agent.getName()), varIdentity.getAgent()));
        if (rmType.isBankWise()) {
            predicates.add(criteriaBuilder.equal(root.get(VaR_.bank.getName()), varIdentity.getBank().get()));
        }
        predicates.add(criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency"),
                varIdentity.getCurrency().toModel()));

        return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

    }

    public static Predicate[] getSearchVaRsPredicates(final Root<VaR> root, final CriteriaBuilder criteriaBuilder,
            final SearchVaRRequest searchRequest) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(VaR_.rmType.getName()), searchRequest.getRmType()));
        if (searchRequest.getAgents() != null && !searchRequest.getAgents().isEmpty()) {
            predicates.add(root.get(VaR_.agent.getName()).in(searchRequest.getAgents()));
        }
        if (searchRequest.getRmType().isBankWise() && searchRequest.getBanks() != null
                && !searchRequest.getBanks().isEmpty()) {
            predicates.add(root.get(VaR_.bank.getName()).in(searchRequest.getBanks()));
        }
        if (searchRequest.getServiceProviders() != null && !searchRequest.getServiceProviders().isEmpty()) {
            predicates.add(root.get(VaR_.instruments.getName()).get(AllInstruments_.serviceProvider.getName())
                    .in(searchRequest.getServiceProviders()));
        }
        if (searchRequest.getProducts() != null && !searchRequest.getProducts().isEmpty()) {
            predicates.add(root.get(VaR_.instruments.getName()).get(AllInstruments_.product.getName())
                    .in(searchRequest.getProducts()));
        }
        if (searchRequest.getSubProducts() != null && !searchRequest.getSubProducts().isEmpty()) {
            predicates.add(root.get(VaR_.instruments.getName()).get(AllInstruments_.subProduct.getName())
                    .in(searchRequest.getSubProducts()));
        }
        if (searchRequest.getServiceTypes() != null && !searchRequest.getServiceTypes().isEmpty()) {
            predicates.add(root.get(VaR_.instruments.getName()).get(AllInstruments_.serviceType.getName())
                    .in(searchRequest.getServiceTypes()));
        }
        if (searchRequest.getCurrencies() != null) {
            Predicate usdCurrencyPredicate = null;
            if (searchRequest.isUsdCurrency()) {
                usdCurrencyPredicate = criteriaBuilder.and(
                        criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency").get("source"),
                                CURRENCY_UNIT_USD),
                        criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency").get("target"),
                                CURRENCY_UNIT_USD));
            }
            Predicate nonUSDCurrenciesPredicate = null;
            if (searchRequest.getCurrencies() != null && !searchRequest.getCurrencies().isEmpty()) {
                nonUSDCurrenciesPredicate = criteriaBuilder.or(
                        root.get(VaR_.exchange.getName()).get("currency").get("source")
                                .in(searchRequest.getCurrencies()),
                        root.get(VaR_.exchange.getName()).get("currency").get("target")
                                .in(searchRequest.getCurrencies()));
            }
            predicates
                    .add(criteriaBuilder.or(usdCurrencyPredicate != null ? usdCurrencyPredicate : criteriaBuilder.or(),
                            nonUSDCurrenciesPredicate != null ? nonUSDCurrenciesPredicate : criteriaBuilder.or()));
        }

        if (searchRequest.getStatus() != null) {
            predicates.add(criteriaBuilder.equal(root.get(VaR_.enabled.getName()), searchRequest.getStatus()));
        }
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate getBasicPredicatesForHighestPriorityFetch(final Root<VaR> root,
            final CriteriaBuilder criteriaBuilder, final RMType rmType, final String serviceProvider,
            final String product, final String subProduct, final String serviceType, final String agent,
            final Optional<String> bank) {
        return criteriaBuilder.and(criteriaBuilder.equal(root.get(VaR_.rmType.getName()), rmType),
                criteriaBuilder.or(
                        criteriaBuilder.equal(root.get(VaR_.instruments.getName())
                                .get(RateInstruments_.serviceProvider.getName()), serviceProvider),
                        criteriaBuilder.equal(
                                root.get(VaR_.instruments.getName()).get(RateInstruments_.serviceProvider.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(VaR_.instruments.getName()).get(RateInstruments_.product.getName()), product),
                        criteriaBuilder
                                .equal(root.get(VaR_.instruments.getName()).get(RateInstruments_.product.getName()),
                                        ALL_INSTRUMENTS)),
                criteriaBuilder.or(criteriaBuilder.equal(
                        root.get(VaR_.instruments.getName()).get(AllInstruments_.subProduct.getName()), subProduct),
                        criteriaBuilder.equal(
                                root.get(VaR_.instruments.getName()).get(AllInstruments_.subProduct.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.or(criteriaBuilder.equal(
                        root.get(VaR_.instruments.getName()).get(AllInstruments_.serviceType.getName()), serviceType),
                        criteriaBuilder.equal(
                                root.get(VaR_.instruments.getName()).get(AllInstruments_.serviceType.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.or(criteriaBuilder.equal(root.get(VaR_.agent.getName()), agent),
                        criteriaBuilder.equal(root.get(VaR_.agent.getName()), ALL_INSTRUMENTS)),

                criteriaBuilder.equal(root.get(VaR_.enabled.getName()), true),

                rmType.isBankWise()
                        ? criteriaBuilder.or(criteriaBuilder.equal(root.get(VaR_.bank.getName()), bank.get()),
                                criteriaBuilder.equal(root.get(VaR_.bank.getName()), ALL_INSTRUMENTS))
                        : criteriaBuilder.and());
    }

    public static Predicate getCurrencyPredicateForHighestPriorityFetch(final Root<VaR> root,
            final CriteriaBuilder criteriaBuilder, final CurrencyUnit currency) {
        if (CURRENCY_UNIT_USD == currency) {
            return criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency").get("source"),
                            CURRENCY_UNIT_USD),
                    criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency").get("target"),
                            CURRENCY_UNIT_USD));
        }
        else {
            return criteriaBuilder.or(
                    criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency").get("source"), currency),
                    criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency").get("target"), currency));
        }
    }

    public static Predicate getCurrencyPairPredicateForHighestPriorityFetch(final Root<VaR> root,
            final CriteriaBuilder criteriaBuilder, final CurrencyExchange currencyExchange) {
        return criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency"), currencyExchange);
    }
}
