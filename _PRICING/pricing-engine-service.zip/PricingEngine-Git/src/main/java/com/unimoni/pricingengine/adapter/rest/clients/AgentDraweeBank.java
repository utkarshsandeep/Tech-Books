package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgentDraweeBank {

    private long agentId;

    private String agentName;

    private long agentBranchId;

    private String agentBranchName;

    private Long draweeBankProductProfileId;

    public AgentDraweeBank(@JsonProperty("agentId") long agentId, @JsonProperty("agentName") String agentName,
            @JsonProperty("agentBranchId") long agentBranchId, @JsonProperty("agentBranchName") String agentBranchName,
            @JsonProperty("draweeBankProductProfileId") Long draweeBankProductProfileId) {
        this.agentId = agentId;
        this.agentName = agentName;
        this.agentBranchId = agentBranchId;
        this.agentBranchName = agentBranchName;
        this.draweeBankProductProfileId = draweeBankProductProfileId;
    }

    public CodeLabelPair<String, String> agentDraweeBankItem() {
        return CodeLabelPair.of("" + this.agentBranchId, "" + this.agentId );
    }
}
