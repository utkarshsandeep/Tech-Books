package com.unimoni.pricingengine.application.service.amigo.event;

import java.time.ZonedDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.unimoni.pricingengine.application.security.SecurityConstants;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.PaasToAmigoStandardChargeResponse;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class StandardChargeCreatedEvent extends AmigoStandardChargeEvent {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;
    
    @NonNull
    private final String updatedBy;
    
    @NonNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ApplicationConstants.AMIGO_DATE_TIME_FORMAT_STANDARD_CHARGE)
    private ZonedDateTime updatedOn;
    
    private PaasToAmigoStandardChargeResponse standardCharge;

    private StandardChargeCreatedEvent(final Type type, final PaasToAmigoStandardChargeResponse standardCharge,
            ZonedDateTime updatedOn) {
        super(type);
        this.updatedBy = SecurityConstants.SYSTEM_USER;
        this.updatedOn = updatedOn;
        this.standardCharge = standardCharge;
    }

    public static StandardChargeCreatedEvent of(final Type type, final PaasToAmigoStandardChargeResponse item,
            ZonedDateTime updatedOn) {
        return new StandardChargeCreatedEvent(type, item, updatedOn);
    }
}
