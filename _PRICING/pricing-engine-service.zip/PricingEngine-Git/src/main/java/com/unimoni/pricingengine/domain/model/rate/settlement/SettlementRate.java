package com.unimoni.pricingengine.domain.model.rate.settlement;

import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.money.CurrencyUnit;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyClass;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.envers.AuditMappedBy;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.unimoni.pricingengine.application.event.listner.EntityChangeListener;
import com.unimoni.pricingengine.application.service.amigo.event.SettlementRateUpdatedEvent;
import com.unimoni.pricingengine.application.service.event.EventPublisher;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.builder.Builder;
import com.unimoni.pricingengine.domain.model.common.type.BaseUUIDIdentifiableVersionableEntity;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.base.dto.CurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.composable.CurrencyExchange;
import com.unimoni.pricingengine.domain.model.rate.composable.Settlement;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.domain.model.remittance.SellBuyRate;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@Slf4j
@Entity
@EntityListeners(EntityChangeListener.class)
//@formatter:off
@Table(name = "SETTLEMENT_RATES",   
    indexes = {
        @Index(name = "IDX_SETTLEMENT_RATES_BANK_CODE", columnList = "BANK_CODE"),
        @Index(name = "IDX_SETTLEMENT_RATES_AGENT_CODE", columnList = "AGENT_CODE"),
        @Index(name = "IDX_SETTLEMENT_RATES_SOURCE_CURRENCY", columnList = "SOURCE_CURRENCY"),
        @Index(name = "IDX_SETTLEMENT_RATES_TARGET_CURRENCY", columnList = "TARGET_CURRENCY"),
        @Index(name = "IDX_SETTLEMENT_RATES_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
        @Index(name = "IDX_SETTLEMENT_RATES_PRODUCT_CODE", columnList = "PRODUCT_CODE"),
        @Index(name = "IDX_SETTLEMENT_RATES_SUB_PRODUCT_CODE", columnList = "SUB_PRODUCT_CODE"),
        @Index(name = "IDX_SETTLEMENT_RATES_SERVICE_TYPE_CODE", columnList = "SERVICE_TYPE_CODE"),
        @Index(name = "IDX_SETTLEMENT_RATES_RM_TYPE", columnList = "RM_TYPE"),
        @Index(name = "IDX_SETTLEMENT_RATES_ENABLED", columnList = "ENABLED"),
        @Index(name = "IDX_SETTLEMENT_RATES_PRIORITY", columnList = "PRIORITY")
    }
)
//@formatter:on
@Audited
public class SettlementRate extends BaseUUIDIdentifiableVersionableEntity<String, Long> {

    @NotNull
    @Column(name = "AGENT_CODE", updatable = false, nullable = false, length = 100)
    private String agent;

    @Getter(value = AccessLevel.NONE)
    @Column(name = "BANK_CODE", updatable = false, length = 100)
    private String bank;

    public Optional<String> bank() {
        return Optional.ofNullable(this.bank);
    }

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RM_TYPE", nullable = false, updatable = false, length = 20)
    private RMType rmType;

    @NotNull
    private CurrencyExchange currency;

    @NotNull
    @Embedded
    private AllInstruments instruments;

    // @formatter:off
    @ElementCollection(targetClass = SettlementValueDateWise.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "SETTLEMENT_VALUE_DATE_WISES", 
        joinColumns = { @JoinColumn(name = "SETTLEMENT_RATE_ID", referencedColumnName = "ID") },
        foreignKey = @ForeignKey(name = "FK_SETTLEMENT_VALUE_DATE_WISES_SETTLEMENT_RATE_ID"))
    @MapKeyClass(VDWType.class)
//    @MapKeyEnumerated(EnumType.STRING)
    @MapKeyColumn(name = "VDW_TYPE", nullable = false)
    @org.hibernate.annotations.OrderBy(clause = "VDW_TYPE asc")
    // @formatter:on
    @Getter(value = AccessLevel.NONE)
    @NotNull
    @Size(min = 4, max = 4)
    private Map<@NotNull VDWType, @NotNull SettlementValueDateWise> valueDateWises = new LinkedHashMap<VDWType, SettlementValueDateWise>();

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    // @formatter:off
    @JoinColumn(name = "VAR_ID", unique = false, nullable = false, 
            foreignKey = @ForeignKey(name = "FK_SETTLEMENT_RATES_VAR_ID"))
    //@formatter:on
    @Audited
    private VaR var;

    @OneToMany(mappedBy = "baseSettlement", fetch = FetchType.LAZY)
    @AuditMappedBy(mappedBy = "baseSettlement")
    private Set<CountryRate> basecountryRate = new HashSet<>();

    @OneToMany(mappedBy = "foreignSettlement", fetch = FetchType.LAZY)
    @AuditMappedBy(mappedBy = "foreignSettlement")
    private Set<CountryRate> foreignCountryRate = new HashSet<>();

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "PRIORITY", nullable = false, updatable = false, length = 20)
    private SettlementPriority priority;

    @Getter(value = AccessLevel.NONE)
    @NotNull
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "ENABLED", length = 1)
    private boolean enabled;

    public boolean isEnabled() {
        return this.enabled;
    }

    @NotNull
    // @formatter:off
    @Column(name = "UPDATED_ON", 
            columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    // @formatter:on
    private ZonedDateTime updatedOn;

    @Column(name = "REASON", length = 256)
    private String reason;

    /*
     * New variable to maintain the data for authentication 
     * 
     */    
    @ElementCollection(targetClass = SettlementValueDateWise.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "SETTLEMENT_VALUE_DATE_WISES_T", 
        joinColumns = { @JoinColumn(name = "SETTLEMENT_RATE_ID", referencedColumnName = "ID") },
        foreignKey = @ForeignKey(name = "FK_SETTLEMENT_VALUE_DATE_WISES_T_SETTLEMENT_RATE_ID"))
    @MapKeyClass(VDWType.class)
    @MapKeyColumn(name = "VDW_TYPE", nullable = false)
    @org.hibernate.annotations.OrderBy(clause = "VDW_TYPE asc")
    @Getter(value = AccessLevel.NONE)   
    @Size(min = 0, max = 4)
    @NotAudited
    private Map<VDWType, SettlementValueDateWise> valueDateWisesTemp = new LinkedHashMap<VDWType, SettlementValueDateWise>();

    
    public boolean updateSettlementCostFromVaR(final Map<VDWType, Settlement> vdwSettlements,
            final ZonedDateTime updatedOn) {
        log.debug("SettlementRate, updating settlementCostFromVar on Settlement");

        Map<VDWType, Cost> countryVdws = new HashMap<>(4);
        for (Entry<VDWType, Settlement> vdwEntry : vdwSettlements.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateSettlementCostFromVaR(this.currency.source(),
                    this.currency.target(), vdwSettlements.get(vdwEntry.getKey()))) {
                countryVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).country());
            }
        }
        if (!countryVdws.isEmpty()) {
            this.updatedOn = updatedOn;
            propagateRateChangeToCountryRates(countryVdws);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateMarginCost(final Map<VDWType, Cost> vdwMargins) {
        Map<VDWType, Cost> countryVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwMargins.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateMarginCost(this.currency.source(),
                    this.currency.target(), vdwMargins.get(vdwEntry.getKey()))) {
                countryVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).country());
                if (vdwEntry.getKey().isCash()) {
                    EventPublisher.publishAmigoEvent(SettlementRateUpdatedEvent.forRateChange(this));
                }
            }
        }
        if (!countryVdws.isEmpty()) {
            propagateRateChangeToCountryRates(countryVdws);
            return true;
        }
        else {
            return false;
        }
    }

    public void updateMarginCostTemp(final Map<VDWType, Cost> vdwMargins) {
        Map<VDWType, Cost> countryVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwMargins.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateMarginCost(this.currency.source(),
                    this.currency.target(), vdwMargins.get(vdwEntry.getKey()))) {
                countryVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).country());                
            }
        }
    }
    
    
    public boolean updateStatus(final boolean status) {
        if (this.enabled == status) {
            return false;
        }
        else {
            this.enabled = status;
            if (status == false) { // Propagate only when record is being disabled.
                propagateStatusChangeToCountryRates();
            }
            return true;
        }
    }

    public void updateReason(final String reason) {
        this.reason = reason;
    }

    public void updatedNow() {
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public void updatedOn(final ZonedDateTime zonedDateTime) {
        this.updatedOn = zonedDateTime;
    }

    private void propagateRateChangeToCountryRates(final Map<VDWType, Cost> countryVdws) {
        if (this.basecountryRate != null && !this.basecountryRate.isEmpty()) {
            this.basecountryRate.forEach(countryRate -> {
                if (countryRate.isEnabled()) {
                    countryRate.updateCountryCostFromBaseSettlement(countryVdws, this.updatedOn);
                }
                else {
                    log.debug("Linked Base Country Rate record is disabled, So can not propagate rate changes");
                }
            });
        }
        if (this.foreignCountryRate != null && !this.foreignCountryRate.isEmpty()) {
            this.foreignCountryRate.forEach(countryRate -> {
                if (countryRate.isEnabled()) {
                    countryRate.updateCountryCostFromForiegnSettlement(countryVdws, this.updatedOn);
                }
                else {
                    log.debug("Linked Foreign Country Rate record is disabled, So can not propagate rate changes");
                }
            });
        }
    }

    private void propagateStatusChangeToCountryRates() {
        if (this.basecountryRate != null && !this.basecountryRate.isEmpty()) {
            this.basecountryRate.forEach(basecountryR -> basecountryR.updateStatus(this.enabled));
        }
        if (this.foreignCountryRate != null && !this.foreignCountryRate.isEmpty()) {
            this.foreignCountryRate.forEach(foreignCountryR -> foreignCountryR.updateStatus(this.enabled));
        }
    }

    public Map<VDWType, SettlementValueDateWise> valueDateWises() {
        return Collections.unmodifiableMap(this.valueDateWises);
    }

    public SettlementValueDateWise valueDateWises(final VDWType vdwType) {
        return this.valueDateWises.get(vdwType);
    }
    
    public Map<VDWType, SettlementValueDateWise> valueDateWisesTemp() {
        return this.valueDateWisesTemp;
    }
    
    public void valueDateWisesTemp(final Map<VDWType, SettlementValueDateWise> vdwMap) {
        this.valueDateWisesTemp = vdwMap;
    }

    public SellBuyRate layerCharge(final VDWType vdwType) {
        return SellBuyRate.of(this.valueDateWises.get(vdwType).country());
    }

    public Optional<SettlementValueDateWise> cash() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.CASH));
    }

    public Optional<SettlementValueDateWise> tom() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.TOM));
    }

    public Optional<SettlementValueDateWise> spot() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.SPOT));
    }

    public Optional<SettlementValueDateWise> future() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.FUTURE));
    }

    public void cash(final SettlementValueDateWise cash) {
        this.valueDateWises.put(VDWType.CASH, cash);
    }

    public void tom(final SettlementValueDateWise tom) {
        this.valueDateWises.put(VDWType.TOM, tom);
    }

    public void spot(final SettlementValueDateWise spot) {
        this.valueDateWises.put(VDWType.SPOT, spot);
    }

    public void future(final SettlementValueDateWise future) {
        this.valueDateWises.put(VDWType.FUTURE, future);
    }

    public SettlementIdentity identity() {
        return this.rmType.isNormal()
                ? SettlementIdentity.ofNormal(this.instruments().serviceProvider(), this.instruments().product(),
                        this.instruments().subProduct(), this.instruments().serviceType(), this.agent(),
                        CurrencyDTO.of(this.currency))
                : SettlementIdentity.ofBankWise(this.instruments().serviceProvider(), this.instruments().product(),
                        this.instruments().subProduct(), this.instruments().serviceType(), this.agent(),
                        this.bank().get(), CurrencyDTO.of(this.currency));

    }

    public static VaRBuilder normal(final String agent) {
        return new SettlementRateBuilder(agent, null, RMType.NORMAL);
    }

    public static VaRBuilder bankWise(final String bank, final String agent) {
        return new SettlementRateBuilder(agent, bank, RMType.BANK_WISE);
    }

    public interface VaRBuilder {
        public SourceCurrencyBuilder var(final VaR var);
    }

    public interface CurrencyExchangeBuilder {
        public InstrumentsBuilder currency(final CurrencyExchange currency);
    }

    public interface SourceCurrencyBuilder extends CurrencyExchangeBuilder {
        public TargetCurrencyBuilder source(final CurrencyUnit sourceCurrency);
    }

    public interface InstrumentsBuilder {
        public ValueDateWiseCashBuilder instruments(final AllInstruments instruments);
    }

    public interface TargetCurrencyBuilder {
        public ValueDateWiseCashBuilder target(final CurrencyUnit targetCurrency);
    }

    public interface InstrumentsServiceProviderBuilder extends InstrumentsBuilder {
        public ProductBuilder serviceProvider(final String serviceProvider);
    }

    public interface ProductBuilder {
        public SubProductBuilder product(final String product);
    }

    public interface SubProductBuilder {
        public ServiceTypeBuilder subProduct(final String subProduct);
    }

    public interface ServiceTypeBuilder {
        public ValueDateWiseCashBuilder serviceType(final String serviceType);
    }

    public interface ValueDateWiseCashBuilder {
        public ReasonForChangeBuilder valueDateWises(final Map<VDWType, SettlementValueDateWise> valueDateWises);

        public TomBuilder cash(final SettlementValueDateWise cash);
    }

    public interface TomBuilder extends Builder<SettlementRate> {
        public SpotBuilder tom(final SettlementValueDateWise tom);
    }

    public interface SpotBuilder extends Builder<SettlementRate> {
        public FutureBuilder spot(final SettlementValueDateWise spot);
    }

    public interface FutureBuilder extends Builder<SettlementRate> {
        public ReasonForChangeBuilder future(final SettlementValueDateWise future);
    }

    public interface ReasonForChangeBuilder extends Builder<SettlementRate> {
        public Builder<SettlementRate> reason(final String reason);
    }

    public static class SettlementRateBuilder implements VaRBuilder, SourceCurrencyBuilder, TargetCurrencyBuilder,
            InstrumentsServiceProviderBuilder, ProductBuilder, SubProductBuilder, ServiceTypeBuilder,
            ValueDateWiseCashBuilder, TomBuilder, SpotBuilder, FutureBuilder, ReasonForChangeBuilder {

        private String agent;

        private String bank;

        private RMType rmType;

        private VaR var;

        private CurrencyExchange currency;

        private CurrencyUnit sourceCurrency;

        private AllInstruments varInstruments;

        private String serviceProvider;

        private String product;

        private String subProduct;

        private Map<VDWType, SettlementValueDateWise> vdws;

        private String reason;

        SettlementRateBuilder(final String agent, final String bank, final RMType rmType) {
            this.agent = agent;
            this.bank = bank;
            this.rmType = rmType;
        }

        @Override
        public SourceCurrencyBuilder var(final VaR var) {
            this.var = var;
            return this;
        }

        @Override
        public InstrumentsBuilder currency(CurrencyExchange currency) {
            this.currency = currency;
            return this;
        }

        @Override
        public TargetCurrencyBuilder source(CurrencyUnit sourceCurrency) {
            this.sourceCurrency = sourceCurrency;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder target(CurrencyUnit targetCurrency) {
            this.currency = CurrencyExchange.of(this.sourceCurrency, targetCurrency);
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder instruments(AllInstruments instruments) {
            this.varInstruments = instruments;
            return this;
        }

        @Override
        public ProductBuilder serviceProvider(String serviceProvider) {
            this.serviceProvider = serviceProvider;
            return this;
        }

        @Override
        public SubProductBuilder product(String product) {
            this.product = product;
            return this;
        }

        @Override
        public ServiceTypeBuilder subProduct(String subProduct) {
            this.subProduct = subProduct;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder serviceType(String serviceType) {
            this.varInstruments = AllInstruments.of(this.serviceProvider, this.product, this.subProduct, serviceType);
            return this;
        }

        @Override
        public ReasonForChangeBuilder valueDateWises(Map<VDWType, SettlementValueDateWise> valueDateWises) {
            this.vdws = valueDateWises;
            return this;
        }

        @Override
        public TomBuilder cash(SettlementValueDateWise cash) {
            this.vdws = new LinkedHashMap<VDWType, SettlementValueDateWise>(4);
            this.vdws.put(VDWType.CASH, cash);
            return this;
        }

        @Override
        public SpotBuilder tom(SettlementValueDateWise tom) {
            this.vdws.put(VDWType.TOM, tom);
            return this;
        }

        @Override
        public FutureBuilder spot(SettlementValueDateWise spot) {
            this.vdws.put(VDWType.SPOT, spot);
            return this;
        }

        @Override
        public ReasonForChangeBuilder future(SettlementValueDateWise future) {
            this.vdws.put(VDWType.FUTURE, future);
            return this;
        }

        @Override
        public Builder<SettlementRate> reason(String reason) {
            this.reason = reason;
            return this;
        }

        @Override
        public SettlementRate build() {
            SettlementRate settlementRate = new SettlementRate();
            settlementRate.rmType = this.rmType;
            settlementRate.currency = this.currency;
            settlementRate.instruments = this.varInstruments;
            settlementRate.valueDateWises = this.vdws;
            settlementRate.agent = this.agent;
            if (this.rmType.isNormal()) {
                settlementRate.priority = SettlementPriority.ofNormal(settlementRate.instruments, this.agent);
            }
            else {
                settlementRate.bank = this.bank;
                settlementRate.priority = SettlementPriority.ofBankWise(settlementRate.instruments, this.bank,
                        this.agent);
            }
            settlementRate.reason = this.reason;
            settlementRate.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
            settlementRate.enabled = true;
            settlementRate.var = this.var;
            return settlementRate;
        }
    }
}
