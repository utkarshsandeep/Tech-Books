package com.unimoni.pricingengine.domain.model.rate.agent;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import javax.money.CurrencyUnit;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyClass;
import javax.persistence.MapKeyColumn;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import com.unimoni.pricingengine.application.event.listner.EntityChangeListener;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.builder.Builder;
import com.unimoni.pricingengine.domain.model.common.type.BaseUUIDIdentifiableVersionableEntity;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.country.AgentItem;
import com.unimoni.pricingengine.domain.model.rate.country.CountryCurrency;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryCurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
//@formatter:off
@NamedEntityGraph(
    name = "agentRate",
    attributeNodes = { @NamedAttributeNode(value = "valueDateWises") }
)
@Entity
@EntityListeners(EntityChangeListener.class)
@Table(name = "AGENT_RATES",   
    indexes = {
        @Index(name = "IDX_AGENT_RATES_BANK_CODE", columnList = "BANK_CODE"),
        @Index(name = "IDX_AGENT_RATES_AGENT_CODE", columnList = "AGENT_CODE"),
        @Index(name = "IDX_AGENT_RATES_RM_TYPE", columnList = "RM_TYPE"), 
        @Index(name = "IDX_AGENT_RATES_BASE_CURRENCY", columnList = "BASE_CURRENCY"),
        @Index(name = "IDX_AGENT_RATES_FOREIGN_CURRENCY", columnList = "FOREIGN_CURRENCY"),
        @Index(name = "IDX_AGENT_RATES_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
        @Index(name = "IDX_AGENT_RATES_PRODUCT_CODE", columnList = "PRODUCT_CODE"),
        @Index(name = "IDX_AGENT_RATES_SUB_PRODUCT_CODE", columnList = "SUB_PRODUCT_CODE"),
        @Index(name = "IDX_AGENT_RATES_SERVICE_TYPE_CODE", columnList = "SERVICE_TYPE_CODE"),
        @Index(name = "IDX_AGENT_RATES_ENABLED", columnList = "ENABLED"),
        @Index(name = "IDX_AGENT_RATES_PRIORITY", columnList = "PRIORITY")
    }
)
//@formatter:on
@Slf4j
@Audited
public class AgentRate extends BaseUUIDIdentifiableVersionableEntity<String, Long> {

    @NotNull
    private AgentItem agent;

    @Getter(value = AccessLevel.NONE)
    @Column(name = "BANK_CODE", updatable = false, length = 100)
    private String bank;

    public Optional<String> bank() {
        return Optional.ofNullable(this.bank);
    }

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RM_TYPE", nullable = false, updatable = false, length = 20)
    private RMType rmType;

    @NotNull
    private CountryCurrency currency;

    @NotNull
    @Embedded
    private AllInstruments instruments;

    // @formatter:off
    @ElementCollection(targetClass = AgentRateValueDateWise.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "AGENT_VALUE_DATE_WISES", 
        joinColumns = { 
                @JoinColumn(name = "AGENT_RATE_ID", referencedColumnName = "ID", 
                        foreignKey = @ForeignKey(name = "FK_AGENT_VALUE_DATE_WISES_AGENT_RATE_ID"))
        }
    )
    @MapKeyClass(VDWType.class)
//    @MapKeyEnumerated(EnumType.STRING)
    @MapKeyColumn(name = "VDW_TYPE", nullable = false)
    @org.hibernate.annotations.OrderBy(clause = "VDW_TYPE asc")
    // @formatter:on
    @Getter(value = AccessLevel.NONE)
    @Audited
    private Map<VDWType, AgentRateValueDateWise> valueDateWises = new LinkedHashMap<VDWType, AgentRateValueDateWise>();

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    // @formatter:off
    @JoinColumn(name = "COUNTRY_RATE_ID", unique = false, nullable = false, 
            foreignKey = @ForeignKey(name = "FK_AGENT_RATES_COUNTRY_RATE_ID"))
    //@formatter:on
    @Audited
    private CountryRate countryRate;

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "PRIORITY", nullable = false, updatable = false, length = 20)
    private AgentRatePriority priority;

    @Getter(value = AccessLevel.NONE)
    @NotNull
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "ENABLED", length = 1)
    private boolean enabled;

    @Column(name = "REASON", length = 256)
    @Audited
    private String reason;

    @NotNull
    // @formatter:off
    @Column(name = "UPDATED_ON", 
            columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    // @formatter:on
    @Audited
    private ZonedDateTime updatedOn;

    public boolean isEnabled() {
        return this.enabled;
    }

    public void updateReason(final String reason) {
        this.reason = reason;
    }

    public void updatedNow() {
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public void updatedOn(final ZonedDateTime zonedDateTime) {
        this.updatedOn = zonedDateTime;
    }

    public boolean updateStatus(final boolean status) {
        if (this.enabled == status) {
            return false;
        }
        else {
            this.enabled = status;
            return true;
        }
    }

    public boolean updateCostFromCountryRate(final Map<VDWType, Cost> vdwAgentCosts, final ZonedDateTime updatedOn) {
        log.debug("Agent Rate, updating rates from Country Layer");
        boolean updated = false;
        for (Entry<VDWType, Cost> vdwEntry : vdwAgentCosts.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateFromCountryLayer(vdwEntry.getValue(),
                    this.agent.rateDisplayMechanism())) {
                updated = true;
            }
        }
        if (updated) {
            this.updatedOn = updatedOn;
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCostMargin(Map<VDWType, Cost> vdwMargins) {
        Map<VDWType, Cost> updatedVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwMargins.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateCostMargin(vdwMargins.get(vdwEntry.getKey()))) {
                updatedVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).margin());
            }
        }
        if (!updatedVdws.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCostMaginLow(Map<VDWType, Cost> vdwMarginLow) {
        Map<VDWType, Cost> updatedVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwMarginLow.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateCostMaginLow(vdwMarginLow.get(vdwEntry.getKey()))) {
                updatedVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).margin());
            }
        }
        if (!updatedVdws.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCostMaginHigh(Map<VDWType, Cost> vdwMarginhigh) {
        Map<VDWType, Cost> updatedVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwMarginhigh.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateCostMaginHigh(vdwMarginhigh.get(vdwEntry.getKey()))) {
                updatedVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).margin());
            }
        }
        if (!updatedVdws.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCostCustomerLowest(Map<VDWType, Cost> vdwcustomerLowest) {
        Map<VDWType, Cost> updatedVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwcustomerLowest.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey())
                    .updateCostCustomerLowest(vdwcustomerLowest.get(vdwEntry.getKey()))) {
                updatedVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).margin());
            }
        }
        if (!updatedVdws.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCostCustomerRate(Map<VDWType, Cost> vdwCustomerRate) {
        Map<VDWType, Cost> updatedVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwCustomerRate.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey())
                    .updateCostCustomerRate(vdwCustomerRate.get(vdwEntry.getKey()))) {
                updatedVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).margin());
            }
        }
        if (!updatedVdws.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCostMaxDiscount(Map<VDWType, Cost> vdwMaxDiscount) {
        Map<VDWType, Cost> updatedVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwMaxDiscount.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey())
                    .updateCostMaxDiscount(vdwMaxDiscount.get(vdwEntry.getKey()))) {
                updatedVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).margin());
            }
        }
        if (!updatedVdws.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }

    public Map<VDWType, AgentRateValueDateWise> valueDateWises() {
        return Collections.unmodifiableMap(this.valueDateWises);
    }

    public AgentRateValueDateWise valueDateWises(final VDWType vdwType) {
        return this.valueDateWises.get(vdwType);
    }

    public BigDecimal layerCharge(final VDWType vdwType) {
        return this.valueDateWises.get(vdwType).customerRate().sellValue();
    }

    public void valueDateWises(final Map<VDWType, AgentRateValueDateWise> newValueDateWises) {
        this.valueDateWises = newValueDateWises;
    }

    public void setZeroValueDateWises() {
        cash(AgentRateValueDateWise.zero());
        tom(AgentRateValueDateWise.zero());
        spot(AgentRateValueDateWise.zero());
        future(AgentRateValueDateWise.zero());
    }

    public Optional<AgentRateValueDateWise> cash() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.CASH));
    }

    public Optional<AgentRateValueDateWise> tom() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.TOM));
    }

    public Optional<AgentRateValueDateWise> spot() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.SPOT));
    }

    public Optional<AgentRateValueDateWise> future() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.FUTURE));
    }

    public void cash(final AgentRateValueDateWise cash) {
        this.valueDateWises.put(VDWType.CASH, cash);
    }

    public void tom(final AgentRateValueDateWise tom) {
        this.valueDateWises.put(VDWType.TOM, tom);
    }

    public void spot(final AgentRateValueDateWise spot) {
        this.valueDateWises.put(VDWType.SPOT, spot);
    }

    public void future(final AgentRateValueDateWise future) {
        this.valueDateWises.put(VDWType.FUTURE, future);
    }

    public AgentRateValueDateWise removeValueDateWise(final VDWType vdwType) {
        return this.valueDateWises.remove(vdwType);
    }

    public void updateValueDateWise(final VDWType vdwType, final AgentRateValueDateWise vdw) {
        this.valueDateWises.put(vdwType, vdw);
    }

    public AgentRateIdentity identity() {
        return this.rmType.isNormal()
                ? AgentRateIdentity.ofNormal(this.instruments().serviceProvider(), this.instruments().product(),
                        this.instruments().subProduct(), this.instruments().serviceType(), this.agent().details(),
                        CountryCurrencyDTO.of(this.currency))
                : AgentRateIdentity.ofBankWise(this.instruments().serviceProvider(), this.instruments().product(),
                        this.instruments().subProduct(), this.instruments().serviceType(), this.agent().details(),
                        this.bank().get(), CountryCurrencyDTO.of(this.currency));

    }

    public static CountryRateBuilder normal(final AgentItem agent) {
        return new AgentRateBuilder(agent, null, RMType.NORMAL);
    }

    public static CountryRateBuilder bankWise(final String bank, final AgentItem agent) {
        return new AgentRateBuilder(agent, bank, RMType.BANK_WISE);
    }

    public interface CountryRateBuilder {
        public BaseCurrencyBuilder countryRate(final CountryRate countryRate);
    }

    public interface CountryExchangeBuilder {
        public InstrumentsBuilder currency(final CountryCurrency currency);
    }

    public interface BaseCurrencyBuilder extends CountryExchangeBuilder {
        public ForeignCurrencyBuilder base(final CurrencyUnit baseCurrency);
    }

    public interface ForeignCurrencyBuilder {
        public ValueDateWiseCashBuilder foreign(final CurrencyUnit foreignCurrency);
    }

    public interface InstrumentsBuilder {
        public ValueDateWiseCashBuilder instruments(final AllInstruments instruments);
    }

    public interface InstrumentsServiceProviderBuilder extends InstrumentsBuilder {
        public ProductBuilder serviceProvider(final String serviceProvider);
    }

    public interface ProductBuilder {
        public SubProductBuilder product(final String product);
    }

    public interface SubProductBuilder {
        public ServiceTypeBuilder subProduct(final String subProduct);
    }

    public interface ServiceTypeBuilder {
        public ValueDateWiseCashBuilder serviceType(final String serviceType);
    }

    public interface ValueDateWiseCashBuilder {
        public ReasonForChangeBuilder valueDateWises(final Map<VDWType, AgentRateValueDateWise> valueDateWises);

        public TomBuilder cash(final AgentRateValueDateWise cash);
    }

    public interface TomBuilder extends Builder<AgentRate> {
        public SpotBuilder tom(final AgentRateValueDateWise tom);
    }

    public interface SpotBuilder extends Builder<AgentRate> {
        public FutureBuilder spot(final AgentRateValueDateWise spot);
    }

    public interface FutureBuilder extends Builder<AgentRate> {
        public ReasonForChangeBuilder future(final AgentRateValueDateWise future);
    }

    public interface ReasonForChangeBuilder extends Builder<AgentRate> {
        public Builder<AgentRate> reason(final String reason);
    }

    public static class AgentRateBuilder implements CountryRateBuilder, BaseCurrencyBuilder, ForeignCurrencyBuilder,
            InstrumentsServiceProviderBuilder, ProductBuilder, SubProductBuilder, ServiceTypeBuilder,
            ValueDateWiseCashBuilder, TomBuilder, SpotBuilder, FutureBuilder, ReasonForChangeBuilder {

        private AgentItem agent;

        private String bank;

        private RMType rmType;

        private CountryRate countryRate;

        private CountryCurrency currency;

        private CurrencyUnit baseCurrency;

        private AllInstruments settlementInstruments;

        private String serviceProvider;

        private String product;

        private String subProduct;

        private Map<VDWType, AgentRateValueDateWise> vdws;

        private String reason;

        AgentRateBuilder(final AgentItem agent, final String bank, final RMType rmType) {
            this.agent = agent;
            this.bank = bank;
            this.rmType = rmType;
        }

        @Override
        public AgentRateBuilder countryRate(final CountryRate countryRate) {
            this.countryRate = countryRate;
            return this;
        }

        @Override
        public InstrumentsBuilder currency(CountryCurrency currency) {
            this.currency = currency;
            return this;
        }

        @Override
        public ForeignCurrencyBuilder base(CurrencyUnit baseCurrency) {
            this.baseCurrency = baseCurrency;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder foreign(CurrencyUnit foreignCurrency) {
            this.currency = CountryCurrency.of(this.baseCurrency, foreignCurrency);
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder instruments(AllInstruments instruments) {
            this.settlementInstruments = instruments;
            return this;
        }

        @Override
        public ProductBuilder serviceProvider(String serviceProvider) {
            this.serviceProvider = serviceProvider;
            return this;
        }

        @Override
        public SubProductBuilder product(String product) {
            this.product = product;
            return this;
        }

        @Override
        public ServiceTypeBuilder subProduct(String subProduct) {
            this.subProduct = subProduct;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder serviceType(String serviceType) {
            this.settlementInstruments = AllInstruments.of(this.serviceProvider, this.product, this.subProduct,
                    serviceType);
            return this;
        }

        @Override
        public ReasonForChangeBuilder valueDateWises(Map<VDWType, AgentRateValueDateWise> valueDateWises) {
            this.vdws = valueDateWises;
            return this;
        }

        @Override
        public TomBuilder cash(AgentRateValueDateWise cash) {
            this.vdws = new LinkedHashMap<VDWType, AgentRateValueDateWise>(4);
            this.vdws.put(VDWType.CASH, cash);
            return this;
        }

        @Override
        public SpotBuilder tom(AgentRateValueDateWise tom) {
            this.vdws.put(VDWType.TOM, tom);
            return this;
        }

        @Override
        public FutureBuilder spot(AgentRateValueDateWise spot) {
            this.vdws.put(VDWType.SPOT, spot);
            return this;
        }

        @Override
        public ReasonForChangeBuilder future(AgentRateValueDateWise future) {
            this.vdws.put(VDWType.FUTURE, future);
            return this;
        }

        @Override
        public Builder<AgentRate> reason(String reason) {
            this.reason = reason;
            return this;
        }

        @Override
        public AgentRate build() {
            AgentRate agentRate = new AgentRate();
            agentRate.rmType = this.rmType;
            agentRate.currency = this.currency;
            agentRate.instruments = this.settlementInstruments;
            agentRate.valueDateWises = this.vdws;
            if (this.rmType.isNormal()) {
                agentRate.agent = this.agent;
                agentRate.priority = AgentRatePriority.ofNormal(agentRate.instruments, this.agent.code());
            }
            else {
                agentRate.bank = this.bank;
                agentRate.agent = this.agent;
                agentRate.priority = AgentRatePriority.ofBankWise(agentRate.instruments, this.bank, this.agent.code());
            }
            agentRate.reason = this.reason;
            agentRate.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
            agentRate.enabled = true;
            agentRate.countryRate = this.countryRate;
            return agentRate;
        }
    }
}
