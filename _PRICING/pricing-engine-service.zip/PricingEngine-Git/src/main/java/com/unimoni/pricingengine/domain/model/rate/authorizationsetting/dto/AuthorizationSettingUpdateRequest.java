package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import java.util.Optional;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "authorizationSettingUpdateRequest", description = "Request to Update the status of Authorization setting")
public class AuthorizationSettingUpdateRequest {

    @Getter(value = AccessLevel.NONE)
    @ApiModelProperty(name = "status", allowEmptyValue = false, dataType = "Boolean", value = "New status, either true or false", required = false, example = "false", allowableValues = "true,false")
    private Boolean status;

    public Optional<Boolean> getStatus() {
        return Optional.ofNullable(this.status);
    }
}