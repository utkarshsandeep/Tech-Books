package com.unimoni.pricingengine.domain.model.rate.settlement.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.domain.model.rate.RMType;

import io.swagger.annotations.ApiParam;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class SettlementRateRequest {

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
    private List<@NotNull String> serviceProviders;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
    private List<@NotNull String> products;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
    private List<@NotNull String> subProducts;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
    private List<@NotNull String> serviceTypes;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Agent codes", example = "AGNT00X1")
    private List<@NotNull String> agents;

    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Bank codes", example = "HDFC")
    private List<@NotNull String> banks;

    @NotEmpty
    private List<@NotNull CurrencyUnit> currencies;

    public static SettlementRateRequest ofNormal(final List<@NotNull String> serviceProviders,
            final List<@NotNull String> products, final List<@NotNull String> subProducts,
            final List<@NotNull String> serviceTypes, final List<@NotNull CurrencyUnit> currencies,
            final List<@NotNull String> agents) {
        SettlementRateRequest settlementRateRequest = new SettlementRateRequest();
        settlementRateRequest.serviceProviders = serviceProviders;
        settlementRateRequest.products = products;
        settlementRateRequest.subProducts = subProducts;
        settlementRateRequest.serviceTypes = serviceTypes;
        settlementRateRequest.currencies = currencies;
        settlementRateRequest.agents = agents;
        return settlementRateRequest;
    }

    public static SettlementRateRequest ofBankWise(final List<@NotNull String> serviceProviders,
            final List<@NotNull String> products, final List<@NotNull String> subProducts,
            final List<@NotNull String> serviceTypes, final List<@NotNull CurrencyUnit> currencies,
            final List<@NotNull String> banks, final List<@NotNull String> agents) {
        SettlementRateRequest settlementRateRequest = ofNormal(serviceProviders, products, subProducts, serviceTypes,
                currencies, agents);
        settlementRateRequest.banks = banks;
        return settlementRateRequest;
    }

    @Getter(value = AccessLevel.NONE)
    @Setter(value = AccessLevel.NONE)
    private List<SettlementBasicIdentity> basicIdentities;

    @SuppressWarnings("unchecked")
    public List<SettlementBasicIdentity> basicIdentities(final RMType rmType) {
        if (this.basicIdentities == null) {
            ImmutableList<String> sps = ImmutableList.copyOf(this.serviceProviders);
            ImmutableList<String> prds = ImmutableList.copyOf(this.products);
            ImmutableList<String> subPrds = ImmutableList.copyOf(this.subProducts);
            ImmutableList<String> srvcTyps = ImmutableList.copyOf(this.serviceTypes);
            ImmutableList<String> agnts = ImmutableList.copyOf(this.agents);
            ImmutableList<CurrencyUnit> currs = ImmutableList.copyOf(this.currencies);
            if (rmType.isNormal()) {
                List<List<Object>> combinations = Lists.cartesianProduct(sps, prds, subPrds, srvcTyps, agnts, currs);
                List<SettlementBasicIdentity> identities = new ArrayList<>(combinations.size());
                for (List<Object> combination : combinations) {
                    identities.add(SettlementBasicIdentity.ofNormal((String) combination.get(0),
                            (String) combination.get(1), (String) combination.get(2), (String) combination.get(3),
                            (String) combination.get(4), (CurrencyUnit) combination.get(5)));
                }
                return this.basicIdentities = Collections.unmodifiableList(identities);
            } else {
                ImmutableList<String> bnks = ImmutableList.copyOf(this.banks);
                List<List<Object>> combinations = Lists.cartesianProduct(sps, prds, subPrds, srvcTyps, agnts, bnks,
                        currs);
                List<SettlementBasicIdentity> identities = new ArrayList<>(combinations.size());
                for (List<Object> combination : combinations) {
                    identities.add(SettlementBasicIdentity.ofBankWise((String) combination.get(0),
                            (String) combination.get(1), (String) combination.get(2), (String) combination.get(3),
                            (String) combination.get(4), (String) combination.get(5),
                            (CurrencyUnit) combination.get(6)));
                }
                return this.basicIdentities = Collections.unmodifiableList(identities);
            }
        } else {
            return this.basicIdentities;
        }
    }
}
