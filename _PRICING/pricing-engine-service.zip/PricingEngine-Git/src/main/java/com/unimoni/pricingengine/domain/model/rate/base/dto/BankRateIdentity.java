package com.unimoni.pricingengine.domain.model.rate.base.dto;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode
@ToString
public class BankRateIdentity {

    private CurrencyUnit sourceCurrency;

    private CurrencyUnit targetCurrency;

    private String serviceProvider;

    private String product;

    private String agent;

    private String bank;

    public boolean contains(final String bank, final String serviceProvider, final String product,
            final CurrencyUnit currency, final String agent) {
        return this.serviceProvider.equals(serviceProvider) && this.product.equals(product) && this.agent.equals(agent)
                && (this.sourceCurrency == currency || this.targetCurrency == currency);
    }

    public RateInstruments rateInstruments() {
        return RateInstruments.of(this.serviceProvider, this.product);
    }
}
