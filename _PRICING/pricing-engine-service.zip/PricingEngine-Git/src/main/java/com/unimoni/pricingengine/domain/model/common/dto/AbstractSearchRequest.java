package com.unimoni.pricingengine.domain.model.common.dto;

public abstract class AbstractSearchRequest implements PageParameterizable {

    protected PaginationData page;

    @Override
    public final PaginationData page() {
        return this.page;
    }

    @Override
    public final boolean moveToNextPage() {
        if (this.page.hasNext()) {
            this.page = page.next();
            return true;
        } else {
            return false;
        }
    }
}
