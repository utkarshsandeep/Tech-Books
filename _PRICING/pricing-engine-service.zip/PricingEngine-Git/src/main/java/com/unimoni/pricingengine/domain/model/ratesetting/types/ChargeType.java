package com.unimoni.pricingengine.domain.model.ratesetting.types;

import java.util.EnumSet;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;
import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

public enum ChargeType {

    // @formatter:off
    ADDITIONAL_CHARGES("Additional Charges"),
    BACKEND_CHARGES("Bankend Charges"),
    CARD_CHARGES("Card Charges"),
    COMMISSION("Commission"),
    OTHER_CHARGES("Other Charges"),
    CANCELLATION_CHARGES("Cancellation Charges"),
    TAX("Tax"),
    SWIFT_CHARGES("Swift Charges");
    
    // @formatter:on

    private final String description;

    private ChargeType(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }

    private static final EnumSet<ChargeType> ALL_VALUES = EnumSet.allOf(ChargeType.class);

    @JsonCreator
    public static ChargeType of(final String name) {
        for (ChargeType e : values())
            if (e.name().equals(name))
                return e;
        throw new IllegalArgumentException();
    }

    public CodeNamePair<String, String> toPair() {
        return CodeNamePair.of(this.name(), this.description());
    }

    @JsonValue
    public Pair<String, String> toPairType() {
        return Pair.of(this.name(), this.description());
    }

    public static EnumSet<ChargeType> all() {
        return ALL_VALUES;
    }

    public static List<CodeNamePair<String, String>> listItems() {
        return ALL_VALUES.stream().map(ChargeType::toPair).collect(ImmutableCollectors.toImmutableList());
    }

    public static List<CodeNamePair<String, String>> listItems(boolean isAll) {
        return ALL_VALUES.stream().filter(e -> isAll || !e.equals(ChargeType.SWIFT_CHARGES)).map(ChargeType::toPair)
                .collect(ImmutableCollectors.toImmutableList());
    }

    /*
     * From value to key
     */
    public static ChargeType getEKey(String type) {
        for (ChargeType e : values())
            if (e.description().equals(type))
                return e;
        throw new IllegalArgumentException();
    }
}
