package com.unimoni.pricingengine.domain.model.remittance.dto;

import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.remittance.RateSkipSetting;
import com.unimoni.pricingengine.domain.model.remittance.RemittanceTransactionInitiationRequest;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of", access = AccessLevel.PRIVATE)
@ToString
public class TxnMetaData {

    private Long agentId;

    private String agentCode;

    private String agentBranchCode;

    private RateDisplayMachenism rateDisplayMachenism;

    private VDWType valueDateWise;

    private RateSkipSetting rateSkipSetting;

    public static TxnMetaData of(final Long agentId, final String agentCode, final String agentBranchCode,
            final RateDisplayMachenism rateDisplayMachenism, final RateSkipSetting rateSkipSetting,
            final VDWType valueDateWise) {
        return of(agentId, agentCode, agentBranchCode, rateDisplayMachenism, valueDateWise, rateSkipSetting);
    }

    public boolean isRateDisplayMachenismChanged(final RemittanceTransactionInitiationRequest txnInitiationRequest) {
        return this.rateDisplayMachenism != txnInitiationRequest.txnInitResponse().rateDisplayMechanism();
    }
}
