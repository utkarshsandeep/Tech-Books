package com.unimoni.pricingengine.application.service.amigo.event;

import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class VaRCreatedEvent extends VDWRateAmigoEvent {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;

    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashAskMargin;

    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashBidMargin;

    private VaRCreatedEvent(final VaR var) {
        super(var.rmType().isNormal() ? Type.VAR_NORMAL : Type.VAR_BANK_WISE, var.agent(),
                var.rmType().isBankWise() ? var.bank().get() : null, var.instruments().serviceProvider(),
                var.instruments().product(), var.instruments().subProduct(), var.instruments().serviceType(),
                var.exchange().currency().source(), var.exchange().currency().target(), var.isEnabled(),
                var.updatedOn());
        this.cashAskMargin = var.cash().get().margin().askValue();
        this.cashBidMargin = var.cash().get().margin().bidValue();
    }

    public static VaRCreatedEvent of(final VaR var) {
        return new VaRCreatedEvent(var);
    }
}
