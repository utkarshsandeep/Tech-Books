package com.unimoni.pricingengine.domain.model.enquiry.country;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.money.CurrencyUnit;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;
import com.unimoni.pricingengine.common.util.Counter;
import com.unimoni.pricingengine.domain.model.enquiry.StreamRequest;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

@Slf4j
@Getter
@Accessors(chain = true, fluent = true)
@ToString(callSuper = true)
public class CountryRateEnquiryRequest extends StreamRequest {

    private List<String> serviceProviders;

    private List<String> products;

    private List<String> subProducts;

    private List<String> serviceTypes;

    private List<String> banks;

    private List<AgentDetails> agents;

    private List<CurrencyUnit> baseCurrencies;

    private List<CurrencyUnit> foreignCurrencies;

    private EnumSet<VDWType> valueDateWises;

    private RateDisplayMachenism rateDisplayMachenism;

    private int endIndex;

    private CountryRateEnquiryRequest(final int nextIndex, final int batchSize, final List<String> serviceProviders,
            final List<String> products, final List<String> subProducts, final List<String> serviceTypes,
            final List<String> banks, final List<AgentDetails> agents, final List<CurrencyUnit> baseCurrencies,
            final List<CurrencyUnit> foreignCurrencies, final EnumSet<VDWType> valueDateWises,
            final RateDisplayMachenism rateDisplayMachenism) {
        super(nextIndex, batchSize);
        this.serviceProviders = serviceProviders;
        this.products = products;
        this.subProducts = subProducts;
        this.serviceTypes = serviceTypes;
        this.banks = banks;
        this.agents = agents;
        this.baseCurrencies = baseCurrencies;
        this.foreignCurrencies = foreignCurrencies;
        this.valueDateWises = valueDateWises;
        this.rateDisplayMachenism = rateDisplayMachenism;
    }

    public static CountryRateEnquiryRequest ofNormal(final Integer startingIndex, final Integer batchSize,
            final Set<String> serviceProviders, final Set<String> products, final Set<String> subProducts,
            final Set<String> serviceTypes, final Set<String> agentsOrBranches, final Set<CurrencyUnit> baseCurrencies,
            final Set<CurrencyUnit> foreignCurrencies, final Set<String> valueDateWises,
            final RateDisplayMachenism rateDisplayMachenism) {
        MasterData masterData = BeanFactory.masterData();
        return new CountryRateEnquiryRequest(startingIndex == null ? 0 : startingIndex,
                batchSize == null ? DEFAULT_BATCH_SIZE : batchSize,
                masterData.validateServiceProviders(serviceProviders), masterData.validateProducts(products),
                masterData.validateSubProducts(subProducts), masterData.validateServiceTypes(serviceTypes), null,
                masterData.validateNormalAgentOrBranch(agentsOrBranches), masterData.validateCurrencies(baseCurrencies),
                masterData.validateCurrencies(foreignCurrencies), VDWType.validate(valueDateWises),
                rateDisplayMachenism);
    }

    public static CountryRateEnquiryRequest ofBankWise(final Integer startingIndex, final Integer batchSize,
            final Set<String> serviceProviders, final Set<String> products, final Set<String> subProducts,
            final Set<String> serviceTypes, final Set<String> banks, final Set<String> agentsOrBranches,
            final Set<CurrencyUnit> baseCurrencies, final Set<CurrencyUnit> foreignCurrencies,
            final Set<String> valueDateWises, final RateDisplayMachenism rateDisplayMachenism) {
        MasterData masterData = BeanFactory.masterData();
        return new CountryRateEnquiryRequest(startingIndex == null ? 0 : startingIndex,
                batchSize == null ? DEFAULT_BATCH_SIZE : batchSize,
                masterData.validateServiceProviders(serviceProviders), masterData.validateProducts(products),
                masterData.validateSubProducts(subProducts), masterData.validateServiceTypes(serviceTypes),
                masterData.validateBanks(banks), masterData.validateBankWiseAgentOrBranch(agentsOrBranches),
                masterData.validateCurrencies(baseCurrencies), masterData.validateCurrencies(foreignCurrencies),
                VDWType.validate(valueDateWises), rateDisplayMachenism);
    }

    @SuppressWarnings("unchecked")
    public Flux<CountryRateEnquiryIdentity> identities(final RMType rmType) {
        // return rmType.isNormal() ? normalIdentities() : bankWiseIdentities();

        ImmutableList<String> sps = ImmutableList.copyOf(this.serviceProviders);
        ImmutableList<String> prds = ImmutableList.copyOf(this.products);
        ImmutableList<String> sbprds = ImmutableList.copyOf(this.subProducts);
        ImmutableList<String> srvctps = ImmutableList.copyOf(this.serviceTypes);
        ImmutableList<AgentDetails> agnts = ImmutableList.copyOf(this.agents);
        ImmutableList<CurrencyUnit> baseCurrs = ImmutableList.copyOf(this.baseCurrencies);
        ImmutableList<CurrencyUnit> foreignCurrs = ImmutableList.copyOf(this.foreignCurrencies);
        List<List<Object>> combinations = Collections.emptyList();
        if (rmType.isNormal()) {
            combinations = Lists.cartesianProduct(sps, prds, sbprds, srvctps, agnts, baseCurrs, foreignCurrs);
        }
        else {
            ImmutableList<String> bnks = ImmutableList.copyOf(this.banks);
            combinations = Lists.cartesianProduct(sps, prds, sbprds, srvctps, bnks, agnts, baseCurrs, foreignCurrs);
        }

        this.endIndex = combinations.size() - 1;
        log.debug("CountryRateEnquiryRequest --> {} \n total combinations --> {}", this,
                this.endIndex + 1);
        
        Counter indexCounter = Counter.initialize("index-counter");
        Iterator<List<Object>> itr = combinations.iterator();
        while (itr.hasNext() && indexCounter.get() < this.nextIndex()) {
            itr.next();
            indexCounter.increment();
        }

        return Flux.generate(() -> itr, (state, sink) -> {
            if (state.hasNext()) {
                List<Object> combination = state.next();
                if (rmType.isNormal()) {
                    sink.next(CountryRateEnquiryIdentity.ofNormal(indexCounter.get(), (String) combination.get(0),
                            (String) combination.get(1), (String) combination.get(2), (String) combination.get(3),
                            (AgentDetails) combination.get(4), (CurrencyUnit) combination.get(5),
                            (CurrencyUnit) combination.get(6), this.valueDateWises, this.rateDisplayMachenism));
                }
                else {
                    sink.next(CountryRateEnquiryIdentity.ofBankWise(indexCounter.get(), (String) combination.get(0),
                            (String) combination.get(1), (String) combination.get(2), (String) combination.get(3),
                            (String) combination.get(4), (AgentDetails) combination.get(5),
                            (CurrencyUnit) combination.get(6), (CurrencyUnit) combination.get(7), this.valueDateWises,
                            this.rateDisplayMachenism));
                }
                indexCounter.increment();
            }
            else {
                sink.complete();
            }
            return state;
        });

    }
}
