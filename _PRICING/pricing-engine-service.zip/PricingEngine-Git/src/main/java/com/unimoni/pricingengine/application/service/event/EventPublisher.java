package com.unimoni.pricingengine.application.service.event;

import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import com.unimoni.pricingengine.adapter.rest.clients.bp.BranchProcessAmigoQatarRequest;
import com.unimoni.pricingengine.adapter.rest.clients.bp.BranchProcessAmigoUpdateRequest;
import com.unimoni.pricingengine.application.service.amigo.event.AmigoEvent;
import com.unimoni.pricingengine.application.service.amigo.event.AmigoStandardChargeEvent;
import com.unimoni.pricingengine.application.service.amigo.event.AmigoStandardChargeEvent.Type;
import com.unimoni.pricingengine.application.service.amigo.event.BranchProcessEvent;
import com.unimoni.pricingengine.application.service.amigo.event.BranchProcessUpdateAmigoEvent;
import com.unimoni.pricingengine.application.service.amigo.event.BranchProcessUpdateAmigoQatarEvent;
import com.unimoni.pricingengine.application.service.amigo.event.BranchProcessUpdateStatusAmigoEvent;
import com.unimoni.pricingengine.application.service.amigo.event.BranchProcessUpdateStatusQatarEvent;
import com.unimoni.pricingengine.application.service.amigo.event.StandardChargeCreatedEvent;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessAmigoCreateRequest;
import com.unimoni.pricingengine.domain.model.event.ProvidedRateDisabledEvent;
import com.unimoni.pricingengine.domain.model.event.ProvidedRateEnabledEvent;
import com.unimoni.pricingengine.domain.model.event.ProvidedRateFrequencyChangedEvent;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.PaasToAmigoStandardChargeResponse;
import com.unimoni.pricingengine.infra.config.SpringProfiles;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component("eventPublisher")
@RequiredArgsConstructor
public class EventPublisher {

    @NonNull
    private static ApplicationEventPublisher applicationEventPublisher;

    @Autowired
    public void setApplicationEventPublisher(final ApplicationEventPublisher applicationEventPublisher) {
        EventPublisher.applicationEventPublisher = applicationEventPublisher;
    }

    public static void publishProvidedRateEnabledEvent(final int rateProviderId, final String rateId,
            final String ricId, final Duration frequency) {
        if ((rateProviderId == ApplicationConstants.THOMSON_RATE_PROVIDER_ID
                || rateProviderId == ApplicationConstants.FUTURE_SOURCE_RATE_PROVIDER_ID)
        /* && SpringProfiles.isRateProviderIntegrationEnabled() */) {
            log.info("ProvidedRateEnabledEvent published for rateProviderId: {}, rateId: {}, ricId: {}",
                    rateProviderId, rateId, ricId);

            applicationEventPublisher
                    .publishEvent(ProvidedRateEnabledEvent.of(rateProviderId, rateId, ricId, frequency));

        }
        else {
            log.info("Rate Provider Integration enabled Status is: "
                    + SpringProfiles.isRateProviderIntegrationEnabled());
        }
    }

    public static void publishProvidedRateDisabledEvent(final int rateProviderId, final String rateId,
            final String ricId) {

        if ((rateProviderId == ApplicationConstants.THOMSON_RATE_PROVIDER_ID
                || rateProviderId == ApplicationConstants.FUTURE_SOURCE_RATE_PROVIDER_ID)
        /* && SpringProfiles.isRateProviderIntegrationEnabled() */) {
            log.info("ProvidedRateDisabledEvent published for rateProviderId: {}, rateId: {}, ricId: {}",
                    rateProviderId, rateId, ricId);

            applicationEventPublisher.publishEvent(ProvidedRateDisabledEvent.of(rateProviderId, rateId, ricId));
        }
        else {
            log.info("Rate Provider Integration enabled Status is: "
                    + SpringProfiles.isRateProviderIntegrationEnabled());
        }
    }

    public static void publishProvidedRateFrequencyChangedEvent(final int rateProviderId, final String rateId,
            final String ricId, final Duration frequency) {
        if ((rateProviderId == ApplicationConstants.THOMSON_RATE_PROVIDER_ID
                || rateProviderId == ApplicationConstants.FUTURE_SOURCE_RATE_PROVIDER_ID)
                && SpringProfiles.isRateProviderIntegrationEnabled()) {
            log.info("ProvidedRateFrequencyChangedEvent published for rateProviderId: {} "
                    + "rateId: {}, ricId: {}, frequency: {}", rateProviderId, rateId, ricId, frequency);

            applicationEventPublisher
                    .publishEvent(ProvidedRateFrequencyChangedEvent.of(rateProviderId, rateId, ricId, frequency));
        }
        else {
            log.info("Rate Provider Integration enabled Status is: "
                    + SpringProfiles.isRateProviderIntegrationEnabled());
        }
    }

    public static <T extends AmigoEvent> void publishAmigoEvent(final T amigoEvent) {
        log.info("AmigoEvent published : {}", amigoEvent);
        applicationEventPublisher.publishEvent(amigoEvent);
    }

    public static <T extends AmigoStandardChargeEvent> void publishSCAmigoEvent(final T amigoEvent) {
        log.info("AmigoStandardChargeEvent published : {}", amigoEvent);
        applicationEventPublisher.publishEvent(amigoEvent);
    }

    public static void publishStandardChargeCreatedEvent(final List<PaasToAmigoStandardChargeResponse> listResp,
            ZonedDateTime timestamp) {
        log.info("Standard Charge published for total new Standard Charge : {} " + listResp.size());
        listResp.stream().forEach(item -> {
            publishSCAmigoEvent(StandardChargeCreatedEvent.of(Type.STANDARD_CHARGES, item, timestamp));
        });
    }

    public static void publishStatusChangeEvent(final PaasToAmigoStandardChargeResponse resp, ZonedDateTime timestamp) {
        log.info("Update Amount Range published for total new Standard Charge : {} " + resp);
        publishSCAmigoEvent(StandardChargeCreatedEvent.of(Type.STANDARD_CHARGES, resp, timestamp));
    }

    ////////////// Branch process
    public static void publishBranchProcessCreatedEvent(final BranchProcessAmigoCreateRequest req) {
        log.info("START-New Deal is pushing to amigo : {} " + req);
        publishBPAmigoEvent(BranchProcessEvent.of(req));
        log.info("END-New Deal is pushing to amigo : {} " + req);
    }

    public static <T extends BranchProcessEvent> void publishBPAmigoEvent(final T amigoEvent) {
        log.info("BranchProcessEvent published : {}", amigoEvent);
        applicationEventPublisher.publishEvent(amigoEvent);
    }

    public static void publishSendUpdateToOtherPartnerEvent(BranchProcessAmigoUpdateRequest req) {
        log.info("START-Sending Updates to amigo : {} " + req);
        publishBPUpdateAmigoEvent(BranchProcessUpdateAmigoEvent.of(req));
        log.info("END-Sending Updates to amigo : {} " + req);
    }

    public static <T extends BranchProcessUpdateAmigoEvent> void publishBPUpdateAmigoEvent(final T amigoEvent) {
        log.info("BranchProcessUpdateAmigoEvent published : {}", amigoEvent);
        applicationEventPublisher.publishEvent(amigoEvent);
    }

    public static void publishSendUpdateToOtherPartnerEvent(BranchProcessAmigoQatarRequest req) {
        log.info("START-Sending Updates to qatar amigo : {} " + req);
        publishBPSendUpdateQatarEvent(BranchProcessUpdateAmigoQatarEvent.of(req));
        log.info("END-Sending Updates to qatar amigo : {} " + req);
    }

    public static <T extends BranchProcessUpdateAmigoQatarEvent> void publishBPSendUpdateQatarEvent(
            final T amigoEvent) {
        log.info("BranchProcessUpdateAmigoEvent published : {}", amigoEvent);
        applicationEventPublisher.publishEvent(amigoEvent);
    }

    public static void publishSendStatusUpdateToOtherPartnerEvent(BranchProcessAmigoUpdateRequest req,
            boolean statusUpdate) {
        log.info("START-Sending Status Updates to amigo : {} " + req);
        if (statusUpdate) {
            publishBranchProcessUpdateStatusAmigoEvent(BranchProcessUpdateStatusAmigoEvent.of(req));
        }
        else {
            publishBPUpdateAmigoEvent(BranchProcessUpdateAmigoEvent.of(req));
        }
        log.info("END-Sending Status Updates to amigo : {} " + req);
    }

    public static <T extends BranchProcessUpdateStatusAmigoEvent> void publishBranchProcessUpdateStatusAmigoEvent(
            final T amigoEvent) {
        log.info("BranchProcessUpdateStatusAmigoEvent published : {}", amigoEvent);
        applicationEventPublisher.publishEvent(amigoEvent);
    }

    public static void publishSendStatusUpdateToOtherPartnerEvent(BranchProcessAmigoQatarRequest req,
            boolean statusUpdate) {
        log.info("START-Sending Status Updates to qatar amigo : {} " + req);
        if (statusUpdate) {
            publishBranchProcessUpdateStatusQatarEvent(BranchProcessUpdateStatusQatarEvent.of(req));
        }
        else {
            publishBPSendUpdateQatarEvent(BranchProcessUpdateAmigoQatarEvent.of(req));
        }
        log.info("END-Sending Status Updates to qatar amigo : {} " + req);
    }

    public static <T extends BranchProcessUpdateStatusQatarEvent> void publishBranchProcessUpdateStatusQatarEvent(
            final T amigoEvent) {
        log.info("BranchProcessUpdateStatusQatarEvent published : {}", amigoEvent);
        applicationEventPublisher.publishEvent(amigoEvent);
    }

    public static <T> void publishServerSentEvents(final T serverSentEventsResponse) {
        // log.info("PublishServerSentEvents published : {}", serverSentEventsResponse);
        applicationEventPublisher.publishEvent(serverSentEventsResponse);
    }

    public static <T> void publishNormalBaseRateToBankwiseBaseRate(final T normalBaseRate) {
        log.info("PublishNormalBaseRateToBankwiseBaseRate published : {}", normalBaseRate);
        applicationEventPublisher.publishEvent(normalBaseRate);
    }

}
