package com.unimoni.pricingengine.domain.model.common.type;

import static com.unimoni.pricingengine.adapter.persistence.PersistenceConstant.Hibernate.UUID2_GENERATOR;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;

import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 
 */
@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@NoArgsConstructor
@EqualsAndHashCode
public abstract class AbstractUUIDIdentifiable<IdType extends Serializable & Comparable<IdType> & CharSequence>
        implements UUIDIdentifiable<IdType> {

    @Id
    @GeneratedValue(generator = UUID2_GENERATOR)
    @Column(name = "ID", updatable = false, nullable = false, length = 50)
    protected IdType id;

    @Override
    public IdType id() {
        return this.id;
    }
}
