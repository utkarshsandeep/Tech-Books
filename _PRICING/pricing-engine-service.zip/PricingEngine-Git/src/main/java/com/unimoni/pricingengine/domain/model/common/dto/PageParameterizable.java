package com.unimoni.pricingengine.domain.model.common.dto;

public interface PageParameterizable {

    public PaginationData page();

    public boolean moveToNextPage();
}
