package com.unimoni.pricingengine.domain.model.rate.base.dto;

import javax.money.CurrencyUnit;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode
@ToString
public class RateIdentity {

    private CurrencyUnit sourceCurrency;

    private CurrencyUnit targetCurrency;

    private String serviceProvider;

    private String product;

    public boolean contains(final String serviceProvider, final String product, final CurrencyUnit currency) {
        return this.serviceProvider.equals(serviceProvider) && this.product.equals(product)
                && (this.sourceCurrency == currency || this.targetCurrency == currency);
    }
}
