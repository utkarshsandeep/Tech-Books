package com.unimoni.pricingengine.domain.model.rate.settlement.dto;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "updateSettlementRateRequest", description = "Update Settlement rate request")
public class UpdateSettlementRateRequest {

    @Getter(value = AccessLevel.NONE)
    @Size(min = 0, max = 4)
    private Map<@NotNull VDWType, @NotNull UpdateMarginDTO> vdwMargins;

    @Getter(value = AccessLevel.NONE)
    @ApiModelProperty(name = "status", allowEmptyValue = false, dataType = "Boolean", value = "New status, either true or false", required = false, example = "false", allowableValues = "true,false")
    private Boolean status;

    @NotBlank(message = "Reason cannot be empty")
    @Valid
    @ApiModelProperty(name = "reason", allowEmptyValue = false, dataType = "String", value = "The reson for update", required = true, example = "High volatility")
    private String reason;

    @ApiModelProperty(hidden = true)
    public Optional<Map<VDWType, UpdateMarginDTO>> getValueDateWises() {
        return Optional.ofNullable(this.vdwMargins);
    }

    public Optional<Boolean> getStatus() {
        return Optional.ofNullable(this.status);
    }
}