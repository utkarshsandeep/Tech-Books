package com.unimoni.pricingengine.domain.model.remittance.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.remittance.AskBidMargin;
import com.unimoni.pricingengine.domain.model.remittance.IBRRate;
import com.unimoni.pricingengine.domain.model.remittance.LayerCharge;
import com.unimoni.pricingengine.domain.model.remittance.RateSkipSetting;
import com.unimoni.pricingengine.domain.model.remittance.RemittanceTransactionInitiationResponse;
import com.unimoni.pricingengine.domain.model.remittance.SellBuyRate;
import com.unimoni.pricingengine.domain.model.remittance.TxnSDCharge;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "of", access = AccessLevel.PRIVATE)
@ToString
@ApiModel(value = "transactionChargeResponse", description = "Remittance Transaction Charge Response")
public class TransactionChargeResponse {

    @ApiModelProperty(name = "transactionUUID", value = "Remittance Transaction UUID", required = true, position = 1)
    private String transactionUUID;

    @ApiModelProperty(name = "charge", value = "Remittance Transaction Charges", required = true, position = 2)
    @JsonInclude(NON_NULL)
    private TxnSDCharge charge;

    @ApiModelProperty(name = "valueDateWise", dataType = "String", value = "Value Date Wise as either of CASH, TOM, SPOT or FUTURE", required = true, allowableValues = "CASH, TOM, SPOT, FUTURE", position = 3)
    private VDWType valueDateWise;

    @ApiModelProperty(name = "rateDisplayMechanism", dataType = "String", value = "Rate Display Machenism of Agent as \"Base currency to Foriegn currency\" or \"Foriegn currency to Base currency\"", required = true, allowEmptyValue = false, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", position = 4)
    private RateDisplayMachenism rateDisplayMechanism;

    @ApiModelProperty(name = "rateSkipSetting", value = "Rate skip setting of Agent", position = 5)
    private RateSkipSetting rateSkipSetting;

    @ApiModelProperty(name = "ibr", value = "Inter Bank Rate", required = true, position = 6)
    private LayerCharge<IBRRate> ibr;

    @ApiModelProperty(name = "var", value = "Value at Risk", required = true, position = 7)
    private LayerCharge<AskBidMargin> var;

    @ApiModelProperty(name = "settlementRate", value = "Settlement Rate", required = true, position = 8)
    private LayerCharge<SellBuyRate> settlementRate;

    @ApiModelProperty(name = "countryRate", value = "Country Rate", required = true, position = 9)
    @JsonInclude(NON_NULL)
    private LayerCharge<BigDecimal> countryRate;

    @ApiModelProperty(name = "agentRate", value = "Agent Rate", required = true, position = 10)
    @JsonInclude(NON_NULL)
    private LayerCharge<BigDecimal> agentRate;

    public static TransactionChargeResponse of(final RemittanceTransactionInitiationResponse txnInitiationResponse,
            final RateSkipSetting rateSkipSetting) {
        if (rateSkipSetting.dontSkipAny()) {
            return of(txnInitiationResponse.transactionUUID(), txnInitiationResponse.charge().skip(rateSkipSetting),
                    txnInitiationResponse.valueDateWise(), txnInitiationResponse.rateDisplayMechanism(),
                    rateSkipSetting, txnInitiationResponse.layerCharges().getIbr(),
                    txnInitiationResponse.layerCharges().getVar(),
                    txnInitiationResponse.layerCharges().getSettlementRate(),
                    txnInitiationResponse.layerCharges().getCountryRate(),
                    txnInitiationResponse.layerCharges().getAgentRate());
        }
        else if (rateSkipSetting.skipAll()) {
            return of(txnInitiationResponse.transactionUUID(), null, txnInitiationResponse.valueDateWise(),
                    txnInitiationResponse.rateDisplayMechanism(), rateSkipSetting,
                    txnInitiationResponse.layerCharges().getIbr(), txnInitiationResponse.layerCharges().getVar(),
                    txnInitiationResponse.layerCharges().getSettlementRate(), null, null);
        }
        else if (rateSkipSetting.skipRatesOnly()) {
            return of(txnInitiationResponse.transactionUUID(), txnInitiationResponse.charge().skip(rateSkipSetting),
                    txnInitiationResponse.valueDateWise(), txnInitiationResponse.rateDisplayMechanism(),
                    rateSkipSetting, txnInitiationResponse.layerCharges().getIbr(),
                    txnInitiationResponse.layerCharges().getVar(),
                    txnInitiationResponse.layerCharges().getSettlementRate(), null, null);
        }
        else {
            return of(txnInitiationResponse.transactionUUID(), txnInitiationResponse.charge().skip(rateSkipSetting),
                    txnInitiationResponse.valueDateWise(), txnInitiationResponse.rateDisplayMechanism(),
                    rateSkipSetting, txnInitiationResponse.layerCharges().getIbr(),
                    txnInitiationResponse.layerCharges().getVar(),
                    txnInitiationResponse.layerCharges().getSettlementRate(),
                    txnInitiationResponse.layerCharges().getCountryRate(),
                    txnInitiationResponse.layerCharges().getAgentRate());
        }
    }
}
