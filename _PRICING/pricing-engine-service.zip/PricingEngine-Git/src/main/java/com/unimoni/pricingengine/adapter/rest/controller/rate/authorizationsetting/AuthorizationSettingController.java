package com.unimoni.pricingengine.adapter.rest.controller.rate.authorizationsetting;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.AUTHORIZATION_QUEUE_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.AUTHORIZATION_SETTING_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.AUTHORIZATION_SETTING_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.AuthorizationSetting.AUTH_QUEUE_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AuthorizationSetting.AUTH_QUEUE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AuthorizationSetting.AUTH_SETTING_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AuthorizationSetting.AUTH_SETTING_URI;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import javax.money.CurrencyUnit;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationStatusType;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationQueueAuthorizeRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationQueueResponse;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationQueueSearchRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingCreateRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingMetaData;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingResponse;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingSearchRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingUpdateRequest;
import com.unimoni.pricingengine.domain.service.ratesetting.AuthorizationQueueService;
import com.unimoni.pricingengine.domain.service.ratesetting.AuthorizationSettingService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import springfox.documentation.annotations.ApiIgnore;

@Validated
@Api(value = "RATE_AUTHORIZATION_SETTING", tags = "Rate Authorization Setting")
@RestController
@RequestMapping(PRICING_API)
@Slf4j
public class AuthorizationSettingController {

    @Autowired
    private AuthorizationSettingService rsService;

    @Autowired
    private AuthorizationQueueService queueService;

    @Autowired
    private PaginatedResourceAssembler<AuthorizationSettingResponse, String> rateSettingAssembler;

    @Autowired
    private PaginatedResourceAssembler<AuthorizationQueueResponse, String> rateQueueAssembler;

    @GetMapping(AUTH_SETTING_URI)
    @ApiOperation(nickname = "get-rate-setting", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets a rate settings records matching the selection filters and sort criteria", notes = "", response = AuthorizationSettingResponse.class, responseContainer = "PaginatedResource")
    @Paginated
    @ApiImplicitParams({
            @ApiImplicitParam(name = "currencies", paramType = "query", dataType = "String", type = "array", value = "ISO Currency Code e.g. USD", allowMultiple = true, example = "INR"),
            @ApiImplicitParam(name = "rateLayerTypes", paramType = "query", dataType = "String", type = "array", dataTypeClass = RateLayerType.class, value = "Rate Layer Type", allowMultiple = false, allowableValues = "IBM_MANAGEMENT, INTER_BANK_RATES, VOLATILITY_MARGIN, SETTLEMENT_MARGIN") })
    public ResponseEntity<PaginatedResource<Resource<AuthorizationSettingResponse>>> getAllRateSettings(
            @ApiParam(allowMultiple = true, type = "String", value = "Rate Setting such as NORMAL, BANKWISE", example = "NORMAL")
            @RequestParam(value = "rateTypes", required = false)
            final List<RMType> rateTypes,

            @ApiParam(allowMultiple = true, type = "String", value = "Layer such as IBM_MANAGEMENT, INTER_BANK_RATES, VOLATILITY_MARGIN, SETTLEMENT_MARGIN", example = "NORMAL")
            @RequestParam(value = "rateLayerTypes", required = false)
            final List<RateLayerType> rateLayerTypes,

            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAEXMUK##### etc.", example = "UAEXMUK#####")
            @RequestParam(value = "serviceProviders", required = false)
            final List<String> serviceProviders,

            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "bankCodes", required = false)
            final List<String> bankCodes,

            @ApiParam(allowMultiple = true, type = "String", value = "Agent Code ", example = "xxxxx")
            @RequestParam(value = "agentCodes", required = false)
            final List<String> agentCodes,

            @RequestParam(value = "currencies", required = false)
            final List<CurrencyUnit> currencies,

            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false)
            final Boolean status,

            @ApiIgnore
            @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, sort = {
                    "UPDATED_ON" }, direction = Sort.Direction.DESC)
            final Pageable pageable, @ApiIgnore
            final PaginationData page, @RequestParam
            @ApiIgnore
            final Map<String, Object> requestParams) {
        // @formatter:on
        final List<AuthorizationSettingResponse> results = rsService
                .getAllRateSettings(AuthorizationSettingSearchRequest.of(rateTypes, rateLayerTypes, serviceProviders,
                        bankCodes, agentCodes, currencies, status, page));

        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(rateSettingAssembler.assemble(results, page, requestParams));
        }
    }

    @PostMapping(AUTH_SETTING_URI)
    @ApiOperation(nickname = "create-authorization-setting", value = "Creates one or multiple new auhtorization setting records", notes = "Create request for authorization settings", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, response = AuthorizationSettingMetaData.class, responseContainer = "List")
    public ResponseEntity<AuthorizationSettingMetaData> createAuthorizationSetting(
            @ApiParam(required = true, name = "createRequests", value = "A List of create Settlement rate requests")
            @RequestBody
            @Valid
            final AuthorizationSettingCreateRequest request) {

        AuthorizationSettingMetaData result = rsService.createRateSetting(request);

        result.setMessage(getMessage(AUTHORIZATION_SETTING_CREATED_SUCCESSFULLY,
                result.getNewAuthorizationSettingCount(), result.getDuplicateAuthorizationSettingCount(),
                result.getNonMatchingAuthorizationSettingCount()));

        return ResponseEntity.ok(result);
    }

    @PatchMapping(AUTH_SETTING_URI)
    @ApiOperation(nickname = "update-authorization-setting-status", value = "Updates one or multiple Authorization setting records", notes = "Request should only contain the updated status values ", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, response = AuthorizationSettingResponse.class, responseContainer = "List")
    @Valid
    public ResponseEntity<List<AuthorizationSettingResponse>> updateStatus(
            @ApiParam(name = "updateAuthSettingStatusRequests", value = "Updates map with record id as key and updated properties as values")
            @RequestBody
            @Valid
            @NotEmpty
            final Map<@NotEmpty String, @NotNull AuthorizationSettingUpdateRequest> updates) {
        final List<AuthorizationSettingResponse> results = rsService.updateStatus(updates);
        return ResponseEntity.ok()
                .headers(addSuccess(getMessage(AUTHORIZATION_SETTING_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }

    @GetMapping(AUTH_SETTING_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-authorization-settings", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download Rate Authorization settings records matching the selection filters and sort criteria", 
        notes = "",
        response = Void.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", dataType = "String", type = "array", value = "ISO Currency Code e.g. USD", allowMultiple = true, example = "INR"),
        @ApiImplicitParam(name = "rateLayerTypes", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = RateLayerType.class,
        value = "Rate Layer Type", allowMultiple = false, 
                allowableValues = "IBM_MANAGEMENT, INTER_BANK_RATES, VOLATILITY_MARGIN, SETTLEMENT_MARGIN"
        )})
    public void downloadRateAuthorizationSettings(
            @ApiParam(allowMultiple = true, type = "String", value = "Rate Setting such as NORMAL, BANKWISE", example = "NORMAL")
            @RequestParam(value = "rateTypes", required = false) final List<RMType> rateTypes,

            @ApiParam(allowMultiple = true, type = "String", value = "Layer such as IBM_MANAGEMENT, INTER_BANK_RATES, VOLATILITY_MARGIN, SETTLEMENT_MARGIN", example = "NORMAL")
            @RequestParam(value = "rateLayerTypes", required = false) final List<RateLayerType> rateLayerTypes,

            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAEXMUK##### etc.", example = "UAEXMUK#####")
            @RequestParam(value = "serviceProviders", required = false) final List<String> serviceProviders,

            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "bankCodes", required = false) final List<String> bankCodes,

            @ApiParam(allowMultiple = true, type = "String", value = "Agent Code ", example = "xxxxx")
            @RequestParam(value = "agentCodes", required = false) final List<String> agentCodes,

            @RequestParam(value = "currencies", required = false) final List<CurrencyUnit> currencies,

            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status,
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on

        FileDownloadHelper.downloadFile(
                AuthorizationSettingSearchRequest.ofDownload(rateTypes, rateLayerTypes, serviceProviders, bankCodes,
                        agentCodes, currencies, status),
                rsService::getAllRateSettings, downloadFileType, fileName, DownloadContext.RATE_AUTHORIZATION_SETTING,
                response);

    }


    @GetMapping(AUTH_QUEUE_DOWNLOAD_URI)
    @ApiOperation(nickname = "download-authorization-queue-settings", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Download Authorization Queue records matching the selection filters and sort criteria", notes = "", response = Void.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "currencies", paramType = "query", dataType = "String", type = "array", value = "ISO Currency Code e.g. USD", allowMultiple = true, example = "INR"),
            @ApiImplicitParam(name = "rateLayerTypes", paramType = "query", dataType = "String", type = "array", dataTypeClass = RateLayerType.class, value = "Rate Layer Type", allowMultiple = false, allowableValues = "IBM_MANAGEMENT, INTER_BANK_RATES, VOLATILITY_MARGIN, SETTLEMENT_MARGIN"),
            @ApiImplicitParam(name = "statusType", paramType = "query", dataType = "String", type = "array", dataTypeClass = RateLayerType.class, value = "Status", allowMultiple = false, allowableValues = "APPROVED, REJECTED, PENDING") })
    public void downloadAuthorizationQueues(
            @ApiParam(allowMultiple = true, type = "String", value = "Rate Setting such as NORMAL, BANKWISE", example = "NORMAL")
            @RequestParam(value = "rateTypes", required = false)
            final List<RMType> rateTypes,

            @RequestParam(value = "rateLayerTypes", required = false)
            final List<RateLayerType> rateLayerTypes,

            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAEXMUK##### etc.", example = "UAEXMUK#####")
            @RequestParam(value = "serviceProviders", required = false)
            final List<String> serviceProviders,

            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "bankCodes", required = false)
            final List<String> bankCodes,

            @ApiParam(allowMultiple = true, type = "String", value = "Agent Code ", example = "xxxxx")
            @RequestParam(value = "agentCodes", required = false)
            final List<String> agentCodes,

            @RequestParam(value = "currencies", required = false)
            final List<CurrencyUnit> currencies,

            @RequestParam(value = "statusType", required = false)
            final List<AuthorizationStatusType> status,

            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false)
            final String fileName,

            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true)
            @NotNull
            final DownloadFileType downloadFileType, @ApiIgnore
            final HttpServletResponse response) {

        FileDownloadHelper.downloadFile(
                AuthorizationQueueSearchRequest.ofDownload(rateTypes, rateLayerTypes, serviceProviders, bankCodes,
                        agentCodes, currencies, status),
                queueService::getAllAuthorizationQueueRecords, downloadFileType, fileName,
                DownloadContext.AUTHORIZATION_QUEUE, response);

    }

    @PatchMapping(AUTH_QUEUE_URI)
    @ApiOperation(nickname = "authorize-queue-data", value = "Authorize one or multiple queue records and update layer data", 
    notes = "Request should only contain the updated status values ",
    consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, 
    response = AuthorizationQueueResponse.class, responseContainer = "List")
    @Valid
    public ResponseEntity<List<AuthorizationQueueResponse>> authorizeLayerData(
            @ApiParam(name = "authorizeRequests", required = true, value = "Updates record id in list with given status")
            @RequestBody @Valid AuthorizationQueueAuthorizeRequest request) {
        
        final List<AuthorizationQueueResponse> results = queueService.authorizeLayerData(request);
        
        return ResponseEntity.ok()
                .headers(addSuccess(getMessage(AUTHORIZATION_QUEUE_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }
}
