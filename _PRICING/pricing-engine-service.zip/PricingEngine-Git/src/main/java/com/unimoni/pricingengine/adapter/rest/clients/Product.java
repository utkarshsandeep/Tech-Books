package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Product {
    private String name;

    public Product(@JsonProperty("product") String name) {
        this.name = name;

    }

    public CodeLabelPair<String, String> productItem() {

        return CodeLabelPair.of(this.name, this.name);
    }

    @Override
    public String toString() {
        return "Product [name=" + name + "]";
    }

}
