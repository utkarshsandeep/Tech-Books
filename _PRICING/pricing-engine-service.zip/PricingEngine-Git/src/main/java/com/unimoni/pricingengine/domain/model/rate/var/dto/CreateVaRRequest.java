package com.unimoni.pricingengine.domain.model.rate.var.dto;

import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.unimoni.pricingengine.domain.model.rate.base.dto.ExchangeDTO;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.rate.var.VaRValueDateWise;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "createVaRRequest", description = "The request to create one or multiple new VaRs")
public class CreateVaRRequest {

    @ApiModelProperty(name = "varId", dataType = "String", value = "The IBR object ID to be linked with this VaR, as recieved in metadata API response", required = true, allowEmptyValue = false, example = "c0a85bc6-692d-1835-8169-2de8e9fa000b")
    @NotEmpty
    private String ibrId;

    @ApiModelProperty(name = "agent", dataType = "String", value = "Agent", required = true)
    @NotNull
    private String agent;

    @ApiModelProperty(name = "bank", dataType = "String", value = "Bank, required only if rmType is BANK_WISE", required = false)
    private String bank;

    @NotNull
    @Valid
    private ExchangeDTO exchange;

    @NotNull
    @Valid
    private AllInstrumentsDTO instruments;

    @NotNull
    @Size(min = 4, max = 4)
    @Valid
    private Map<@NotNull VDWType, @NotNull VaRValueDateWiseDTO> valueDateWises;

    public Map<VDWType, VaRValueDateWise> valueDateWises() {
        return this.valueDateWises.entrySet().stream()
                .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue().toModel()));
    }

    @ApiModelProperty(name = "reasonForChange", dataType = "String", value = "The reason for change of this rate", allowEmptyValue = false, example = "High volatility")
    private String reasonForChange;

    public Optional<String> getBank() {
        return Optional.ofNullable(this.bank);
    }
}
