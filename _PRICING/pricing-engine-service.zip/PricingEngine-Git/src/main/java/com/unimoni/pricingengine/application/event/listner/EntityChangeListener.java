package com.unimoni.pricingengine.application.event.listner;

import javax.persistence.PostUpdate;

import com.unimoni.pricingengine.application.service.event.EventPublisher;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateResponse;
import com.unimoni.pricingengine.domain.model.rate.base.BankWiseBaseRate;
import com.unimoni.pricingengine.domain.model.rate.base.NormalBaseRate;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseRateResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.IBRResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.NormalRateResponse;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateResponse;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementRateResponse;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRResponse;

//@Slf4j
public class EntityChangeListener {

    @PostUpdate
    public void entityPostUpdate(Object object) {
        if (object instanceof NormalBaseRate) {
            // log.debug(">>>>>>>> Listening entityPostUpdate for NormalBaseRate >>>>>>>>");

            NormalBaseRate normalBaseRate = (NormalBaseRate) object;
            EventPublisher.publishServerSentEvents(NormalRateResponse.of(normalBaseRate));
        }

        if (object instanceof BankWiseBaseRate) {
            // log.debug(">>>>>>>> Listening entityPostUpdate for BankWiseBaseRate >>>>>>>>");

            BankWiseBaseRate bankWiseBaseRate = (BankWiseBaseRate) object;
            EventPublisher.publishServerSentEvents(BankWiseRateResponse.of(bankWiseBaseRate));
        }

        if (object instanceof NormalIBR) {
            // log.debug(">>>>>>>> Listening entityPostUpdate for NormalIBR >>>>>>>>");

            NormalIBR normalIBR = (NormalIBR) object;
            EventPublisher.publishServerSentEvents(IBRResponse.of(normalIBR));
        }

        if (object instanceof BankWiseIBR) {
            // log.debug(">>>>>>>>>> Listening entityPostUpdate for BankWiseIBR >>>>>>>>>>");

            BankWiseIBR bankWiseIBR = (BankWiseIBR) object;
            EventPublisher.publishServerSentEvents(IBRResponse.of(bankWiseIBR));
        }

        if (object instanceof VaR) {
            // log.debug(">>>>>>>>>> Listening entityPostUpdate for VaR >>>>>>>>>>");

            VaR var = (VaR) object;
            EventPublisher.publishServerSentEvents(VaRResponse.of(var));
        }

        if (object instanceof SettlementRate) {
            // log.debug(">>>>>>>>>> Listening entityPostUpdate for SettlementRate >>>>>>>>>>");

            SettlementRate settlementRate = (SettlementRate) object;
            EventPublisher.publishServerSentEvents(SettlementRateResponse.of(settlementRate));
        }

        if (object instanceof CountryRate) {
            // log.debug(">>>>>>>>>> Listening entityPostUpdate for CountryRate >>>>>>>>>>");

            CountryRate countryRate = (CountryRate) object;
            EventPublisher.publishServerSentEvents(CountryRateResponse.of(countryRate));
        }

        if (object instanceof AgentRate) {
            // log.debug(">>>>>>>>>> Listening entityPostUpdate for AgentRate >>>>>>>>>>");

            AgentRate agentRate = (AgentRate) object;
            EventPublisher.publishServerSentEvents(AgentRateResponse.of(agentRate));
        }
    }
}