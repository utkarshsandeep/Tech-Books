package com.unimoni.pricingengine.application.service.onboarding.model;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.country.AgentItem;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@ApiModel(value = "agentListItem", description = "Agent or Branch Dropdown list item")
@EqualsAndHashCode(of = "id", callSuper = false)
public class AgentListItem extends AbstractPairItem {

    @ApiModelProperty(name = "id", value = "Agent or Branch Id to be used in Remittance Transactions", example = "345", position = 1)
    private long id;

    @ApiModelProperty(name = "type", dataType = "String", value = "Whether its an agent or branch", example = "AGENT", allowableValues = "AGENT,BRANCH", position = 4)
    private AgentItem.Type type;

    @ApiModelProperty(name = "rateDisplayMachenism", dataType = "String", value = "Rate display machenism", example = "BC_TO_FC", allowableValues = "BC_TO_FC,FC_TO_BC", position = 5)
    private RateDisplayMachenism rateDisplayMachenism;

    @ApiModelProperty(name = "id", value = "Parent Agent Id of branch", example = "433", position = 6)
    @JsonInclude(NON_NULL)
    private Long parentAgent;

    public AgentListItem(final long id, final String code, final String name, final AgentItem.Type type,
            final RateDisplayMachenism rateDisplayMachenism, final Long parentAgent) {
        super(code, name);
        this.id = id;
        this.type = type;
        this.rateDisplayMachenism = rateDisplayMachenism;
        this.parentAgent = parentAgent;
    }
    
    public static AgentListItem ofAgent(final long id, final String code, final String name, 
            final RateDisplayMachenism rateDisplayMachenism) {
        return new AgentListItem(id, code, name, AgentItem.Type.AGENT, rateDisplayMachenism, null);
    }
    
    public static AgentListItem ofBranch(final long id, final String code, final String name, 
            final RateDisplayMachenism rateDisplayMachenism, final Long parentAgent) {
        return new AgentListItem(id, code, name, AgentItem.Type.BRANCH, rateDisplayMachenism, parentAgent);
    }
}
