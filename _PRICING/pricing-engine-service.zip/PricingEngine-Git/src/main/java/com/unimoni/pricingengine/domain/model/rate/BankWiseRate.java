package com.unimoni.pricingengine.domain.model.rate;

public interface BankWiseRate {

    // Common methods for Normal rate markup layer

//    public String bank();
}
