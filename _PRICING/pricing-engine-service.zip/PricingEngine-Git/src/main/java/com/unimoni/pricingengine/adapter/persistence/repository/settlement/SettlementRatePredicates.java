package com.unimoni.pricingengine.adapter.persistence.repository.settlement;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;
import static com.unimoni.pricingengine.common.constants.ApplicationConstants.CURRENCY_UNIT_USD;

import java.util.ArrayList;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments_;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate_;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SearchSettlementRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementIdentity;

public abstract class SettlementRatePredicates {

    public static Predicate getSettlementRateByIdentityPredicates(final Root<SettlementRate> root,
            final CriteriaBuilder criteriaBuilder, final RMType rmType, final SettlementIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(SettlementRate_.rmType.getName()), rmType));
        predicates.add(criteriaBuilder.equal(root.get(SettlementRate_.instruments.getName()),
                identity.getInstruments().toModel()));
        predicates.add(criteriaBuilder.equal(root.get(SettlementRate_.agent.getName()), identity.getAgent()));
        if (rmType.isBankWise()) {
            predicates.add(criteriaBuilder.equal(root.get(SettlementRate_.bank.getName()), identity.getBank().get()));
        }
        predicates.add(
                criteriaBuilder.equal(root.get(SettlementRate_.currency.getName()), identity.getCurrency().toModel()));

        return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
    }

    public static Predicate[] getSearchSettlementRatesPredicates(final Root<SettlementRate> root,
            final CriteriaBuilder criteriaBuilder, final SearchSettlementRatesRequest searchRequest) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(SettlementRate_.rmType.getName()), searchRequest.getRmType()));
        if (searchRequest.getAgents() != null && !searchRequest.getAgents().isEmpty()) {
            predicates.add(root.get(SettlementRate_.agent.getName()).in(searchRequest.getAgents()));
        }
        if (searchRequest.getRmType().isBankWise() && searchRequest.getBanks() != null
                && !searchRequest.getBanks().isEmpty()) {
            predicates.add(root.get(SettlementRate_.bank.getName()).in(searchRequest.getBanks()));
        }
        if (searchRequest.getServiceProviders() != null && !searchRequest.getServiceProviders().isEmpty()) {
            predicates.add(root.get(SettlementRate_.instruments.getName())
                    .get(AllInstruments_.serviceProvider.getName()).in(searchRequest.getServiceProviders()));
        }
        if (searchRequest.getProducts() != null && !searchRequest.getProducts().isEmpty()) {
            predicates.add(root.get(SettlementRate_.instruments.getName()).get(AllInstruments_.product.getName())
                    .in(searchRequest.getProducts()));
        }
        if (searchRequest.getSubProducts() != null && !searchRequest.getSubProducts().isEmpty()) {
            predicates.add(root.get(SettlementRate_.instruments.getName()).get(AllInstruments_.subProduct.getName())
                    .in(searchRequest.getSubProducts()));
        }
        if (searchRequest.getServiceTypes() != null && !searchRequest.getServiceTypes().isEmpty()) {
            predicates.add(root.get(SettlementRate_.instruments.getName()).get(AllInstruments_.serviceType.getName())
                    .in(searchRequest.getServiceTypes()));
        }
        if (searchRequest.getCurrencies() != null) {
            Predicate usdCurrencyPredicate = null;
            if (searchRequest.isUsdCurrency()) {
                usdCurrencyPredicate = criteriaBuilder.and(
                        criteriaBuilder.equal(root.get(SettlementRate_.currency.getName()).get("source"),
                                CURRENCY_UNIT_USD),
                        criteriaBuilder.equal(root.get(SettlementRate_.currency.getName()).get("target"),
                                CURRENCY_UNIT_USD));
            }
            Predicate nonUSDCurrenciesPredicate = null;
            if (searchRequest.getCurrencies() != null && !searchRequest.getCurrencies().isEmpty()) {
                nonUSDCurrenciesPredicate = criteriaBuilder.or(
                        root.get(SettlementRate_.currency.getName()).get("source").in(searchRequest.getCurrencies()),
                        root.get(SettlementRate_.currency.getName()).get("target").in(searchRequest.getCurrencies()));
            }
            predicates
                    .add(criteriaBuilder.or(usdCurrencyPredicate != null ? usdCurrencyPredicate : criteriaBuilder.or(),
                            nonUSDCurrenciesPredicate != null ? nonUSDCurrenciesPredicate : criteriaBuilder.or()));
        }

        if (searchRequest.getStatus() != null) {
            predicates
                    .add(criteriaBuilder.equal(root.get(SettlementRate_.enabled.getName()), searchRequest.getStatus()));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getSettlementRateByRmTypeAndId(Root<SettlementRate> root, CriteriaBuilder criteriaBuilder,
            RMType rmType, String id) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(SettlementRate_.id.getName()), id));
        if (RMType.NORMAL.equals(rmType)) {
            predicates.add(criteriaBuilder.equal(root.get(SettlementRate_.rmType.getName()), rmType));
        }
        predicates.add(criteriaBuilder.equal(root.get(SettlementRate_.enabled.getName()), true));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate getSettlementRatePredicatesForHighestPriorityFetch(final Root<SettlementRate> root,
            final CriteriaBuilder criteriaBuilder, final RMType rmType, final String serviceProvider,
            final String product, final String subProduct, final String serviceType, final String bank,
            final String agent, final CurrencyUnit currency) {

        Predicate basicPredicate = criteriaBuilder.and(
                criteriaBuilder.or(
                        criteriaBuilder.equal(root.get(SettlementRate_.instruments.getName())
                                .get(AllInstruments_.serviceProvider.getName()), serviceProvider),
                        criteriaBuilder.equal(root.get(SettlementRate_.instruments.getName())
                                .get(AllInstruments_.serviceProvider.getName()), ALL_INSTRUMENTS)),
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(SettlementRate_.instruments.getName()).get(AllInstruments_.product.getName()),
                                product),
                        criteriaBuilder.equal(
                                root.get(SettlementRate_.instruments.getName()).get(AllInstruments_.product.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.or(
                        criteriaBuilder.equal(root.get(SettlementRate_.instruments.getName())
                                .get(AllInstruments_.subProduct.getName()), subProduct),
                        criteriaBuilder.equal(root.get(SettlementRate_.instruments.getName())
                                .get(AllInstruments_.subProduct.getName()), ALL_INSTRUMENTS)),
                criteriaBuilder.or(
                        criteriaBuilder.equal(root.get(SettlementRate_.instruments.getName())
                                .get(AllInstruments_.serviceType.getName()), serviceType),
                        criteriaBuilder.equal(root.get(SettlementRate_.instruments.getName())
                                .get(AllInstruments_.serviceType.getName()), ALL_INSTRUMENTS)),
                criteriaBuilder.or(criteriaBuilder.equal(root.get(SettlementRate_.agent.getName()), agent),
                        criteriaBuilder.equal(root.get(SettlementRate_.agent.getName()), ALL_INSTRUMENTS)),
                criteriaBuilder.equal(root.get(SettlementRate_.enabled.getName()), true),
                criteriaBuilder.equal(root.get(SettlementRate_.rmType.getName()), rmType), CURRENCY_UNIT_USD == currency
                        ? criteriaBuilder.and(
                                criteriaBuilder.equal(
                                        root.get(SettlementRate_.currency.getName()).get("source"), CURRENCY_UNIT_USD),
                                criteriaBuilder.equal(root.get(SettlementRate_.currency.getName()).get("target"),
                                        CURRENCY_UNIT_USD))
                        : criteriaBuilder.or(
                                criteriaBuilder.equal(root.get(SettlementRate_.currency.getName()).get("source"),
                                        currency),
                                criteriaBuilder.equal(root.get(SettlementRate_.currency.getName()).get("target"),
                                        currency)));

        if (rmType.isBankWise()) {
            return criteriaBuilder.and(basicPredicate,
                    criteriaBuilder.or(criteriaBuilder.equal(root.get(SettlementRate_.bank.getName()), bank),
                            criteriaBuilder.equal(root.get(SettlementRate_.bank.getName()), ALL_INSTRUMENTS)));
        }
        else {
            return basicPredicate;
        }
    }
}
