package com.unimoni.pricingengine.adapter.persistence.repository.country;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.NonUniqueResultException;
import javax.persistence.Tuple;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.MapJoin;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryRateEnquiryIdentity;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryRateEnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryVDWRateType;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRateValueDateWise;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate_;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.country.dto.SearchCountryRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class CountryRateRepositoryImpl extends AbstractJPA implements CountryRateRepositoryJPA {

    @Override
    public Optional<CountryRate> findActiveCountryRateByIdentity(final RMType rmType,
            final CountryRateIdentity countryIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<CountryRate> query = criteriaQuery(CountryRate.class);
        Root<CountryRate> var = query.from(CountryRate.class);
        query.where(CountryRatePredicates.getCountryRateByIdentityPredicates(var, criteriaBuilder, rmType,
                countryIdentity));
        query.select(var);
        return getSingleResultSafely(query);
    }

    @Override
    public List<CountryRate> findAllCountryRates(final SearchCountryRatesRequest searchRequest) {
        long totalRecords = findCountryRatesCount(searchRequest);
        searchRequest.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            CriteriaQuery<CountryRate> query = criteriaQuery(CountryRate.class);
            Root<CountryRate> rate = query.from(CountryRate.class);

            query.where(CountryRatePredicates.getSearchCountryRatesPredicates(rate, criteriaBuilder, searchRequest));

            query.select(rate);
            query.distinct(true);
            query.orderBy(criteriaBuilder.asc(rate.get(CountryRate_.currency.getName()).get("base")));

            TypedQuery<CountryRate> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(searchRequest.page().queryFirstResult());
            typedQuery.setMaxResults(searchRequest.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findCountryRatesCount(final SearchCountryRatesRequest searchRequest) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<CountryRate> rate = query.from(CountryRate.class);

        query.where(CountryRatePredicates.getSearchCountryRatesPredicates(rate, criteriaBuilder, searchRequest));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<CountryRate> findCountryRatesByIds(RMType rmType, List<String> ids, boolean eagerFetchCountry) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<CountryRate> query = criteriaQuery(CountryRate.class);
        Root<CountryRate> settlement = query.from(CountryRate.class);
        query.where(criteriaBuilder.and(criteriaBuilder.equal(settlement.get(CountryRate_.rmType.getName()), rmType),
                settlement.get(CountryRate_.id.getName()).in(ids)));
        query.select(settlement);
        TypedQuery<CountryRate> typedQuery = typedQuery(query);
        // if (eagerFetchCountry) {
        // typedQuery.setHint("javax.persistence.fetchgraph",
        // entityManager.getEntityGraph("bankWiseBaseRate"));
        // }
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public Optional<CountryRate> findHighestPriorityCountryRateByAgentBasicIdentity(RMType rmType,
            AgentRateIdentity identity) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<CountryRate> query = criteriaQuery(CountryRate.class);
        Root<CountryRate> rate = query.from(CountryRate.class);
        query.select(rate);
        Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
        Root<CountryRate> maxPriority = maxPriorityQuery.from(CountryRate.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(CountryRate_.priority.getName())));
        maxPriorityQuery.where(CountryRatePredicates.getCountryRatesByAgentIdentitiesPredicates(maxPriority,
                criteriaBuilder, rmType, identity));

        query.where(
                criteriaBuilder.and(
                        CountryRatePredicates.getCountryRatesByAgentIdentitiesPredicates(rate, criteriaBuilder, rmType,
                                identity),
                        criteriaBuilder.equal(rate.get(CountryRate_.priority.getName()), maxPriorityQuery)));
        if (identity.isAgent()) {
            try {
                return getSingleResultSafely(query);
            }
            catch (final NonUniqueResultException unre) {
                log.error("Duplicate highest priority Country rate record for rmType: {} and AgentRateIdentity: {}",
                        rmType, identity);
                throw unre;
            }
        }
        else {
            List<CountryRate> agentAndBranchCountryRates = getUnmodifiableResultList(query);
            if (agentAndBranchCountryRates.isEmpty()) {
                return Optional.empty();
            }
            else if (agentAndBranchCountryRates.size() == 1) {
                return Optional.of(agentAndBranchCountryRates.get(0));
            }
            else {
                for (CountryRate cr : agentAndBranchCountryRates) {
                    if (cr.agent().isBranch()) {
                        return Optional.of(cr);
                    }
                }
            }
            // Above if-elses cater to all conditions, following will never happen
            return Optional.empty();
        }
    }

    @Override
    public CountryRate getCountryRateReference(RMType rmType, String countryRateId) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<CountryRate> query = criteriaQuery(CountryRate.class);
        Root<CountryRate> settlement = query.from(CountryRate.class);
        query.where(
                CountryRatePredicates.getCountryRateByRmTypeAndId(settlement, criteriaBuilder, rmType, countryRateId));
        query.select(settlement);
        return getSingleResultSafely(query).get();
    }

    @Override
    public Optional<CountryRateEnquiryResponse> findCountryRateForEnquiry(final RMType rmType,
            final CountryVDWRateType vdwRateType, final CountryRateEnquiryIdentity enquiryIdentity) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Tuple> query = criteriaQuery(Tuple.class);
        Root<CountryRate> rate = query.from(CountryRate.class);
        MapJoin<CountryRate, VDWType, CountryRateValueDateWise> valueDateWises = rate.join(CountryRate_.valueDateWises);

        AgentRateIdentity agentRateIdentity = enquiryIdentity.agentRateIdentity(rmType);
        Predicate mainQueryPredicate = criteriaBuilder.and(CountryRatePredicates
                .getCountryRatesByAgentIdentitiesPredicates(rate, criteriaBuilder, rmType, agentRateIdentity),
                valueDateWises.key().in(enquiryIdentity.valueDateWises()));

        query.multiselect(valueDateWises.key(), valueDateWises.value());

        Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
        Root<CountryRate> maxPriority = maxPriorityQuery.from(CountryRate.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(CountryRate_.priority.getName())));

        maxPriorityQuery.where(CountryRatePredicates.getCountryRatesByAgentIdentitiesPredicates(rate, criteriaBuilder,
                rmType, agentRateIdentity));

        query.where(mainQueryPredicate,
                criteriaBuilder.equal(rate.get(CountryRate_.priority.getName()), maxPriorityQuery));
        List<Tuple> result = getUnmodifiableResultList(query);
        Map<VDWType, CountryRateValueDateWise> vdwRates = result.stream()
                .collect(Collectors.toMap(t -> (VDWType) t.get(0), t -> (CountryRateValueDateWise) t.get(1),
                        (e1, e2) -> e1, () -> new LinkedHashMap<VDWType, CountryRateValueDateWise>(result.size())));

        return CountryRateEnquiryResponse.of(enquiryIdentity, vdwRateType, vdwRates);
    }
}
