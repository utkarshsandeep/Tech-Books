package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.util.List;
import java.util.stream.Collectors;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.common.enums.standard.CurrencyCode;
import com.unimoni.pricingengine.domain.model.common.dto.AbstractSearchRequest;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
public class SearchBankWiseBaseRateRequest extends AbstractSearchRequest {

    private List<String> banks;

    private List<String> agents;

    private List<String> serviceProviders;

    private List<String> products;

    private List<CurrencyUnit> currencies;

    private boolean usdCurrency;

    private Boolean status;

    private SearchBankWiseBaseRateRequest(final List<String> banks, final List<String> agents,
            final List<String> serviceProviders, final List<String> products, final List<CurrencyUnit> currencies,
            final Boolean status, final PaginationData page) {
        this.banks = banks;
        this.agents = agents;
        this.serviceProviders = serviceProviders;
        this.products = products;
        if (currencies != null && currencies.contains(CurrencyCode.USD.getCurrencyUnit())) {
            this.usdCurrency = true;
            this.currencies = currencies.stream().filter(curr -> !curr.equals(CurrencyCode.USD.getCurrencyUnit()))
                    .collect(Collectors.toList());
        }
        else {
            this.usdCurrency = false;
            this.currencies = currencies;
        }
        this.status = status;
        this.page = page;
    }

    public static SearchBankWiseBaseRateRequest of(final List<String> banks, final List<String> agents,
            final List<String> serviceProviders, final List<String> products, final List<CurrencyUnit> currencies,
            final Boolean status, final PaginationData page) {
        return new SearchBankWiseBaseRateRequest(banks, agents, serviceProviders, products, currencies, status, page);
    }

    public static SearchBankWiseBaseRateRequest ofDownload(final List<String> banks, final List<String> agents,
            final List<String> serviceProviders, final List<String> products, final List<CurrencyUnit> currencies,
            final Boolean status) {
        return of(banks, agents, serviceProviders, products, currencies, status,
                PaginationData.ofFirstPage(BeanFactory.applicationProperties().getDownloadChunkSize()));
    }
}
