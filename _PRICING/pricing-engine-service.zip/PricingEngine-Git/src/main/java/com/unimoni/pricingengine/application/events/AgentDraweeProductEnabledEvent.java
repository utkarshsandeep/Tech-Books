package com.unimoni.pricingengine.application.events;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentDraweeProductEnabledEvent {
	

	private Integer draweeBankProductProfileId;
	
	private Integer agentDraweeBank4RatesId;
	
	
	public AgentDraweeProductEnabledEvent(@JsonProperty Integer draweeBankProductProfileId, 
		@JsonProperty Integer agentDraweeBank4RatesId)
	{
			
		this.draweeBankProductProfileId=draweeBankProductProfileId;
		this.agentDraweeBank4RatesId= agentDraweeBank4RatesId;
	}
	


}
