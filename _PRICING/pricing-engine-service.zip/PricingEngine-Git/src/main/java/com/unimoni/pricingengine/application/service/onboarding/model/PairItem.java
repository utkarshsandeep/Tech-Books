package com.unimoni.pricingengine.application.service.onboarding.model;

import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

public interface PairItem<T, S> extends Comparable<PairItem<T, S>> {

    CodeNamePair<T, S> pair(); 
}
