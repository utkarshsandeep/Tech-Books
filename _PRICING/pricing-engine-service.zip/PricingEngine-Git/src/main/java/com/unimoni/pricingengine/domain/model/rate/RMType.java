package com.unimoni.pricingengine.domain.model.rate;

import com.fasterxml.jackson.annotation.JsonCreator;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "rmType", description = "Rate Management Type")
public enum RMType {

    // @formatter:off
    NORMAL("Normal or agent wise rate"),
    BANK_WISE("Bank wise rate");
    // @formatter:on

    private final String description;

    private RMType(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }

    @JsonCreator
    public static RMType of(final String name) {
        for (RMType e : values())
            if (e.name().equals(name))
                return e;
        throw new IllegalArgumentException();
    }

    public boolean isNormal() {
        return this == NORMAL;
    }

    public boolean isBankWise() {
        return this == RMType.BANK_WISE;
    }
}
