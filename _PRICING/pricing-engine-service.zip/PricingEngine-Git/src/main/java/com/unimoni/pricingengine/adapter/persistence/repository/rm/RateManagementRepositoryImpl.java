package com.unimoni.pricingengine.adapter.persistence.repository.rm;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.money.CurrencyUnit;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.BankWiseIBREnquiryIdentity;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.BankWiseIBREnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.NormalIBREnquiryIdentity;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.NormalIBREnquiryResponse;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer_;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateProvider_;
import com.unimoni.pricingengine.domain.model.rate.base.BankWiseBaseRate;
import com.unimoni.pricingengine.domain.model.rate.base.BankWiseBaseRate_;
import com.unimoni.pricingengine.domain.model.rate.base.NormalBaseRate;
import com.unimoni.pricingengine.domain.model.rate.base.NormalBaseRate_;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseEventRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateIdentity;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchBankWiseBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchNormalBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.composable.Exchange_;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR_;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR_;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRBasicIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRIdentity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class RateManagementRepositoryImpl extends AbstractJPA implements RateManagementRepositoryJPA {

    @Override
    public List<NormalBaseRate> findAllNormalBaseRates(final SearchNormalBaseRateRequest request) {
        long totalRecords = findNormalBaseRatesCount(request);
        request.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            CriteriaQuery<NormalBaseRate> query = criteriaQuery(NormalBaseRate.class);
            Root<NormalBaseRate> rate = query.from(NormalBaseRate.class);

            query.where(BaseRatePredicates.getSearchNormalRatesPredicates(rate, criteriaBuilder, request));

            query.select(rate);
            query.distinct(true);
            query.orderBy(
                    criteriaBuilder.asc(rate.get(NormalBaseRate_.exchange.getName()).get("currency").get("source")));

            TypedQuery<NormalBaseRate> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(request.page().queryFirstResult());
            typedQuery.setMaxResults(request.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    public List<NormalBaseRate> findEnabledNonManualNormalBaseRates() {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<NormalBaseRate> query = criteriaQuery(NormalBaseRate.class);
        Root<NormalBaseRate> rate = query.from(NormalBaseRate.class);
        query.where(criteriaBuilder.and(criteriaBuilder.equal(rate.get(AbstractLayer_.enabled.getName()), true),
                criteriaBuilder.notEqual(rate.get(NormalBaseRate_.rateProvider.getName())
                        .get(RateProvider_.id.getName()).as(Integer.class),
                        ApplicationConstants.MANUAL_RATE_PROVIDER_ID)));

        query.select(rate);
        return getUnmodifiableResultList(query);
    }

    private long findNormalBaseRatesCount(final SearchNormalBaseRateRequest request) {
        CriteriaBuilder criteriaBuilder = entityManager().getCriteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<NormalBaseRate> rate = query.from(NormalBaseRate.class);

        query.where(BaseRatePredicates.getSearchNormalRatesPredicates(rate, criteriaBuilder, request));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<NormalBaseRate> findNormalBaseRatesByIds(List<String> ids, boolean eagerFetchIbrAndVar) {
        CriteriaQuery<NormalBaseRate> query = criteriaQuery(NormalBaseRate.class);
        Root<NormalBaseRate> rate = query.from(NormalBaseRate.class);
        query.where(rate.get(NormalBaseRate_.id.getName()).in(ids));
        query.select(rate);
        TypedQuery<NormalBaseRate> typedQuery = typedQuery(query);
        if (eagerFetchIbrAndVar) {
            typedQuery.setHint("javax.persistence.fetchgraph", entityManager().getEntityGraph("normalBaseRate"));
        }
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public Optional<NormalBaseRate> findActiveNormalBaseRatesByIdentity(final RateIdentity identity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<NormalBaseRate> query = criteriaQuery(NormalBaseRate.class);
        Root<NormalBaseRate> rate = query.from(NormalBaseRate.class);
        query.where(BaseRatePredicates.getIdentityNormalRatesPredicates(rate, criteriaBuilder, identity));
        query.select(rate);
        return getSingleResultSafely(typedQuery(query));
    }

    @Override
    public List<BankWiseBaseRate> findAllBankWiseBaseRates(final SearchBankWiseBaseRateRequest request) {
        long totalRecords = findBankWiseBaseRatesCount(request);
        request.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            CriteriaQuery<BankWiseBaseRate> query = criteriaQuery(BankWiseBaseRate.class);
            Root<BankWiseBaseRate> rate = query.from(BankWiseBaseRate.class);

            query.where(BaseRatePredicates.getSearchBankWiseRatesPredicates(rate, criteriaBuilder, request));

            query.select(rate);
            query.distinct(true);
            query.orderBy(
                    criteriaBuilder.asc(rate.get(NormalBaseRate_.exchange.getName()).get("currency").get("source")));

            TypedQuery<BankWiseBaseRate> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(request.page().queryFirstResult());
            typedQuery.setMaxResults(request.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findBankWiseBaseRatesCount(final SearchBankWiseBaseRateRequest request) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<BankWiseBaseRate> rate = query.from(BankWiseBaseRate.class);
        query.where(BaseRatePredicates.getSearchBankWiseRatesPredicates(rate, criteriaBuilder, request));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<BankWiseBaseRate> findBankWiseBaseRatesByIds(List<String> ids, boolean eagerFetchIbrAndVar) {
        CriteriaQuery<BankWiseBaseRate> query = criteriaQuery(BankWiseBaseRate.class);
        Root<BankWiseBaseRate> rate = query.from(BankWiseBaseRate.class);
        query.where(rate.get(BankWiseBaseRate_.id.getName()).in(ids));
        query.select(rate);
        TypedQuery<BankWiseBaseRate> typedQuery = typedQuery(query);
        if (eagerFetchIbrAndVar) {
            typedQuery.setHint("javax.persistence.fetchgraph", entityManager().getEntityGraph("bankWiseBaseRate"));
        }
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public Optional<BankWiseBaseRate> findActiveBankWiseBaseRatesByIdentity(final BankRateIdentity identity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<BankWiseBaseRate> query = criteriaQuery(BankWiseBaseRate.class);
        Root<BankWiseBaseRate> rate = query.from(BankWiseBaseRate.class);
        query.where(BaseRatePredicates.getIdentityBankWiseRatesPredicates(rate, criteriaBuilder, identity));
        query.select(rate);
        return getSingleResultSafely(query);
    }

    @Override
    public List<NormalIBR> findAllNormalIBRRates(final SearchNormalBaseRateRequest request) {
        long totalRecords = findNormalIBRRatesCount(request);
        request.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            CriteriaQuery<NormalIBR> query = criteriaQuery(NormalIBR.class);
            Root<NormalIBR> rate = query.from(NormalIBR.class);

            query.where(BaseRatePredicates.getSearchNormalIBRPredicates(rate, criteriaBuilder, request));

            query.select(rate);
            query.distinct(true);
            query.orderBy(criteriaBuilder.asc(rate.get(NormalIBR_.exchange.getName()).get("currency").get("source")));

            TypedQuery<NormalIBR> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(request.page().queryFirstResult());
            typedQuery.setMaxResults(request.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findNormalIBRRatesCount(final SearchNormalBaseRateRequest request) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<NormalIBR> rate = query.from(NormalIBR.class);

        query.where(BaseRatePredicates.getSearchNormalIBRPredicates(rate, criteriaBuilder, request));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<NormalIBR> findNormalIBRRatesByIds(List<String> ids, boolean eagerLoadVar) {
        // CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<NormalIBR> query = criteriaQuery(NormalIBR.class);
        Root<NormalIBR> rate = query.from(NormalIBR.class);
        if (eagerLoadVar) {
            rate.fetch(NormalIBR_.vars, JoinType.LEFT);
            query.where(rate.get(NormalIBR_.id.getName()).in(ids));
            // query.where(rate.get(NormalIBR_.id.getName()).in(ids), criteriaBuilder
            // .equal(rate.join(NormalIBR_.vars.getName(), JoinType.LEFT).get(VaR_.enabled.getName()), true));
        }
        else {
            query.where(rate.get(NormalIBR_.id.getName()).in(ids));
        }
        query.distinct(true);
        query.select(rate);
        return getUnmodifiableResultList(query);
    }

    @Override
    public NormalIBR getNormalIBRReference(final String ibrId) {
        return getReference(NormalIBR.class, ibrId);
    }

    @Override
    public Optional<NormalIBR> findActiveNormalIBRByIdentity(final RateIdentity identity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<NormalIBR> query = criteriaQuery(NormalIBR.class);
        Root<NormalIBR> rate = query.from(NormalIBR.class);
        query.where(BaseRatePredicates.getIdentityNormalIBRPredicates(rate, criteriaBuilder, identity));
        query.select(rate);
        return getSingleResultSafely(typedQuery(query));
    }

    @Override
    public List<BankWiseIBR> findAllBankWiseIBRRates(final SearchBankWiseBaseRateRequest request) {
        long totalRecords = findBankWiseIBRRatesCount(request);
        request.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            CriteriaQuery<BankWiseIBR> query = criteriaQuery(BankWiseIBR.class);
            Root<BankWiseIBR> rate = query.from(BankWiseIBR.class);

            query.where(BaseRatePredicates.getSearchBankWiseIBRRatesPredicates(rate, criteriaBuilder, request));

            query.select(rate);
            query.distinct(true);
            query.orderBy(criteriaBuilder.asc(rate.get(BankWiseIBR_.exchange.getName()).get("currency").get("source")));

            TypedQuery<BankWiseIBR> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(request.page().queryFirstResult());
            typedQuery.setMaxResults(request.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findBankWiseIBRRatesCount(final SearchBankWiseBaseRateRequest request) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<BankWiseIBR> rate = query.from(BankWiseIBR.class);

        query.where(BaseRatePredicates.getSearchBankWiseIBRRatesPredicates(rate, criteriaBuilder, request));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<BankWiseIBR> findBankWiseIBRRatesByIds(List<String> ids, boolean eagerLoadVar) {
        // CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<BankWiseIBR> query = criteriaQuery(BankWiseIBR.class);
        Root<BankWiseIBR> rate = query.from(BankWiseIBR.class);
        if (eagerLoadVar) {
            rate.fetch(BankWiseIBR_.vars, JoinType.LEFT);
            query.where(rate.get(BankWiseIBR_.id.getName()).in(ids));
            // query.where(rate.get(BankWiseIBR_.id.getName()).in(ids), criteriaBuilder
            // .equal(rate.join(BankWiseIBR_.vars.getName(), JoinType.LEFT).get(VaR_.enabled.getName()), true));
        }
        else {
            query.where(rate.get(BankWiseIBR_.id.getName()).in(ids));
        }
        query.distinct(true);
        query.select(rate);
        return getUnmodifiableResultList(query);
    }

    @Override
    public Optional<NormalBaseRate> findNormalBaseRateById(String id, boolean eagerFetchIbrAndVar) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<NormalBaseRate> query = criteriaQuery(NormalBaseRate.class);
        Root<NormalBaseRate> rate = query.from(NormalBaseRate.class);

        query.select(rate);

        Predicate rateIdEqualsPredicate = criteriaBuilder.equal(rate.get(NormalBaseRate_.id.getName()), id);
        query.where(rateIdEqualsPredicate);

        TypedQuery<NormalBaseRate> typedQuery = typedQuery(query);
        if (eagerFetchIbrAndVar) {
            typedQuery.setHint("javax.persistence.fetchgraph", entityManager().getEntityGraph("normalBaseRate"));
        }
        return getSingleResultSafely(typedQuery);
    }

    @Override
    public BankWiseIBR getBankWiseIBRReference(final String ibrId) {
        return getReference(BankWiseIBR.class, ibrId);
    }

    @Override
    public Optional<BankWiseIBR> findActiveBankWiseIBRByIdentity(final BankRateIdentity identity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<BankWiseIBR> query = criteriaQuery(BankWiseIBR.class);
        Root<BankWiseIBR> rate = query.from(BankWiseIBR.class);
        query.where(BaseRatePredicates.getIdentityBankWiseIBRPredicates(rate, criteriaBuilder, identity));
        query.select(rate);
        return getSingleResultSafely(query);
    }

    @Override
    public Optional<? extends AbstractLayer> findHighestPriorityIBRByVaRBasicIdentity(RMType rmType,
            VaRBasicIdentity varBasicIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        try {
            if (rmType.isNormal()) {
                CriteriaQuery<NormalIBR> query = criteriaQuery(NormalIBR.class);
                Root<NormalIBR> rate = query.from(NormalIBR.class);
                query.select(rate);
                Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
                Root<NormalIBR> maxPriority = maxPriorityQuery.from(NormalIBR.class);
                maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(NormalIBR_.priority.getName())));
                maxPriorityQuery.where(
                        BaseRatePredicates.getNormalIBRBasicPredicatesForHighestPriorityFetch(maxPriority,
                                criteriaBuilder, varBasicIdentity.getServiceProvider(), varBasicIdentity.getProduct()),
                        BaseRatePredicates.getIBRCurrencyPredicateForHighestPriorityFetch(maxPriority, criteriaBuilder,
                                varBasicIdentity.getCurrency()));

                query.where(
                        BaseRatePredicates.getNormalIBRBasicPredicatesForHighestPriorityFetch(rate, criteriaBuilder,
                                varBasicIdentity.getServiceProvider(), varBasicIdentity.getProduct()),
                        BaseRatePredicates.getIBRCurrencyPredicateForHighestPriorityFetch(rate, criteriaBuilder,
                                varBasicIdentity.getCurrency()),
                        criteriaBuilder.equal(rate.get(NormalIBR_.priority.getName()), maxPriorityQuery));

                return getSingleResultSafely(query);
            }
            else {
                CriteriaQuery<BankWiseIBR> query = criteriaQuery(BankWiseIBR.class);
                Root<BankWiseIBR> rate = query.from(BankWiseIBR.class);
                query.select(rate);
                Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
                Root<BankWiseIBR> maxPriority = maxPriorityQuery.from(BankWiseIBR.class);
                maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(BankWiseIBR_.priority.getName())));

                maxPriorityQuery.where(
                        BaseRatePredicates.getBankWiseIBRBasicPredicatesForHighestPriorityFetch(maxPriority,
                                criteriaBuilder, varBasicIdentity.getServiceProvider(), varBasicIdentity.getProduct(),
                                varBasicIdentity.getBank().get(), varBasicIdentity.getAgent()),
                        BaseRatePredicates.getIBRCurrencyPredicateForHighestPriorityFetch(maxPriority, criteriaBuilder,
                                varBasicIdentity.getCurrency()));

                query.where(
                        BaseRatePredicates.getBankWiseIBRBasicPredicatesForHighestPriorityFetch(rate, criteriaBuilder,
                                varBasicIdentity.getServiceProvider(), varBasicIdentity.getProduct(),
                                varBasicIdentity.getBank().get(), varBasicIdentity.getAgent()),
                        BaseRatePredicates.getIBRCurrencyPredicateForHighestPriorityFetch(rate, criteriaBuilder,
                                varBasicIdentity.getCurrency()),
                        criteriaBuilder.equal(rate.get(BankWiseIBR_.priority.getName()), maxPriorityQuery));

                return getSingleResultSafely(query);
            }
        }
        catch (final NonUniqueResultException unre) {
            log.error("Duplicate highest priority IBR record for rmType: {} and VaRBasicIdentity: {}", rmType,
                    varBasicIdentity);
            throw unre;
        }
    }

    @Override
    public Optional<? extends AbstractLayer> findHighestPriorityIBRByVaRIdentity(final RMType rmType,
            final VaRIdentity varIdentity) {
        try {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            if (rmType.isNormal()) {
                CriteriaQuery<NormalIBR> query = criteriaQuery(NormalIBR.class);
                Root<NormalIBR> rate = query.from(NormalIBR.class);
                query.select(rate);
                Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
                Root<NormalIBR> maxPriority = maxPriorityQuery.from(NormalIBR.class);
                maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(NormalIBR_.priority.getName())));
                maxPriorityQuery.where(
                        BaseRatePredicates.getNormalIBRBasicPredicatesForHighestPriorityFetch(maxPriority,
                                criteriaBuilder, varIdentity.getInstruments().getServiceProvider(),
                                varIdentity.getInstruments().getProduct()),
                        BaseRatePredicates.getIBRCurrencyPairPredicateForHighestPriorityFetch(maxPriority,
                                criteriaBuilder, varIdentity.getCurrency().toModel()));

                query.where(BaseRatePredicates.getNormalIBRBasicPredicatesForHighestPriorityFetch(rate, criteriaBuilder,
                        varIdentity.getInstruments().getServiceProvider(), varIdentity.getInstruments().getProduct()),
                        BaseRatePredicates.getIBRCurrencyPairPredicateForHighestPriorityFetch(rate, criteriaBuilder,
                                varIdentity.getCurrency().toModel()),
                        criteriaBuilder.equal(rate.get(NormalIBR_.priority.getName()), maxPriorityQuery));

                return getSingleResultSafely(query);
            }
            else {
                CriteriaQuery<BankWiseIBR> query = criteriaQuery(BankWiseIBR.class);
                Root<BankWiseIBR> rate = query.from(BankWiseIBR.class);
                query.select(rate);
                Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
                Root<BankWiseIBR> maxPriority = maxPriorityQuery.from(BankWiseIBR.class);
                maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(BankWiseIBR_.priority.getName())));

                maxPriorityQuery.where(BaseRatePredicates.getBankWiseIBRBasicPredicatesForHighestPriorityFetch(
                        maxPriority, criteriaBuilder, varIdentity.getInstruments().getServiceProvider(),
                        varIdentity.getInstruments().getProduct(), varIdentity.getBank().get(), varIdentity.getAgent()),
                        BaseRatePredicates.getIBRCurrencyPairPredicateForHighestPriorityFetch(maxPriority,
                                criteriaBuilder, varIdentity.getCurrency().toModel()));

                query.where(BaseRatePredicates.getBankWiseIBRBasicPredicatesForHighestPriorityFetch(rate,
                        criteriaBuilder, varIdentity.getInstruments().getServiceProvider(),
                        varIdentity.getInstruments().getProduct(), varIdentity.getBank().get(), varIdentity.getAgent()),
                        BaseRatePredicates.getIBRCurrencyPairPredicateForHighestPriorityFetch(rate, criteriaBuilder,
                                varIdentity.getCurrency().toModel()),
                        criteriaBuilder.equal(rate.get(BankWiseIBR_.priority.getName()), maxPriorityQuery));

                return getSingleResultSafely(query);
            }
        }
        catch (final NonUniqueResultException unre) {
            log.error("Duplicate highest priority IBR record for rmType: {} and VaRIdentity: {}", rmType, varIdentity);
            throw unre;
        }
    }

    // Added to handle event for Bank Onboard
    @Transactional
    @Override
    public List<NormalIBR> findByCurrencyInNormalIBR(BankWiseEventRateRequest createEventRateRequest) {
        // TODO Auto-generated method stub
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<NormalIBR> query = criteriaQuery(NormalIBR.class);
        Root<NormalIBR> root = query.from(NormalIBR.class);

        query.where(BaseRatePredicates.getSearchNormalIBRPredicatesforEvent(root, criteriaBuilder,
                createEventRateRequest.getCurrencyCode()));

        query.select(root);

        return getUnmodifiableResultList(query);

    }

    @Override
    public long findCountByIdentity(String product, String serviceProvider, CurrencyUnit source, CurrencyUnit target,
            Boolean status, String agentDisplayCode, String bankDisplayCode) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<BankWiseIBR> root = query.from(BankWiseIBR.class);

        query.where(BaseRatePredicates.getCountNormalIBRPredicatesforEvent(root, criteriaBuilder, product,
                serviceProvider, source, target, status, agentDisplayCode, bankDisplayCode));

        query.select(criteriaBuilder.countDistinct(root));

        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<BankWiseBaseRate> findAllActiveBankWiseRateByRateIdentity(final RateIdentity rateIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<BankWiseBaseRate> query = criteriaQuery(BankWiseBaseRate.class);
        Root<BankWiseBaseRate> rate = query.from(BankWiseBaseRate.class);
        query.where(BaseRatePredicates.getIdentityBankWiseRatesPredicatesByRateIdentity(rate, criteriaBuilder,
                rateIdentity));
        query.select(rate);

        return getUnmodifiableResultList(query);
    }

    @Override
    public List<CurrencyUnit> findDistinctNormalIBRCurrencies() {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<CurrencyUnit> query = criteriaQuery(CurrencyUnit.class);
        Root<NormalIBR> rate = query.from(NormalIBR.class);
        query.select(IBRSelectExpressions.currencySelectExpression(rate, criteriaBuilder)).distinct(true);
        query.where(criteriaBuilder.equal(rate.get(NormalIBR_.enabled.getName()), true));
        return getUnmodifiableResultList(query);
    }

    @Override
    public List<CurrencyUnit> findDistinctBankWiseIBRCurrencies() {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<CurrencyUnit> query = criteriaQuery(CurrencyUnit.class);
        Root<BankWiseIBR> rate = query.from(BankWiseIBR.class);
        query.select(IBRSelectExpressions.currencySelectExpression(rate, criteriaBuilder)).distinct(true);
        query.where(criteriaBuilder.equal(rate.get(BankWiseIBR_.enabled.getName()), true));
        return getUnmodifiableResultList(query);
    }

    @Override
    public Optional<NormalIBREnquiryResponse> findNormalIBRForEnquiry(final NormalIBREnquiryIdentity enquiryIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<NormalIBREnquiryResponse> query = criteriaQuery(NormalIBREnquiryResponse.class);
        Root<NormalIBR> rate = query.from(NormalIBR.class);

        query.select(criteriaBuilder.construct(NormalIBREnquiryResponse.class,
                criteriaBuilder.literal(enquiryIdentity.index()),
                criteriaBuilder.literal(enquiryIdentity.serviceProvider()),
                criteriaBuilder.literal(enquiryIdentity.product()),
                IBRSelectExpressions.currencySelectExpression(rate, criteriaBuilder),
                rate.get(NormalIBR_.exchange.getName()).get(Exchange_.rate.getName())));

        Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
        Root<NormalIBR> maxPriority = maxPriorityQuery.from(NormalIBR.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(NormalIBR_.priority.getName())));
        maxPriorityQuery.where(
                BaseRatePredicates.getNormalIBRBasicPredicatesForHighestPriorityFetch(maxPriority, criteriaBuilder,
                        enquiryIdentity.serviceProvider(), enquiryIdentity.product()),
                BaseRatePredicates.getIBRCurrencyPredicateForHighestPriorityFetch(maxPriority, criteriaBuilder,
                        enquiryIdentity.currency()));

        query.where(
                BaseRatePredicates.getNormalIBRBasicPredicatesForHighestPriorityFetch(rate, criteriaBuilder,
                        enquiryIdentity.serviceProvider(), enquiryIdentity.product()),
                BaseRatePredicates.getIBRCurrencyPredicateForHighestPriorityFetch(rate, criteriaBuilder,
                        enquiryIdentity.currency()),
                criteriaBuilder.equal(rate.get(NormalIBR_.priority.getName()), maxPriorityQuery));

        NormalIBREnquiryResponse result = null;
        try {
            result = entityManager().createQuery(query).getSingleResult();
        }
        catch (final NonUniqueResultException e) {
            // Ignore
            // log.debug("Duplicate records found: {} for normal IBR inquiry identity: {} ignored", e.getMessage(),
            // enquiryIdentity);
        }
        catch (final NoResultException e) {
            // Ignore
            // log.debug("No records found: {} for normal IBR enquiry identity: {}", e.getMessage(),
            // enquiryIdentity);
        }
        return Optional.ofNullable(result);
    }

    @Override
    public Optional<BankWiseIBREnquiryResponse> findBankWiseIBRForEnquiry(
            final BankWiseIBREnquiryIdentity enquiryIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<BankWiseIBREnquiryResponse> query = criteriaQuery(BankWiseIBREnquiryResponse.class);
        Root<BankWiseIBR> rate = query.from(BankWiseIBR.class);

        query.select(criteriaBuilder.construct(BankWiseIBREnquiryResponse.class,
                criteriaBuilder.literal(enquiryIdentity.index()),
                criteriaBuilder.literal(enquiryIdentity.serviceProvider()),
                criteriaBuilder.literal(enquiryIdentity.product()), criteriaBuilder.literal(enquiryIdentity.bank()),
                criteriaBuilder.literal(enquiryIdentity.agent()),
                IBRSelectExpressions.currencySelectExpression(rate, criteriaBuilder),
                rate.get(BankWiseIBR_.exchange.getName()).get(Exchange_.rate.getName())));

        Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
        Root<BankWiseIBR> maxPriority = maxPriorityQuery.from(BankWiseIBR.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(BankWiseIBR_.priority.getName())));
        maxPriorityQuery.where(
                BaseRatePredicates.getBankWiseIBRBasicPredicatesForHighestPriorityFetch(maxPriority, criteriaBuilder,
                        enquiryIdentity.serviceProvider(), enquiryIdentity.product(), enquiryIdentity.bank(),
                        enquiryIdentity.agent()),
                BaseRatePredicates.getIBRCurrencyPredicateForHighestPriorityFetch(maxPriority, criteriaBuilder,
                        enquiryIdentity.currency()));

        query.where(
                BaseRatePredicates.getBankWiseIBRBasicPredicatesForHighestPriorityFetch(rate, criteriaBuilder,
                        enquiryIdentity.serviceProvider(), enquiryIdentity.product(), enquiryIdentity.bank(),
                        enquiryIdentity.agent()),
                BaseRatePredicates.getIBRCurrencyPredicateForHighestPriorityFetch(rate, criteriaBuilder,
                        enquiryIdentity.currency()),
                criteriaBuilder.equal(rate.get(BankWiseIBR_.priority.getName()), maxPriorityQuery));

        BankWiseIBREnquiryResponse result = null;
        try {
            result = entityManager().createQuery(query).getSingleResult();
        }
        catch (final NonUniqueResultException e) {
            // Ignore
            // log.debug("Duplicate records found: {} for bank wise enquiry identity: {} ignored", e.getMessage(),
            // enquiryIdentity);
        }
        catch (final NoResultException e) {
            // Ignore
            // log.debug("No records found: {} for bank wise enquiry identity: {}", e.getMessage(),
            // enquiryIdentity);
        }
        return Optional.ofNullable(result);
    }
}
