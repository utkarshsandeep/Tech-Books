package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import javax.validation.constraints.NotNull;

import org.joda.beans.gen.PropertyDefinition;

import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverride;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverrides;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "agentCustomerRateChange", description = "Agent Sell and Buy values for CustomerRate, CustomerLowest, MaxDiscount")
public class AgentRateCustomerRateChangeDTO {

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Customer Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Customer Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "customerRate", required = true, notes = "Customer Rate cost Buy and Sell values")
    private CostDTO customerRate;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Maximum Discounted Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Maximum Discounted Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "maxDiscount", required = true, notes = "Max Discount cost Buy and Sell values")
    private CostDTO maxDiscount;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Lowest Transaction Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Lowest Transaction Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "customerLowest", required = true, notes = "Customer Lowest cost Buy and Sell values")
    private CostDTO customerLowest;

    public static AgentRateCustomerRateChangeDTO byCustomerRateFormula(final CostDTO cost, CostDTO marginRate,
            CostDTO marginLow, CostDTO marginHigh, final RateDisplayMachenism RDM) {
        AgentRateCustomerRateChangeDTO agentValueDateWise = new AgentRateCustomerRateChangeDTO();

        if (RDM.isBCtoFC()) {
            // Customer Rate Sell = Cost Sell Rate – Sell Margin
            // Customer Rate Buy = Cost Buy Rate + Cash Buy Margin
            CostDTO newCustomerRate = CostDTO.of(cost.getSellValue().subtract(marginRate.getSellValue()),
                    cost.getBuyValue().add(marginRate.getBuyValue()));
            validatePositive(newCustomerRate.getBuyValue(), "Customer Buy");
            validatePositive(newCustomerRate.getSellValue(), "Customer Sell");
            agentValueDateWise.customerRate = newCustomerRate;

            // Customer Maximum Discounted Sell Rate = Customer Sell Rate + Sell Margin Low
            // Customer Maximum Discounted Buy Rate = Customer Buy Rate - Buy Margin Low
            CostDTO newMaxDiscount = CostDTO.of(
                    agentValueDateWise.customerRate.getSellValue().add(marginLow.getSellValue()),
                    agentValueDateWise.customerRate.getBuyValue().subtract(marginLow.getBuyValue()));
            validatePositive(newMaxDiscount.getBuyValue(), "Max Discount Buy");
            validatePositive(newMaxDiscount.getSellValue(), "Max Discount Sell");
            agentValueDateWise.maxDiscount = newMaxDiscount;

            // Customer Lowest Sell Rate = Customer Sell Rate – Sell Margin High
            // Customer Lowest Buy Rate = Customer Buy Rate + Buy Margin High
            CostDTO newCustomerLowest = CostDTO.of(
                    agentValueDateWise.customerRate.getSellValue().subtract(marginHigh.getSellValue()),
                    agentValueDateWise.customerRate.getBuyValue().add(marginHigh.getBuyValue()));
            validatePositive(newCustomerLowest.getBuyValue(), "Customer Lowest Buy");
            validatePositive(newCustomerLowest.getSellValue(), "Customer Lowest Sell");
            agentValueDateWise.customerLowest = newCustomerLowest;
        }
        else {
            // Customer Rate Sell = Cost Sell Rate + Sell Margin
            // Customer Rate Buy = Cost Buy Rate - Buy Margin
            CostDTO newCustomerRate = CostDTO.of(cost.getSellValue().add(marginRate.getSellValue()),
                    cost.getBuyValue().subtract(marginRate.getBuyValue()));
            validatePositive(newCustomerRate.getBuyValue(), "Customer Buy");
            validatePositive(newCustomerRate.getSellValue(), "Customer Sell");
            agentValueDateWise.customerRate = newCustomerRate;

            // Customer Maximum Discounted Sell Rate = Customer Sell Rate – Sell Margin Low
            // Customer Maximum Discounted Buy Rate = Customer Buy Rate + Buy Margin Low
            CostDTO newMaxDiscount = CostDTO.of(
                    agentValueDateWise.customerRate.getSellValue().subtract(marginLow.getSellValue()),
                    agentValueDateWise.customerRate.getBuyValue().add(marginLow.getBuyValue()));
            validatePositive(newMaxDiscount.getBuyValue(), "Max Discount Buy");
            validatePositive(newMaxDiscount.getSellValue(), "Max Discount Sell");
            
            agentValueDateWise.maxDiscount = newMaxDiscount;

            // Customer Lowest Sell Rate = Customer Sell Rate + Sell Margin High
            // Customer Lowest Buy Rate = Customer Buy Rate – Buy Margin High
            CostDTO newCustomerLowest = CostDTO.of(
                    agentValueDateWise.customerRate.getSellValue().add(marginHigh.getSellValue()),
                    agentValueDateWise.customerRate.getBuyValue().subtract(marginHigh.getBuyValue()));
            validatePositive(newCustomerLowest.getBuyValue(), "Customer Lowest Buy");
            validatePositive(newCustomerLowest.getSellValue(), "Customer Lowest Sell");
            
            agentValueDateWise.customerLowest = newCustomerLowest;
        }
        
        return agentValueDateWise;
    }
}
