package com.unimoni.pricingengine.domain.model.rate.base.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties
public class AgentUpdateDeleteRequest {
	private String rateDisplayMechanism;

	private String status;

	private Integer value;

	private Long id;

	@JsonCreator
	public AgentUpdateDeleteRequest(@JsonProperty("id") Long id,
			@JsonProperty("rateDisplayMechanism") String rateDisplayMechanism, @JsonProperty("status") String status,
			@JsonProperty("value") Integer value) {

		this.id = id;
		this.rateDisplayMechanism = rateDisplayMechanism;
		this.status = status;
		this.value = value;
	}
}
