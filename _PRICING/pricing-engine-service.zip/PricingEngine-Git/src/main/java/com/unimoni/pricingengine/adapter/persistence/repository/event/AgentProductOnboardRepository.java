package com.unimoni.pricingengine.adapter.persistence.repository.event;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.domain.model.rate.AgentProductOnboard;

@Repository
public interface AgentProductOnboardRepository extends JpaRepository<AgentProductOnboard, Long> {
	
	public List<AgentProductOnboard> findBydraweeBankProductProfileId(Integer draweeBankProductProfileId);

}
