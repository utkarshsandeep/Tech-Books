package com.unimoni.pricingengine.application.service.amigo.dto;

import java.util.Optional;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.base.dto.CurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRIdentity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class VDWRateAmigoRequest extends AmigoRequest {

    @ApiModelProperty(name = "agentCode", value = "Agent code", required = true, example = "AGENT001", position = 1)
    @NotNull
    private String agentCode;

    @ApiModelProperty(name = "bankCode", value = "Bank code, required only if rmType is BANK_WISE", required = false, example = "HDFC", position = 2)
    private String bankCode;

    @ApiModelProperty(name = "subProductCode", value = "Sub product code such as Account Credit, Cash payout etc.", required = true, example = "Account Credit", position = 5)
    @NotNull
    private String subProductCode;

    @ApiModelProperty(name = "serviceTypeCode", value = "Service type code such as Flash, Normal etc.", required = true, example = "Flash", position = 6)
    @NotNull
    private String serviceTypeCode;

    public Optional<String> bank() {
        return Optional.ofNullable(this.bankCode);
    }

    @JsonIgnore
    public VaRIdentity varIdentity(final RMType rmType) {
        return rmType.isNormal()
                ? VaRIdentity.ofNormal(this.serviceProviderCode, this.productCode, this.subProductCode,
                        this.serviceTypeCode, this.agentCode, CurrencyDTO.of(this.sourceCcy, this.targetCcy))
                : VaRIdentity.ofBankWise(this.serviceProviderCode, this.productCode, this.subProductCode,
                        this.serviceTypeCode, this.agentCode, this.bankCode,
                        CurrencyDTO.of(this.sourceCcy, this.targetCcy));
    }

    @JsonIgnore
    public SettlementIdentity settlementIdentity(final RMType rmType) {
        return rmType.isNormal()
                ? SettlementIdentity.ofNormal(this.serviceProviderCode, this.productCode, this.subProductCode,
                        this.serviceTypeCode, this.agentCode, CurrencyDTO.of(this.sourceCcy, this.targetCcy))
                : SettlementIdentity.ofBankWise(this.serviceProviderCode, this.productCode, this.subProductCode,
                        this.serviceTypeCode, this.agentCode, this.bankCode,
                        CurrencyDTO.of(this.sourceCcy, this.targetCcy));
    }

    public AllInstruments instruments() {
        return AllInstruments.of(this.serviceProviderCode, this.productCode, this.subProductCode, this.serviceTypeCode);
    }
}
