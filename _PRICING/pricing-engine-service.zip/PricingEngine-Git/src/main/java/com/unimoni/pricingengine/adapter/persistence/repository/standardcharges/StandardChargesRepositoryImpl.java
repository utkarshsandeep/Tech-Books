package com.unimoni.pricingengine.adapter.persistence.repository.standardcharges;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.remittance.dto.TxnSDChargeCalculationRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardCharge;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardChargeAmountRangeDateWise;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardChargeAmountRangeDateWise_;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardChargeAmountRangeWise;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardChargeAmountRangeWise_;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardCharge_;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.SearchStandardChargesRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargesIdentity;

@Repository
public class StandardChargesRepositoryImpl extends AbstractJPA implements StandardChargesRepositoryJPA {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<StandardCharge> findAllStandardCharges() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StandardCharge> query = criteriaBuilder.createQuery(StandardCharge.class);
        Root<StandardCharge> sc = query.from(StandardCharge.class);
        query.select(sc);
        return entityManager.createQuery(query).getResultList();
    }

    @Override
    public Optional<StandardCharge> findStandardChargesById(final String scId) {
        StandardCharge sc = entityManager.find(StandardCharge.class, scId);
        return sc == null ? Optional.empty() : Optional.of(sc);
    }

    @Override
    public List<StandardCharge> getAllStandardCharges(SearchStandardChargesRequest searchRequest) {

        long totalRecords = findStandardChargesCount(searchRequest);
        searchRequest.page().totalRecords(totalRecords);
        if (totalRecords == 0 && totalRecords == 1) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
            CriteriaQuery<StandardCharge> query = criteriaBuilder.createQuery(StandardCharge.class);
            Root<StandardCharge> rate = query.from(StandardCharge.class);

            query.where(
                    StandardChargesPredicates.getSearchStandardChargesPredicates(rate, criteriaBuilder, searchRequest));

            query.select(rate);
            query.distinct(true);

            TypedQuery<StandardCharge> typedQuery = entityManager.createQuery(query);
            typedQuery.setFirstResult(searchRequest.page().queryFirstResult());
            typedQuery.setMaxResults(searchRequest.page().queryMaxResults());

            return getUnmodifiableResultList(typedQuery);
        }

    }

    private long findStandardChargesCount(final SearchStandardChargesRequest searchRequest) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> query = criteriaBuilder.createQuery(Long.class);
        Root<StandardCharge> rate = query.from(StandardCharge.class);

        query.where(StandardChargesPredicates.getSearchStandardChargesPredicates(rate, criteriaBuilder, searchRequest));

        query.select(criteriaBuilder.countDistinct(rate));
        return entityManager.createQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<StandardCharge> getAllStandardChargesOnCurrencies(String currencyFrom, String currencyTo) {

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StandardCharge> query = criteriaBuilder.createQuery(StandardCharge.class);
        Root<StandardCharge> root = query.from(StandardCharge.class);

        List<Predicate> predicates = new ArrayList<>();
        predicates.add(criteriaBuilder.equal(root.get("currencyFrom"), currencyFrom));

        predicates.add(criteriaBuilder.equal(root.get("currencyTo"), currencyTo));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.enabled.getName()), true));

        query.where(predicates.toArray(new Predicate[predicates.size()]));
        query.select(root);

        TypedQuery<StandardCharge> typedQuery = entityManager.createQuery(query);

        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public Optional<StandardCharge> findActiveStandardChargesByIdentity(StandardChargesIdentity scIdentity) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StandardCharge> query = criteriaBuilder.createQuery(StandardCharge.class);
        Root<StandardCharge> root = query.from(StandardCharge.class);

        query.where(StandardChargesPredicates.getSCByIdentityPredicates(root, criteriaBuilder, scIdentity));
        query.select(root);

        return getSingleResultSafely(entityManager.createQuery(query));
    }

    @Override
    public List<StandardCharge> findStandardChargesByIds(List<String> ids, boolean eagerAmtRange) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StandardCharge> query = criteriaBuilder.createQuery(StandardCharge.class);
        Root<StandardCharge> rate = query.from(StandardCharge.class);
        query.where(rate.get(StandardCharge_.id.getName()).in(ids));
        query.select(rate);

        TypedQuery<StandardCharge> typedQuery = entityManager.createQuery(query);
        /*
         * if (eagerAmtRange) { typedQuery.setHint("javax.persistence.fetchgraph",
         * entityManager.getEntityGraph("standardCharge")); }
         */

        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public List<StandardChargeAmountRangeWise> findStandardChargeAmountRangeByIds(List<String> ids,
            boolean eagerFetchIbrAndVar) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StandardChargeAmountRangeWise> query = criteriaBuilder
                .createQuery(StandardChargeAmountRangeWise.class);
        Root<StandardChargeAmountRangeWise> rate = query.from(StandardChargeAmountRangeWise.class);
        query.where(rate.get(StandardChargeAmountRangeWise_.id.getName()).in(ids));
        query.select(rate);

        TypedQuery<StandardChargeAmountRangeWise> typedQuery = entityManager.createQuery(query);

        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public List<StandardChargeAmountRangeDateWise> findStandardChargeAmountRangeDateByIds(List<String> ids,
            boolean eagerFetchIbrAndVar) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StandardChargeAmountRangeDateWise> query = criteriaBuilder
                .createQuery(StandardChargeAmountRangeDateWise.class);
        Root<StandardChargeAmountRangeDateWise> rate = query.from(StandardChargeAmountRangeDateWise.class);
        query.where(rate.get(StandardChargeAmountRangeDateWise_.id.getName()).in(ids));
        query.select(rate);

        TypedQuery<StandardChargeAmountRangeDateWise> typedQuery = entityManager.createQuery(query);

        return getUnmodifiableResultList(typedQuery);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<StandardCharge> getStandardChargesForRemittance(TxnSDChargeCalculationRequest request, boolean isCancel,
            final BigDecimal calculatedPayInAmount, final BigDecimal calculatedPayOutAmount) {
        String queryStr = formSelectQuery(request, isCancel, calculatedPayInAmount, calculatedPayOutAmount);
        //log.debug("Query--" + queryStr);

        Query query = entityManager.createNativeQuery(queryStr, StandardCharge.class);

        List<StandardCharge> list = query.getResultList();
        return list;
    }

    private String formSelectQuery(TxnSDChargeCalculationRequest request, boolean isCancel,
            final BigDecimal calculatedPayInAmount, final BigDecimal calculatedPayOutAmount) {
        StringBuffer sf = new StringBuffer(500);
        sf.append("SELECT * ");
        sf.append(" from ( ");
        sf.append(" select  X.* , row_number() over ( ");
        sf.append("partition BY X.CHARGE_TYPE  order by case when  X.SERVICE_PROVIDER_CODE = 'All' then 1 else 0 end ");

        sf.append(",case when X.SOURCE_CODE = 'All' AND X.SOURCE_TYPE = 'ALL' then 1 else 0 end "); // ALL

        sf.append(",case when X.SOURCE_CODE = '"); // COUNTRY
        sf.append(request.originatingCountry());
        sf.append("' AND X.SOURCE_TYPE = 'COUNTRY' then 1 else 0 end ");

        sf.append(",case when X.SOURCE_CODE = '"); // AGENT
        sf.append(request.agentCode());
        sf.append("' AND X.SOURCE_TYPE = 'AGENT' then 1 else 0 end ");

        sf.append(",case when X.SOURCE_CODE = '"); // BRANCH
        sf.append(request.agentBranchCode());
        sf.append("' AND X.SOURCE_TYPE = 'BRANCH' then 1 else 0 end ");

        sf.append(",case when X.DESTINATION_CODE = 'All' AND X.DESTINATION_TYPE = 'ALL' then 1 else 0 end "); // ALL

        sf.append(",case when X.DESTINATION_CODE = '"); // COUNTRY
        sf.append(request.destinationCountry());
        sf.append("' AND X.DESTINATION_TYPE = 'COUNTRY' then 1 else 0 end ");

        sf.append(",case when X.DESTINATION_CODE = '"); // BANK
        sf.append(request.bankCode());
        sf.append("' AND X.DESTINATION_TYPE = 'BANK' then 1 else 0 end ");

        sf.append(",case when X.PRODUCT_CODE = 'All' then 1 else 0 end ");
        sf.append(",case when X.SUB_PRODUCT_CODE = 'All' then 1 else 0 end ");
        sf.append(",case when X.SERVICE_TYPE_CODE = 'All' then 1 else 0 end ");
        sf.append(",case when X.FROM_CCY = 'All' then 1 else 0 end ");
        sf.append(",case when X.TO_CCY = 'All' then 1 else 0 end ");
        sf.append(",case when X.CUSTOMER_TYPE = 'All' then 1 else 0 end ");
        sf.append(",case when X.BENEFICIARY_TYPE = 'All' then 1 else 0 end ");
        sf.append(",case when X.PAYMANT_MODE = 'All' then 1 else 0 end ");
        sf.append(") rn from STANDARD_CHARGES X ");
        sf.append("INNER JOIN STANDARD_AMOUNT_RANGE Y ON X.id = Y.standard_charge_id");
        sf.append(" where ");
        sf.append("X.SERVICE_PROVIDER_CODE in('All', '");
        sf.append(request.instruments().serviceProvider());
        sf.append("') ");

        sf.append("and X.SOURCE_CODE in('All', '");
        sf.append(request.agentCode());
        sf.append("' , '");
        sf.append(request.originatingCountry());
        sf.append("' , '");
        sf.append(request.agentBranchCode());
        sf.append("') ");

        sf.append("and X.DESTINATION_CODE in('All', '");
        sf.append(request.bankCode());
        sf.append("' , '");
        sf.append(request.destinationCountry());
        sf.append("') ");

        sf.append("and X.PRODUCT_CODE in('All', '");
        sf.append(request.instruments().product());
        sf.append("') ");

        sf.append("and X.SUB_PRODUCT_CODE in('All', '");
        sf.append(request.instruments().subProduct());
        sf.append("') ");

        sf.append("and X.SERVICE_TYPE_CODE in('All', '");
        sf.append(request.instruments().serviceType());
        sf.append("') ");

        sf.append("and X.FROM_CCY in('All', '");
        sf.append(request.payIn().getCurrencyCode());
        sf.append("') ");

        sf.append("and X.TO_CCY in('All', '");
        sf.append(request.payOut().getCurrencyCode());
        sf.append("') ");

        sf.append("and X.CUSTOMER_TYPE in('All', '");
        sf.append(request.customerType().name());
        sf.append("') ");

        sf.append("and X.BENEFICIARY_TYPE in('All', '");
        sf.append(request.beneficiaryType().name());
        sf.append("') ");

        sf.append("and X.TRANSACTION_TYPE in('");
        sf.append(request.transactionType().name());
        sf.append("') ");

        sf.append("and X.PAYMANT_MODE in('All', '");
        sf.append(request.paymentMode().name());
        sf.append("') ");

        sf.append("and X.ENABLED = 'Y' ");

        if (isCancel) {
            sf.append("and X.CHARGE_TYPE = 'CANCELLATION_CHARGES' ");
        }
        else {
            sf.append("and X.CHARGE_TYPE != 'CANCELLATION_CHARGES' ");
            if (request.swiftChargeType() != null) {
                sf.append("and (( X.CHARGE_TYPE = 'SWIFT_CHARGES' and X.SWIFT_CHARGE_TYPE = '");
                sf.append(request.swiftChargeType().name());
                sf.append("') ");
                sf.append("OR (X.CHARGE_TYPE != 'SWIFT_CHARGES')) ");
            }
            else {
                sf.append("and X.CHARGE_TYPE !='SWIFT_CHARGES' ");
            }
        }

        sf.append("and Y.VDW_TYPE = '");
        sf.append(request.valueDateWise().name());
        sf.append("' ");

        sf.append(" and Y.ENABLED = 'Y' ");

        // Handle Amount Range conditions
        sf.append(addAmountRangeCondtion(isCancel, calculatedPayInAmount, calculatedPayOutAmount));

        sf.append(") X where rn IN (1)");

        return sf.toString();
    }

    private static String addAmountRangeCondtion(boolean isCancel, final BigDecimal calculatedPayInAmount,
            final BigDecimal calculatedPayOutAmount) {
        StringBuffer sf = new StringBuffer(300);
        if (isCancel) {
            sf.append(" and Y.AMOUNT_FROM <= ");
            sf.append(calculatedPayInAmount);

            sf.append(" and Y.AMOUNT_TO >= ");
            sf.append(calculatedPayInAmount);
        }
        else {
            sf.append("and (( X.CHARGE_TYPE != 'SWIFT_CHARGES'");
            sf.append(" and Y.AMOUNT_FROM <= ");
            sf.append(calculatedPayInAmount);

            sf.append(" and Y.AMOUNT_TO >= ");
            sf.append(calculatedPayInAmount);

            sf.append(") OR (");
            sf.append("X.CHARGE_TYPE = 'SWIFT_CHARGES'");
            sf.append(" and Y.AMOUNT_FROM <= ");
            sf.append(calculatedPayOutAmount);

            sf.append(" and Y.AMOUNT_TO >= ");
            sf.append(calculatedPayOutAmount);

            sf.append("))");
        }
        return sf.toString();
    }

    @Override
    public Optional<StandardCharge> findActiveStandardChargesByStandardCharge(StandardCharge sc) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StandardCharge> query = criteriaBuilder.createQuery(StandardCharge.class);
        Root<StandardCharge> root = query.from(StandardCharge.class);

        query.where(StandardChargesPredicates.getPredicatesByStandardCharge(root, criteriaBuilder, sc));
        query.select(root);

        return getSingleResultSafely(entityManager.createQuery(query));
    }

}
