package com.unimoni.pricingengine.common.util;

public class CircularCounter implements Comparable<CircularCounter> {

    private final String name; // counter name

    private int initialValue = 0; // current value

    private int count = 0; // current value

    private int maxCount = 0; // current value

    /**
     * Initializes a new counter starting at 0, with the given name.
     *
     * @param id the name of the counter
     */
    private CircularCounter(final String name, final int initialValue, final int maxValue) {
        this.name = name;
        this.initialValue = initialValue;
        this.count = initialValue;
        this.maxCount = maxValue;
    }

    /**
     * Initializes a new counter starting at 0, with the given name.
     *
     * @param name the name of the counter
     */
    public static CircularCounter initialize(final String name) {
        return new CircularCounter(name, 0, Integer.MAX_VALUE);
    }

    /**
     * Initializes a new counter starting at 0, with the given id.
     *
     * @param name the name of the counter
     * @param initialValue Initial value of the counter
     */
    public static CircularCounter initialize(final String name, final int initialValue) {
        return new CircularCounter(name, initialValue, Integer.MAX_VALUE);
    }

    /**
     * Initializes a new counter starting at 0, with the given id.
     *
     * @param name the name of the counter
     * @param initialValue Initial value of the counter
     */
    public static CircularCounter initialize(final String name, final int initialValue, final int maxValue) {
        return new CircularCounter(name, initialValue, maxValue);
    }

    /**
     * Increments the counter by 1.
     */
    public void increment() {
        if (++this.count > this.maxCount) {
            this.count = this.initialValue;
        }
    }

    /**
     * Increments the counter by 1 and returns the incremented value.
     */
    public int incrementAndGet() {
        return ++this.count > this.maxCount ? this.count = this.initialValue : this.count;
    }

    /**
     * Increments the counter by 1 and returns the same.
     */
    public int getAndIncrement() {
        return this.count + 1 > this.maxCount ? this.count = this.initialValue : ++this.count;
    }

    /**
     * Returns the current counter value.
     */
    public int get() {
        return this.count;
    }

    public int set(final int newCount) {
        return this.count = newCount;
    }

    /**
     * Returns the current counter value.
     */
    public int getMaxValue() {
        return this.maxCount;
    }

    /**
     * Returns the current value of this counter.
     *
     * @return the current value of this counter
     */
    public String name() {
        return this.name;
    }

    /**
     * Returns a string representation of this counter.
     *
     * @return a string representation of this counter
     */
    public String toString() {
        return name + ": " + count;
    }

    /**
     * Compares this counter to the specified counter.
     *
     * @param that the other counter
     * @return {@code 0} if the value of this counter equals the value of that counter; a negative integer if the value
     * of this counter is less than the value of that counter; and a positive integer if the value of this counter is
     * greater than the value of that counter
     */
    @Override
    public int compareTo(CircularCounter that) {
        if (this.count < that.count)
            return -1;
        else if (this.count > that.count)
            return +1;
        else
            return 0;
    }
}
