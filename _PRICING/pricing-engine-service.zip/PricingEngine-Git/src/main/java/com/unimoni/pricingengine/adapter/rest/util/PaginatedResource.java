package com.unimoni.pricingengine.adapter.rest.util;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.PagedResources.PageMetadata;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.ResourceSupport;
import org.springframework.util.Assert;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.common.dto.ViewModel;

public class PaginatedResource<T> extends ResourceSupport implements Iterable<T> {

    @JsonInclude(NON_EMPTY)
    private Map<String, Object> attributes = new LinkedHashMap<>();

    public void addAttribute(String key, Object value) {
        attributes.put(key, value);
    }

    @JsonProperty("attributes")
    public Map<String, Object> getAttributes() {
        return attributes;
    }

    private final Collection<T> content;

    private PaginationData metadata;

    /**
     * Default constructor to allow instantiation by reflection.
     */
    protected PaginatedResource() {
        this(new ArrayList<T>(), null);
    }

    /**
     * Creates a new {@link PagedResources} from the given content, {@link PageMetadata} and {@link Link}s (optional).
     * 
     * @param content must not be {@literal null}.
     * @param metadata
     * @param links
     */
    public PaginatedResource(final Collection<T> content, final PaginationData metadata, final Link... links) {
        this(content, metadata, Arrays.asList(links));
    }

    /**
     * Creates a new {@link PagedResources} from the given content {@link PageMetadata} and {@link Link}s.
     * 
     * @param content must not be {@literal null}.
     * @param metadata
     * @param links
     */
    public PaginatedResource(final Collection<T> content, final PaginationData metadata, final Iterable<Link> links) {

        Assert.notNull(content, "Content must not be null!");

        this.content = new ArrayList<T>();

        for (T element : content) {
            this.content.add(element);
        }
        this.add(links);
        this.metadata = metadata;
    }

    /**
     * Returns the pagination metadata.
     * 
     * @return the metadata
     */
    @JsonProperty("page")
    public PaginationData getMetadata() {
        return metadata;
    }

    /**
     * Factory method to easily create a {@link PagedResources} instance from a set of entities and pagination metadata.
     * 
     * @param content must not be {@literal null}.
     * @param metadata
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T extends Resource<S>, S> PaginatedResource<T> wrap(final Iterable<S> content,
            final PaginationData page) {

        Assert.notNull(content, "Content must not be null!");
        ArrayList<T> resources = new ArrayList<T>();

        for (S element : content) {
            resources.add((T) new Resource<S>(element));
        }

        return new PaginatedResource<T>(resources, page);
    }

    /**
     * Factory method to easily create a {@link PagedResources} instance from a set of entities and pagination metadata.
     * 
     * @param content must not be {@literal null}.
     * @param metadata
     * @return
     */
    public static <T extends ViewModel<I>, I> PaginatedResource<Resource<T>> wrap(final Iterable<T> content,
            final PaginationData page, final ResourceAssembler<T, I> resourceAssembler,
            final Object... assemblerParameters) {

        Assert.notNull(content, "Content must not be null!");
        ArrayList<Resource<T>> resources = new ArrayList<>();

        for (T element : content) {
            resources.add(resourceAssembler.assemble(element, true, assemblerParameters));
        }

        return new PaginatedResource<Resource<T>>(resources, page);
    }

    /**
     * Returns the underlying elements.
     * 
     * @return the content will never be {@literal null}.
     */
    @JsonProperty("content")
    public Collection<T> getContent() {
        return Collections.unmodifiableCollection(content);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Iterable#iterator()
     */
    @Override
    public Iterator<T> iterator() {
        return content.iterator();
    }

    /**
     * Returns the Link pointing to the next page (if set).
     * 
     * @return
     */
    @JsonIgnore
    public Link getNextLink() {
        return getLink(Link.REL_NEXT);
    }

    /**
     * Returns the Link pointing to the previous page (if set).
     * 
     * @return
     */
    @JsonIgnore
    public Link getPreviousLink() {
        return getLink(Link.REL_PREVIOUS);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.hateoas.ResourceSupport#toString()
     */
    @Override
    public String toString() {
        return String.format("PagedResource { content: %s, metadata: %s, links: %s }", getContent(), metadata,
                getLinks());
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.hateoas.Resources#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }

        if (obj == null || !getClass().equals(obj.getClass())) {
            return false;
        }

        PaginatedResource<?> that = (PaginatedResource<?>) obj;
        boolean metadataEquals = this.metadata == null ? that.metadata == null : this.metadata.equals(that.metadata);

        return metadataEquals ? super.equals(obj) : false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.hateoas.Resources#hashCode()
     */
    @Override
    public int hashCode() {

        int result = super.hashCode();
        result += this.metadata == null ? 0 : 31 * this.metadata.hashCode();
        return result;
    }
}
