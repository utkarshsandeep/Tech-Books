package com.unimoni.pricingengine.adapter.rest.controller.events;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.unimoni.pricingengine.domain.model.rate.AgentProductOnboard;

//EVENT AGENT_RATE_FOR_DRAWEE_PRODUCT_ENABLED
@FeignClient(name = "ONBOARDING-BANK-SERVICE", url = "http://bank-onboarding-service-snap.dev.apps.ocp.uaeexchange.com/onboarding/api/v1")
public interface AgentDetailsForProductProfileId {

    // http://bank-onboarding-service-snap.dev.apps.ocp.uaeexchange.com/api/v1/onboarding/draweeBankProductProfiles/1947/agentDraweeBank4Rates/1972
    @RequestMapping("/draweeBankProductProfiles/{draweeBankProductProfileId}/agentDraweeBank4Rates/{agentDraweeBankForRateId}")
    public AgentProductOnboard agentDetails(
            @PathVariable(value = "draweeBankProductProfileId") Integer draweeBankProductProfileId,
            @PathVariable(value = "agentDraweeBankForRateId") Integer agentDraweeBankForRateId);

}
