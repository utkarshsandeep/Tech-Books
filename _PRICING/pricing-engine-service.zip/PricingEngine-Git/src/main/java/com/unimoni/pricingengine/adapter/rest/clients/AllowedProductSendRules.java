package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllowedProductSendRules {

    private String message;

    private List<ServiceProviderDetails> serviceProviderDetails;

    private int total;

    public AllowedProductSendRules(@JsonProperty("message") String message,
            @JsonProperty("data") List<ServiceProviderDetails> serviceProviderDetails,
            @JsonProperty("total") int total) {
        this.message = message;
        this.serviceProviderDetails = serviceProviderDetails;
        this.total = total;
    }

}
