package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AgentOnboardRequest {
	
	@NotEmpty
	private String id;
	
	@NotEmpty
	private String name;
	
	@NotEmpty
	private String displayName;
	
	@NotNull()
	private boolean status;
	
	private Date createdDate;
	
	private Date modifiedDate;
	
	private String country;
	
	private String code;
	
	private String countryCode;
	
	private Boolean deleted;
	
	public static AgentOnboardRequest of(final String id, final String name, final String displayName, final String country, final String code,
						final String countryCode, final boolean status, final Date createdDate, final Date modifiedDate) {
		AgentOnboardRequest agentOnboardRequest = new AgentOnboardRequest();
		
		agentOnboardRequest.id = id;
		agentOnboardRequest.name = name;
		agentOnboardRequest.displayName = displayName;
		agentOnboardRequest.country = country;
		agentOnboardRequest.code = code;
		agentOnboardRequest.country = countryCode;
		agentOnboardRequest.status = status;
		agentOnboardRequest.createdDate = createdDate;
		agentOnboardRequest.modifiedDate = modifiedDate;
		
		return agentOnboardRequest;
	}
}
