package com.unimoni.pricingengine.application.event.listner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.money.CurrencyUnit;
import javax.money.Monetary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.unimoni.pricingengine.adapter.rest.controller.events.AgentOnBoard;
import com.unimoni.pricingengine.adapter.rest.controller.events.BankOnBoard;
import com.unimoni.pricingengine.application.events.BankWiseEvent;
import com.unimoni.pricingengine.common.annotation.spring.OnboardingIntegration;
import com.unimoni.pricingengine.domain.model.rate.BankProductOnboard;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.RateSourceType;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateMetaData;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateRequest;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.CreateAgentRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchDataForDraweeBankResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchDataResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchInfoResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentCurrencyCode;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentCurrencyResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardCurrencies;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentUpdateDeleteRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseEventRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseEventSettlementRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseEventVarRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.ExchangeDTO;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateDTO;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.country.AgentItem;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateMetaData;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateRequest;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CreateCountryRateRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CreateSettlementRateRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementMetaData;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementRateRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementRateResponse;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementValueDateWiseDTO;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.rate.var.dto.CreateVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.MarginDTO;
import com.unimoni.pricingengine.domain.model.rate.var.dto.SettlementDTO;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRMetaData;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRResponse;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRValueDateWiseDTO;
import com.unimoni.pricingengine.domain.service.agent.AgentRateService;
import com.unimoni.pricingengine.domain.service.country.CountryRateService;
import com.unimoni.pricingengine.domain.service.rm.RateManagementService;
import com.unimoni.pricingengine.domain.service.settlement.SettlementRateService;
import com.unimoni.pricingengine.domain.service.var.VaRService;

import lombok.extern.slf4j.Slf4j;

@Conditional(value = OnboardingIntegration.class)
@Component
@Slf4j
public class BankWiseOnboardListner {

	@Autowired
	private RateManagementService rateManagementService;

	@Autowired
	private VaRService varService;

	@Autowired
	private SettlementRateService settlementService;

	@Autowired
	private CountryRateService countryRateService;

	@Autowired
	private BankOnBoard bankOnboard;

	@Autowired
	private AgentOnBoard agentOnBoard;

	@Autowired
	private AgentRateService agentRateService;

	@Autowired
	private Gson gson;

	@JmsListener(destination = "AGENT_RATE_FOR_DRAWEE_PRODUCT_ENABLED", containerFactory = "topicListenerFactory")
	public void onApplicationEvent(final Message jsonMessage) {

		log.info("******AGENT_RATE_FOR_DRAWEE_PRODUCT_ENABLED******" + jsonMessage);
		TextMessage textMessage = (TextMessage) jsonMessage;
		String payload;
		try {
			payload = textMessage.getText();
		} catch (JMSException e1) {
			e1.printStackTrace();
			return;
		}
		log.info("******EVENT_PAYLOAD*******", payload);

		Integer draweeBankId = null;
		Integer draweeBankProductId = null;
		Integer agentDraweeBankForRateId = null;
		BankProductOnboard response = null;
		AgentBranchDataForDraweeBankResponse agentBranchRateResponse = null;
		BankWiseEvent bankWiseEvent;

		RateDisplayMachenism rdm = null;

		bankWiseEvent = gson.fromJson(payload, BankWiseEvent.class);

		draweeBankId = (int) (long) bankWiseEvent.getDraweeBankId();

		draweeBankProductId = (int) (long) bankWiseEvent.getDraweeBankProductProfileId();
		agentDraweeBankForRateId = (int) (long) bankWiseEvent.getDraweeBankForRateId();

		log.info("*******DraweeBankId*********" + draweeBankId);
		log.info("*******draweeBankProductProfileId********" + draweeBankProductId);
		log.info("*******agentDraweeBankForRateId*" + agentDraweeBankForRateId);
		try {
			response = bankOnboard.bankOnBoard(draweeBankId, draweeBankProductId);
			log.info("*******DraweeBank Response******" + response);
			agentBranchRateResponse = bankOnboard.agentInformationFromBankProfileIdAndAgentDraweeBank4RateId(
					draweeBankProductId, agentDraweeBankForRateId);
			log.info("******AgentBranchRateResponse********" + agentBranchRateResponse);
			// RDM
			AgentUpdateDeleteRequest agentUpdateDeleteRequest = agentOnBoard.getAgentRateDisplay(
					agentBranchRateResponse.getAgentId(), agentBranchRateResponse.getAgentBranchId());

			if ("FOREIGN_CURRENCY_TO_BASE_CURRENCY".equals(agentUpdateDeleteRequest.getRateDisplayMechanism())) {

				rdm = RateDisplayMachenism.FC_TO_BC;
			} else if ("BASE_CURRENCY_TO_FOREIGN_CURRENCY".equals(agentUpdateDeleteRequest.getRateDisplayMechanism())) {
				rdm = RateDisplayMachenism.BC_TO_FC;

			}
			String agentDisplayCode = getAgentDisplayCode(agentBranchRateResponse.getAgentId(),
					agentBranchRateResponse.getAgentBranchId());

			log.info("******RDM******* " + rdm + "*******AgentDisplayCode********" + agentDisplayCode);
			if (agentDisplayCode == null) {
				return;
			}

			Integer agentId = agentBranchRateResponse.getAgentId();
			createRecordByEvent(agentId, response, agentBranchRateResponse, rdm, agentDisplayCode);

		} catch (Exception e) {

			log.error("****Exception ******" + e.getStackTrace());
		}
	}

	private String getAgentDisplayCode(Integer agentId, Integer agentBranchId) {
		AgentOnboardResponse agentCurrencyResponse = agentOnBoard.agentOnBoard(agentId);
		log.info("******Agent Display Response*****" + agentCurrencyResponse);
		log.info("******Agent Display code******" + agentCurrencyResponse.getCode());
		return agentCurrencyResponse.getCode();
	}

	public void createRecordByEvent(Integer agentId, BankProductOnboard response,

			AgentBranchDataForDraweeBankResponse agentBranchRateResponse, RateDisplayMachenism rdm,

			String agentDisplayCode) {

		log.info("******createRecordByEvent******* ");
		BankWiseEventRateRequest eventRateRequest = new BankWiseEventRateRequest();
		eventRateRequest.setBankId(response.getDraweeBankId());
		eventRateRequest.setServiceProvider(response.getServiceProviderCode());
		eventRateRequest.setProduct(response.getProductType());
		eventRateRequest.setStatus(true);
		eventRateRequest.setAgentId(agentId);
		eventRateRequest.setCurrencyCode(Monetary.getCurrency(response.getCurrencyCode()));
		eventRateRequest.setAgentDisplayCode(agentDisplayCode);
		eventRateRequest.setBankDisplayCode(response.getDisplayName());
		eventRateRequest.setRateSourceType(RateSourceType.MANUAL);

		try {
			log.info("******createBankWiseEventBaseRate*******");
			rateManagementService.createBankWiseEventBaseRate(eventRateRequest);

		} catch (Exception e) {
			log.error("****Exception******" + e.getStackTrace());

		}
		log.info("*****Creating BankWiseEventVarRateRequest******");
		BankWiseEventVarRateRequest bankWiseEventRaterequest = new BankWiseEventVarRateRequest();
		bankWiseEventRaterequest.setAgentId(agentId);
		bankWiseEventRaterequest.setDraweeBankId(response.getDraweeBankId());
		bankWiseEventRaterequest.setServiceProvider(response.getServiceProviderCode());
		bankWiseEventRaterequest.setProduct(response.getProductType());
		bankWiseEventRaterequest.setProductSubtype(response.getProductSubType());
		bankWiseEventRaterequest.setServiceType(response.getServiceType() != null ? response.getServiceType() : "All");
		bankWiseEventRaterequest.setCurrencyCode(Monetary.getCurrency(response.getCurrencyCode()));
		bankWiseEventRaterequest.setAgentDisplayCode(agentDisplayCode);
		bankWiseEventRaterequest.setBankDisplayCode(response.getDisplayName());

		VaRRequest bankWiseVarRequest = createBankWiseVarMetaRequest(bankWiseEventRaterequest);
		log.info("******createBankWiseVarMetaRequest*******" + bankWiseVarRequest);

		log.info("*****createVaRMetaData Method call******");
		VaRMetaData bankWiseVarMetaData = varService.createVaRMetaData(RMType.BANK_WISE, bankWiseVarRequest);
		log.info("******createdVaRMetaData*******" + bankWiseVarMetaData);
		List<VaRResponse> newVars = bankWiseVarMetaData.getNewVars();
		log.info("****newVars*****" + newVars);

		if (!newVars.isEmpty()) {
			log.info("******createBankWiseVarRequest method call********");
			List<CreateVaRRequest> createBankWiseVarRequest = createBankWiseVarRequest(newVars);
			log.info("******createBankWiseVarRequest******" + createBankWiseVarRequest);
			varService.createVaRs(RMType.BANK_WISE, createBankWiseVarRequest);

		}
		log.info("***Creating BankWise Event SettlementRequest******");
		BankWiseEventSettlementRequest bankWiseEventSettlementRequest = new BankWiseEventSettlementRequest();
		bankWiseEventSettlementRequest.setAgentId(agentId);
		bankWiseEventSettlementRequest.setDraweeBankId(response.getDraweeBankId());
		bankWiseEventSettlementRequest.setProduct(response.getProductType());
		bankWiseEventSettlementRequest.setProductSubtype(response.getProductSubType());
		bankWiseEventSettlementRequest.setServiceProvider(response.getServiceProviderCode());
		bankWiseEventSettlementRequest
				.setServiceType(response.getServiceType() != null ? response.getServiceType() : "All");
		bankWiseEventSettlementRequest.setCurrencyCode(Monetary.getCurrency(response.getCurrencyCode()));
		bankWiseEventSettlementRequest.setAgentDisplayCode(agentDisplayCode);
		bankWiseEventSettlementRequest.setBankDisplayCode(response.getDisplayName());

		SettlementRateRequest settlementRequest = new SettlementRateRequest();
		String bank = "BANK";
		settlementRequest = createBankWiseSettlementMetaRequest(bank, bankWiseEventSettlementRequest, agentId);
		SettlementMetaData settlementMetaData = settlementService.createSettlementRateMetaData(RMType.BANK_WISE,
				settlementRequest);
		List<SettlementRateResponse> settlementrateResponse = settlementMetaData.getNewSettlements();

		if (!settlementrateResponse.isEmpty()) {
			List<CreateSettlementRateRequest> createRequests = createRequest(settlementrateResponse);
			settlementService.createSettlementRates(RMType.BANK_WISE, createRequests);
			log.info("*****Creating Settlement Rates******");
		}

		AgentOnboardResponse agentOnBoardResponse = agentOnBoard.agentOnBoard(agentId);
		log.info("*****agentOnBoardResponse*******" + agentOnBoardResponse);
		AgentBranchResponse agentBranchResponse = agentOnBoard.getAgentBranch(agentOnBoardResponse.getId());
		log.info("******agentBranchResponse******" + agentBranchResponse);

		List<Integer> listOfBranchesForAgent = new ArrayList<Integer>();
		for (AgentBranchDataResponse branchData : agentBranchResponse.getData()) {
			listOfBranchesForAgent.add(branchData.getId());
		}

		List<String> listOfCurrencies = new ArrayList<String>();

		List<ArrayList<AgentOnboardCurrencies>> listOfAgentOnboardCurrencies = new ArrayList<ArrayList<AgentOnboardCurrencies>>();
		List<AgentCurrencyResponse> listOfAgentCurrencyResponse = new ArrayList<AgentCurrencyResponse>();
		List<AgentCurrencyCode> listOfCurrencyCodes = new ArrayList<AgentCurrencyCode>();
		// AgentCurrencyResponse agentCurrencyResponse = new AgentCurrencyResponse();

		for (Integer branchId : listOfBranchesForAgent) {
			AgentCurrencyResponse agentCurrencyResponse = new AgentCurrencyResponse();
			agentCurrencyResponse = agentOnBoard.getAgentCurency(agentId, branchId);
			listOfAgentCurrencyResponse.add(agentCurrencyResponse);
		}

		for (int i = 0; i < listOfAgentCurrencyResponse.size(); i++) {
			listOfAgentOnboardCurrencies
					.add((ArrayList<AgentOnboardCurrencies>) listOfAgentCurrencyResponse.get(i).getData());
		}

		for (int i = 0; i < listOfAgentOnboardCurrencies.size(); i++) {
			List<AgentOnboardCurrencies> listOfAgentCurrencies = listOfAgentOnboardCurrencies.get(i);

			for (int j = 0; j < listOfAgentCurrencies.size(); j++) {
				ArrayList<AgentCurrencyCode> tempList = (ArrayList<AgentCurrencyCode>) listOfAgentCurrencies.get(j)
						.getCurrencyCodes();
				listOfCurrencyCodes.addAll(tempList);
				tempList.clear();
			}
		}

		/*
		 * for (AgentCurrencyCode currencyCodes : listOfCurrencyCodes) { if
		 * (!listOfCurrencies.contains(currencyCodes.getCode())) {
		 * listOfCurrencies.add(currencyCodes.getCode()); } }
		 */
		listOfCurrencies.add(response.getCurrencyCode());
		List<String> listOfBaseCurrencies = getListOfAgentBaseCurrencies(agentId, listOfBranchesForAgent, response);
		log.info("*****listOfBaseCurrencies*******" + listOfBaseCurrencies);
		if (agentId != null && listOfBaseCurrencies.size() > 0) {

			if (listOfBaseCurrencies.size() > 0 && rdm != null) {
				log.info("*****Create Record For BankCountry******");
				createRecordForBankCountry(agentDisplayCode, listOfCurrencies, listOfBaseCurrencies,
						listOfBranchesForAgent, response.getServiceProviderCode(), response.getProductType(),
						response.getProductSubType(),
						response.getServiceType() != null ? response.getServiceType() : "All",
						response.getDisplayName(), rdm);

				// Create Record For Bank Wise Agent Rate
				AgentBranchInfoResponse agentBranchInfo = agentOnBoard
						.getAgentBranchInfo(agentBranchRateResponse.getAgentBranchId());
				log.info("*****agentBranchInfo******" + agentBranchInfo);
				log.info("*****create Record For BankAgent******");
				createRecordForBankAgent(agentDisplayCode, listOfCurrencies, listOfBaseCurrencies,
						listOfBranchesForAgent, response.getServiceProviderCode(), response.getProductType(),
						response.getProductSubType(),
						response.getServiceType() != null ? response.getServiceType() : "All",
						agentBranchInfo.getBranchDisplayName(), rdm,response.getDisplayName());

			}
		}
	}

	private void createRecordForBankAgent(String agentId, List<String> listOfCurrencies,
			List<String> listOfBaseCurrencies, List<Integer> listOfBranchesForAgent, String serviceProviderCode,
			String productType, String productSubType, String serviceType, String draweeBankId,

			RateDisplayMachenism rdm,String displayName) {
		log.info("*****Inside createRecordForBankAgent*******");
		AgentRateRequest agentRateRequest = createAgentRateMetaRequest(agentId, listOfCurrencies, listOfBaseCurrencies,
				listOfBranchesForAgent, serviceProviderCode, productType, productSubType, serviceType, draweeBankId,
				rdm,displayName);
		log.info("*****Created AgentRate Meta Request" + agentRateRequest);
		AgentRateMetaData agentRateMetaData = agentRateService.createAgentRateMetaData(RMType.BANK_WISE,
				agentRateRequest);
		log.info("*****Created AgentRate MetaData" + agentRateMetaData);
		List<CreateAgentRateRequest> createRequests = null;

		if (agentRateMetaData.getNewAgentRatesCount() > 0) {
			createRequests = new ArrayList<CreateAgentRateRequest>();
			for (int i = 0; i < agentRateMetaData.getNewAgentRatesCount(); i++) {
				CreateAgentRateRequest createAgentRateRequest = new CreateAgentRateRequest();

				createAgentRateRequest.setCurrency(agentRateMetaData.getNewAgentRates().get(i).getCurrency());
				createAgentRateRequest.setCountryRateId(agentRateMetaData.getNewAgentRates().get(i).getCountryRateId());
				createAgentRateRequest
						.setValueDateWises(agentRateMetaData.getNewAgentRates().get(i).getValueDateWises());
				createAgentRateRequest.setAgent(agentRateMetaData.getNewAgentRates().get(i).getAgent());
				createAgentRateRequest.setBank(agentRateMetaData.getNewAgentRates().get(i).getBank());
				createAgentRateRequest.setInstruments(agentRateMetaData.getNewAgentRates().get(i).getInstruments());
				createRequests.add(createAgentRateRequest);

			}
		}

		if (createRequests != null && createRequests.size() > 0) {
			log.info("****Call createAgentRates Method*****");
			agentRateService.createAgentRates(RMType.BANK_WISE, createRequests);
		}

	}

	private AgentRateRequest createAgentRateMetaRequest(String agentId, List<String> listOfCurrencies,
			List<String> listOfBaseCurrencies, List<Integer> listOfBranchesForAgent, String serviceProviderCode,
			String productType, String productSubType, String serviceType, String draweeBankId,

			RateDisplayMachenism rdm,String displayName) {

		log.info("*****Inside Create Agent Rate MetaRequest******");
		AgentRateRequest agentRateRequest = new AgentRateRequest();
		List<String> serviceProviders = new ArrayList<String>();
		List<String> products = new ArrayList<String>();
		List<String> subProducts = new ArrayList<String>();
		List<String> serviceTypes = new ArrayList<String>();
		List<String> banks = new ArrayList<String>();
		serviceProviders.add(serviceProviderCode);
		products.add(productType);
		subProducts.add(productSubType);
		serviceTypes.add(serviceType);
		banks.add(displayName);

		AgentDetails agent = AgentDetails.of(draweeBankId, rdm, AgentItem.Type.BRANCH);

		List<AgentDetails> listOfAgents = new ArrayList<AgentDetails>();

		listOfAgents.add(agent);

		List<CurrencyUnit> baseCurrencies = new ArrayList<CurrencyUnit>();
		for (int i = 0; i < listOfBaseCurrencies.size(); i++) {
			CurrencyUnit currency = Monetary.getCurrency(listOfBaseCurrencies.get(i));
			baseCurrencies.add(currency);
		}
		List<CurrencyUnit> foreignCurrencies = new ArrayList<CurrencyUnit>();
		for (int i = 0; i < listOfCurrencies.size(); i++) {
			CurrencyUnit currency = Monetary.getCurrency(listOfCurrencies.get(i));
			foreignCurrencies.add(currency);
		}

		agentRateRequest.setProducts(products);
		agentRateRequest.setSubProducts(subProducts);
		agentRateRequest.setServiceProviders(serviceProviders);
		agentRateRequest.setServiceTypes(serviceTypes);
		agentRateRequest.setBaseCurrencies(baseCurrencies);
		agentRateRequest.setForeignCurrencies(foreignCurrencies);
		agentRateRequest.setAgents(listOfAgents);
		agentRateRequest.setBanks(banks);

		return agentRateRequest;
	}

	// To create the request for VarBankMetaData
	public VaRRequest createBankWiseVarMetaRequest(BankWiseEventVarRateRequest bankWiseEventRaterequest) {
		log.info("******Inside Create BankWise Var MetaRequest Method");
		List<String> serviceProviders = new ArrayList<String>();
		List<String> products = new ArrayList<String>();
		List<String> subProducts = new ArrayList<String>();
		List<String> serviceTypes = new ArrayList<String>();
		List<String> bank = new ArrayList<String>();
		List<CurrencyUnit> currencies = new ArrayList<CurrencyUnit>();
		List<String> agent = new ArrayList<String>();

		serviceProviders.add(bankWiseEventRaterequest.getServiceProvider());

		products.add(bankWiseEventRaterequest.getProduct());

		subProducts.add(bankWiseEventRaterequest.getProductSubtype());

		serviceTypes.add(bankWiseEventRaterequest.getServiceType());

		bank.add(bankWiseEventRaterequest.getBankDisplayCode());

		currencies.add(bankWiseEventRaterequest.getCurrencyCode());

		agent.add(String.valueOf(bankWiseEventRaterequest.getAgentDisplayCode()));

		return VaRRequest.ofBankWise(serviceProviders, products, subProducts, serviceTypes, currencies, bank, agent);

	}

	// To create the request for VarBankWise
	public List<CreateVaRRequest> createBankWiseVarRequest(List<VaRResponse> newVars) {

		log.info("*****Inside create BankWise VarRequest Method*****");

		List<CreateVaRRequest> createBankWiseVarRequestList = new ArrayList<CreateVaRRequest>();
		for (int i = 0; i < newVars.size(); i++) {

			CreateVaRRequest createBankWiseVarRequest = new CreateVaRRequest();

			createBankWiseVarRequest.setAgent(newVars.get(i).getAgent());
			createBankWiseVarRequest.setBank(newVars.get(i).getBank());
			createBankWiseVarRequest.setIbrId(newVars.get(i).getIbrId());
			ExchangeDTO exchange = new ExchangeDTO();
			exchange.setCurrency(newVars.get(i).getExchange().getCurrency());
			exchange.setRate(RateDTO.zero());
			createBankWiseVarRequest.setExchange(exchange);
			createBankWiseVarRequest.setInstruments(newVars.get(i).getInstruments());
			createBankWiseVarRequest.setReasonForChange(" ");
			Map<VDWType, VaRValueDateWiseDTO> valueDateWises = new HashMap<VDWType, VaRValueDateWiseDTO>();
			VaRValueDateWiseDTO valueDateWise = new VaRValueDateWiseDTO();
			valueDateWise.setMargin(MarginDTO.zero());
			valueDateWise.setSettlement(SettlementDTO.zero());
			valueDateWises.put(VDWType.CASH, valueDateWise);
			valueDateWises.put(VDWType.FUTURE, valueDateWise);
			valueDateWises.put(VDWType.SPOT, valueDateWise);
			valueDateWises.put(VDWType.TOM, valueDateWise);
			createBankWiseVarRequest.setValueDateWises(valueDateWises);
			createBankWiseVarRequestList.add(createBankWiseVarRequest);
		}
		return createBankWiseVarRequestList;
	}

	public SettlementRateRequest createBankWiseSettlementMetaRequest(String type,
			BankWiseEventSettlementRequest bankWiseEventSettlementrequest, Integer agentId) {
		log.info("*****Inside create BankWise SettlementMetaRequest Method*******");

		List<String> serviceProviders = new ArrayList<String>();
		List<String> products = new ArrayList<String>();
		List<String> subProducts = new ArrayList<String>();
		List<String> serviceTypes = new ArrayList<String>();
		List<String> bank = new ArrayList<String>();
		List<String> agents = new ArrayList<String>();
		List<CurrencyUnit> currencies = new ArrayList<CurrencyUnit>();

		serviceProviders.add(bankWiseEventSettlementrequest.getServiceProvider());
		products.add(bankWiseEventSettlementrequest.getProduct());
		subProducts.add(bankWiseEventSettlementrequest.getProductSubtype());
		serviceTypes.add(bankWiseEventSettlementrequest.getServiceType());
		bank.add(bankWiseEventSettlementrequest.getBankDisplayCode());
		currencies.add(bankWiseEventSettlementrequest.getCurrencyCode());

		agents.add(bankWiseEventSettlementrequest.getAgentDisplayCode());

		SettlementRateRequest bankWiseSettlementRequest = new SettlementRateRequest();
		bankWiseSettlementRequest.setCurrencies(currencies);
		bankWiseSettlementRequest.setServiceProviders(serviceProviders);
		bankWiseSettlementRequest.setProducts(products);
		bankWiseSettlementRequest.setSubProducts(subProducts);
		bankWiseSettlementRequest.setServiceTypes(serviceTypes);
		bankWiseSettlementRequest.setAgents(agents);
		bankWiseSettlementRequest.setBanks(bank);

		return bankWiseSettlementRequest;

	}

	/**
	 * To create the request for SettlementBankWise Create
	 * 
	 */
	public List<CreateSettlementRateRequest> createRequest(List<SettlementRateResponse> settlementrateResponse) {

		log.info("******Create Request for SettlementRateRequest*******");

		List<CreateSettlementRateRequest> createSettlementRateRequestList = new ArrayList<CreateSettlementRateRequest>();
		for (int i = 0; i < settlementrateResponse.size(); i++) {
			CreateSettlementRateRequest createSettlementRateRequest = new CreateSettlementRateRequest();
			createSettlementRateRequest.setAgent(settlementrateResponse.get(0).getAgent());
			createSettlementRateRequest.setBank(settlementrateResponse.get(0).getBank());
			createSettlementRateRequest.setVarId(settlementrateResponse.get(0).getVarId());
			createSettlementRateRequest.setCurrency(settlementrateResponse.get(0).getCurrency());
			createSettlementRateRequest.setInstruments(settlementrateResponse.get(0).getInstruments());
			createSettlementRateRequest.setReasonForChange("");

			Map<VDWType, SettlementValueDateWiseDTO> valueDateWises = new HashMap<VDWType, SettlementValueDateWiseDTO>();

			SettlementValueDateWiseDTO settlementValueDateWise = new SettlementValueDateWiseDTO();
			settlementValueDateWise.setMargin(CostDTO.zero());
			settlementValueDateWise.setSettlement(CostDTO.zero());

			valueDateWises.put(VDWType.CASH, settlementValueDateWise);
			valueDateWises.put(VDWType.FUTURE, settlementValueDateWise);
			valueDateWises.put(VDWType.SPOT, settlementValueDateWise);
			valueDateWises.put(VDWType.TOM, settlementValueDateWise);

			createSettlementRateRequest.setValueDateWises(valueDateWises);
			createSettlementRateRequestList.add(createSettlementRateRequest);
		}

		return createSettlementRateRequestList;

	}

	private List<String> getListOfAgentBaseCurrencies(Integer agentId, List<Integer> listOfBranchesForAgent,
			BankProductOnboard response) {
		List<String> listOfBaseCurrencies = new ArrayList<String>();

		List<ArrayList<AgentOnboardCurrencies>> listOfAgentBaseCurrencies = new ArrayList<ArrayList<AgentOnboardCurrencies>>();
		List<AgentCurrencyResponse> listOfAgentBaseCurrencyResponse = new ArrayList<AgentCurrencyResponse>();
		List<AgentCurrencyCode> listOfCurrencyCodes = new ArrayList<AgentCurrencyCode>();
		AgentCurrencyResponse agentCurrencyResponse = new AgentCurrencyResponse();

		for (Integer branchId : listOfBranchesForAgent) {
			agentCurrencyResponse = agentOnBoard.getAgentBaseCurrencies(agentId, branchId);
			listOfAgentBaseCurrencyResponse.add(agentCurrencyResponse);
		}

		for (int i = 0; i < listOfAgentBaseCurrencyResponse.size(); i++) {
			listOfAgentBaseCurrencies
					.add((ArrayList<AgentOnboardCurrencies>) listOfAgentBaseCurrencyResponse.get(i).getData());
		}

		for (int i = 0; i < listOfAgentBaseCurrencies.size(); i++) {

			List<AgentOnboardCurrencies> listOfAgentCurrencies = listOfAgentBaseCurrencies.get(i);

			for (int j = 0; j < listOfAgentCurrencies.size(); j++) {
				if (response.getServiceProviderCode().equals(listOfAgentCurrencies.get(j).getServiceProviderCode())
						&& response.getProductType().equals(listOfAgentCurrencies.get(j).getProductType())
								&& response.getServiceType().equals(listOfAgentCurrencies.get(j).getServiceType())
								&& response.getProductSubType().equals(listOfAgentCurrencies.get(j).getSubProductType())) {
					ArrayList<AgentCurrencyCode> tempList = (ArrayList<AgentCurrencyCode>) listOfAgentCurrencies.get(j)
							.getCurrencyCodes();
					listOfCurrencyCodes.addAll(tempList);
					tempList.clear();
				}
			}
		}

		for (AgentCurrencyCode currencyCodes : listOfCurrencyCodes) {

			if (!listOfBaseCurrencies.contains(currencyCodes.getCode())
					&& "string".equals(currencyCodes.getCode()) != true) {
				listOfBaseCurrencies.add(currencyCodes.getCode());
			}
		}

		return listOfBaseCurrencies;
	}

	private void createRecordForBankCountry(String agentId, List<String> listOfCurrencies,
			List<String> listOfBaseCurrencies, List<Integer> listOfBranchesForAgent, String ServiceProviderCode,

			String ProductType, String ProductSubType, String ServiceType, String bank, RateDisplayMachenism rdm) {

		log.info("*****Inside createRecordForBankCountry Method*******");
		CountryRateRequest countryRateRequest = createCountryRateMetaRequest(agentId, listOfCurrencies,
				listOfBaseCurrencies, listOfBranchesForAgent, ServiceProviderCode, ProductType, ProductSubType,
				ServiceType, bank, rdm);
		CountryRateMetaData countryRateMetaData = countryRateService.createCountryRateMetaData(RMType.BANK_WISE,
				countryRateRequest);

		List<CreateCountryRateRequest> createRequests = null;
		createRequests = new ArrayList<CreateCountryRateRequest>();

		if (countryRateMetaData.getNewCountryRatesCount() > 0) {
			for (int i = 0; i < countryRateMetaData.getNewCountryRatesCount(); i++) {
				CreateCountryRateRequest createCountryRateRequest = new CreateCountryRateRequest();
				createCountryRateRequest
						.setInstruments(countryRateMetaData.getNewCountryRates().get(i).getInstruments());
				createCountryRateRequest.setCurrency(countryRateMetaData.getNewCountryRates().get(i).getCurrency());
				createCountryRateRequest
						.setBaseSettlementId(countryRateMetaData.getNewCountryRates().get(i).getBaseSettlementId());
				createCountryRateRequest.setForeignSettlementId(
						countryRateMetaData.getNewCountryRates().get(i).getForeignSettlementId());
				createCountryRateRequest
						.setValueDateWises(countryRateMetaData.getNewCountryRates().get(i).getValueDateWises());
				createCountryRateRequest.setAgent(countryRateMetaData.getNewCountryRates().get(i).getAgent());
				createCountryRateRequest.setBank(countryRateMetaData.getNewCountryRates().get(i).getBank());
				createRequests.add(createCountryRateRequest);
			}
		}

		if (createRequests != null && createRequests.size() > 0) {
			log.info("*****Call createCountryRates Method*******");
			countryRateService.createCountryRates(RMType.BANK_WISE, createRequests);
		}
	}

	private CountryRateRequest createCountryRateMetaRequest(String agentId, List<String> listOfCurrencies,
			List<String> listOfBaseCurrencies, List<Integer> listOfBranchesForAgent, String serviceProvider,

			String product, String subProduct, String serviceType, String bank, RateDisplayMachenism rdm) {

		log.info("*******Inside createCountryRateMetaRequest method*******");
		CountryRateRequest countryRateRequest = new CountryRateRequest();
		List<CountryRateRequest> countryRaterequestList = new ArrayList<CountryRateRequest>();
		List<String> serviceProviders = new ArrayList<String>();
		List<String> products = new ArrayList<String>();
		List<String> subProducts = new ArrayList<String>();
		List<String> serviceTypes = new ArrayList<String>();
		List<String> banks = new ArrayList<String>();
		serviceProviders.add(serviceProvider);
		products.add(product);
		subProducts.add(subProduct);
		serviceTypes.add(serviceType);
		banks.add(bank);

		AgentDetails agent = AgentDetails.of(String.valueOf(agentId), rdm, AgentItem.Type.AGENT);

		List<AgentDetails> listOfAgents = new ArrayList<AgentDetails>();
		listOfAgents.add(agent);

		List<CurrencyUnit> baseCurrencies = new ArrayList<CurrencyUnit>();
		for (int i = 0; i < listOfBaseCurrencies.size(); i++) {
			CurrencyUnit currency = Monetary.getCurrency(listOfBaseCurrencies.get(i));
			baseCurrencies.add(currency);
		}
		List<CurrencyUnit> foreignCurrencies = new ArrayList<CurrencyUnit>();
		for (int i = 0; i < listOfCurrencies.size(); i++) {
			CurrencyUnit currency = Monetary.getCurrency(listOfCurrencies.get(i));
			foreignCurrencies.add(currency);
		}

		countryRateRequest.setProducts(products);
		countryRateRequest.setSubProducts(subProducts);
		countryRateRequest.setServiceProviders(serviceProviders);
		countryRateRequest.setServiceTypes(serviceTypes);
		countryRateRequest.setBaseCurrencies(baseCurrencies);
		countryRateRequest.setForeignCurrencies(foreignCurrencies);
		countryRateRequest.setAgents(listOfAgents);
		countryRateRequest.setBanks(banks);

		countryRaterequestList.add(countryRateRequest);

		return countryRateRequest;
	}
}