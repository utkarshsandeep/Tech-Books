package com.unimoni.pricingengine.domain.model.bp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.money.CurrencyUnit;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.springframework.format.annotation.DateTimeFormat;

import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessCreateRequest;
import com.unimoni.pricingengine.domain.model.common.type.BaseUUIDIdentifiableVersionableEntity;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Entity
@Table(name = "BRANCH_PROCESS", indexes = { @Index(name = "IDX_BP_DEAL_ID", columnList = "DEAL_ID"),
        @Index(name = "IDX_BP_STATUS", columnList = "STATUS"),
        @Index(name = "IDX_BP_SOURCE_TYPE", columnList = "SOURCE_TYPE"),
        @Index(name = "IDX_BP_CREATE_DATE_TIME", columnList = "CREATE_DATE_TIME") })
@Audited
public class BranchProcess extends BaseUUIDIdentifiableVersionableEntity<String, Long>
        implements Comparable<BranchProcess> {

    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a");

    @Column(name = "CREATE_DATE_TIME", updatable = false, nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate createDateTime;

    @NotNull
    @Column(name = "DEAL_ID", updatable = false, nullable = false, length = 100)
    private String deal;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "REQUEST_TYPE", updatable = true, nullable = false, length = 20)
    private BranchProcessRequestType requestType;

    @NotNull
    @Column(name = "DEAL_TYPE", updatable = true, nullable = false, length = 20)
    private String dealType;

    @NotNull
    @Column(name = "CARD_TYPE", updatable = false, nullable = false, length = 100)
    private String cardType;

    @NotNull
    @Column(name = "AGENT_CODE", updatable = false, nullable = false, length = 100)
    private String agent;

    @NotNull
    @Column(name = "BANK_CODE", updatable = false, nullable = false, length = 100)
    private String bank;

    @NotNull
    @Column(name = "PROPOSED_RATE", columnDefinition = "NUMBER(*,10)")
    private BigDecimal proposedRate = BigDecimal.ZERO;

    @NotNull
    @Column(name = "OFFERED_RATE", columnDefinition = "NUMBER(*,10)")
    private BigDecimal offeredRate = BigDecimal.ZERO;

    @NotNull
    @Column(name = "AMOUNT", columnDefinition = "NUMBER(*,10)")
    private BigDecimal amount;

    @NotNull
    @Column(name = "BALANCE_AMOUNT", columnDefinition = "NUMBER(*,10)")
    private BigDecimal balanceAmount;

    @NotNull
    @Column(name = "PAY_IN_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit payInCurrency;

    @NotNull
    @Column(name = "PAY_OUT_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit payOutCurrency;

    @NotNull
    @Embedded
    private AllInstruments instruments;

    @NotNull
    @Column(name = "TRANSMISSION_DATE", nullable = false, updatable = false)
    // @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime transmissionDate;

    @Column(name = "INITIATION_DATE", nullable = false, updatable = false)
    // @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime initiationDate;

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Setter(value = AccessLevel.NONE)
    @Column(name = "STATUS", updatable = true, nullable = false, length = 100)
    private StatusType status;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "SOURCE_TYPE", updatable = true, nullable = false, length = 20)
    private BranchProcessSourceType sourceType;

    @Column(name = "DEAL_TXN_ID", updatable = true, nullable = true, length = 100)
    private String dealTxnId;

    public boolean updateStatus(final StatusType status) {
        if (this.status == status) {
            return false;
        }
        else {
            this.status = status;
            return true;
        }
    }

    @Override
    public int compareTo(BranchProcess bp) {
        if (status.ordinal() == bp.status.ordinal())
            return 0;
        else if (status.ordinal() > bp.status.ordinal())
            return 1;
        else
            return -1;
    }

    public static BranchProcess of(BranchProcessCreateRequest reqObj) {
        AllInstruments instruments = null;
        if (reqObj.getInstrumentType().equals("XR")) { // only handle XR.
            instruments = AllInstruments.of(reqObj.getServiceProviderCode(), "Remittance", "Account Credit", "Normal");
        }

        BranchProcess branchProcess = BranchProcess.of(LocalDate.now(), reqObj.getDealId(), reqObj.getRequestType(),
                reqObj.getDealType(), reqObj.getCardType(), reqObj.getAgentCode(), reqObj.getBankCode(),
                BigDecimal.ZERO, // default proposed rate
                BigDecimal.ZERO, // default offered rate
                reqObj.getAmount(), reqObj.getBalanceAmount(), reqObj.getPayInCcy(), reqObj.getPayOutCcy(), instruments,
                LocalDateTime.parse(reqObj.getTransmissionDate(), formatter),
                LocalDateTime.parse(reqObj.getInititaionDate(), formatter), reqObj.getDealStatus(),
                reqObj.getSourceType(), null);

        if (reqObj.getDealStatus().equals(StatusType.REQUEST_RECEIVED)) {
            branchProcess.setProposedRate(new BigDecimal(reqObj.getRate()));
        }
        if (reqObj.getDealStatus().equals(StatusType.ACCEPTED)) {
            branchProcess.setOfferedRate(new BigDecimal(reqObj.getRate()));
        }

        return branchProcess;
    }

}
