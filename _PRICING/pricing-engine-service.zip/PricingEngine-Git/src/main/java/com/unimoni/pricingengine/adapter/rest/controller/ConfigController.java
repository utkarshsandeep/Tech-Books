package com.unimoni.pricingengine.adapter.rest.controller;

import static com.unimoni.pricingengine.common.constants.RestConstants.Config.*;
import static org.springframework.http.MediaType.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import javax.validation.constraints.NotEmpty;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unimoni.pricingengine.adapter.rest.util.HeaderUtil;
import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;
import com.unimoni.pricingengine.application.service.rateProvider.RateProviderService;
import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;
import com.unimoni.pricingengine.domain.model.rate.RateProvider;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationStatusType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.BeneficiaryType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.ChargeBasisType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.ChargeType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.CustomerType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.PaymentMode;
import com.unimoni.pricingengine.domain.model.standardcharges.types.SwiftChargeType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.TransactionType;
import com.unimoni.pricingengine.infra.config.ApplicationProperties;
import com.unimoni.pricingengine.infra.config.ApplicationProperties.Config;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Api(value = "config-api", description = "Static Data API", tags = "Static Data")
@RestController
@RequestMapping(CONFIG_URI)
public class ConfigController {

    @NonNull
    private ApplicationProperties.Config config;

    private MasterData masterData;

    public ConfigController(final ApplicationProperties applicationProperties,
            final RateProviderService rpExchangeRateService, final MasterData masterData) {
        this.config = applicationProperties.getConfig();
        this.masterData = masterData;
        this.config.setRateProviders(rpExchangeRateService.getAllRateProviders());
    }

    @GetMapping
    // @formatter:off
    @ApiOperation(nickname = "get-configs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all configurations: Service providers, Products, Rate providers and Currencies", 
        response = Config.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<Config> getConfig() {
        return ResponseEntity.ok(this.config);
    }

    @GetMapping(CONFIG_RATE_PROVIDERS_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-rate-providers",  
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all Rate Providers", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<RateProvider>> getRateProviders() {
        return ResponseEntity.ok(this.config.getRateProviders());
    }

    @GetMapping(CONFIG_VAR_REASONS_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-currencies",  
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all configurations, Service providers, Products, Rate Providers and Currencies", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<String>> getVaRReasons() {
        return ResponseEntity.ok(this.config.getVarReasons());
    }

    @GetMapping(CONFIG_TRANSACTION_TYPES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-transactionType", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all Transaction Type", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getTransactionType() {
        return ResponseEntity.ok(TransactionType.listItems());
    }

    @GetMapping(CONFIG_BENEFICIARY_TYPES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-beneficiaryType", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all beneficiary Type", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getBeneficiaryType() {
        return ResponseEntity.ok(BeneficiaryType.listItems());
    }

    @GetMapping(CONFIG_CUSTOMER_TYPES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-customerType", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all Customer Type", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getCustomerType() {
        return ResponseEntity.ok(CustomerType.listItems());
    }

    @GetMapping(CONFIG_CHARGE_TYPES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-chargeType", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets filtered Charge Type", 
        response = List.class, 
        notes = "")
    @ApiImplicitParams({        
        @ApiImplicitParam(name = "transactionType", paramType = "query",
            dataType = "String", type = "array", dataTypeClass = TransactionType.class,
            value = "Transaction Type in the format: code(SEND, RECEIVE)", allowMultiple = false, 
                    allowableValues = "SEND, RECEIVE, CANCEL_BEFORE_PROVIDER, CANCEL_AFTER_PROVIDER"
        )
    })
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getChargeType(
            @RequestParam(value = "transactionType", required = false) final TransactionType transactionType,
            @RequestParam(value = "bankCode", required = false) final List<String> bankCodeList) {

        if (transactionType != null && !transactionType.equals(TransactionType.RECEIVE) && bankCodeList != null
                && !bankCodeList.isEmpty()) {
            List<CodeNamePair<String, String>> codeNamePair = this.masterData.getMatchedBankCode(bankCodeList);
            if (codeNamePair != null && !codeNamePair.isEmpty() && codeNamePair.size() >= bankCodeList.size()) {
                return ResponseEntity.ok(ChargeType.listItems(true));
            }
        }
        return ResponseEntity.ok(ChargeType.listItems(false));
    }

    @GetMapping(CONFIG_CHARGE_TYPES_ALL_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-all-chargeType", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all Charge Type", 
        response = List.class, 
        notes = "")    
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getAllChargeType() {
        return ResponseEntity.ok(ChargeType.listItems());
    }

    @GetMapping(CONFIG_SWIFT_CHARGE_TYPES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-SwiftChargeType", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all SwiftCharge Type", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getSwiftChargeType() {
        return ResponseEntity.ok(SwiftChargeType.listItems());
    }

    @GetMapping(CONFIG_CHARGE_BASIS_TYPES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-chargeBasisType", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all chargeBasis Type", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getChargeBasisType() {
        return ResponseEntity.ok(ChargeBasisType.listItems());
    }

    @GetMapping(CONFIG_PAYMENT_MODES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-paymentMode", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all Paymentmode", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getPaymentMode() {
        return ResponseEntity.ok(PaymentMode.listItems());
    }

    @GetMapping(CONFIG_MASTER_DATA_REFRESH_URI)
    // @formatter:off
    @ApiOperation(nickname = "set-msdata-lockmode", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Sets msdata lock mode", 
        response = List.class, 
        notes = "")
    public ResponseEntity<Void> refreshMasterData(
            @ApiParam(allowMultiple = true, type = "String", value = "Code", required = true)
            @RequestParam(value = "code", required = true) @NotEmpty final String code,
            @ApiParam(allowMultiple = true, type = "String", value = "Type", required = true, allowableValues = "BOTH,AGENT,BANK,RESET")
            @RequestParam(value = "type", required = true) @NotEmpty final String type) {
        // @formatter:on
        if (code.equals("National")) {
            if (type.equals("RESET")) {
                try {
                    this.masterData.initialize();
                } catch (InterruptedException | ExecutionException e) {
                    return ResponseEntity.ok().headers(HeaderUtil.addError("Failed with exception")).build();
                }
            } else if (type.equals("BOTH")) {
                this.masterData.refreshAgentsAndBanksData();
            } else if (type.equals("AGENT")) {
                this.masterData.refreshAgentsData();
            } else if (type.equals("BANK")) {
                this.masterData.refreshBanksData();
            } else {
                return ResponseEntity.ok().headers(HeaderUtil.addError("Invalid type")).build();
            }
            return ResponseEntity.ok().headers(HeaderUtil.addSuccess("Performed successfully")).build();
        } else {
            return ResponseEntity.ok().headers(HeaderUtil.addError("Invalid code")).build();
        }
    }

    @GetMapping(CONFIG_RATE_LAYER_TYPES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-layerType", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets all RateLayerType", 
        response = List.class, 
        notes = "")
    // @formatter:on
    public ResponseEntity<List<CodeNamePair<String, String>>> getRateLayerType() {
        return ResponseEntity.ok(RateLayerType.listItems());
    }

    @GetMapping(CONFIG_AUTHORIZATION_STATUS_URI)
    @ApiOperation(nickname = "get-AuthorizationStatusType", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all AuthorizationStatusType at Queue UI", response = List.class, notes = "")
    public ResponseEntity<List<CodeNamePair<String, String>>> getAuthorizationStatusType() {
        List<CodeNamePair<String, String>> results = new ArrayList<>();
        results.addAll(AuthorizationStatusType.listItems().stream()
                .filter(item -> !AuthorizationStatusType.EXPIRED.name().equals(item.getCode()))
                .collect(Collectors.toList()));
        return ResponseEntity.ok(results);
    }
}
