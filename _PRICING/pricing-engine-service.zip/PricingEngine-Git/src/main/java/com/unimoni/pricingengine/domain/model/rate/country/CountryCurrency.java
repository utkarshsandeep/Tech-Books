package com.unimoni.pricingengine.domain.model.rate.country;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.CURRENCY_UNIT_USD;

import javax.money.CurrencyUnit;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.springframework.util.Assert;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
@org.hibernate.annotations.Immutable
public class CountryCurrency {

    @NotNull
    @Column(name = "BASE_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit base;

    @NotNull
    @Column(name = "FOREIGN_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit foreign;

    @Transient
    private static final String SEPERATOR = "";

    public static CountryCurrency of(final CurrencyUnit base, final CurrencyUnit foreign) {
        Assert.notNull(base, "baseCurrency must not be null!");
        Assert.notNull(foreign, "foreignCurrency must not be null!");
        CountryCurrency currencyExchange = new CountryCurrency();
        currencyExchange.base = base;
        currencyExchange.foreign = foreign;
        return currencyExchange;
    }

    public String ccy() {
        return ccy(SEPERATOR);
    }

    public String ccy(final String seperator) {
        return this.base.getCurrencyCode() + seperator + this.foreign.getCurrencyCode();
    }

    public boolean isContainingUSD() {
        return this.base == CURRENCY_UNIT_USD || this.foreign == CURRENCY_UNIT_USD;
    }
}