package com.unimoni.pricingengine.domain.model.remittance;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.common.enums.standard.CountryCode;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.remittance.dto.TransactionChargeRequest;
import com.unimoni.pricingengine.domain.model.remittance.dto.TxnLayerChargeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.types.BeneficiaryType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.CustomerType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.PaymentMode;
import com.unimoni.pricingengine.domain.model.standardcharges.types.SwiftChargeType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@ToString
@Entity
//@formatter:off
@Table(name = "REMITTANCE_TRANSACTION_INITIATION_REQUESTS", 
     indexes = { 
         @Index(name = "IDX_TXN_INIT_REQS_TRANSACTION_UUID", columnList = "TRANSACTION_UUID")  
     }
)
//@formatter:on
public class RemittanceTransactionInitiationRequest extends AbstractRemittanceTransaction {

    @NotNull
    @Column(name = "AGENT_BRANCH_ID", updatable = false, nullable = false)
    private Long agentBranchId;

    @NotEmpty
    @Column(name = "AGENT_BRANCH_CODE", updatable = false, length = 100)
    private String agentBranchCode;

    @NotNull
    @Column(name = "AGENT_ID", updatable = false, nullable = false)
    private Long agentId;

    @NotEmpty
    @Column(name = "AGENT_CODE", updatable = false, length = 100)
    private String agentCode;

    @NotEmpty
    @Column(name = "BANK_CODE", updatable = false, nullable = false, length = 100)
    private String bankCode;

    @NotNull
    private AllInstruments instruments;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "BENEFICIARY_TYPE", nullable = false, updatable = false, length = 20)
    private BeneficiaryType beneficiaryType;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "PAYMENT_MODE", nullable = false, updatable = false, length = 20)
    private PaymentMode paymentMode;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "CUSTOMER_TYPE", nullable = false, updatable = false, length = 20)
    private CustomerType customerType;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "ORIGINATING_COUNTRY", nullable = false, updatable = false, length = 2)
    private CountryCode originatingCountry;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "DESTINATION_COUNTRY", nullable = false, updatable = false, length = 2)
    private CountryCode destinationCountry;

    @NotNull
    private TransactionCurrencies currencies;

    @NotNull
    private TxnAmount amount;

    @NotNull
    @Column(name = "INITIATION_DATE", nullable = false, updatable = false)
    private LocalDate initiationDate;

    @NotNull
    @Column(name = "TRANSMISSION_DATE", nullable = false, updatable = false)
    private LocalDate transmissionDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "SWIFT_CHARGE_TYPE", nullable = true, updatable = true, length = 10)
    private SwiftChargeType swiftChargeType;

    @OneToOne(mappedBy = "txnInitRequest", cascade = CascadeType.ALL, fetch = FetchType.EAGER, optional = true)
    private RemittanceTransactionInitiationResponse txnInitResponse;

    public void setResponse(final RemittanceTransactionInitiationResponse txnInitResponse) {
        this.txnInitResponse = txnInitResponse;
    }

    @OneToMany(mappedBy = "txnInitRequest", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @org.hibernate.annotations.OrderBy(clause = "CREATED_ON desc")
    private List<RemittanceTransactionCancellationRequest> txnCancellationRequest = new ArrayList<>();

    public void addCancellationRequest(final RemittanceTransactionCancellationRequest txnCancellationRequest) {
        this.txnCancellationRequest.add(txnCancellationRequest);
    }

    public static RemittanceTransactionInitiationRequest of(final TransactionChargeRequest transactionChargeRequest,
            String agentBranchCode, final Long agentId, final String agentCode, final ZonedDateTime txnTimestamp) {
        RemittanceTransactionInitiationRequest txnInitiationRequest = new RemittanceTransactionInitiationRequest();
        txnInitiationRequest.transactionUUID = transactionChargeRequest.getTransactionUUID();
        txnInitiationRequest.agentBranchId = transactionChargeRequest.getAgentBranchId();
        txnInitiationRequest.agentBranchCode = agentBranchCode;
        txnInitiationRequest.agentId = agentId;
        txnInitiationRequest.agentCode = agentCode;
        txnInitiationRequest.bankCode = transactionChargeRequest.getBankCode();
        txnInitiationRequest.instruments = transactionChargeRequest.getInstruments();
        txnInitiationRequest.beneficiaryType = transactionChargeRequest.getBeneficiaryType();
        txnInitiationRequest.paymentMode = transactionChargeRequest.getPaymentMode();
        txnInitiationRequest.customerType = transactionChargeRequest.getCustomerType();
        txnInitiationRequest.originatingCountry = transactionChargeRequest.getOriginatingCountry();
        txnInitiationRequest.destinationCountry = transactionChargeRequest.getDestinationCountry();
        txnInitiationRequest.currencies = TransactionCurrencies.of(transactionChargeRequest.getPayInCurrency(),
                transactionChargeRequest.getPayOutCurrency(), transactionChargeRequest.getSettlementCurrency(),
                transactionChargeRequest.getSericeProviderCurrency(),
                transactionChargeRequest.getPassSettlementCurrency());
        txnInitiationRequest.amount = transactionChargeRequest.getAmount();
        txnInitiationRequest.initiationDate = transactionChargeRequest.getInitiationDate();
        txnInitiationRequest.transmissionDate = transactionChargeRequest.getTransmissionDate();
        txnInitiationRequest.createdOn = txnTimestamp;
        txnInitiationRequest.swiftChargeType = transactionChargeRequest.getSwiftChargeType();

        return txnInitiationRequest;
    }

    public TxnLayerChargeRequest layerChargeRequest() {
        return TxnLayerChargeRequest.of(this.transactionUUID, this.agentBranchCode, this.agentCode, this.bankCode,
                this.instruments);
    }
}