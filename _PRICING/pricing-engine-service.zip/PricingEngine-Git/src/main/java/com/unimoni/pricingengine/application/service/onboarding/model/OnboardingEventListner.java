package com.unimoni.pricingengine.application.service.onboarding.model;

import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.AGENT_RATE_FOR_DRAWEE_PRODUCT_DISABLED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.AGENT_RATE_FOR_DRAWEE_PRODUCT_ENABLED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.ALLOWED_PRODUCTS_SEND_RULE_CREATED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.ALLOWED_PRODUCTS_SEND_RULE_UPDATED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.DRAWEE_BANK_DISABLED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.DRAWEE_BANK_ENABLED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.DRAWEE_BANK_PRODUCT_DELETED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.DRAWEE_BANK_PRODUCT_DISABLED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.DRAWEE_BANK_PRODUCT_ENABLED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.DRAWEE_BANK_PRODUCT_ONBOARDED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.ROUND_OFF_CUT_OFF_RATE_SETTING_CREATED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.ROUND_OFF_CUT_OFF_RATE_SETTING_UPDATED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.UAEEXCHANGE_RATE_FOR_DRAWEE_PRODUCT_DISABLED;
import static com.unimoni.pricingengine.common.constants.OnboardingJMSConstants.UAEEXCHANGE_RATE_FOR_DRAWEE_PRODUCT_ENABLED;

import javax.jms.Message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.unimoni.pricingengine.common.annotation.spring.JmsIntegration;

import lombok.extern.slf4j.Slf4j;

@JmsIntegration
@Slf4j
@Component
public class OnboardingEventListner {

    @Autowired
    private MasterData masterData;

//    @JmsListener(destination = AGENT_ONBOARDED, containerFactory = "topicListenerFactory")
//    public void handleAgentOnboardedEvent(final Message message) {
//        log.info("Received {} event : {}", AGENT_ONBOARDED, message);
//        // this.masterData.refreshAgentsData();
//        this.masterData.refreshAgentsAndBanksData();
//    }
//
//    @JmsListener(destination = AGENT_UPDATED, containerFactory = "topicListenerFactory")
//    public void handleAgentUpdatedEvent(final Message message) {
//        log.info("Received {} event : {}", AGENT_UPDATED, message);
//        // this.masterData.refreshAgentsData();
//        this.masterData.refreshAgentsAndBanksData();
//    }

    @JmsListener(destination = ROUND_OFF_CUT_OFF_RATE_SETTING_CREATED, containerFactory = "topicListenerFactory")
    public void handleRoundOffCutOffRateSettingCreatedEvent(final Message message) {
        log.info("Received {} event : {}", ROUND_OFF_CUT_OFF_RATE_SETTING_CREATED, message);
        // this.masterData.refreshAgentsData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = ROUND_OFF_CUT_OFF_RATE_SETTING_UPDATED, containerFactory = "topicListenerFactory")
    public void handleRoundOffCutOffRateSettingUpdatedEvent(final Message message) {
        log.info("Received {}  event : {}", ROUND_OFF_CUT_OFF_RATE_SETTING_UPDATED, message);
        // this.masterData.refreshAgentsData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = ALLOWED_PRODUCTS_SEND_RULE_CREATED, containerFactory = "topicListenerFactory")
    public void handleAllowedProductsSendRuleCreatedEvent(final Message message) {
        log.info("Received {} event : {}", ALLOWED_PRODUCTS_SEND_RULE_CREATED, message);
        // this.masterData.refreshAgentsData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = ALLOWED_PRODUCTS_SEND_RULE_UPDATED, containerFactory = "topicListenerFactory")
    public void handleAllowedProductsSendRuleUpdatedEvent(final Message message) {
        log.info("Received {} event : {}", ALLOWED_PRODUCTS_SEND_RULE_UPDATED, message);
        // this.masterData.refreshAgentsData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = DRAWEE_BANK_ENABLED, containerFactory = "topicListenerFactory")
    public void handleDraweeBankEnabledEvent(final Message message) {
        log.info("Received {} event : {}", DRAWEE_BANK_ENABLED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = DRAWEE_BANK_DISABLED, containerFactory = "topicListenerFactory")
    public void handleDraweeBankDisabledEvent(final Message message) {
        log.info("Received {} event : {}", DRAWEE_BANK_DISABLED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = UAEEXCHANGE_RATE_FOR_DRAWEE_PRODUCT_ENABLED, containerFactory = "topicListenerFactory")
    public void handleUaeexchangeRateForDraweeProductEnabledEvent(final Message message) {
        log.info("Received {} event : {}", UAEEXCHANGE_RATE_FOR_DRAWEE_PRODUCT_ENABLED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = UAEEXCHANGE_RATE_FOR_DRAWEE_PRODUCT_DISABLED, containerFactory = "topicListenerFactory")
    public void handleUaeexchangeRateForDraweeProductDisabledEvent(final Message message) {
        log.info("Received {} event : {}", UAEEXCHANGE_RATE_FOR_DRAWEE_PRODUCT_DISABLED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = AGENT_RATE_FOR_DRAWEE_PRODUCT_ENABLED, containerFactory = "topicListenerFactory")
    public void handleAgentRateForDraweeProductEnabledEvent(final Message message) {
        log.info("Received {} event : {}", AGENT_RATE_FOR_DRAWEE_PRODUCT_ENABLED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = AGENT_RATE_FOR_DRAWEE_PRODUCT_DISABLED, containerFactory = "topicListenerFactory")
    public void handleAgentRateForDraweeProductDisabledEvent(final Message message) {
        log.info("Received {} event : {}", AGENT_RATE_FOR_DRAWEE_PRODUCT_DISABLED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = DRAWEE_BANK_PRODUCT_ONBOARDED, containerFactory = "topicListenerFactory")
    public void handleDraweeBankProductOnboardedEvent(final Message message) {
        log.info("Received {} event : {}", DRAWEE_BANK_PRODUCT_ONBOARDED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = DRAWEE_BANK_PRODUCT_DISABLED, containerFactory = "topicListenerFactory")
    public void handleDraweeBankProductDisabledEvent(final Message message) {
        log.info("Received {} event : {}", DRAWEE_BANK_PRODUCT_DISABLED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = DRAWEE_BANK_PRODUCT_ENABLED, containerFactory = "topicListenerFactory")
    public void handleDraweeBankProductEnabledEvent(final Message message) {
        log.info("Received {} event : {}", DRAWEE_BANK_PRODUCT_ENABLED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }

    @JmsListener(destination = DRAWEE_BANK_PRODUCT_DELETED, containerFactory = "topicListenerFactory")
    public void handleDraweeBankProductDeletedEvent(final Message message) {
        log.info("Received {} event : {}", DRAWEE_BANK_PRODUCT_DELETED, message);
        // this.masterData.refreshBanksData();
        this.masterData.refreshAgentsAndBanksData();
    }
}
