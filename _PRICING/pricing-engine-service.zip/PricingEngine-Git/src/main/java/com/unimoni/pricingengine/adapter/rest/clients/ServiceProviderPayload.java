package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ServiceProviderPayload {

    List<String> serviceProviderCodes;

    List<Long> agentBranchIds;

    List<String> productTypes;

    List<String> subProductTypes;

    List<String> serviceTypes;

}
