package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChargeRulePayload {

    public String id;

    public String productType;

    public String subProductType;

    public String serviceType;

    public String reasonCode;

    public ChargeRuleSettingPayload chargesRuleSettings;

    public boolean status;

    public ChargeRulePayload(final @JsonProperty("id") String id, final @JsonProperty("productType") String productType,
            final @JsonProperty("subProductType") String subProductType,
            final @JsonProperty("serviceType") String serviceType, final @JsonProperty("reasonCode") String reasonCode,
            final @JsonProperty("chargesRuleSettings") ChargeRuleSettingPayload chargesRuleSettings,
            final @JsonProperty("status") String status) {
        this.id = id;
        this.productType = productType;
        this.subProductType = subProductType;
        this.serviceType = serviceType;
        this.reasonCode = reasonCode;
        this.chargesRuleSettings = chargesRuleSettings;
        this.status = status != null && status.equalsIgnoreCase("ENABLED");
    }
    
    public static enum ReasonCode {
        
        AGENT_FAULT("AGENT_FAULT"),
        CUSTOMER_WISH("CUSTOMER_WISH"),
        SERVICE_PROVIDER_FAULT("SP_FAULT");
        
        private final String description;
        private ReasonCode(final String description) {
            this.description = description;
        }

        public String description() {
            return this.description;
        }
    }

    public boolean isEnabled() {
        return this.status;
    }
}
