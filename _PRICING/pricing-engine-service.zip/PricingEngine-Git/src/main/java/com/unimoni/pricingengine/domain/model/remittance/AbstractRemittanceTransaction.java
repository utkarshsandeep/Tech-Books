package com.unimoni.pricingengine.domain.model.remittance;

import static com.unimoni.pricingengine.adapter.persistence.PersistenceConstant.Hibernate.GLOBAL_SEQ_ID_GENERATOR;

import java.time.ZonedDateTime;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.common.type.Identifiable;
import com.unimoni.pricingengine.domain.model.common.type.Versionable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class AbstractRemittanceTransaction implements Identifiable<Long>, Versionable<Long> {

    @Id
    @GeneratedValue(generator = GLOBAL_SEQ_ID_GENERATOR)
    @Column(name = "ID", updatable = false, nullable = false)
    @Access(AccessType.FIELD)
    protected Long id;

    @Version
    @Access(AccessType.FIELD)
    @Column(name = "version", nullable = false)
    private Long version;
    
    @NotNull
    @Column(name = "TRANSACTION_UUID", updatable = false, nullable = false, length = 50)
    protected String transactionUUID;

    @NotNull
    // @formatter:off
    @Column(name = "CREATED_ON", 
            columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    // @formatter:on
    protected ZonedDateTime createdOn;
}
