package com.unimoni.pricingengine.adapter.rest.util;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.common.constants.ApplicationConstants;

/**
 * General Utility class
 */
public final class PricingUtils {
    
    private PricingUtils() {
    }

    public static boolean isUSDCurrency(final CurrencyUnit currency) {
        return ApplicationConstants.CURRENCY_UNIT_USD == currency;
    }
}
