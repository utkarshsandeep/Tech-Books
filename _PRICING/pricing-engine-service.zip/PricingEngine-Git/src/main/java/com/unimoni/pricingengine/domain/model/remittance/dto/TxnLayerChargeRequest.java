package com.unimoni.pricingengine.domain.model.remittance.dto;

import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
public class TxnLayerChargeRequest {
    
    private String transactionUUID;

    private String agentBranchCode;

    private String agentCode;

    private String bank;

    private AllInstruments instruments;
}
