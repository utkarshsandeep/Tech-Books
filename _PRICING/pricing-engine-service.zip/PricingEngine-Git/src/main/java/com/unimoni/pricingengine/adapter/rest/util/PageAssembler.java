package com.unimoni.pricingengine.adapter.rest.util;

import java.util.List;
import java.util.Map;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.web.util.UriComponents;

import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.common.dto.ViewModel;

public interface PageAssembler<T extends ViewModel<I>, I> {

    public <A extends ResourceAssembler<T, I>> PaginatedResource<Resource<T>> assemble(final Iterable<T> content,
            final PaginationData page, final Map<String, Object> paramsMap);

    public <A extends ResourceAssembler<T, I>> PaginatedResource<Resource<T>> assemble(final Iterable<T> content,
            final PaginationData page, final Map<String, Object> paramsMap, final A resourceAssembler,
            final Object... assemblerParameters);

    public Link selfLink(final Map<String, Object> paramsMap);

    public List<Link> paginationLinks(final PaginationData page, final Map<String, Object> paramsMap,
            final UriComponents uriComponents);
}
