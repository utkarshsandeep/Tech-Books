package com.unimoni.pricingengine.adapter.rest.clients.bp;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessAmigoCreateRequest;

@FeignClient(name = "bpAmigoClient", url = "${amigo-url.amigo-base-url}")
public interface BranchProcessAmigoClient {

    @RequestMapping(path = "/Paas_Integration/specialDeal/updateDealOfferedRate", method = RequestMethod.POST, consumes = "application/json")
    BranchProcessAmigoResponse updateOfferedRateAmigo(@RequestBody BranchProcessAmigoUpdateRequest payload);

    @RequestMapping(path = "/Paas_Integration/specialDeal/insertSpecialDealTxnData", method = RequestMethod.POST, consumes = "application/json")
    BranchProcessAmigoResponse pushDealToAmigo(@RequestBody BranchProcessAmigoCreateRequest payload);

    @RequestMapping(path = "/Paas_Integration/specialDeal/updateDealStatus", method = RequestMethod.POST, consumes = "application/json")
    BranchProcessAmigoResponse updateDealStatusAmigo(@RequestBody BranchProcessAmigoUpdateRequest payload);

}
