package com.unimoni.pricingengine.domain.model.rate;

import static com.unimoni.pricingengine.adapter.persistence.PersistenceConstant.Hibernate.GLOBAL_SEQ_ID_GENERATOR;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "BANK_PRODUCT_ONBOARD")
@EqualsAndHashCode
public class BankProductOnboard /* implements UUIDIdentifiable<String> */ {

	@Id
	@GeneratedValue(generator = GLOBAL_SEQ_ID_GENERATOR)
	@Column(name = "ID", updatable = false, nullable = false)
	@Access(AccessType.FIELD)
	@Setter(value = AccessLevel.NONE)
	private long eventId;

	@Version
	@Access(AccessType.FIELD)
	@Column(name = "version", nullable = false)
	@Setter(value = AccessLevel.NONE)
	private long version;

	@Column(name = "BANK_PRODUCT_PROFILE_ID", updatable = false, nullable = false, length = 36)
	private String id;

	@Column(name = "CURRENCY_CODE", updatable = false, nullable = false, length = 36)
	private String currencyCode;

	@Column(name = "STATUS", updatable = false, nullable = false, length = 36)
	private String status;

	@Column(name = "PRODUCT_TYPE", updatable = false, nullable = false, length = 36)
	private String productType;

	@Column(name = "DISPLAY_NAME", updatable = false, nullable = false, length = 36)
	private String displayName;

	@Column(name = "DRAWEE_BANK_ID", updatable = false, nullable = false, length = 36)
	private String draweeBankId;

	@Column(name = "CREATED_DATE", updatable = false, nullable = false, length = 36)
	private String createdDate;

	@Column(name = "MODIFIED_DATE", updatable = false, nullable = false, length = 36)
	private String modifiedDate;

	@Column(name = "SERVICE_PROVIDER_CODE", updatable = false, nullable = false, length = 36)
	private String serviceProviderCode;

	@Column(name = "BANK_NAME", updatable = false, nullable = false, length = 36)
	private String bankName;

	@Column(name = "PRODUCT_SUBTYPE", updatable = false, nullable = false, length = 36)
	private String productSubType;

	@Column(name = "SERVICE_TYPE", updatable = false, nullable = true, length = 36)
	private String serviceType;

	@Column(name = "SWIFT_CODE", updatable = false, nullable = false, length = 36)
	private String swiftCode;

	@Column(name = "ACCOUNT_NUMBER", updatable = false, nullable = false, length = 36)
	private String accountNumber;

	@Column(name = "UAEX_BANK_WISE", updatable = false, nullable = false, length = 36)
	private Boolean uaexBankWiseRateCcy;

	@Column(name = "DELETED", updatable = false, nullable = false, length = 36)
	private Boolean deleted;

}
