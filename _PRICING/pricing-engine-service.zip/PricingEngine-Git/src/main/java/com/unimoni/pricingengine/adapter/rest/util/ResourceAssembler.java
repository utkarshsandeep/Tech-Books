package com.unimoni.pricingengine.adapter.rest.util;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.List;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.util.Assert;

import com.unimoni.pricingengine.domain.model.common.dto.ViewModel;

public interface ResourceAssembler<T extends ViewModel<I>, I> {

    public default Resource<T> assemble(final T content, final boolean justSelfLink, Object... parameters) {
        Assert.notNull(content, "Content must not be null!");
        Resource<T> resource = new Resource<>(content);
        resource.add(selfLink(content.id(), parameters));
        if (!justSelfLink) {
            resource.add(affordances(content, parameters));
        }
        return resource;
    }

    public default URI selfURI(final I identifier, Object... parameters) {
        try {
            return new URI(selfLink(identifier, parameters).withSelfRel().getHref());
        }
        catch (URISyntaxException e) {
            throw new RuntimeException("URISyntaxException while getting self-link URI with ID: " + identifier, e);
        }
    }

    public Link selfLink(final I identifier, Object... parameters);

    public default List<Link> affordances(final T content, Object... parameters) {
        return Collections.emptyList();
    }
}
