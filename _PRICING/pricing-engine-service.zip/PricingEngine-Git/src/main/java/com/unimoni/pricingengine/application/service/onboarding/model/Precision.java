package com.unimoni.pricingengine.application.service.onboarding.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public class Precision {

    private int value;
    
    private Type type;
    
    public enum Type {
        ROUND_OFF, CUT_OFF;
    }
}
