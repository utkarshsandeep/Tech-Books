package com.unimoni.pricingengine.adapter.persistence.repository.rp;

import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.rate.RateProvider;
import com.unimoni.pricingengine.domain.model.rate.RateProvider_;

@Repository
public class RateProviderRepositoryImpl extends AbstractJPA implements RateProviderRepositoryJPA {

    @Override
    public RateProvider saveRateProvider(final RateProvider rateProvider) {
        return persist(rateProvider);
    }

    @Override
    public List<RateProvider> findAllRateProviders() {
        CriteriaQuery<RateProvider> query = criteriaQuery(RateProvider.class);
        Root<RateProvider> rateProvider = query.from(RateProvider.class);
        query.select(rateProvider);
        return getUnmodifiableResultList(query);
    }

    @Override
    public RateProvider getRateProviderReference(final int rateProviderId) {
        return getReference(RateProvider.class, rateProviderId);
    }

    public Optional<RateProvider> findRateProviderById(final int rateProviderId) {
        return findByIdSafely(RateProvider.class, rateProviderId);
    }

    @Override
    public Optional<RateProvider> findRateProviderByName(String rateProviderName) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<RateProvider> query = criteriaQuery(RateProvider.class);
        Root<RateProvider> rateProvider = query.from(RateProvider.class);
        query.select(rateProvider);

        Predicate rateProviderNameEqualsPredicate = criteriaBuilder
                .equal(rateProvider.get(RateProvider_.name.getName()), rateProviderName);
        query.where(rateProviderNameEqualsPredicate);
        return getSingleResultSafely(query);
    }
}
