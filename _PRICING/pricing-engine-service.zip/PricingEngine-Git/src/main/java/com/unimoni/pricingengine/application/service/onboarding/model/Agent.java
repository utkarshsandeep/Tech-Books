package com.unimoni.pricingengine.application.service.onboarding.model;

import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode(of = "agentId")
@ToString
public class Agent implements Partner {

    private long agentId;

    private String agentDisplayCode;

    private CodeNamePair<String, String> country;

    private RateDisplayMachenism rateDisplayMechanism;

    private List<AgentBranch> branches;

    private List<Product> products;

    @Getter(value = AccessLevel.NONE)
    private CodeNamePair<String, String> pair;

    private Agent(final long agentId, final String agentDisplayCode, final CodeNamePair<String, String> country,
            final RateDisplayMachenism rateDisplayMechanism, final List<AgentBranch> branches,
            final List<Product> products) {
        this.agentId = agentId;
        this.agentDisplayCode = agentDisplayCode;
        this.country = country;
        this.rateDisplayMechanism = rateDisplayMechanism;
        this.branches = branches;
        this.products = products;
        this.pair = CodeNamePair.of(this.agentDisplayCode, this.agentDisplayCode);
    }

    public static Agent of(final long agentId, final String agentDisplayCode,
            final CodeNamePair<String, String> country, final RateDisplayMachenism rateDisplayMechanism,
            final List<AgentBranch> branches, final List<Product> products) {
        return new Agent(agentId, agentDisplayCode, country, rateDisplayMechanism, branches, products);
    }

    public Optional<RateDisplayMachenism> rateDisplayMechanism() {
        return Optional.ofNullable(this.rateDisplayMechanism);
    }

    @Override
    public CodeNamePair<String, String> pair() {
        return this.pair;
    }

    @Override
    public int compareTo(final PairItem<String, String> other) {
        return this.agentDisplayCode.compareTo(other.pair().getName());
    }

    public AgentListItem agentListItem() {
        return AgentListItem.ofAgent(this.agentId, this.agentDisplayCode, this.agentDisplayCode, rateDisplayMechanism);
    }

    @Override
    public String getCode() {
        return this.agentDisplayCode;
    }
    
    public AgentDetails details() {
        return AgentDetails.ofAgent(this.agentDisplayCode, this.rateDisplayMechanism);
    }
}
