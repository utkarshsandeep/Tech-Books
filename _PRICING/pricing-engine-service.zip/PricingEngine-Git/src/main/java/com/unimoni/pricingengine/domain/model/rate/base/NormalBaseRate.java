package com.unimoni.pricingengine.domain.model.rate.base;

import static com.unimoni.pricingengine.adapter.persistence.PersistenceConstant.TableMetaData.TABLE_NORMAL_BASE_RATES;
import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.envers.Audited;
import org.springframework.util.Assert;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.application.event.listner.EntityChangeListener;
import com.unimoni.pricingengine.application.service.amigo.event.IBRUpdatedEvent;
import com.unimoni.pricingengine.application.service.event.EventPublisher;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.builder.Builder;
import com.unimoni.pricingengine.domain.model.builder.MultiBuilder;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.NormalRate;
import com.unimoni.pricingengine.domain.model.rate.RateProvider;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateIdentity;
import com.unimoni.pricingengine.domain.model.rate.composable.Exchange;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR;
import com.unimoni.pricingengine.domain.model.validation.RatesValidationHelper;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString
@Slf4j
//@formatter:off
@NamedEntityGraph(
    name = "normalBaseRate",
    attributeNodes = {
        @NamedAttributeNode(value = "ibr", subgraph = "normalIbr")
    },
    subgraphs = {
        @NamedSubgraph(
                name = "normalIbr",
                attributeNodes = {
                    @NamedAttributeNode("vars")}
        )
    }
)
@Entity
@EntityListeners(EntityChangeListener.class)
@DiscriminatorValue("NORMAL_BASE")
@SecondaryTable(name = TABLE_NORMAL_BASE_RATES, 
    indexes = {
        @Index(name = "IDX_NORMAL_BASE_RATES_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
        @Index(name = "IDX_NORMAL_BASE_RATES_PRODUCT_CODE", columnList = "PRODUCT_CODE") 
    }, 
    pkJoinColumns = @PrimaryKeyJoinColumn(name = "ID"), 
    foreignKey = @ForeignKey(name = "FK_NORMAL_BASE_RATES_MANAGED_RATES_ID")
)
// @formatter:on
@Audited
public class NormalBaseRate extends AbstractLayer implements BaseRate, NormalRate {

    @NotNull
    @Embedded
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "serviceProvider", 
            column = @Column(table = TABLE_NORMAL_BASE_RATES, name = "SERVICE_PROVIDER_CODE", 
                updatable = false, nullable = false, length = 100)),
        @AttributeOverride(name = "product", 
            column = @Column(table = TABLE_NORMAL_BASE_RATES, name = "PRODUCT_CODE", 
                updatable = false, nullable = false, length = 100)) 
    })
    // @formatter:on
    private RateInstruments instruments;

    @NotNull
    @ManyToOne
    // @formatter:off
    @JoinColumn(table = TABLE_NORMAL_BASE_RATES, name = "RATE_PROVIDER_ID", nullable = false, updatable = false, 
                foreignKey = @ForeignKey(name = "FK_NORMAL_BASE_RATE_RATE_PROVIDER_ID"))
    //@formatter:on
    private RateProvider rateProvider;

    @Column(table = TABLE_NORMAL_BASE_RATES, name = "RIC_ID", nullable = true, updatable = false, length = 50)
    private String ricId;

    @Column(table = TABLE_NORMAL_BASE_RATES, name = "FREQUENCY", nullable = true, length = 15)
    private Duration frequency;

    @Getter(value = AccessLevel.NONE)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(table = TABLE_NORMAL_BASE_RATES, name = "IS_LIVE", length = 1)
    private Boolean live;

    @NotNull
    @OneToOne(fetch = FetchType.LAZY, optional = false, cascade = CascadeType.ALL)
    // @formatter:off
    @JoinColumn(table = TABLE_NORMAL_BASE_RATES, name = "IBR_ID", unique = true, updatable = false, nullable = false, 
            foreignKey = @ForeignKey(name = "FK_NORMAL_BASE_RATES_IBR_ID"))
    //@formatter:on
    private NormalIBR ibr;

    public boolean updateRate(final BigDecimal askValue, final BigDecimal bidValue) {
        return updateRate(ExchangeRate.of(askValue, bidValue));
    }

    public boolean updateRate(final ExchangeRate rate) {
        if (exchange().updateRate(rate)) {
            this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
            propagateRateChangeToIbr();

            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateStatus(final boolean status) {

        if (this.enabled == status) {
            return false;
        }
        else {
            this.enabled = status;

            // if(status == false) { //Propagate only when record is being disabled.
            propagateStatusChangeToIbr();
            // }

            return true;
        }
    }

    private NormalIBR publishToIbr() {
        return this.ibr == null ? this.ibr = NormalIBR.of(this) : this.ibr;
    }

    private NormalIBR propagateRateChangeToIbr() {
        if (this.ibr.isEnabled()) {
            if (this.ibr.updateRate(this.exchange.rate(), this.updatedOn)) {
                EventPublisher.publishNormalBaseRateToBankwiseBaseRate(this);
                
                EventPublisher.publishAmigoEvent(IBRUpdatedEvent.normalIBRForRateChange(this.ibr));
            }
            else {
                log.debug("New rate is found to be same as old, So no updates have happened");
            }
        }
        else {
            log.debug("Linked IBR record is disabled, So can not propagate rate changes");
        }
        return this.ibr;
    }

    private NormalIBR propagateStatusChangeToIbr() {
        if (this.ibr.updateStatus(this.enabled)) {
            EventPublisher.publishAmigoEvent(IBRUpdatedEvent.normalIBRForStatusChange(this.ibr));
        }
        return this.ibr;
    }

    public RateIdentity identity() {
        return RateIdentity.of(this.exchange.currency().source(), this.exchange.currency().target(),
                this.instruments.serviceProvider(), this.instruments.product());
    }

    public boolean isLive() {
        return this.live;
    }

    public void updateLiveness(boolean live) {
        this.live = live;
    }

    public boolean updateFrequency(final Duration newfrequency) {
        if (this.frequency.compareTo(newfrequency) == 0) {
            return false;
        }
        else {
            this.frequency = newfrequency;

            return true;
        }
    }

    public static TargetCurrencyBuilder from(final CurrencyUnit sourceCurrency) {
        return new NormalBaseRateBuilder(sourceCurrency);
    }

    public interface TargetCurrencyBuilder {
        public AskValueBuilder to(final CurrencyUnit targetCurrency);
    }

    public interface AskValueBuilder {
        public BidValueBuilder askAt(final BigDecimal askValue);
    }

    public interface BidValueBuilder {
        public RateProviderBuilder bidAt(final BigDecimal bidValue);
    }

    public interface RateProviderBuilder {
        public RicIdBuilder rateProvider(final RateProvider rateProvider);

        public ServiceProviderBuilder manualRateProvider(final RateProvider rateProvider);
    }

    public interface RicIdBuilder {
        public FrequencyBuilder ricId(final String ricId);
    }

    public interface FrequencyBuilder {
        public IsLiveBuilderBuilder updateAfterEvery(final Duration frequency);
    }

    public interface IsLiveBuilderBuilder {
        public ServiceProviderBuilder considerLive(final boolean live);
    }

    public interface ServiceProviderBuilder {

        public Builder<NormalBaseRate> allInstruments();

        public SingleServiceProviderProductBuilder allServiceProviders();

        public SingleServiceProviderProductBuilder serviceProvider(final String serviceProvider);

        public MultipleServiceProviderProductBuilder serviceProvider(final String... serviceProviders);
    }

    public interface SingleServiceProviderProductBuilder {

        public Builder<NormalBaseRate> allProducts();

        public Builder<NormalBaseRate> product(final String product);

        public MultiBuilder<NormalBaseRate> product(final String... products);
    }

    public interface MultipleServiceProviderProductBuilder {

        public Builder<NormalBaseRate> withAllProducts();

        public MultiBuilder<NormalBaseRate> withProduct(final String product);

        public MultiBuilder<NormalBaseRate> withProduct(final String... products);
    }

    // -------------------------------------------------------------------------

    public static IdentityAskValueBuilder of(final List<RateIdentity> identities) {
        return new NormalBaseRateBuilder(identities);
    }

    public interface IdentityAskValueBuilder {
        public IdentityBidValueBuilder askValue(final BigDecimal askValue);
    }

    public interface IdentityBidValueBuilder {
        public IdentityRateProviderBuilder bidValue(final BigDecimal bidValue);
    }

    public interface IdentityRateProviderBuilder {
        public IdentityRicIdBuilder withRateProvider(final RateProvider rateProvider);

        public MultiBuilder<NormalBaseRate> withManualRateProvider(final RateProvider rateProvider);
    }

    public interface IdentityRicIdBuilder {
        public IdentityFrequencyBuilder withRicId(final String ricId);
    }

    public interface IdentityFrequencyBuilder {
        public IdentityIsLiveBuilderBuilder withFrequency(final Duration frequency);
    }

    public interface IdentityIsLiveBuilderBuilder {
        public MultiBuilder<NormalBaseRate> isLive(final boolean live);
    }

    public static class NormalBaseRateBuilder implements TargetCurrencyBuilder, AskValueBuilder, BidValueBuilder,
            RateProviderBuilder, RicIdBuilder, FrequencyBuilder, IsLiveBuilderBuilder, ServiceProviderBuilder,
            SingleServiceProviderProductBuilder, MultipleServiceProviderProductBuilder, Builder<NormalBaseRate>,
            MultiBuilder<NormalBaseRate>, IdentityAskValueBuilder, IdentityBidValueBuilder, IdentityRateProviderBuilder,
            IdentityRicIdBuilder, IdentityFrequencyBuilder, IdentityIsLiveBuilderBuilder {

        private String ricId;

        private CurrencyUnit sourceCurrency;

        private CurrencyUnit targetCurrency;

        private BigDecimal askValue;

        private BigDecimal bidValue;

        private RateProvider rateProvider;

        private Duration frequency;

        private boolean live;

        private String serviceProvider;

        private ImmutableList<String> serviceProviders;

        private String product;

        private ImmutableList<String> products;

        NormalBaseRateBuilder(final CurrencyUnit sourceCurrency) {
            this.sourceCurrency = sourceCurrency;
        }

        private List<RateIdentity> identities;

        NormalBaseRateBuilder(final List<RateIdentity> identities) {
            this.identities = identities;
        }

        @Override
        public AskValueBuilder to(final CurrencyUnit targetCurrency) {
            this.targetCurrency = targetCurrency;
            return this;
        }

        @Override
        public BidValueBuilder askAt(final BigDecimal askValue) {
            Assert.notNull(askValue, "askValue must not be null!");
            this.askValue = askValue;
            return this;
        }

        @Override
        public RateProviderBuilder bidAt(final BigDecimal bidValue) {
            Assert.notNull(bidValue, "bidValue must not be null!");
            this.bidValue = bidValue;
            return this;
        }

        @Override
        public RicIdBuilder rateProvider(final RateProvider rateProvider) {
            Assert.notNull(rateProvider, "rateProvider must not be null!");
            this.rateProvider = rateProvider;
            return this;
        }

        @Override
        public FrequencyBuilder ricId(final String ricId) {
            Assert.isTrue(StringUtils.isNotEmpty(ricId), "ricId must not be null or empty");
            this.ricId = ricId;
            return this;
        }

        @Override
        public IsLiveBuilderBuilder updateAfterEvery(final Duration frequency) {
            Assert.notNull(frequency, "frequency must not be null!");
            this.frequency = frequency;
            return this;
        }

        @Override
        public ServiceProviderBuilder considerLive(final boolean live) {
            this.live = live;
            return this;
        }

        @Override
        public ServiceProviderBuilder manualRateProvider(final RateProvider rateProvider) {
            Assert.notNull(rateProvider, "rateProvider must not be null!");
            Assert.isTrue(rateProvider.isManual(), "rateProvider is not of Manual type!");
            this.rateProvider = rateProvider;
            return this;
        }

        @Override
        public Builder<NormalBaseRate> allInstruments() {
            this.serviceProvider = ALL_INSTRUMENTS;
            this.product = ALL_INSTRUMENTS;
            return this;
        }

        @Override
        public SingleServiceProviderProductBuilder allServiceProviders() {
            this.serviceProvider = ALL_INSTRUMENTS;
            return this;
        }

        @Override
        public SingleServiceProviderProductBuilder serviceProvider(String serviceProvider) {
            Assert.isTrue(StringUtils.isNotEmpty(serviceProvider), "serviceProvider must not be null or empty");
            this.serviceProvider = serviceProvider;
            return this;
        }

        @Override
        public MultipleServiceProviderProductBuilder serviceProvider(String... serviceProviders) {
            Assert.noNullElements(serviceProviders, "serviceProviders must not be null!");
            this.serviceProviders = ImmutableList.copyOf(serviceProviders);
            return this;
        }

        @Override
        public Builder<NormalBaseRate> allProducts() {
            this.product = ALL_INSTRUMENTS;
            return this;
        }

        @Override
        public Builder<NormalBaseRate> product(String product) {
            Assert.isTrue(StringUtils.isNotEmpty(product), "product must not be null or empty");
            this.product = product;
            return this;
        }

        @Override
        public MultiBuilder<NormalBaseRate> product(String... products) {
            Assert.noNullElements(products, "products must not be null!");
            this.products = ImmutableList.copyOf(products);
            return this;
        }

        @Override
        public Builder<NormalBaseRate> withAllProducts() {
            this.product = ALL_INSTRUMENTS;
            return this;
        }

        @Override
        public MultiBuilder<NormalBaseRate> withProduct(String product) {
            Assert.isTrue(StringUtils.isNotEmpty(product), "product must not be null or empty");
            this.product = product;
            return this;
        }

        @Override
        public MultiBuilder<NormalBaseRate> withProduct(String... products) {
            Assert.noNullElements(products, "products must not be null!");
            this.products = ImmutableList.copyOf(products);
            return this;
        }

        @Override
        public NormalBaseRate build() {
            NormalBaseRate normalBaseRate = new NormalBaseRate();
            normalBaseRate.rateProvider = this.rateProvider;
            normalBaseRate.ricId = this.ricId;
            normalBaseRate.exchange = Exchange.of(this.sourceCurrency, this.targetCurrency, this.askValue,
                    this.bidValue);
            normalBaseRate.frequency = this.frequency;
            normalBaseRate.live = this.live;
            normalBaseRate.instruments = RateInstruments.of(this.serviceProvider, this.product);
            normalBaseRate.enabled = true;
            normalBaseRate.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
            normalBaseRate.publishToIbr();
            return normalBaseRate;
        }

        @SuppressWarnings("unchecked")
        @Override
        public List<NormalBaseRate> buildAll() {
            if (this.identities == null) {
                List<List<String>> combinations = Lists.cartesianProduct(serviceProviders, products);
                List<NormalBaseRate> instances = new ArrayList<>(combinations.size());
                ZonedDateTime timestamp = DateTimeHelper.nowZonedDateTimeUTC();
                RatesValidationHelper.validateAskAndBidValueForNormal(this.sourceCurrency, this.targetCurrency, this.askValue,
                        this.bidValue);
                Exchange exchange = Exchange.of(this.sourceCurrency, this.targetCurrency, this.askValue, this.bidValue);
                for (List<String> combination : combinations) {
                    NormalBaseRate normalBaseRate = new NormalBaseRate();
                    normalBaseRate.rateProvider = this.rateProvider;
                    normalBaseRate.ricId = this.ricId;
                    normalBaseRate.exchange = exchange;
                    normalBaseRate.frequency = this.frequency;
                    normalBaseRate.live = this.live;
                    normalBaseRate.instruments = RateInstruments.of(combination.get(0), combination.get(1));
                    normalBaseRate.enabled = true;
                    normalBaseRate.updatedOn = timestamp;
                    normalBaseRate.publishToIbr();
                    instances.add(normalBaseRate);
                }
                return Collections.unmodifiableList(instances);
            }
            else {
                List<NormalBaseRate> instances = new ArrayList<>(this.identities.size());
                ZonedDateTime timestamp = DateTimeHelper.nowZonedDateTimeUTC();
                for (RateIdentity identity : this.identities) {
                    RatesValidationHelper.validateAskAndBidValueForNormal(identity.getSourceCurrency(),
                            identity.getTargetCurrency(), this.askValue, this.bidValue);
                    NormalBaseRate normalBaseRate = new NormalBaseRate();
                    normalBaseRate.rateProvider = this.rateProvider;
                    normalBaseRate.ricId = this.ricId;
                    normalBaseRate.exchange = Exchange.of(identity.getSourceCurrency(), identity.getTargetCurrency(),
                            this.askValue, this.bidValue);
                    normalBaseRate.frequency = this.frequency;
                    normalBaseRate.live = this.live;
                    normalBaseRate.instruments = RateInstruments.of(identity.getServiceProvider(),
                            identity.getProduct());
                    normalBaseRate.enabled = true;
                    normalBaseRate.updatedOn = timestamp;
                    normalBaseRate.publishToIbr();
                    instances.add(normalBaseRate);
                }
                return Collections.unmodifiableList(instances);
            }
        }

        @Override
        public MultiBuilder<NormalBaseRate> isLive(boolean live) {
            this.live = live;
            return this;
        }

        @Override
        public IdentityIsLiveBuilderBuilder withFrequency(Duration frequency) {
            Assert.notNull(frequency, "frequency must not be null!");
            this.frequency = frequency;
            return this;
        }

        @Override
        public IdentityFrequencyBuilder withRicId(String ricId) {
            Assert.notNull(rateProvider, "rateProvider must not be null!");
            this.ricId = ricId;
            return this;
        }

        @Override
        public IdentityRicIdBuilder withRateProvider(RateProvider rateProvider) {
            Assert.notNull(rateProvider, "rateProvider must not be null!");
            this.rateProvider = rateProvider;
            return this;
        }

        @Override
        public MultiBuilder<NormalBaseRate> withManualRateProvider(RateProvider rateProvider) {
            Assert.notNull(rateProvider, "rateProvider must not be null!");
            this.rateProvider = rateProvider;
            return this;
        }

        @Override
        public IdentityRateProviderBuilder bidValue(BigDecimal bidValue) {
            Assert.notNull(bidValue, "bidValue must not be null!");
            this.bidValue = bidValue;
            return this;
        }

        @Override
        public IdentityBidValueBuilder askValue(BigDecimal askValue) {
            Assert.notNull(askValue, "askValue must not be null!");
            this.askValue = askValue;
            return this;
        }
    }

    /*
     * @PrePersist public void onPrePersist(NormalBaseRate nb) {
     * log.debug("-------------onPrePersist NormalBaseRateEventChanged-------------------"); }
     * 
     * @PreUpdate public void onPreUpdate(NormalBaseRate nb) {
     * log.debug("-------------onPreUpdate NormalBaseRateEventChanged-------------------"); }
     * 
     * @PreRemove public void onPreRemove(NormalBaseRate nb) {
     * log.debug("-------------onPreRemove NormalBaseRateEventChanged-------------------"); }
     */
}
