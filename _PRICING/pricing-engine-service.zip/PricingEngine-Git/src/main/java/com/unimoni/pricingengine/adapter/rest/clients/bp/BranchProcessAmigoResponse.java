package com.unimoni.pricingengine.adapter.rest.clients.bp;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@SuppressWarnings("serial")
@Setter
@Getter
@AllArgsConstructor(staticName="of")
@NoArgsConstructor
public class BranchProcessAmigoResponse implements Serializable {
	private String dealId;
	private String status;
	private String message;
}
