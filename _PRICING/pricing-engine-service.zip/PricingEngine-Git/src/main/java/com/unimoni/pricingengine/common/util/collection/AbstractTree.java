package com.unimoni.pricingengine.common.util.collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Queue;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.springframework.util.Assert;

public abstract class AbstractTree<E> implements Tree<E> {

    @Override
    public Stream<Position<E>> stream() {
        return StreamSupport.stream(positions().spliterator(), false);
    }

    @Override
    public Stream<Position<E>> stream(final int level) {
        Assert.notNull(level, "level must not be null!");

        return StreamSupport.stream(positions(level).spliterator(), false);
    }

    @Override
    public Optional<Position<E>> position(final E element, final int level) {
        Assert.notNull(element, "element must not be null!");
        Assert.notNull(level, "level must not be null!");

        return stream(level).filter(p -> p.element().equals(element)).findFirst();
    }

    @Override
    public boolean isInternal(final Position<E> position) throws IllegalStateException {
        Assert.notNull(position, "position must not be null!");

        return numChildren(position) > 0;
    }

    @Override
    public boolean isLeaf(final Position<E> position) throws IllegalStateException {
        Assert.notNull(position, "position must not be null!");

        return numChildren(position) == 0;
    }

    @Override
    public boolean isRoot(final Position<E> position) throws IllegalStateException {
        Assert.notNull(position, "position must not be null!");

        return position == root();
    }

    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    public int depth(final Position<E> position) {
        Assert.notNull(position, "position must not be null!");

        if (isRoot(position)) {
            return 0;
        }

        return 1 + depth(parent(position).get());
    }

    /**
     * Returns the height of the subtree rooted at Position p.
     *
     * @param position
     * @return
     */
    public int height(final Position<E> position) {
        Assert.notNull(position, "position must not be null!");

        int height = 0;

        for (Position<E> child : children(position)) {
            height = Math.max(height, 1 + height(child));
        }

        return height;
    }

    /**
     * Adds positions of the subtree rooted at position to the given snapshot.
     * 
     * @param position
     * @param snapshot
     */
    private void preOrderSubtree(final Position<E> position, final List<Position<E>> snapshot) {
        snapshot.add(position); // for preorder, we add position before exploring subtrees

        for (Position<E> child : children(position)) {
            preOrderSubtree(child, snapshot);
        }
    }

    /**
     * Returns an iterable collection of positions of the tree, reported in
     * preorder.
     * 
     * @return
     */
    public Iterable<Position<E>> preOrder() {
        List<Position<E>> snapshot = new ArrayList<>();
        if (!isEmpty()) {
            preOrderSubtree(root(), snapshot);
        }

        return snapshot;
    }

    /**
     * Adds positions of the subtree rooted at Position p to the given snapshot.
     * 
     * @param position
     * @param snapshot
     */
    private void postOrderSubtree(final Position<E> position, final List<Position<E>> snapshot) {
        for (Position<E> child : children(position)) {
            postOrderSubtree(child, snapshot);
        }

        snapshot.add(position); // for preorder, we add position before exploring subtrees
    }

    public Iterable<Position<E>> postOrder() {
        List<Position<E>> snapshot = new ArrayList<>();
        if (!isEmpty()) {
            postOrderSubtree(root(), snapshot);
        }

        return snapshot;
    }

    /**
     * Returns an iterable collection of positions of the tree in breadth-first
     * order.
     * 
     * @return
     */
    @Override
    public Iterable<Position<E>> breathFirst() {
        List<Position<E>> snapshot = new ArrayList<>();

        if (!isEmpty()) {
            Queue<Position<E>> fringe = new LinkedList<>();
            fringe.add(root());

            while (!fringe.isEmpty()) {
                Position<E> position = fringe.remove();
                snapshot.add(position);

                for (Position<E> child : children(position)) {
                    fringe.add(child);
                }
            }
        }

        return snapshot;
    }
}
