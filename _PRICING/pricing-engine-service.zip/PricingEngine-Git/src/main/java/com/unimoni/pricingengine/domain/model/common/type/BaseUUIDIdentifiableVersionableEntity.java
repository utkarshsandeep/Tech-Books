package com.unimoni.pricingengine.domain.model.common.type;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import lombok.NoArgsConstructor;

@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@NoArgsConstructor
public class BaseUUIDIdentifiableVersionableEntity<CodeType extends Serializable & Comparable<CodeType> & CharSequence, VersionType extends Comparable<VersionType> & Serializable>
        extends AbstractUUIDIdentifiable<CodeType> implements Versionable<VersionType> {

    @Version
    @Access(AccessType.FIELD)
    @Column(name = "version", nullable = false)
    private VersionType version;

    @Override
    public VersionType version() {
        return version;
    }
}
