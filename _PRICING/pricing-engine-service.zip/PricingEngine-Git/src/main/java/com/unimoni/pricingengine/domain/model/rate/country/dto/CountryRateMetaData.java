package com.unimoni.pricingengine.domain.model.rate.country.dto;

import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public class CountryRateMetaData {

    private int nonMatchingSettlementsCount;

    private List<CountryRateIdentity> nonMatchingSettlements;

    private int duplicateCountryRatesCount;

    private List<CountryRateIdentity> duplicateCountryRates;

    private int newCountryRatesCount;

    private List<CountryRateResponse> newCountryRates;

    public static CountryRateMetaData of(final List<CountryRateIdentity> nonMatchingSettlements,
            final List<CountryRateIdentity> duplicateCountryRates, final List<CountryRateResponse> newCountryRates) {
        CountryRateMetaData settlementMetaData = new CountryRateMetaData();
        settlementMetaData.nonMatchingSettlements = nonMatchingSettlements;
        settlementMetaData.nonMatchingSettlementsCount = nonMatchingSettlements != null ? nonMatchingSettlements.size()
                : 0;
        settlementMetaData.duplicateCountryRates = duplicateCountryRates;
        settlementMetaData.duplicateCountryRatesCount = duplicateCountryRates != null ? duplicateCountryRates.size()
                : 0;
        settlementMetaData.newCountryRates = newCountryRates;
        settlementMetaData.newCountryRatesCount = newCountryRates != null ? newCountryRates.size() : 0;
        return settlementMetaData;
    }
}
