package com.unimoni.pricingengine.domain.model.enquiry.country;

public enum CountryVDWRateType {
    
    AGENT, COST_RATE;
    
    public boolean isAgent() {
        return this == AGENT;
    }

    public boolean isCostRate() {
        return this == COST_RATE;
    }
}
