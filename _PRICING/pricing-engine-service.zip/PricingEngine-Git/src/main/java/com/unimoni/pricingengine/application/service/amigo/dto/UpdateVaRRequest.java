package com.unimoni.pricingengine.application.service.amigo.dto;

import java.math.BigDecimal;
import java.util.Optional;

import com.unimoni.pricingengine.domain.model.rate.composable.Margin;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "amigoUpdateVaRRequest", description = "Update VaR Request by Amigo, Atleast one of cashAskMargin, cashBidMargin or status is mandatory")
public class UpdateVaRRequest extends VDWRateAmigoRequest {

    @ApiModelProperty(name = "cashAskMargin", dataType = "BigDecimal", value = "New CASH Ask Margin in BigDecimal with 8 decimal points precision (Optional)", required = false, example = "75.32560000", position = 9)
    private BigDecimal cashAskMargin;

    @ApiModelProperty(name = "cashBidMargin", dataType = "BigDecimal", value = "New CASH Bid Margin in BigDecimal with 8 decimal points precision (Optional)", required = false, example = "75.32560000", position = 10)
    private BigDecimal cashBidMargin;

    @ApiModelProperty(name = "status", dataType = "Boolean", value = "New Status (Optional)", required = false, example = "75.32560000", position = 11)
    private Boolean status;

    public Optional<Boolean> status() {
        return Optional.ofNullable(this.status);
    }

    public Optional<BigDecimal> cashAskMargin() {
        return Optional.ofNullable(this.cashAskMargin);
    }

    public Optional<BigDecimal> cashBidMargin() {
        return Optional.ofNullable(this.cashBidMargin);
    }

    public Optional<Margin> cashMargin() {
        return cashAskMargin().isPresent() && cashBidMargin().isPresent()
                ? Optional.of(Margin.of(this.cashAskMargin, this.cashBidMargin))
                : Optional.empty();
    }
}
