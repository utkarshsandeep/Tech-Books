package com.unimoni.pricingengine.domain.model.remittance;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.adapter.persistence.jpa.converter.LayerChargesAttributeConverter;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@ToString
@Entity
//@formatter:off
@Table(name = "REMITTANCE_TRANSACTION_CANCELLATION_RESPONSES", 
   indexes = { 
       @Index(name = "IDX_TXN_CANCEL_RESPS_TRANSACTION_UUID", columnList = "TRANSACTION_UUID")  
   }
)
//@formatter:on
public class RemittanceTransactionCancellationResponse extends AbstractRemittanceTransaction {

    @OneToOne
    // @formatter:off
    @JoinColumn(name = "TXN_CNCL_REQ_ID", 
        referencedColumnName = "ID", 
        foreignKey = @ForeignKey(name = "FK_REMIT_CANCEL_RESPONSES_REQUEST_TXN_UUID"))
    // @formatter:on
    private RemittanceTransactionCancellationRequest txnCancelRequest;

    @NotNull
    private TxnCancellationCharge charge;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RATE_DISPLAY_MECHANISM", nullable = false, updatable = false, length = 20)
    private RateDisplayMachenism rateDisplayMechanism;

    @NotNull
    private RateSkipSetting rateSkipSetting;
    
    @NotNull
    @Convert(converter = LayerChargesAttributeConverter.class)
    @Column(name = "LAYER_CHARGES", columnDefinition = "CLOB")
    private LayerCharges layerCharges;

    public static RemittanceTransactionCancellationResponse of(
            final RemittanceTransactionCancellationRequest txnCancelRequest, final TxnCancellationCharge charge,
            final RateDisplayMachenism rateDisplayMechanism, final RateSkipSetting rateSkipSetting, final LayerCharges layerCharges,
            final ZonedDateTime txnTimestamp) {
        RemittanceTransactionCancellationResponse txnCancellationResponse = new RemittanceTransactionCancellationResponse();
        txnCancellationResponse.txnCancelRequest = txnCancelRequest;
        txnCancellationResponse.transactionUUID = txnCancelRequest.transactionUUID();
        txnCancellationResponse.charge = charge;
        txnCancellationResponse.rateDisplayMechanism = rateDisplayMechanism;
        txnCancellationResponse.rateSkipSetting = rateSkipSetting;
        txnCancellationResponse.layerCharges = layerCharges;
        txnCancellationResponse.createdOn = txnTimestamp;
        return txnCancellationResponse;
    }
}
