package com.unimoni.pricingengine.adapter.persistence.repository.rate.authorizationsetting;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationQueue;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationQueue_;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationStatusType;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationQueueSearchRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.ColumnNameType;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

@Repository
public class AuthorizationQueueRepositoryImpl extends AbstractJPA implements AuthorizationQueueRepositoryJPA {

    /**
     * Find all queue data, created today, and order by status (Pending, Approved, Rejected) 
     */
    @Override
    public List<AuthorizationQueue> findAllAuthorizationQueueRecords(
            final AuthorizationQueueSearchRequest searchRequest) {
        final long totalRecords = findAuthorizationQueueCount(searchRequest);
        searchRequest.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            final CriteriaBuilder criteriaBuilder = criteriaBuilder();
            final CriteriaQuery<AuthorizationQueue> query = criteriaQuery(AuthorizationQueue.class);
            final Root<AuthorizationQueue> root = query.from(AuthorizationQueue.class);

            query.where(AuthorizationSettingPredicates.getSearchAuthorizationQueuePredicates(root, criteriaBuilder,
                    searchRequest));
            query.orderBy(criteriaBuilder.asc(root.get(AuthorizationQueue_.status)));

            query.select(root);
            final TypedQuery<AuthorizationQueue> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(searchRequest.page().queryFirstResult());
            typedQuery.setMaxResults(searchRequest.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findAuthorizationQueueCount(final AuthorizationQueueSearchRequest searchRequest) {
        final CriteriaBuilder criteriaBuilder = criteriaBuilder();
        final CriteriaQuery<Long> query = criteriaQuery(Long.class);
        final Root<AuthorizationQueue> rate = query.from(AuthorizationQueue.class);

        query.where(AuthorizationSettingPredicates.getSearchAuthorizationQueuePredicates(rate, criteriaBuilder,
                searchRequest));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    /**
     * Find queue data by status (Pending data), while running schedule batch to close all pending request.
     * 
     * */
    @Override
    public List<AuthorizationQueue> findByStatus(AuthorizationStatusType status) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();

        CriteriaQuery<AuthorizationQueue> query = criteriaQuery(AuthorizationQueue.class);
        Root<AuthorizationQueue> root = query.from(AuthorizationQueue.class);
        query.where(
                AuthorizationSettingPredicates.getAuthQueuePredictaes(criteriaBuilder, root, null, null, null, status));
        query.select(root);

        TypedQuery<AuthorizationQueue> typedQuery = typedQuery(query);
        return getUnmodifiableResultList(typedQuery);
    }

    /**
     * Method to fetch existing queue data from different layers (Volatility, settlement, ibr, Inter bank)
     * while update/create record in queue table.
     * */
    @Override
    public Optional<AuthorizationQueue> findAuthorizationQueueData(String refId, AuthorizationStatusType status,
            VDWType vdwType, ColumnNameType columnName) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();

        CriteriaQuery<AuthorizationQueue> query = criteriaQuery(AuthorizationQueue.class);
        Root<AuthorizationQueue> root = query.from(AuthorizationQueue.class);
        query.where(AuthorizationSettingPredicates.getAuthQueuePredictaes(criteriaBuilder, root, refId, vdwType,
                columnName, status));
        query.select(root);

        TypedQuery<AuthorizationQueue> typedQuery = typedQuery(query);
        return getSingleResultSafely(typedQuery);
    }
}
