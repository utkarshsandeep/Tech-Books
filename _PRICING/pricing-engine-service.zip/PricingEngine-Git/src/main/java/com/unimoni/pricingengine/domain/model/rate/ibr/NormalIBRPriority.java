package com.unimoni.pricingengine.domain.model.rate.ibr;

import static com.unimoni.pricingengine.domain.model.rate.RatePriority.isAll;
import static com.unimoni.pricingengine.domain.model.rate.RatePriority.isSpecific;

import com.unimoni.pricingengine.domain.model.rate.RatePriority;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments;

public enum NormalIBRPriority implements RatePriority {

    // @formatter:off
    // ZERO is lowest priority and THREE is highest
    /**
     * "If SP = “All” and Product = “All”"
     */
    ZERO,
    
    /**
     * "If SP = “Specific” and Product = “All”"
     */
    ONE,
    
    /**
     * "If SP = “All” and Product = “Specific”"
     */
    TWO,
    
    /**
     * "If SP = “Specific” and Product = “Specific”"
     */
    THREE;
    // @formatter:on

    public static NormalIBRPriority of(final RateInstruments rateInstruments) {
        String serviceProvider = rateInstruments.serviceProvider();
        String product = rateInstruments.product();
        
        if (isAll(serviceProvider) && isAll(product)) {
            return ZERO;
        }
        else if (isSpecific(serviceProvider) && isAll(product)) {
            return ONE;
        }
        else if (isAll(serviceProvider) && isSpecific(product)) {
            return TWO;
        }
        else {
            return THREE;
        }
    }
}
