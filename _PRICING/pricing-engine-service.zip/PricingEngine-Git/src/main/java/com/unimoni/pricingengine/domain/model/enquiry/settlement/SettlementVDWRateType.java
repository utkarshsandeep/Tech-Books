package com.unimoni.pricingengine.domain.model.enquiry.settlement;

public enum SettlementVDWRateType {
    
    SETTLEMENT, COUNTRY;
    
    public boolean isSettlement() {
        return this == SETTLEMENT;
    }

    public boolean isCountry() {
        return this == COUNTRY;
    }
}
