package com.unimoni.pricingengine.domain.model.rate.ibr;

import com.unimoni.pricingengine.domain.model.rate.composable.Exchange;
import com.unimoni.pricingengine.domain.model.remittance.IBRRate;

public interface InterBankRate {

    public String id();

    public Exchange exchange();

    public default IBRRate layerCharge() {
        throw new UnsupportedOperationException("Not Supported for Base Rate");
    }
}
