package com.unimoni.pricingengine.adapter.rest.controller.events;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.unimoni.pricingengine.domain.model.rate.BankProductOnboard;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchDataForDraweeBankResponse;

//integration :// http://bank-onboarding-service-snap.integration.apps.ocp.uaeexchange.com/api/v1/onboarding
// dev : http://bank-onboarding-service-snap.dev.apps.ocp.uaeexchange.com/onboarding/api/v1
//@FeignClient(name = "ONBOARDING-BANK-SERVICE", url = "http://bank-onboarding-service-snap.dev.apps.ocp.uaeexchange.com/onboarding/api/v1")
@FeignClient(name = "bank-onboarding-client", url = "${onboarding.base-url.bank-onboarding}")
public interface BankOnBoard {

    @RequestMapping("/draweeBanks/{draweeBankId}/draweeBankProductProfiles/{draweeBankProductProfileId}")
    public BankProductOnboard bankOnBoard(@PathVariable(value = "draweeBankId") Integer draweeBankId,
            @PathVariable(value = "draweeBankProductProfileId") Integer draweeBankProductProfileId);

    @RequestMapping("draweeBankProductProfiles/{draweeBankId}/agentDraweeBank4Rates/{draweeBankProductProfileId}")
    public BankProductOnboard agentInformationFromBankProfileIdAndRateId(
            @PathVariable(value = "draweeBankId") Integer draweeBankId,
            @PathVariable(value = "draweeBankProductProfileId") Integer draweeBankProductProfileId);
    
    @RequestMapping("draweeBankProductProfiles/{draweeBankProductProfileId}/agentDraweeBank4Rates/{agentDraweeBankForRateId}")
    public AgentBranchDataForDraweeBankResponse agentInformationFromBankProfileIdAndAgentDraweeBank4RateId(
            @PathVariable(value = "draweeBankProductProfileId") Integer draweeBankProductProfileId,
            @PathVariable(value = "agentDraweeBankForRateId") Integer agentDraweeBankForRateId);

}
