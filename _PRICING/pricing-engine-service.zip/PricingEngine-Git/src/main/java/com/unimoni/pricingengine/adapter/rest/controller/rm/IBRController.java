package com.unimoni.pricingengine.adapter.rest.controller.rm;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.BANK_WISE_IBR_UPDATED_PARTIALLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.BANK_WISE_IBR_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.NORMAL_IBR_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.BANK_WISE_IBR_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.BANK_WISE_IBR_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.BANK_WISE_IBR_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_IBR_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_IBR_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_IBR_UPDATE_STATUS_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_IBR_URI;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.money.CurrencyUnit;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.base.dto.IBRResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchBankWiseBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchNormalBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.UpdateRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.UpdateRequest;
import com.unimoni.pricingengine.domain.service.rm.RateManagementService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "IBR", description = "Inter Bank Rates (IBR Layer)", tags = "2nd Layer")
@RestController
@RequestMapping(PRICING_API)
@Slf4j
public class IBRController {

    @Autowired
    private RateManagementService rateManagementService;

    @Autowired
    private PaginatedResourceAssembler<IBRResponse, String> pageAssembler;

    private final CopyOnWriteArrayList<SseEmitter> normalIBREmitters = new CopyOnWriteArrayList<>();

    private final CopyOnWriteArrayList<SseEmitter> bankWiseIBREmitters = new CopyOnWriteArrayList<>();

    @PatchMapping(NORMAL_IBR_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-normal-ibr", 
        value = "Updates a Normal IBR record", 
        notes = "Request should only contain the updated values "
                + "for Ask Value, Bid Value or Status. "
                + "If a value is not changed the respective value should not be there in request"
    )
    // @Deprecated
    public ResponseEntity<List<IBRResponse>> updateNormalIbr(
            @RequestBody @Valid @NotNull final UpdateRequest<@NotEmpty String, @NotNull UpdateRateRequest> updateRequest) {
    // @formatter:on

        updateRequest.getUpdates().values().forEach(x -> {
            if (x.askValue().isPresent()) {
                validatePositive(x.askValue().get(), "Ask Value");
            }
            if (x.bidValue().isPresent()) {
                validatePositive(x.bidValue().get(), "Bid Value");
            }
        });

        List<IBRResponse> results = rateManagementService.updateNormalIbrRate(updateRequest);
        return ResponseEntity.ok().headers(addSuccess(getMessage(NORMAL_IBR_UPDATED_SUCCESSFULLY))).body(results);
    }

    @PutMapping(NORMAL_IBR_UPDATE_STATUS_URI)
    // @formatter:off
    @ApiOperation(nickname = "enable-disable-ibr-status", 
        value = "Updates a base rate record", 
        notes = "Enables or Disables a Normal IBR record"
    )
    @Deprecated
    public ResponseEntity<Void> updateNormlaIbrStatus(
            @PathVariable String id, @RequestParam(value = "status", required = true) final boolean status) {
    // @formatter:on
        return null;
    }

    @GetMapping(NORMAL_IBR_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-normal-ibrs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Normal IBR records matching the selection filters and sort criteria", 
        response = PaginatedResource.class, 
        notes = "")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    @Paginated
    public ResponseEntity<PaginatedResource<Resource<IBRResponse>>> getAllNormalIbrs(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page,  
            @ApiIgnore @RequestParam Map<String, Object> requestParams) {
     // @formatter:on
        List<IBRResponse> results = rateManagementService.getAllNormalIBRRates(
                SearchNormalBaseRateRequest.of(serviceProviders, products, currencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(pageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(NORMAL_IBR_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-normal-ibrs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Normal IBR records matching the selection filters and sort criteria", 
        response = Void.class, 
        notes = "")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public void downloadNormalIbrs(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
     // @formatter:on
        FileDownloadHelper.downloadFile(
                SearchNormalBaseRateRequest.ofDownload(serviceProviders, products, currencies, status),
                rateManagementService::getAllNormalIBRRates, downloadFileType, fileName, DownloadContext.NORMAL_IBR,
                response);
    }

    @PatchMapping(BANK_WISE_IBR_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-bank-wise-ibr", value = "Updates a Bank wise IBR record", notes = "Request should only contain the updated values "
            + "for Ask Value, Bid Value or Status. "
            + "If a value is not changed the respective value should not be there in request")
    public ResponseEntity<List<IBRResponse>> updateBankWiseIbr(
            @RequestBody @Valid @NotEmpty final UpdateRequest<@NotEmpty String, @NotNull UpdateRateRequest> updateRequest) {
        // @formatter:on

        updateRequest.getUpdates().values().forEach(x -> {
            if (x.askValue().isPresent()) {
                validatePositive(x.askValue().get(), "Ask Value");
            }
            if (x.bidValue().isPresent()) {
                validatePositive(x.bidValue().get(), "Bid Value");
            }
        });

        List<IBRResponse> results = rateManagementService.updateBankWiseIBRRate(updateRequest);
        String message = updateRequest.updateSize() == results.size() ? getMessage(BANK_WISE_IBR_UPDATED_SUCCESSFULLY)
                : getMessage(BANK_WISE_IBR_UPDATED_PARTIALLY);
        return ResponseEntity.ok().headers(addSuccess(message)).body(results);
    }

    @PutMapping(BANK_WISE_IBR_URI)
    // @formatter:off
    @ApiOperation(nickname = "enable-disable-bank-wsie-ibr", 
        value = "Enables or Disables a Bank wise IBR record", 
        notes = ""
    )
    // @formatter:on
    @Deprecated
    public ResponseEntity<Void> updateBankWiseIbrStatus(@PathVariable String id,
            @RequestParam(value = "status", required = true)
            final boolean status) {
        log.debug("REST request to updateBaseRateStatus() ------>>>");
        return null;
    }

    @GetMapping(BANK_WISE_IBR_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-bank-wise-ibrs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Base rate records matching the selection filters and sort criteria", 
        response = PaginatedResource.class, 
        notes = "")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    @Paginated
    public ResponseEntity<PaginatedResource<Resource<IBRResponse>>> getAllBankWiseIbrs(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents,
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Forex")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @ApiIgnore @RequestParam Map<String, Object> requestParams) {
     // @formatter:on

        List<IBRResponse> results = rateManagementService.getAllBankWiseIBRRates(
                SearchBankWiseBaseRateRequest.of(banks, agents, serviceProviders, products, currencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(pageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(BANK_WISE_IBR_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-bank-wise-ibrs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Bank wise IBR records matching the selection filters and sort criteria", 
        response = Void.class, 
        notes = "")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public void downloadBankWiseIbrs(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents,
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Forex")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
     // @formatter:on
        FileDownloadHelper.downloadFile(
                SearchBankWiseBaseRateRequest.ofDownload(banks, agents, serviceProviders, products, currencies, status),
                rateManagementService::getAllBankWiseIBRRates, downloadFileType, fileName,
                DownloadContext.BANK_WISE_IBR, response);
    }

    // --------------------- Server Sent Events Code Start --------------------------

    @GetMapping(NORMAL_IBR_SERVER_SENT_EVENTS)
    public SseEmitter sendNormalIBRSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.normalIBREmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.normalIBREmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.normalIBREmitters.remove(emitter);
        });

        return emitter;
    }

    @GetMapping(BANK_WISE_IBR_SERVER_SENT_EVENTS)
    public SseEmitter sendBankWiseIBRSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.bankWiseIBREmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.bankWiseIBREmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.bankWiseIBREmitters.remove(emitter);
        });

        return emitter;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleServerSentEvents(IBRResponse ibrResponse) {
        List<SseEmitter> normalDeadEmitters = new ArrayList<>();
        List<SseEmitter> bankDeadEmitters = new ArrayList<>();

        if (ibrResponse.getBank() != null && !ibrResponse.getBank().isEmpty()) {
            this.bankWiseIBREmitters.forEach(emitter -> {
                try {
                    emitter.send(ibrResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    bankDeadEmitters.add(emitter);
                }
            });

            this.bankWiseIBREmitters.removeAll(bankDeadEmitters);
        }
        else {
            this.normalIBREmitters.forEach(emitter -> {
                try {
                    emitter.send(ibrResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    normalDeadEmitters.add(emitter);
                }
            });

            this.normalIBREmitters.removeAll(normalDeadEmitters);
        }
    }

    // --------------------- Server Sent Events Code Ends --------------------------
}
