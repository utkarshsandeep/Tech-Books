package com.unimoni.pricingengine.domain.model.bp.dto;

import java.math.BigDecimal;

import javax.money.CurrencyUnit;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
public class BranchProcessAmigoCreateRequest {
	
	private String dealId;

    private String requestType;
    
    private String dealType;
    
    private String serviceProviderCode;
    
    private String dealStatus;
	
    private String agentCode;
    
    private String bankCode;
    
    private String rate;
	
    private String indicativeRate;
    
    private String costRate;
    
    private String gHQOfferedRate;
    
    private String cardType;
	
    private BigDecimal amount;
	
	private BigDecimal balanceAmount;

	private CurrencyUnit payInCcy;
	
	private CurrencyUnit payOutCcy;
	
	private String InstrumentType;
	
	private String transmissionDate;
	
	private String inititaionDate;
	
	private String ratePublishInfo;
	
	private String isSpecialStatus;
	
	private String status;
	
    private String sourceType;

    public static BranchProcessAmigoCreateRequest of(BranchProcessCreateRequest reqObj) {       
        return BranchProcessAmigoCreateRequest.of(reqObj.getDealId(), 
                reqObj.getRequestType().name(),
                reqObj.getDealType(),
                reqObj.getServiceProviderCode(), 
                reqObj.getDealStatus().name(), 
                reqObj.getAgentCode(), 
                reqObj.getBankCode(), 
                reqObj.getRate(), 
                reqObj.getIndicativeRate(), 
                reqObj.getCostRate(), 
                reqObj.getGHQOfferedRate(), 
                reqObj.getCardType(), 
                reqObj.getAmount(), 
                reqObj.getBalanceAmount(), 
                reqObj.getPayInCcy(), 
                reqObj.getPayOutCcy(), 
                reqObj.getInstrumentType(), 
                reqObj.getTransmissionDate(), 
                reqObj.getInititaionDate(), 
                reqObj.getRatePublishInfo(), 
                reqObj.getIsSpecialStatus(), 
                reqObj.getStatus(), 
                reqObj.getSourceType().name());
    }
}
