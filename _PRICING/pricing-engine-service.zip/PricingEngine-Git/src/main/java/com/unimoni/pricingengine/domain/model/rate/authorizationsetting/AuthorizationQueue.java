package com.unimoni.pricingengine.domain.model.rate.authorizationsetting;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;

import javax.money.CurrencyUnit;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.springframework.format.annotation.DateTimeFormat;

import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.common.type.BaseUUIDIdentifiableVersionableEntity;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.ColumnNameType;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@Table(name = "AUTHORIZATION_QUEUE", indexes = { @Index(name = "IDX_AUTHORIZATION_QUEUE_REF_ID", columnList = "REF_ID"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_RATE_TYPE", columnList = "RATE_TYPE"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_RATE_LAYER_TYPE", columnList = "RATE_LAYER_TYPE"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_BANK_CODE", columnList = "BANK_CODE"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_AGENT_CODE", columnList = "AGENT_CODE"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_CURRENCY", columnList = "CURRENCY"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_CREATED_BY", columnList = "CREATED_BY"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_UPDATED_BY", columnList = "UPDATED_BY"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_STATUS", columnList = "STATUS"),
        @Index(name = "IDX_AUTHORIZATION_QUEUE_CREATED_DATE", columnList = "CREATED_DATE") })
@Audited
public class AuthorizationQueue extends BaseUUIDIdentifiableVersionableEntity<String, Long> {

    @NotNull
    @Column(name = "REF_ID", updatable = false, nullable = false, length = 50)
    protected String refID;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RATE_TYPE", nullable = false, updatable = false, length = 20)
    private RMType rateType;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RATE_LAYER_TYPE", nullable = false, updatable = false, length = 50)
    private RateLayerType rateLayerType;

    @NotNull
    @Column(name = "SERVICE_PROVIDER_CODE", updatable = false, nullable = false, length = 100)
    protected String serviceProvider;

    @Column(name = "BANK_CODE", updatable = false, nullable = true, length = 100)
    private String bankCode;

    @NotNull
    @Column(name = "AGENT_CODE", updatable = false, nullable = false, length = 100)
    private String agentCode;

    @NotNull
    @Column(name = "CURRENCY", updatable = false, nullable = false, length = 10)
    private CurrencyUnit currency;

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "STATUS", updatable = true, nullable = false)
    private AuthorizationStatusType status;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "VDW_TYPE", nullable = true, insertable = true, updatable = false)
    protected VDWType vdwType;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "COLUMN_CHANGED", updatable = false, nullable = false, length = 100)
    private ColumnNameType columnChanged;

    @Setter
    @Column(name = "OLD_VALUE", columnDefinition = "NUMBER(*,10)")
    private BigDecimal oldValue;

    @Setter
    @Column(name = "UPDATED_VALUE", columnDefinition = "NUMBER(*,10)")
    private BigDecimal updatedValue;

    @NotNull
    @Column(name = "UPDATED_ON", columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    private ZonedDateTime updatedOn;

    @Column(name = "CREATED_BY", updatable = false, nullable = true, length = 100)
    private String createdBy;

    @Column(name = "UPDATED_BY", updatable = false, nullable = true, length = 100)
    private String updatedBy;

    @Column(name = "CREATED_DATE", updatable = false, nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate createdDate;

    public void updatedNow() {
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public void updatedOn(final ZonedDateTime zonedDateTime) {
        this.updatedOn = zonedDateTime;
    }

    public boolean updateStatus(final AuthorizationStatusType status) {
        if (this.status == status) {
            return false;
        }
        else {
            this.status = status;
            return true;
        }
    }

    /*
     * public AuthorizationSettingIdentity identity() { return AuthorizationSettingIdentity.of(this.rateType,
     * this.rateLayerType, this.serviceProvider, this.bankCode, this.agentCode, this.currency); }
     */

    /*
     * public static List<AuthorizationQueue> of(List<AuthorizationSettingIdentity> identities, ZonedDateTime zd) {
     * final List<AuthorizationQueue> instances = new ArrayList<>(identities.size());
     * 
     * for (final AuthorizationSettingIdentity identity : identities) { if(RMType.BANK_WISE == identity.getRateType() &&
     * (identity.getBankCode() == null || identity.getBankCode().isEmpty())) { throw new
     * RateException(RateExceptionExceptionType.BANK_CODE_MANDAOTRY, Status.PRECONDITION_FAILED); }
     * instances.add(AuthorizationQueue.of( identity.getRateType(), identity.getRateLayerType(),
     * identity.getServiceProvider(), identity.getBankCode(), identity.getAgentCode(), identity.getCurrency(), true,
     * zd)); //create enabled record with current timestamp }
     * 
     * return instances; }
     */

}
