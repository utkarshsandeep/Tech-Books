package com.unimoni.pricingengine.adapter.rest.controller.events;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchInfoResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentCurrencyResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardCurrencies;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentUpdateDeleteRequest;

@FeignClient(name = "agent-onboarding-client", url = "${onboarding.base-url.agent-onboarding}")

/*@FeignClient(name = "agent-onboarding-client", url = "http://agent-onboarding-service-snap.dev.apps.ocp.uaeexchange.com/onboarding/api/v1", configuration = {
        ApplicationProperties.class, FeignClientConfig.class })*/
public interface AgentOnBoard {

    @RequestMapping("/agents/agent/{agentId}")
    public AgentOnboardResponse agentOnBoard(@PathVariable(value = "agentId") Integer agentId);

    @RequestMapping("/agent/{agentId}/branches")
    public AgentBranchResponse getAgentBranch(@PathVariable(value = "agentId") Integer agentId);

    @RequestMapping("/agents/{agentId}/branches/{branchId}/allowedProductsSendRules")
    public AgentCurrencyResponse getAgentCurency(@PathVariable(value = "agentId") Integer agentId,
            @PathVariable(value = "branchId") Integer branchId);

    @RequestMapping("/agents/api/v1/agents/agent/{agentId}")
    public AgentOnboardResponse agentDeleted(@PathVariable(value = "agentId") Integer agentId);

    @RequestMapping("/agents/{agentId}/branches/{agentBranchId}/rateSettings")
    public AgentUpdateDeleteRequest getAgentRateDisplay(@PathVariable(value = "agentId") Integer agentId,
            @PathVariable(value = "agentBranchId") Integer agentBranchId);

    @RequestMapping("/agents/agentId}")
    public AgentUpdateDeleteRequest getAgentUpdateRecord(@PathVariable(value = "agentId") Integer agentId);

    @RequestMapping("/agents/{agentId}/branches/{branchId}/allowedProductsSendRules")
    public AgentCurrencyResponse getAgentBaseCurrencies(@PathVariable(value = "agentId") Integer agentId,
            @PathVariable(value = "branchId") Integer branchId);

    @RequestMapping("/agents/{agentId}/branches/{agentBranchId}/rateSettings")
    public AgentCurrencyResponse getAgentRateDisplayMechanism(@PathVariable(value = "agentId") Integer agentId,
            @PathVariable(value = "branchId") Integer branchId);
    
    @RequestMapping("agents/{agentId}/branches/{agentBranchId}/allowedProductsSendRules/{allowedProductsSendRuleId}")
    public AgentOnboardCurrencies getAgentProductSendRule(@PathVariable(value = "agentId") Integer agentId,
            @PathVariable(value = "agentBranchId") Integer branchId, @PathVariable(value = "allowedProductsSendRuleId") Integer allowedProductsSendRuleId);
    
    @RequestMapping("/agents/branches/{id}")
    public AgentBranchInfoResponse getAgentBranchInfo(@PathVariable(value = "id") Integer id);

}
