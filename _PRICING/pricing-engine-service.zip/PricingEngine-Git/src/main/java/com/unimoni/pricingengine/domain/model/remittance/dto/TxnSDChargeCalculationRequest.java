package com.unimoni.pricingengine.domain.model.remittance.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.common.enums.standard.CountryCode;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.remittance.RemittanceTransactionInitiationRequest;
import com.unimoni.pricingengine.domain.model.remittance.TxnAmount;
import com.unimoni.pricingengine.domain.model.standardcharges.types.BeneficiaryType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.CustomerType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.PaymentMode;
import com.unimoni.pricingengine.domain.model.standardcharges.types.SwiftChargeType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.TransactionType;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@ToString
public class TxnSDChargeCalculationRequest {

    private long agentBranchId;

    private String agentBranchCode;

    private long agentId;

    private String agentCode;

    private RateDisplayMachenism rateDisplayMechanism;

    private String bankCode;

    private AllInstruments instruments;

    private BeneficiaryType beneficiaryType;

    private PaymentMode paymentMode;

    private CustomerType customerType;

    private TransactionType transactionType;

    private CountryCode originatingCountry;

    private CountryCode destinationCountry;

    private LocalDate initiationDate;

    private VDWType valueDateWise;

    private CurrencyUnit payIn;

    private CurrencyUnit payOut;

    private TxnAmount amount;

    private BigDecimal rate;
    
    private SwiftChargeType swiftChargeType;

    protected TxnSDChargeCalculationRequest(final RemittanceTransactionInitiationRequest txnInitiationRequest,
            final RateDisplayMachenism rateDisplayMachenism, final VDWType valueDateWise,
            final TransactionType transactionType, final BigDecimal agentPayoutRate) {
        this.agentBranchId = txnInitiationRequest.agentBranchId();
        this.agentBranchCode = txnInitiationRequest.agentBranchCode();
        this.agentId = txnInitiationRequest.agentId();
        this.agentCode = txnInitiationRequest.agentCode();
        this.rateDisplayMechanism = rateDisplayMachenism;
        this.bankCode = txnInitiationRequest.bankCode();
        this.instruments = txnInitiationRequest.instruments();
        this.beneficiaryType = txnInitiationRequest.beneficiaryType();
        this.paymentMode = txnInitiationRequest.paymentMode();
        this.customerType = txnInitiationRequest.customerType();
        this.transactionType = transactionType;
        this.originatingCountry = txnInitiationRequest.originatingCountry();
        this.destinationCountry = txnInitiationRequest.destinationCountry();
        this.initiationDate = txnInitiationRequest.initiationDate();
        this.valueDateWise = valueDateWise;
        this.payIn = txnInitiationRequest.currencies().payIn();
        this.payOut = txnInitiationRequest.currencies().payOut();
        this.amount = txnInitiationRequest.amount();
        this.rate = agentPayoutRate;
        this.swiftChargeType = txnInitiationRequest.swiftChargeType();
    }

    public static TxnSDChargeCalculationRequest of(final RemittanceTransactionInitiationRequest txnInitiationRequest,
            final RateDisplayMachenism rateDisplayMachenism, final VDWType valueDateWise, final BigDecimal agentPayoutRate) {
        return new TxnSDChargeCalculationRequest(txnInitiationRequest, rateDisplayMachenism, valueDateWise,
                TransactionType.SEND, agentPayoutRate);
    }
}
