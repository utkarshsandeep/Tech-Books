package com.unimoni.pricingengine.common.exception;

import org.zalando.problem.Status;

import com.unimoni.pricingengine.common.enums.ErrorCodeType;

public class BranchProcessException extends PricingEngineException {

    private static final long serialVersionUID = 1L;

    private ErrorCodeType exceptionType;

    public enum BranchProcessExceptionType implements ErrorCodeType {

        //@formatter:off
        RATE_NOT_FOUND_FOR_BP_OFFER_RATE("rate.not.found.for.bp.offer.currency", BRANCH_PROCESS_EXCEPTION_TITLE),
        AMOUNT_CONSUMED_NULL("amount.counsmed.for.bp.null", BRANCH_PROCESS_EXCEPTION_TITLE),
        BALANCE_AMOUNT_LOW("balance.amount.low", BRANCH_PROCESS_EXCEPTION_TITLE),
        RATE_DISPLAY_NOT_AVAILABLE("rate.display.not.available", BRANCH_PROCESS_EXCEPTION_TITLE),
        DUPLICATE_DEAL_RECORDS("duplicate.deal.records", BRANCH_PROCESS_EXCEPTION_TITLE);
        
        //@formatter:on

        private final String errorCode;

        private final String title;

        private BranchProcessExceptionType(final String errorCode, final String title) {
            this.errorCode = errorCode;
            this.title = title;
        }

        private BranchProcessExceptionType(final String errorCode) {
            this.errorCode = errorCode;
            this.title = REMITTANCE_TRANSACTION_EXCEPTION_TITLE;
        }

        @Override
        public String errorCode() {
            return this.errorCode;
        }

        @Override
        public String title() {
            return this.title;
        }
    }

    public BranchProcessException(BranchProcessExceptionType exceptionType, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), parameters);
        setExceptionType(exceptionType);
    }

    public BranchProcessException(BranchProcessExceptionType exceptionType, Status status,
            Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), status, parameters);
        setExceptionType(exceptionType);
    }

    private void setExceptionType(BranchProcessExceptionType exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Override
    public ErrorCodeType exceptionType() {
        return this.exceptionType;
    }
}
