package com.unimoni.pricingengine.domain.model.bp;

import java.util.EnumSet;

public enum StatusType {
	REQUEST_RECEIVED,
	REQUEST_FOR_CANCELLATION,
	RESPONSE_SENT_TO_PARTNER,
	RESPONSE_SENT_TO_PARTNER_BRANCH,
	ACCEPTED,
	PARTIALLY_IMPLEMENTED,
	CANCELLATION_APPROVED,
	CANCELLATION_REJECTED,
	REJECTED,
	IMPLEMENTED,
	EXPIRED;
	
	public static final EnumSet<StatusType> req_or_accepted = EnumSet.of(REQUEST_RECEIVED, ACCEPTED);
	
	public static final EnumSet<StatusType> partiall_implemented = EnumSet.of(PARTIALLY_IMPLEMENTED);

	public static final EnumSet<StatusType> req_or_accepted_or_partially_implemented = EnumSet.of(REQUEST_RECEIVED, ACCEPTED,PARTIALLY_IMPLEMENTED);
    
	
}
