package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Currency {
    private String code;

    private String name;

    public Currency(@JsonProperty("code") String code, @JsonProperty("currencyName") String name) {
        this.code = code;
        this.name = name;
    }

    public CodeLabelPair<String, String> currencyItem() {
        return CodeLabelPair.of(this.code, this.name);
    }
}