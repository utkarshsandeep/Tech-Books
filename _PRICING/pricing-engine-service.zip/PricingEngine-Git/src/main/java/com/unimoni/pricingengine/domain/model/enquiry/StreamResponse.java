package com.unimoni.pricingengine.domain.model.enquiry;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.function.Supplier;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.ToString;

@Getter
//@ToString(onlyExplicitlyIncluded = true)
public class StreamResponse {

//    @ToString.Include
    // @JsonIgnore
    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "The index if identity within the sorted list of combinations", required = false, example = "345", position = 1)
    private Integer identityIndex;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "The maximum number of required per batch", required = false, example = "200", position = 2)
    private Integer batchSize;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "The number of remaining batches available to be fetched after current batch", required = false, example = "12", position = 3)
    private Integer remainingBatches;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Whether or not more batches available after current batch", required = false, example = "true", position = 4)
    private Boolean hasMore;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "The HATEOUS URI to fetch next available batch of records", required = false, position = 5, example = "http://localhost:8080/api/v1/prices/normalIbrRates?serviceProviders=BTSAFRA%23%23%23%23%23&products=Remittance&subProducts=Account%20Credit&startingIndex=12548&batchSize=200")
    private String more;

    protected StreamResponse() {
    }

    protected StreamResponse(final int identityIndex) {
        this.identityIndex = identityIndex;
    }

    private static final String NO_RECORDS_FOUND = "No records available";

    private static final String ALL_RECORDS_SERVED = "No more records available";

    protected StreamResponse(final int batchSize, final int recordCount, final int endIndex, final int lastIndex,
            final Supplier<String> linkSupplier) {
        this.batchSize = batchSize;
        this.hasMore = lastIndex < endIndex;
        if (this.hasMore) { // May have more records
            this.remainingBatches = (int) Math.ceil((double) (endIndex - lastIndex) / (double) batchSize);
            this.more = linkSupplier.get();
        }
        else {
            this.remainingBatches = 0;
            this.more = recordCount == 0 ? NO_RECORDS_FOUND : ALL_RECORDS_SERVED;
        }
    }
}
