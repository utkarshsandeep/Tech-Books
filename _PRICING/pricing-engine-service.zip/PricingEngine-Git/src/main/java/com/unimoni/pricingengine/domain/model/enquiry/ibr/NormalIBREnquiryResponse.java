package com.unimoni.pricingengine.domain.model.enquiry.ibr;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import javax.money.CurrencyUnit;

import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.enquiry.StreamResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateDTO;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.ToString;

@Getter
@ApiModel(value = "normalIBREnquiryResponse", description = "Normal IBR enquiry response")
@ToString
public class NormalIBREnquiryResponse extends StreamResponse {

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Service Provider such as UAE, UK etc.", required = true, example = "UAEEXNZ#####", position = 1)
    private String serviceProvider;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Product such as Remittance, Forex etc.", required = true, example = "Remittance", position = 2)
    private String product;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Currency Code in ISO format e.g. INR", required = true, example = "INR", position = 3)
    private CurrencyUnit currency;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Normal IBR Ask and Bid values", required = true, position = 4)
    private RateDTO rate;

    public NormalIBREnquiryResponse(final int identityIndex, final String serviceProvider, final String product,
            final CurrencyUnit currency, final ExchangeRate exchangeRate) {
        super(identityIndex);
        this.serviceProvider = serviceProvider;
        this.product = product;
        this.currency = currency;
        this.rate = RateDTO.of(exchangeRate);
    }

    private NormalIBREnquiryResponse(final int batchSize, final int recordCount, final int endIndex,
            final int lastIndex, final Supplier<String> linkSupplier) {
        super(batchSize, recordCount, endIndex, lastIndex, linkSupplier);
    }

    public static NormalIBREnquiryResponse end(final NormalIBREnquiryRequest enquiryRequest, final int recordCount,
            final int lastIndex, final String URI) {
        return new NormalIBREnquiryResponse(enquiryRequest.batchSize(), recordCount, enquiryRequest.endIndex(),
                lastIndex, () -> moreLink(enquiryRequest, lastIndex, URI));
    }

    public static String moreLink(final NormalIBREnquiryRequest enquiryRequest, final int lastIndex, final String URI) {
        final Map<String, Object> paramsMap = new LinkedHashMap<>(5);
        paramsMap.put("serviceProviders", enquiryRequest.serviceProviders().toArray());
        paramsMap.put("products", enquiryRequest.products().toArray());
        paramsMap.put("currencies", enquiryRequest.currencies().stream().map(CurrencyUnit::getCurrencyCode).toArray());
        paramsMap.put("startingIndex", lastIndex);
        paramsMap.put("batchSize", enquiryRequest.batchSize());

        String queryParameters = paramsMap.entrySet().stream().map((x) -> x.getKey() + "={" + x.getKey() + "}")
                .collect(Collectors.joining("&"));
        String uri = URI + "?" + queryParameters;
        return UriComponentsBuilder.fromUriString(uri).build().expand(paramsMap).encode().toUriString();
    }
}
