package com.unimoni.pricingengine.domain.model.rate.composable;

import java.math.BigDecimal;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.rate.RateValue;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
@Access(AccessType.FIELD)
public class Cost implements RateValue {

    @NotNull
    @Column(name = "SELL_VALUE", columnDefinition = "NUMBER(*,10)")
    private BigDecimal sellValue;

    @NotNull
    @Column(name = "BUY_VALUE", columnDefinition = "NUMBER(*,10)")
    private BigDecimal buyValue;

    public static Cost of(final BigDecimal sellValue, final BigDecimal buyValue) {
        Cost countryCost = new Cost();
        countryCost.sellValue = RateValue.preciseTo8Decimals(sellValue);
        countryCost.buyValue = RateValue.preciseTo8Decimals(buyValue);
        return countryCost;
    }

    public static final Cost ZERO = Cost.of(RateValue.ZERO, RateValue.ZERO);

    public static final Cost ONE = Cost.of(RateValue.ONE, RateValue.ONE);
}
