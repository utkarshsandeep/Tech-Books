package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AgentBranchResponse {
	private List<AgentBranchDataResponse> data ;
	
	public AgentBranchResponse(@JsonProperty List<AgentBranchDataResponse> data) {
		this.data = data;
		
	}
}
