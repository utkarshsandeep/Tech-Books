package com.unimoni.pricingengine.domain.model.common.type;

import java.io.Serializable;

public interface UUIDIdentifiable<IdType extends Serializable & Comparable<IdType>> {

    public IdType id();

}
