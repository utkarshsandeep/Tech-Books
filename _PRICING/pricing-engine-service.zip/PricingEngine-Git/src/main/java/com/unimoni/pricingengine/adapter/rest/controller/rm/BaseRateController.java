package com.unimoni.pricingengine.adapter.rest.controller.rm;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addError;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.BANK_WISE_RATE_CREATED_PARTIALLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.BANK_WISE_RATE_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.BANK_WISE_RATE_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.NORMAL_RATE_CREATED_PARTIALLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.NORMAL_RATE_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.NORMAL_RATE_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.BANK_WISE_BASE_RATE_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.BANK_WISE_BASE_RATE_UPDATE_STATUS_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.BANK_WISE_BASE_RATE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.BANK_WISE_RATE_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_BASE_RATE_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_BASE_RATE_IDENTITY_WISE;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_BASE_RATE_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_BASE_RATE_UPDATE_STATUS_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.RateManagement.NORMAL_BASE_RATE_URI;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.money.CurrencyUnit;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.base.NormalBaseRate;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseRateResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.NormalRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.NormalRateResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateDTO;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateIdentity;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchBankWiseBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchNormalBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.UpdateBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.UpdateRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.UpdateRequest;
import com.unimoni.pricingengine.domain.service.rm.RateManagementService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import springfox.documentation.annotations.ApiIgnore;

@Slf4j
@Api(value = "RMUI", description = "IBR Management (RMUI Layer)", tags = "1st Layer")
@RestController
@RequestMapping(PRICING_API)
public class BaseRateController {

    @Autowired
    private RateManagementService rateManagementService;

    @Autowired
    private PaginatedResourceAssembler<NormalRateResponse, String> normalPageAssembler;

    @Autowired
    private PaginatedResourceAssembler<BankWiseRateResponse, String> banWisePageAssembler;

    private final CopyOnWriteArrayList<SseEmitter> normalBaseRateEmitters = new CopyOnWriteArrayList<>();

    private final CopyOnWriteArrayList<SseEmitter> bankWiseBaseRateemitters = new CopyOnWriteArrayList<>();

    @PostMapping(NORMAL_BASE_RATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "create-normal-base-rate", 
        value = "Creates a new Normal Base Rate resource", 
        notes = ""
    )
    public ResponseEntity<List<NormalRateResponse>> createNormalBaseRate(
            @RequestBody @Valid @NotNull final NormalRateRequest rateRequest) {
    // @formatter:on 

        validatePositive(rateRequest.getExchange().getRate().getAskValue(), "Ask Value");
        validatePositive(rateRequest.getExchange().getRate().getBidValue(), "Bid Value");

        if ((rateRequest.getRateProvider() == ApplicationConstants.THOMSON_RATE_PROVIDER_ID
                || rateRequest.getRateProvider() == ApplicationConstants.FUTURE_SOURCE_RATE_PROVIDER_ID)) {
            if (rateRequest.getFrequency() == null) {
                throw new RateException(RateExceptionExceptionType.FREQUENCY_REQUIRED_FOR_NON_MANUAL_RATE_PROVIDERS,
                        Status.BAD_REQUEST,
                        rateRequest.getRateProvider() == ApplicationConstants.THOMSON_RATE_PROVIDER_ID
                                ? "Thomson Reuters"
                                : "Future Source");
            }
            else if (rateRequest.getFrequency().duration().compareTo(Duration.ofMillis(250)) < 0) {
                throw new RateException(
                        RateExceptionExceptionType.FREQUENCY_OUTSIDE_RANGE_FOR_NON_MANUAL_RATE_PROVIDERS,
                        Status.BAD_REQUEST);
            }

            if (StringUtils.isEmpty(rateRequest.getRicId())) {
                throw new RateException(RateExceptionExceptionType.RIC_ID_REQUIRED_FOR_NON_MANUAL_RATE_PROVIDERS,
                        Status.BAD_REQUEST,
                        rateRequest.getRateProvider() == ApplicationConstants.THOMSON_RATE_PROVIDER_ID
                                ? "Thomson Reuters"
                                : "Future Source");
            }
        }
        List<NormalRateResponse> results = rateManagementService.createNormalBaseRate(rateRequest);
        String message = rateRequest.identityCount() == results.size()
                ? getMessage(NORMAL_RATE_CREATED_SUCCESSFULLY, results.size())
                : getMessage(NORMAL_RATE_CREATED_PARTIALLY, results.size(),
                        (rateRequest.identityCount() - results.size()));
        return ResponseEntity.created(null).headers(addSuccess(message)).body(results);
    }

    @PatchMapping(NORMAL_BASE_RATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-normal-base-rate", 
        value = "Updates a Normal Base rate record", 
        notes = "Request should only contain the updated values "
                + "for Ask Value, Bid Value, Update Frequency or Status. "
                + "If a value is not changed the respective value should not be there in request"
    )
    @Valid
    public ResponseEntity<List<NormalRateResponse>> updateNormalBaseRate(
            @RequestBody @Valid final UpdateRequest<@NotEmpty String, @NotNull UpdateBaseRateRequest> updateRequest) {
    // @formatter:on

        updateRequest.getUpdates().values().forEach(x -> {
            if (x.askValue().isPresent()) {
                validatePositive(x.askValue().get(), "Ask Value");
            }
            if (x.bidValue().isPresent()) {
                validatePositive(x.bidValue().get(), "Bid Value");
            }
        });

        List<NormalRateResponse> results = rateManagementService.updateNormalBaseRate(updateRequest);
        return ResponseEntity.ok().headers(addSuccess(getMessage(NORMAL_RATE_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }

    @PutMapping(NORMAL_BASE_RATE_UPDATE_STATUS_URI)
    // @formatter:off
    @ApiOperation(nickname = "enable-disable-normal-base-rate", 
        value = "Enables or Disables a Normal Base rate record", 
        notes = ""
    )
    @Deprecated
    public ResponseEntity<Void> updateNormalBaseRateStatus(
            @PathVariable String id,
            @RequestParam(value = "status", required = true) final boolean status) {
    // @formatter:on
        return null;
    }

    @GetMapping(NORMAL_BASE_RATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-normal-base-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Normal Base rate records matching the selection filters and sort criteria", 
        response = PaginatedResource.class, 
        notes = "")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    @Paginated
    public ResponseEntity<PaginatedResource<Resource<NormalRateResponse>>> getAllNormalBaseRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @ApiIgnore @RequestParam Map<String, Object> requestParams) {
    // @formatter:on
        // try {
        // log.info("???????????? IdentityHelper.getLoginName() ---> {}", IdentityHelper.getLoginName());
        // }
        // catch (Exception e) {
        // e.printStackTrace();
        // }
        List<NormalRateResponse> results = rateManagementService.getAllNormalBaseRates(
                SearchNormalBaseRateRequest.of(serviceProviders, products, currencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(normalPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(NORMAL_BASE_RATE_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-normal-base-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Normal Base rate records matching the selection filters and sort criteria", 
        response = Void.class, 
        notes = "")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public void downloadNormalBaseRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status,
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on
        FileDownloadHelper.downloadFile(
                SearchNormalBaseRateRequest.ofDownload(serviceProviders, products, currencies, status),
                rateManagementService::getAllNormalBaseRates, downloadFileType, fileName,
                DownloadContext.NORMAL_BASE_RATE, response);
    }

    // --------------------- Bank Wise APIs --------------------------

    @PostMapping(BANK_WISE_BASE_RATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "create-bank-wise-base-rate", 
        value = "Creates a new Bank Wise Base Rate resource", 
        notes = ""
    )
    public ResponseEntity<List<BankWiseRateResponse>> createBankWiseBaseRate(
            @RequestBody @Valid final BankWiseRateRequest rateRequest) {
    // @formatter:on

        validatePositive(rateRequest.getExchange().getRate().getAskValue(), "Ask Value");
        validatePositive(rateRequest.getExchange().getRate().getBidValue(), "Bid Value");

        List<BankWiseRateResponse> results = rateManagementService.createBankWiseBaseRate(rateRequest);
        String message = rateRequest.identityCount() == results.size()
                ? getMessage(BANK_WISE_RATE_CREATED_SUCCESSFULLY, results.size())
                : getMessage(BANK_WISE_RATE_CREATED_PARTIALLY, results.size(),
                        (rateRequest.identityCount() - results.size()));
        return ResponseEntity.created(null).headers(addSuccess(message)).body(results);
    }

    @PatchMapping(BANK_WISE_BASE_RATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-bank-wise-base-rate", 
        value = "Updates a Bank wise Base rate record", 
        notes = "Request should only contain the updated values "
                + "for Ask Value, Bid Value or Status. "
                + "If a value is not changed the respective value should not be there in request"
    )
    public ResponseEntity<List<BankWiseRateResponse>> updateBankWiseBaseRate(
            @RequestBody @Valid @NotEmpty final UpdateRequest<@NotEmpty String, @NotNull UpdateRateRequest> updateRequest) {
    // @formatter:on

        updateRequest.getUpdates().values().forEach(x -> {
            if (x.askValue().isPresent()) {
                validatePositive(x.askValue().get(), "Ask Value");
            }
            if (x.bidValue().isPresent()) {
                validatePositive(x.bidValue().get(), "Bid Value");
            }
        });

        List<BankWiseRateResponse> results = rateManagementService.updateBankWiseBaseRate(updateRequest);
        return ResponseEntity.ok().headers(addSuccess(getMessage(BANK_WISE_RATE_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }

    @PutMapping(BANK_WISE_BASE_RATE_UPDATE_STATUS_URI)
    // @formatter:off
    @ApiOperation(nickname = "enable-disable-bank-wise-base-rate", 
        value = "Enables or Disables a Normal Base rate record", 
        notes = ""
    )
    @Deprecated
    public ResponseEntity<Void> updateBankWiseBaseRateStatus(
            @PathVariable String id,
            @RequestParam(value = "status", required = true) final boolean status) {
    // @formatter:on
        return null;
    }

    @GetMapping(BANK_WISE_BASE_RATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-bank-wise-base-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Bank wise Base rate records matching the selection filters and sort criteria", 
        response = PaginatedResource.class, 
        notes = "")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    @Paginated
    public ResponseEntity<PaginatedResource<Resource<BankWiseRateResponse>>> getAllBankWiseBaseRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks,
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents,
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @ApiIgnore @RequestParam Map<String, Object> requestParams/*,
            final Principal principle,
            final @ApiIgnore @AuthenticationPrincipal KeycloakAuthenticationToken authenticationToken*/) {
    // @formatter:on

        // log.info("???????????? principle ---> {}", principle);
        // log.info("???????????? authenticationToken ---> {}", authenticationToken);

        List<BankWiseRateResponse> results = rateManagementService.getAllBankWiseBaseRates(
                SearchBankWiseBaseRateRequest.of(banks, agents, serviceProviders, products, currencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(banWisePageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(BANK_WISE_RATE_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-bank-wise-base-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Bank wise Base rate records matching the selection filters and sort criteria", 
        response = Void.class, 
        notes = "")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public void downloadBankWiseBaseRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks,
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents,
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on
        FileDownloadHelper.downloadFile(
                SearchBankWiseBaseRateRequest.ofDownload(banks, agents, serviceProviders, products, currencies, status),
                rateManagementService::getAllBankWiseBaseRates, downloadFileType, fileName,
                DownloadContext.BANK_WISE_BASE_RATE, response);
    }

    @GetMapping(NORMAL_BASE_RATE_IDENTITY_WISE)
    // @formatter:off
    @ApiOperation(nickname = "get-normal-base-rate-by-rate-identity", 
        value = "Get the updated rate from normal base rate using rate identity",
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = RateDTO.class,
        notes = "Request parameter must contain serviceProvider, product, sourceCurrency and targetCurrency."
    )
    @Valid
    public ResponseEntity<RateDTO> getActiveNormalBaseRateByRateIdentity(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final @NotEmpty String serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final @NotEmpty String products, 
            @ApiParam(allowMultiple = true, type = "String", value = "ISO Currency Code e.g. INR, USD etc.", example = "INR")
            @RequestParam(value = "sourceCurrency", required = false) final @NotNull CurrencyUnit sourceCurrency,
            @ApiParam(allowMultiple = true, type = "String", value = "ISO Currency Code e.g. INR, USD etc.", example = "USD")
            @RequestParam(value = "targetCurrency", required = false) final @NotNull CurrencyUnit targetCurrency) {
    // @formatter:on

        Optional<NormalBaseRate> normalBaseRate = this.rateManagementService.getActiveNormalBaseRateByIdentity(
                RateIdentity.of(sourceCurrency, targetCurrency, serviceProviders, products));
        if (!normalBaseRate.isPresent()) {
            return ResponseEntity.notFound().headers(addError(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(RateDTO.of(normalBaseRate.get().exchange().rate()));
        }
    }

    // --------------------- Server Sent Events Code Start --------------------------

    @GetMapping(NORMAL_BASE_RATE_SERVER_SENT_EVENTS)
    public SseEmitter sendNormalBaseRateSSEvents(HttpServletResponse response) {
        log.info(">>>>>>>>> NormalBaseRate SSE Event BaseRateController >>>>>>>>>");

        response.setHeader("Cache-Control", "no-store");
        response.setHeader("Content-Type", "text/event-stream;charset=UTF-8");

        SseEmitter emitter = new SseEmitter();
        this.normalBaseRateEmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.normalBaseRateEmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.normalBaseRateEmitters.remove(emitter);
        });

        return emitter;
    }

    @GetMapping(BANK_WISE_BASE_RATE_SERVER_SENT_EVENTS)
    public SseEmitter sendBankWiseBaseRateSSEvents(HttpServletResponse response) {
        log.info(">>>>>>>>> BankwiseBaseRate SSE Event BaseRateController >>>>>>>>>");

        response.setHeader("Cache-Control", "no-store");
        response.setHeader("Content-Type", "text/event-stream;charset=UTF-8");

        SseEmitter emitter = new SseEmitter();
        this.bankWiseBaseRateemitters.add(emitter);

        emitter.onCompletion(() -> {
            this.bankWiseBaseRateemitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.bankWiseBaseRateemitters.remove(emitter);
        });

        return emitter;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleNormalRateServerSentEvents(NormalRateResponse normalRateResponse) {
        List<SseEmitter> deadEmitters = new ArrayList<>();

        this.normalBaseRateEmitters.forEach(emitter -> {
            try {
                emitter.send(normalRateResponse);
            }
            catch (Exception e) {
                e.printStackTrace();
                deadEmitters.add(emitter);
            }
        });

        this.normalBaseRateEmitters.removeAll(deadEmitters);
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleBankWiseRateServerSentEvents(BankWiseRateResponse bankWiseRateResponse) {
        List<SseEmitter> deadEmitters = new ArrayList<>();

        this.bankWiseBaseRateemitters.forEach(emitter -> {
            try {
                emitter.send(bankWiseRateResponse);
            }
            catch (Exception e) {
                e.printStackTrace();
                deadEmitters.add(emitter);
            }
        });

        this.bankWiseBaseRateemitters.removeAll(deadEmitters);
    }

    // --------------------- Server Sent Events Code Ends --------------------------

}
