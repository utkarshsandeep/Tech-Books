package com.unimoni.pricingengine.common.exception;

import org.zalando.problem.Status;

import com.unimoni.pricingengine.common.enums.ErrorCodeType;

public class MasterDataValidationException extends PricingEngineException {

    private static final long serialVersionUID = 1L;

    private ErrorCodeType exceptionType;

    public enum MasterDataValidationExceptionType implements ErrorCodeType {

        //@formatter:off
        INVALID_SERVICE_PROVIDERS("invalid.serviceProviders", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        INVALID_PRODUCTS("invalid.products", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        INVALID_SUB_PRODUCTS("invalid.subProducts", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        INVALID_SERVICE_TYPES("invalid.serviceTypes", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        INVALID_AGENTS("invalid.agents", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        INVALID_AGENTS_OR_BRANCHES("invalid.agents.or.branches", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        INVALID_BANKS("invalid.banks", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        INVALID_CURRENCIES("invalid.currencies", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        SPECIFIC_CURRENCIES_REQUIRED("specific.currencies.required", MASTER_DATA_VALIDATION_EXCEPTION_TITLE),
        INVALID_VALUE_DATE_WISES("invalid.valueDateWises", MASTER_DATA_VALIDATION_EXCEPTION_TITLE);
        //@formatter:on

        private final String errorCode;

        private final String title;

        private MasterDataValidationExceptionType(final String errorCode, final String title) {
            this.errorCode = errorCode;
            this.title = title;
        }

        private MasterDataValidationExceptionType(final String errorCode) {
            this.errorCode = errorCode;
            this.title = MASTER_DATA_VALIDATION_EXCEPTION_TITLE;
        }

        @Override
        public String errorCode() {
            return this.errorCode;
        }

        @Override
        public String title() {
            return this.title;
        }
    }

    public MasterDataValidationException(MasterDataValidationExceptionType exceptionType, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), Status.BAD_REQUEST, parameters);
        setExceptionType(exceptionType);
    }

    public MasterDataValidationException(MasterDataValidationExceptionType exceptionType, Status status,
            Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), status, parameters);
        setExceptionType(exceptionType);
    }

    private void setExceptionType(MasterDataValidationExceptionType exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Override
    public ErrorCodeType exceptionType() {
        return this.exceptionType;
    }
}
