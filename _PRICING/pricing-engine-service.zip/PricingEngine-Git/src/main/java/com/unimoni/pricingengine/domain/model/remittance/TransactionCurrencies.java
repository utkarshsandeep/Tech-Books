package com.unimoni.pricingengine.domain.model.remittance;

import javax.money.CurrencyUnit;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@Embeddable
public class TransactionCurrencies {

    @NotNull
    @Column(name = "PAYIN_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit payIn;

    @NotNull
    @Column(name = "PAYOUT_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit payOut;

    @NotNull
    @Column(name = "SETTLEMENT_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit settlement;

    @NotNull
    @Column(name = "SERVICE_PROVIDER_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit serviceProvider;

    @NotNull
    @Column(name = "PASS_SETTLEMENT_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit passSettlement;
    
    public CurrencyUnit getByType(final TxnCurrencyType currencyType) {
        switch (currencyType) {
        case PAY_IN:
            return this.payIn;
        case PAY_OUT:
            return this.payOut;
        case SETTLEMENT:
            return this.settlement;
        case SERVICE_PROVIDER:
            return this.serviceProvider;
        case PASS_SETTLEMENT:
            return this.passSettlement;

        default:
            throw new IllegalArgumentException("Invalid currencyType: " + currencyType);
        }
    }

    public static enum TxnCurrencyType {
        
        // @formatter:off
        PAY_IN("Pay In Currency"), 
        PAY_OUT("Pay Out Currency"), 
        SETTLEMENT("Settlement Currency"), 
        SERVICE_PROVIDER("Service Provider Currency"), 
        PASS_SETTLEMENT("Pass Settlement Currency");
        // @formatter:on

        private final String description;

        private TxnCurrencyType(final String description) {
            this.description = description;
        }

        public String description() {
            return this.description;
        }
    }
}
