package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import java.util.List;

import javax.money.CurrencyUnit;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
public class AuthorizationQueueUpdateRequest {
    @NotNull
    protected String refId;
    
    @NotNull
    protected RMType rateType;
    
    @NotNull
    protected RateLayerType rateLayerType;
    
    @NotNull
    protected String serviceProvider;
    
    protected String bankCode;
    
    @NotNull
    protected String agentCode;
    
    @NotNull
    protected CurrencyUnit currency;    
    
    @NotNull
    protected List<ColumnValueEdited> updatedValues;
    
}
