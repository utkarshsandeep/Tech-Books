package com.unimoni.pricingengine.adapter.persistence.repository.rm;

import javax.money.CurrencyUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer_;

public abstract class IBRSelectExpressions {

    static Expression<CurrencyUnit> currencySelectExpression(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder) {

        return criteriaBuilder.<CurrencyUnit> selectCase()
                .when(criteriaBuilder.equal(root.get(AbstractLayer_.exchange.getName()).get("currency").get("source"),
                        ApplicationConstants.CURRENCY_UNIT_USD),
                        root.get(AbstractLayer_.exchange.getName()).get("currency").get("target"))
                .otherwise(root.get(AbstractLayer_.exchange.getName()).get("currency").get("source"));
    }
}
