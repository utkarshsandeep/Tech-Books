package com.unimoni.pricingengine.common.exception;

import org.zalando.problem.Status;

import com.unimoni.pricingengine.common.enums.ErrorCodeType;

public class StandardChargeException extends PricingEngineException {

    private static final long serialVersionUID = 1L;

    private ErrorCodeType exceptionType;

    public enum StandardChargeExceptionType implements ErrorCodeType {

        //@formatter:off
        ILLEGAL_CODE_TYPE_REQUEST_PARAMETER("illegal.code.type.request.parameter", STANDARD_CHARGE_EXCEPTION_TITLE),
        INVALID_IDS("invalid.ids", STANDARD_CHARGE_EXCEPTION_TITLE),
        INVALID_AMOUNT_RANGE_IDS("invalid.amountrange.ids", STANDARD_CHARGE_EXCEPTION_TITLE),		
		DOWNlOAD_FAILURE("download.failure", DOWNLOAD_EXCEPTION_TITLE),
		DUPLICATE_RECORDS("duplicate.standardcharge", STANDARD_CHARGE_EXCEPTION_TITLE),
	    DUPLICATE_AMOUNT_RANGE("duplicate.amountRange", STANDARD_CHARGE_EXCEPTION_TITLE),
	    DUPLICATE_AMOUNT_RANGE_DATE("duplicate.amountRangeDate", STANDARD_CHARGE_EXCEPTION_TITLE),
	    DATERANGE_MISSING("missing.amountRangeDate", STANDARD_CHARGE_EXCEPTION_TITLE),
	    CHARGE_BASIS_CONFLICT("chargebasis.conflict", STANDARD_CHARGE_EXCEPTION_TITLE),
	    NO_DATA_TO_SAVE("standardcharge.nodataToSave", STANDARD_CHARGE_EXCEPTION_TITLE),
	    NOT_MATHCED_AMOUNT_RANGE("standardcharge.amountrange", STANDARD_CHARGE_EXCEPTION_TITLE),
        WRONG_BRANCH_ID("standardcharge.wrong.id", STANDARD_CHARGE_EXCEPTION_TITLE), 
        AMOUNT_RANGE_MISSING("missing.amountrange", STANDARD_CHARGE_EXCEPTION_TITLE),
        COMMISSION_MISSING("commission.missing", STANDARD_CHARGE_EXCEPTION_TITLE),
        UPLOAD_WRONG_AMOUNT_RANGE("upload.wrong.amount.range", STANDARD_CHARGE_EXCEPTION_TITLE),
        UPLOAD_NO_DATA("upload.no.data", STANDARD_CHARGE_EXCEPTION_TITLE),
        UPLOAD_WRONG_DATA("upload.wrong.data", STANDARD_CHARGE_EXCEPTION_TITLE),
        WRONG_FILE("wrong.file", STANDARD_CHARGE_EXCEPTION_TITLE),
        FILE_EMPTY("wrong.file.empty", STANDARD_CHARGE_EXCEPTION_TITLE),
        AMOUNT_RANGE_CONFLICT("conflict.amount.range", STANDARD_CHARGE_EXCEPTION_TITLE),
        AMOUNT_DATE_RANGE_CONFLICT("conflict.amount.date.range", STANDARD_CHARGE_EXCEPTION_TITLE),
        AMOUNT_RANGE_WRONG("amount.range.wrong", STANDARD_CHARGE_EXCEPTION_TITLE),
        SC_UNIQUE("standard.charge.unique", STANDARD_CHARGE_EXCEPTION_TITLE),
        DB_ERROR("db.error", STANDARD_CHARGE_EXCEPTION_TITLE),
        AGENT_RATE_ZERO("agent.rate.zero", STANDARD_CHARGE_EXCEPTION_TITLE),
        SWIFT_TYPE_CHARGE_BASIS_CONFLICT("swifttype.chargebasis.conflict", STANDARD_CHARGE_EXCEPTION_TITLE),
        MISSING_DATA_IN_ONBOARDING("missing.in.onboarding", STANDARD_CHARGE_EXCEPTION_TITLE),
        SWIFT_NEGATIVE_VALUE("swift.negative.value", STANDARD_CHARGE_EXCEPTION_TITLE),
        DATE_RANGE_WRONG("date.range.wrong", STANDARD_CHARGE_EXCEPTION_TITLE);
		//@formatter:on

        private final String errorCode;

        private final String title;

        private StandardChargeExceptionType(final String errorCode, final String title) {
            this.errorCode = errorCode;
            this.title = title;
        }

        private StandardChargeExceptionType(final String errorCode) {
            this.errorCode = errorCode;
            this.title = STANDARD_CHARGE_EXCEPTION_TITLE;
        }

        @Override
        public String errorCode() {
            return this.errorCode;
        }

        @Override
        public String title() {
            return this.title;
        }
    }

    public StandardChargeException(StandardChargeExceptionType exceptionType, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), parameters);
        setExceptionType(exceptionType);
    }

    public StandardChargeException(StandardChargeExceptionType exceptionType, Status status, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), status, parameters);
        setExceptionType(exceptionType);
    }

    private void setExceptionType(StandardChargeExceptionType exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Override
    public ErrorCodeType exceptionType() {
        return this.exceptionType;
    }
}
