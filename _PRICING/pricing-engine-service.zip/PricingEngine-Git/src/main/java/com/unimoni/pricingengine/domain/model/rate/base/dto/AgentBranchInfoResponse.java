package com.unimoni.pricingengine.domain.model.rate.base.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties
@ToString
public class AgentBranchInfoResponse {
	public String branchDisplayName;
	public String branchName;
	public String agentDisplayName;
	public String agentName;
	public String address1;
	public String address2;
	public String poBox;
	public String phone;
	public String mobile;
	public String contactPerson;
	public String city;
	public String country;
	public String state;
	public Integer id;
	public String zip;
	public String fax;
	public String email;
	public String createdDate;
	public String modifiedDate;
	public String status;
	public Integer agentId;
	public String countryCode;
	public String agentCode;
	public String isdCode;
	public Boolean deleted;
	public AgentBranchInfoResponse(@JsonProperty String branchDisplayName,@JsonProperty String branchName,@JsonProperty String agentDisplayName,
			@JsonProperty String agentName,@JsonProperty String address1,@JsonProperty String address2,@JsonProperty String poBox,@JsonProperty String phone,@JsonProperty String mobile,
			@JsonProperty String contactPerson, @JsonProperty String city,@JsonProperty String country,@JsonProperty String state,@JsonProperty Integer id,@JsonProperty String zip,@JsonProperty String fax,
			@JsonProperty String email,@JsonProperty String createdDate,@JsonProperty String modifiedDate,@JsonProperty String status,@JsonProperty Integer agentId,@JsonProperty String countryCode,
			@JsonProperty String agentCode,@JsonProperty String isdCode,@JsonProperty Boolean deleted) {
		super();
		this.branchDisplayName = branchDisplayName;
		this.branchName = branchName;
		this.agentDisplayName = agentDisplayName;
		this.agentName = agentName;
		this.address1 = address1;
		this.address2 = address2;
		this.poBox = poBox;
		this.phone = phone;
		this.mobile = mobile;
		this.contactPerson = contactPerson;
		this.city = city;
		this.country = country;
		this.state = state;
		this.id = id;
		this.zip = zip;
		this.fax = fax;
		this.email = email;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.status = status;
		this.agentId = agentId;
		this.countryCode = countryCode;
		this.agentCode = agentCode;
		this.isdCode = isdCode;
		this.deleted = deleted;
	}
	
	

}
