package com.unimoni.pricingengine.common.util.download;

import java.security.InvalidParameterException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.joda.beans.Bean;
import org.joda.beans.MetaProperty;

import com.unimoni.pricingengine.common.enums.Describable;
import com.unimoni.pricingengine.common.util.Counter;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;
import com.unimoni.pricingengine.common.util.download.jodaBeans.BeanProperty;
import com.unimoni.pricingengine.common.util.download.jodaBeans.Beans;
import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverride;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverrides;

public class DownloadMetaData {

    private final Map<Integer, BeanProperty> metaData;

    private final Map<String, BeanProperty> overrideMetaData;

    private final String[] header;

    private final DownloadContext downloadContext;

    private final int columnCount;

    private final Beans beans;

    public static DownloadMetaData of(final Bean rootBean, final DownloadContext downloadContext) {
        return new DownloadMetaData(rootBean, downloadContext);
    }

    private DownloadMetaData(final Bean rootBean, final DownloadContext downloadContext) {
        this.downloadContext = downloadContext;
        this.metaData = new LinkedHashMap<>();
        this.overrideMetaData = new LinkedHashMap<>();
        this.beans = Beans.of(rootBean);

        prepareBeanMetaData(rootBean, Counter.initialize("bean-counter"), Optional.empty(), new StringBuilder(200));

        Set<String> validPropPathSet = this.metaData.values().stream().map(BeanProperty::qualifiedName)
                .collect(Collectors.toSet());
        this.overrideMetaData.keySet().forEach(propPath -> {
            if (!validPropPathSet.contains(propPath)) {
                throw new IllegalArgumentException(
                        "Illegal field name: " + propPath + "in @DownloadOverrides or @DownloadOverride");
            }
        });

        List<String> headerValues = this.metaData.values().stream().filter(BeanProperty::isDownloadable)
                .map(BeanProperty::columnName).collect(ImmutableCollectors.toImmutableList());

        this.columnCount = headerValues.size();
        this.header = headerValues.toArray(new String[this.columnCount]);
    }

    private void prepareBeanMetaData(final Bean bean, final Counter counter, final Optional<String> columnNamePrefix,
            final StringBuilder propertyPath) {
        Iterator<MetaProperty<?>> itr = bean.metaBean().metaPropertyIterable().iterator();
        while (itr.hasNext()) {
            MetaProperty<?> prop = itr.next();
            if (this.beans.isBean(prop)) {
                try {
                    DownloadOverrides downloadOverridesAnnotation = prop.annotation(DownloadOverrides.class);
                    try {
                        prop.annotation(DownloadOverride.class);
                        throw new InvalidParameterException("The field " + prop.name() + " in class: "
                                + prop.declaringType().getName()
                                + " is annotated with both @DownloadOverrides and @DownloadOverride, can use either but not both on a particular field");
                    }
                    catch (NoSuchElementException ex) {
                        // Ignore
                    }
                    try {
                        prop.annotation(Download.class);
                        throw new InvalidParameterException(
                                "Field: " + prop.name() + " in class: " + prop.declaringType().getName()
                                        + " is of bean type, so @Download is not allowed here");
                    }
                    catch (NoSuchElementException ex) {
                        // Ignore
                    }
                    for (DownloadOverride downloadOverrideAnnotation : downloadOverridesAnnotation.value()) {
                        addOverrideBeanProperty(propertyPath.toString() + prop.name(), downloadOverrideAnnotation);
                    }
                }
                catch (NoSuchElementException e) {
                    try {
                        DownloadOverride downloadOverrideAnnotation = prop.annotation(DownloadOverride.class);
                        addOverrideBeanProperty(propertyPath.toString() + prop.name(), downloadOverrideAnnotation);
                    }
                    catch (NoSuchElementException ex) {
                        // Ignore
                    }
                }
                prepareBeanMetaData(beans.nextBean(prop.propertyType().getName()).get(), counter, columnNamePrefix,
                        propertyPath.append(prop.name()).append("."));
                propertyPath.setLength(propertyPath.length() - (prop.name().length() + 1));
            }
            else if (prop.propertyType().isAssignableFrom(Map.class)) {
                Map<?, ?> mapAttribute = (Map<?, ?>) prop.get(beans.bean(prop.declaringType().getName()).get());
                mapAttribute.entrySet().forEach(e -> {
                    Describable describe = (Describable) e.getKey();
                    prepareBeanMetaData(beans.nextBean(e.getValue().getClass().getName()).get(), counter,
                            Optional.of(describe.description()),
                            propertyPath.append(prop.name()).append(".").append(describe.value()).append("."));
                    propertyPath
                            .setLength(propertyPath.length() - (prop.name().length() + describe.value().length() + 2));
                });
            }
            else {
                propertyPath.append(prop.name());
                String propQualifiedName = propertyPath.toString();
                if (this.overrideMetaData.containsKey(propQualifiedName)) {
                    if(columnNamePrefix.isPresent()) {
                        this.metaData.put(counter.get(), this.overrideMetaData.get(propQualifiedName).addPrefixToColumnName(columnNamePrefix.get()));
                    } else {
                        this.metaData.put(counter.get(), this.overrideMetaData.get(propQualifiedName));
                    }
                }
                else {
                    try {
                        Download downloadAnnotation = prop.annotation(Download.class);
                        this.metaData.put(counter.get(),
                                BeanProperty.of(prop.name(), propQualifiedName,
                                        columnNamePrefix.isPresent()
                                                ? columnNamePrefix.get() + " " + downloadAnnotation.columnName()
                                                : downloadAnnotation.columnName(),
                                        downloadAnnotation.contexts().length == 0 ? true
                                                : Arrays.asList(downloadAnnotation.contexts())
                                                        .contains(this.downloadContext)));
                    }
                    catch (NoSuchElementException ex) {
                        throw new InvalidParameterException("@Download annotation is required on the field "
                                + prop.name() + " in class: " + prop.declaringType().getName());
                    }
                }
                propertyPath.setLength(propertyPath.length() - prop.name().length());
                counter.increment();
            }
        }
    }

    private void addOverrideBeanProperty(final String propertyPath, DownloadOverride downloadOverrideAnnotation) {
        String propQualifiedName = propertyPath + "." + downloadOverrideAnnotation.fieldName();
        BeanProperty overrideProperty = BeanProperty.of(
                downloadOverrideAnnotation.fieldName().substring(
                        downloadOverrideAnnotation.fieldName().lastIndexOf(".") + 1,
                        downloadOverrideAnnotation.fieldName().length()),
                propQualifiedName, downloadOverrideAnnotation.download().columnName(),
                downloadOverrideAnnotation.download().contexts().length == 0 ? true
                        : Arrays.asList(downloadOverrideAnnotation.download().contexts())
                                .contains(this.downloadContext));
        overrideMetaData.put(propQualifiedName, overrideProperty);
    }

    public String[] header() {
        return this.header;
    }

    public int columnCount() {
        return this.columnCount;
    }

    public DownloadContext downloadContext() {
        return this.downloadContext;
    }

    public boolean isDownloadable(final int index) {
        return this.metaData.get(index).isDownloadable();
    }
}
