package com.unimoni.pricingengine.common.constants;

import java.time.ZoneId;
import java.util.Locale;
import java.util.TimeZone;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.common.enums.standard.CurrencyCode;

import lombok.Value;

/**
 * Application constants.
 */
@Value
public final class ApplicationConstants {

    public static final String REPOSITORY_PACKAGE = "com.unimoni.pricingengine.adapter.persistence.repository";

    public static final String CONTROLLER_PACKAGE = "com.unimoni.pricingengine.adapter.rest.controller";

    public static final CurrencyUnit CURRENCY_UNIT_USD = CurrencyCode.USD.getCurrencyUnit();

    public final static Locale DEFAULT_LOCALE = Locale.getDefault();

    public final static ZoneId DEFAULT_ZONE_ID = ZoneId.systemDefault();

    public final static ZoneId ZONE_ID_UTC = ZoneId.of("UTC");

    // public final static ZoneId ZONE_ID_INDIA = ZoneId.of("Asia/Kolkata");

    public final static ZoneId ZONE_ID_UAE = ZoneId.of("Asia/Dubai");

    public final static TimeZone TIME_ZONE_UTC = TimeZone.getTimeZone(ZONE_ID_UTC);

    // public final static TimeZone TIME_ZONE_INDIA = TimeZone.getTimeZone(ZONE_ID_INDIA);

    public final static TimeZone TIME_ZONE_UAE = TimeZone.getTimeZone(ZONE_ID_UAE);
    
    public final static String AMIGO_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS (O)";
    
    public final static String AMIGO_DATE_TIME_FORMAT_STANDARD_CHARGE = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

    public final static String ALL_INSTRUMENTS = "All";

    public final static int MANUAL_RATE_PROVIDER_ID = 1;

    public final static int THOMSON_RATE_PROVIDER_ID = 2;

    public final static int FUTURE_SOURCE_RATE_PROVIDER_ID = 3;

    public static final String SCHEDULED_RATE_FETCHER_JOB_GROUP_ID = "RATE_FETCHER_JOB_GROUP";

    public static final String QUARTZ_JOB_DETAILS_RATE_KEY = "RATE_ID";

    public static final String QUARTZ_JOB_DETAILS_RIC_ID_KEY = "RIC_ID";

    public static final String QUARTZ_JOB_DETAILS_FREQUENCY_KEY = "FREQUENCY";

    public static final String RATE_PROVIDER_ID = "Rate_Provider_Id";
}
