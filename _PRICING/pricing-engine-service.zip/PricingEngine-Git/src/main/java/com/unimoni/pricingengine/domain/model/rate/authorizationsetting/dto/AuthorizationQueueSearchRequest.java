package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import java.util.List;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.common.dto.AbstractSearchRequest;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationStatusType;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
public class AuthorizationQueueSearchRequest extends AbstractSearchRequest {

    private final List<RMType> rateTypes;

    private final List<RateLayerType> rateLayerTypes;

    private final List<String> serviceProviders;

    private final List<String> bankCodes;

    private final List<String> agentCodes;

    private final List<CurrencyUnit> currencies;

    private final List<AuthorizationStatusType> statusType;

    private AuthorizationQueueSearchRequest(final List<RMType> rateTypes, final List<RateLayerType> rateLayerTypes,
            final List<String> serviceProviders, final List<String> bankCodes, final List<String> agentCodes,
            final List<CurrencyUnit> currencies, final List<AuthorizationStatusType> statusType, final PaginationData page) {
        this.rateTypes = rateTypes;
        this.rateLayerTypes = rateLayerTypes;

        this.serviceProviders = serviceProviders;
        this.bankCodes = bankCodes;
        this.agentCodes = agentCodes;
        this.currencies = currencies;

        this.statusType = statusType;
        this.page = page;
    }

    public static AuthorizationQueueSearchRequest of(final List<RMType> rateTypes,
            final List<RateLayerType> rateLayerTypes, final List<String> serviceProviders, final List<String> bankCodes,
            final List<String> agentCodes, final List<CurrencyUnit> currencies,
            final List<AuthorizationStatusType> statusType, final PaginationData page) {
        return new AuthorizationQueueSearchRequest(rateTypes, rateLayerTypes, serviceProviders, bankCodes, agentCodes,
                currencies, statusType, page);
    }

    public static AuthorizationQueueSearchRequest ofDownload(final List<RMType> rateTypes,
            final List<RateLayerType> rateLayerTypes, final List<String> serviceProviders, final List<String> bankCodes,
            final List<String> agentCodes, final List<CurrencyUnit> currencies,
            final List<AuthorizationStatusType> statusType) {

        return AuthorizationQueueSearchRequest.of(rateTypes, rateLayerTypes, serviceProviders, bankCodes, agentCodes,
                currencies, statusType,
                PaginationData.ofFirstPage(BeanFactory.applicationProperties().getDownloadChunkSize()));
    }

}
