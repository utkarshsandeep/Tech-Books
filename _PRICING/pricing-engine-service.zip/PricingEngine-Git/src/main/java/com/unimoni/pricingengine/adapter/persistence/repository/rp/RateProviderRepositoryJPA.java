package com.unimoni.pricingengine.adapter.persistence.repository.rp;

import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.rate.RateProvider;

public interface RateProviderRepositoryJPA extends JPA {

	public RateProvider saveRateProvider(final RateProvider rateProvider);

	public List<RateProvider> findAllRateProviders();

	public RateProvider getRateProviderReference(final int rateProviderId);

	public Optional<RateProvider> findRateProviderById(final int rateProviderId);

	public Optional<RateProvider> findRateProviderByName(final String rateProviderName);
}
