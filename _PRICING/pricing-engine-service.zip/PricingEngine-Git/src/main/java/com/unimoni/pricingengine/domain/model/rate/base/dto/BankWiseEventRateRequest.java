package com.unimoni.pricingengine.domain.model.rate.base.dto;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.rate.RateSourceType;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BankWiseEventRateRequest {
	
	
	private String bankId;
	
	private Integer agentId;
	
	private CurrencyUnit currencyCode;
	
	private String serviceProvider;
	
	private String product;
	
	private ExchangeDTO exchange;
	
	private Boolean status;
	
	private String bankDisplayCode;
	
	private String agentDisplayCode;
	
	private RateSourceType rateSourceType;
	
}
