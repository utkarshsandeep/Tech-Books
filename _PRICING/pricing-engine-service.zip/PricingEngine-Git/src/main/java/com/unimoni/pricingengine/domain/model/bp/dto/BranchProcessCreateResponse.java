package com.unimoni.pricingengine.domain.model.bp.dto;

import java.io.Serializable;

import com.unimoni.pricingengine.domain.model.bp.BranchProcessSourceType;
import com.unimoni.pricingengine.domain.model.bp.StatusType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@SuppressWarnings("serial")
@Getter
@AllArgsConstructor(staticName = "of")
@ToString
public class BranchProcessCreateResponse implements Serializable {
    private String dealId;
	private StatusType status;
	private BranchProcessSourceType sourceType;

}
