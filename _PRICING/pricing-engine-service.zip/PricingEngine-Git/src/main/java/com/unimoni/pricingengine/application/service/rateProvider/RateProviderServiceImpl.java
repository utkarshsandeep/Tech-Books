package com.unimoni.pricingengine.application.service.rateProvider;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.unimoni.pricingengine.adapter.persistence.repository.rp.RateProviderRepositoryJPA;
import com.unimoni.pricingengine.domain.model.rate.RateProvider;

@Service
public class RateProviderServiceImpl implements RateProviderService {

    @Autowired
    private RateProviderRepositoryJPA rpExchangeRateRepository;

    @Override
    @Transactional
    public RateProvider createRateProvider(final RateProvider rateProvider) {
        return rpExchangeRateRepository.saveRateProvider(rateProvider);
    }

    @Override
    @Transactional
    public List<RateProvider> getAllRateProviders() {
        return rpExchangeRateRepository.findAllRateProviders();
    }

    @Override
    public Optional<RateProvider> getManualRateProvider() {
        return rpExchangeRateRepository.findRateProviderByName(RateProvider.MANUAL);
    }

    @Override
    public Optional<RateProvider> getThomsonReutersRateProvider() {
        return rpExchangeRateRepository.findRateProviderByName(RateProvider.THOMSON_REUTERS);
    }

    @Override
    public Optional<RateProvider> getFutureSourceRateProvider() {
        return rpExchangeRateRepository.findRateProviderByName(RateProvider.FUTURE_SOURCE);
    }

    @Override
    public RateProvider loadRateProvider(final int rateProviderId) {
        return rpExchangeRateRepository.getRateProviderReference(rateProviderId);
    }

    @Override
    public Optional<RateProvider> getRateProviderById(int rateProviderId) {
        return rpExchangeRateRepository.findRateProviderById(rateProviderId);
    }
}
