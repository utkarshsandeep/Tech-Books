package com.unimoni.pricingengine.domain.model.rate;

public enum LayerType {

    // @formatter:off
    BASE_RATE("Base Rate"),
    IBR("Interbank Rate"),
    VAR("Value at Risk"),
    SETTLEMENT("Settlement"),
    COUNTRY("Country");
    // @formatter:on

    private final String description;

    private LayerType(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }
}
