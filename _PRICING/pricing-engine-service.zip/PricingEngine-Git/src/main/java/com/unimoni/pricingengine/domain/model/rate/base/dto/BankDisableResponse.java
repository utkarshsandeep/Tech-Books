package com.unimoni.pricingengine.domain.model.rate.base.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BankDisableResponse {
	
	private String serviceProviderCode;
	private String status;
	private String bankName;
	private String country;
	private String id;
	private String createdDate;
	private String modifiedDate;
	private String bankId;
	private String deleted;
	
	public BankDisableResponse( @JsonProperty String serviceProviderCode,
			@JsonProperty String status,
			@JsonProperty String bankName,
			@JsonProperty String country,
			@JsonProperty String id,
			@JsonProperty String createdDate,
			@JsonProperty String modifiedDate,
			@JsonProperty String bankId,
			@JsonProperty String deleted) {
		this.serviceProviderCode = serviceProviderCode;
		this.status = status;
		this.bankName= bankName;
		this.country= country;
		this.id=id;
		this.createdDate= createdDate;
		this.modifiedDate= modifiedDate;
		this.bankId = bankId;
		this.deleted= deleted;
	}

}
