package com.unimoni.pricingengine.domain.model.event;

import java.time.Duration;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ProvidedRateEnabledEvent {

    private int rateProviderId;

    private String rateId;

    private String ricId;

    private Duration frequency;

    @JsonCreator
    public static ProvidedRateEnabledEvent of(@JsonProperty("rateProviderId") Integer rateProviderId, @JsonProperty("rateId") String rateId,
            @JsonProperty("ricId") String ricId, @JsonProperty("frequency") String frequency) {
        ProvidedRateEnabledEvent providedRateEnabledEvent = new ProvidedRateEnabledEvent();
        providedRateEnabledEvent.rateProviderId = rateProviderId;
        providedRateEnabledEvent.rateId = rateId;
        providedRateEnabledEvent.ricId = ricId;
        providedRateEnabledEvent.frequency = Duration.parse(frequency);
        return providedRateEnabledEvent;
    }

    public static ProvidedRateEnabledEvent of(Integer rateProviderId, String rateId,
            String ricId, Duration frequency) {
        ProvidedRateEnabledEvent providedRateEnabledEvent = new ProvidedRateEnabledEvent();
        providedRateEnabledEvent.rateProviderId = rateProviderId;
        providedRateEnabledEvent.rateId = rateId;
        providedRateEnabledEvent.ricId = ricId;
        providedRateEnabledEvent.frequency = frequency;
        return providedRateEnabledEvent;
    }
}

