package com.unimoni.pricingengine.domain.model.enquiry.country;

import java.util.EnumSet;
import java.util.Optional;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryCurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@ToString
public class CountryRateEnquiryIdentity {

    private int index;

    private String serviceProvider;

    private String product;

    private String subProduct;

    private String serviceType;

    private String bank;

    private AgentDetails agent;

    private CurrencyUnit baseCurrency;

    private CurrencyUnit foreignCurrency;

    private EnumSet<VDWType> valueDateWises;

    private RateDisplayMachenism rateDisplayMachenism;

    public static CountryRateEnquiryIdentity ofNormal(final int index, final String serviceProvider,
            final String product, final String subProduct, final String serviceType, final AgentDetails agent,
            final CurrencyUnit baseCurrency, final CurrencyUnit foreignCurrency, final EnumSet<VDWType> valueDateWises,
            final RateDisplayMachenism rateDisplayMachenism) {
        return new CountryRateEnquiryIdentity(index, serviceProvider, product, subProduct, serviceType, null, agent,
                baseCurrency, foreignCurrency, valueDateWises, rateDisplayMachenism);
    }

    public static CountryRateEnquiryIdentity ofBankWise(final int index, final String serviceProvider,
            final String product, final String subProduct, final String serviceType, final String bank,
            final AgentDetails agent, final CurrencyUnit baseCurrency, final CurrencyUnit foreignCurrency,
            final EnumSet<VDWType> valueDateWises, final RateDisplayMachenism rateDisplayMachenism) {
        return new CountryRateEnquiryIdentity(index, serviceProvider, product, subProduct, serviceType, bank, agent,
                baseCurrency, foreignCurrency, valueDateWises, rateDisplayMachenism);
    }

    public Optional<String> bank() {
        return Optional.ofNullable(this.bank);
    }

    public AgentRateIdentity agentRateIdentity(final RMType rmType) {
        return rmType.isNormal()
                ? AgentRateIdentity.ofNormal(this.serviceProvider, this.product, this.subProduct, this.serviceType,
                        this.agent, CountryCurrencyDTO.of(this.baseCurrency, this.foreignCurrency))
                : AgentRateIdentity.ofBankWise(this.serviceProvider, this.product, this.subProduct, this.serviceType,
                        this.agent, this.bank, CountryCurrencyDTO.of(this.baseCurrency, this.foreignCurrency));
    }

    public CountryRateIdentity countryRateIdentity(final RMType rmType) {
        return rmType.isNormal()
                ? CountryRateIdentity.ofNormal(this.serviceProvider, this.product, this.subProduct, this.serviceType,
                        this.agent, CountryCurrencyDTO.of(this.baseCurrency, this.foreignCurrency))
                : CountryRateIdentity.ofBankWise(this.serviceProvider, this.product, this.subProduct, this.serviceType,
                        this.agent, this.bank, CountryCurrencyDTO.of(this.baseCurrency, this.foreignCurrency));
    }

    public boolean areCurrenciesSame() {
        return this.baseCurrency == this.foreignCurrency;
    }
}
