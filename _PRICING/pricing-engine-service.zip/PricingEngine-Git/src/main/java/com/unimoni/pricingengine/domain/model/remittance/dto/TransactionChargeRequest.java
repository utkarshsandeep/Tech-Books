package com.unimoni.pricingengine.domain.model.remittance.dto;

import java.time.LocalDate;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.common.enums.standard.CountryCode;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.remittance.TxnAmount;
import com.unimoni.pricingengine.domain.model.standardcharges.types.BeneficiaryType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.CustomerType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.PaymentMode;
import com.unimoni.pricingengine.domain.model.standardcharges.types.SwiftChargeType;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "transactionChargeRequest", description = "Remittance Transaction Charge Request")
public class TransactionChargeRequest {

    private String transactionUUID;

    private long agentBranchId;
    
    private String bankCode;

    private BeneficiaryType beneficiaryType;

    private CurrencyUnit payInCurrency;

    private CurrencyUnit payOutCurrency;

    private CurrencyUnit settlementCurrency;

    private CurrencyUnit sericeProviderCurrency;

    private CurrencyUnit passSettlementCurrency;

    private CustomerType customerType;

    private CountryCode originatingCountry;

    private CountryCode destinationCountry;

    private PaymentMode paymentMode;

    private AllInstruments instruments;

    private TxnAmount amount;

    private LocalDate initiationDate;

    private LocalDate transmissionDate;
    
    private SwiftChargeType swiftChargeType;
}