package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PayloadWrapper<T> {

    private List<T> payload;

    public PayloadWrapper(@JsonProperty("data") List<T> data) {
        this.payload = data;
    }
}
