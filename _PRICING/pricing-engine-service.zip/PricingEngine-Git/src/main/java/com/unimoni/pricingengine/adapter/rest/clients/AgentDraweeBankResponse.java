package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgentDraweeBankResponse {

    private String message;

    private List<AgentDraweeBank> agentDraweeBank;

    public AgentDraweeBankResponse(@JsonProperty("message") String message,
            @JsonProperty("data") List<AgentDraweeBank> agentDraweeBank) {
        super();
        this.message = message;
        this.agentDraweeBank = agentDraweeBank;
    }

}
