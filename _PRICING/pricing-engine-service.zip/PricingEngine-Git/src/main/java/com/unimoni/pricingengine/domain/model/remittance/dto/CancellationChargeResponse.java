package com.unimoni.pricingengine.domain.model.remittance.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.remittance.AskBidMargin;
import com.unimoni.pricingengine.domain.model.remittance.IBRRate;
import com.unimoni.pricingengine.domain.model.remittance.LayerCharge;
import com.unimoni.pricingengine.domain.model.remittance.RateSkipSetting;
import com.unimoni.pricingengine.domain.model.remittance.RemittanceTransactionCancellationResponse;
import com.unimoni.pricingengine.domain.model.remittance.SellBuyRate;
import com.unimoni.pricingengine.domain.model.remittance.TxnCancellationCharge;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "of", access = AccessLevel.PRIVATE)
@ToString
@ApiModel(value = "cancellationChargeResponse", description = "Cancellation Charge Response")
public class CancellationChargeResponse {

    @ApiModelProperty(name = "transactionUUID", value = "Remittance Transaction UUID", required = true, position = 1)
    private String transactionUUID;

    @ApiModelProperty(name = "charge", value = "Transaction Cancellation Charges", required = true, position = 2)
    @JsonInclude(NON_NULL)
    private TxnCancellationCharge charge;

    @ApiModelProperty(name = "rateDisplayMechanism", dataType = "String", value = "Rate Display Machenism of Agent as \"Base currency to Foriegn currency\" or \"Foriegn currency to Base currency\"", required = true, allowEmptyValue = false, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", position = 3)
    private RateDisplayMachenism rateDisplayMechanism;

    @ApiModelProperty(name = "rateSkipSetting", value = "Rate skip setting of Agent", position = 4)
    private RateSkipSetting rateSkipSetting;

    @ApiModelProperty(name = "ibr", value = "Inter Bank Rate", required = true, position = 5)
    private LayerCharge<IBRRate> ibr;

    @ApiModelProperty(name = "var", value = "Value at Risk", required = true, position = 6)
    private LayerCharge<AskBidMargin> var;

    @ApiModelProperty(name = "settlementRate", value = "Settlement Rate", required = true, position = 7)
    private LayerCharge<SellBuyRate> settlementRate;

    @ApiModelProperty(name = "countryRate", value = "Country Rate", required = true, position = 8)
    @JsonInclude(NON_NULL)
    private LayerCharge<BigDecimal> countryRate;

    @ApiModelProperty(name = "agentRate", value = "Agent Rate", required = true, position = 9)
    @JsonInclude(NON_NULL)
    private LayerCharge<BigDecimal> agentRate;

    public static CancellationChargeResponse of(final RemittanceTransactionCancellationResponse txnCancellationResponse,
            final RateSkipSetting rateSkipSetting) {
        if (rateSkipSetting.dontSkipAny()) {
            return of(txnCancellationResponse.transactionUUID(), txnCancellationResponse.charge().skip(rateSkipSetting),
                    txnCancellationResponse.rateDisplayMechanism(), rateSkipSetting,
                    txnCancellationResponse.layerCharges().getIbr(), txnCancellationResponse.layerCharges().getVar(),
                    txnCancellationResponse.layerCharges().getSettlementRate(),
                    txnCancellationResponse.layerCharges().getCountryRate(),
                    txnCancellationResponse.layerCharges().getAgentRate());
        }
        else if (rateSkipSetting.skipAll()) {
            return of(txnCancellationResponse.transactionUUID(), null, txnCancellationResponse.rateDisplayMechanism(),
                    rateSkipSetting, txnCancellationResponse.layerCharges().getIbr(),
                    txnCancellationResponse.layerCharges().getVar(),
                    txnCancellationResponse.layerCharges().getSettlementRate(), null, null);
        }
        else if (rateSkipSetting.skipRatesOnly()) {
            return of(txnCancellationResponse.transactionUUID(), txnCancellationResponse.charge().skip(rateSkipSetting),
                    txnCancellationResponse.rateDisplayMechanism(), rateSkipSetting,
                    txnCancellationResponse.layerCharges().getIbr(), txnCancellationResponse.layerCharges().getVar(),
                    txnCancellationResponse.layerCharges().getSettlementRate(), null, null);
        }
        else { // rateSkipSetting.skipCustomerFeeOnly()
            return of(txnCancellationResponse.transactionUUID(), txnCancellationResponse.charge().skip(rateSkipSetting),
                    txnCancellationResponse.rateDisplayMechanism(), rateSkipSetting,
                    txnCancellationResponse.layerCharges().getIbr(), txnCancellationResponse.layerCharges().getVar(),
                    txnCancellationResponse.layerCharges().getSettlementRate(),
                    txnCancellationResponse.layerCharges().getCountryRate(),
                    txnCancellationResponse.layerCharges().getAgentRate());
        }
    }
}
