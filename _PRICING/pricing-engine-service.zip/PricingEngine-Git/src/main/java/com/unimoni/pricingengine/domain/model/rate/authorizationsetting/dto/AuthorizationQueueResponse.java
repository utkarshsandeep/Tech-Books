package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Map;

import javax.money.CurrencyUnit;
import javax.persistence.Column;
import javax.validation.constraints.NotNull;

import org.joda.beans.Bean;
import org.joda.beans.BeanBuilder;
import org.joda.beans.JodaBeanUtils;
import org.joda.beans.MetaBean;
import org.joda.beans.MetaProperty;
import org.joda.beans.Property;
import org.joda.beans.gen.BeanDefinition;
import org.joda.beans.gen.PropertyDefinition;
import org.joda.beans.impl.direct.DirectBeanBuilder;
import org.joda.beans.impl.direct.DirectMetaBean;
import org.joda.beans.impl.direct.DirectMetaProperty;
import org.joda.beans.impl.direct.DirectMetaPropertyMap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.domain.model.common.dto.ViewModel;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationQueue;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationStatusType;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@BeanDefinition
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ApiModel(value = "authorizationQueue", description = "Authorization Queue")
public class AuthorizationQueueResponse implements ViewModel<String>, Bean {

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "authorizationQueueId", notes = "Authorization Queue Id")
    private String authorizationQueueId;

    @Override
    public String id() {
        return this.authorizationQueueId;
    }

    @Download(columnName = "Rate Type")
    @PropertyDefinition
    @ApiModelProperty(name = "rateType", dataType = "String", value = "Rate Type such as Normal, BankWise", allowEmptyValue = false, required = true, example = "NORMAL")
    @NotNull
    protected RMType rateType;

    @Download(columnName = "Rate Layer Type")
    @PropertyDefinition
    @ApiModelProperty(name = "rateLayerType", dataType = "String", value = "Rate Layer Type such as IBR_MANAGEMENT etc.", allowEmptyValue = false, required = true, example = "IBR_MANAGEMENT")
    @NotNull
    protected RateLayerType rateLayerType;

    @Download(columnName = "Service Provider")
    @PropertyDefinition
    @ApiModelProperty(name = "serviceProvider", dataType = "String", value = "Service Providers such as UAE, UK etc.", allowEmptyValue = false, required = true, example = "UAE")
    @NotNull
    protected String serviceProvider;

    @Download(columnName = "Bank Code")
    @PropertyDefinition
    @ApiModelProperty(name = "bankCode", dataType = "String", value = "Bank Code such as icici etc.", allowEmptyValue = true, required = false, example = "icici")
    protected String bankCode;

    @NotNull
    @Download(columnName = "Agent Code")
    @PropertyDefinition
    @ApiModelProperty(name = "agentCode", dataType = "String", value = "Agent Code such as icici etc.", allowEmptyValue = false, required = true, example = "12345")
    protected String agentCode;

    @NotNull
    @Download(columnName = "Currency")
    @PropertyDefinition
    @ApiModelProperty(name = "agentCode", dataType = "String", value = "Agent Code such as icici etc.", allowEmptyValue = false, required = true, example = "INR")
    protected CurrencyUnit currency;

    //@PropertyDefinition
    //@ApiModelProperty(name = "vdwType", dataType = "String", value = "CASH", allowEmptyValue = true, required = false, example = "CASH, TOM")
    private String vdwType;

    @NotNull
    @Download(columnName = "Value Edited")
    @PropertyDefinition
    @ApiModelProperty(name = "valueEdited", dataType = "String", value = "Column name.", allowEmptyValue = false, required = true, example = "BUY_VALUE")
    protected String valueEdited;

    @ApiModelProperty(name = "oldValue", dataType = "BigDecimal", value = "Old Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.3200000")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @Download(columnName = "Old Value")
    @PropertyDefinition
    private BigDecimal oldValue;

    @ApiModelProperty(name = "updatedValue", dataType = "BigDecimal", value = "Updated Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.3200000")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @Download(columnName = "Updated Value")
    @PropertyDefinition
    private BigDecimal updatedValue;

    @Download(columnName = "Authorize")
    @PropertyDefinition
    @ApiModelProperty(name = "statusType", dataType = "String", value = "Approved, Rejected, Pending", allowEmptyValue = false, required = true, example = "APPROVED")
    protected AuthorizationStatusType statusType;

    @Column(name = "UPDATED_ON", columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    private ZonedDateTime updatedOn;

    public void updatedNow() {
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public void updatedOn(final ZonedDateTime zonedDateTime) {
        this.updatedOn = zonedDateTime;
    }

    private static String buildColumnName(RateLayerType layerType, VDWType vdwType, ColumnNameType columnType) {
        StringBuffer sf = new StringBuffer(50);
        if (RateLayerType.SETTLEMENT_MARGIN == layerType) {
            return sf.append(ColumnNameType.SETTLEMENT.description()).append(" ")
                    .append((vdwType != null ? vdwType.description() : "")).append(" ").append(columnType.description())
                    .toString();
        }

        return columnType.description();
    }

    public static AuthorizationQueueResponse of(AuthorizationQueue queue) {

        return AuthorizationQueueResponse.of(queue.id(), queue.rateType(), queue.rateLayerType(),
                queue.serviceProvider(), queue.bankCode(), queue.agentCode(), queue.currency(),
                queue.vdwType() != null ? queue.vdwType().name() : null,
                buildColumnName(queue.rateLayerType(), queue.vdwType(), queue.columnChanged()), queue.oldValue(),
                queue.updatedValue(), queue.status(), queue.updatedOn());
    }

  //------------------------- AUTOGENERATED START -------------------------
  /**
   * The meta-bean for {@code AuthorizationQueueResponse}.
   * @return the meta-bean, not null
   */
  public static AuthorizationQueueResponse.Meta meta() {
    return AuthorizationQueueResponse.Meta.INSTANCE;
  }

  static {
    MetaBean.register(AuthorizationQueueResponse.Meta.INSTANCE);
  }

  @Override
  public AuthorizationQueueResponse.Meta metaBean() {
    return AuthorizationQueueResponse.Meta.INSTANCE;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the rateType.
   * @return the value of the property
   */
  public RMType getRateType() {
    return rateType;
  }

  /**
   * Sets the rateType.
   * @param rateType  the new value of the property
   */
  public void setRateType(RMType rateType) {
    this.rateType = rateType;
  }

  /**
   * Gets the the {@code rateType} property.
   * @return the property, not null
   */
  public final Property<RMType> rateType() {
    return metaBean().rateType().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the rateLayerType.
   * @return the value of the property
   */
  public RateLayerType getRateLayerType() {
    return rateLayerType;
  }

  /**
   * Sets the rateLayerType.
   * @param rateLayerType  the new value of the property
   */
  public void setRateLayerType(RateLayerType rateLayerType) {
    this.rateLayerType = rateLayerType;
  }

  /**
   * Gets the the {@code rateLayerType} property.
   * @return the property, not null
   */
  public final Property<RateLayerType> rateLayerType() {
    return metaBean().rateLayerType().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the serviceProvider.
   * @return the value of the property
   */
  public String getServiceProvider() {
    return serviceProvider;
  }

  /**
   * Sets the serviceProvider.
   * @param serviceProvider  the new value of the property
   */
  public void setServiceProvider(String serviceProvider) {
    this.serviceProvider = serviceProvider;
  }

  /**
   * Gets the the {@code serviceProvider} property.
   * @return the property, not null
   */
  public final Property<String> serviceProvider() {
    return metaBean().serviceProvider().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the bankCode.
   * @return the value of the property
   */
  public String getBankCode() {
    return bankCode;
  }

  /**
   * Sets the bankCode.
   * @param bankCode  the new value of the property
   */
  public void setBankCode(String bankCode) {
    this.bankCode = bankCode;
  }

  /**
   * Gets the the {@code bankCode} property.
   * @return the property, not null
   */
  public final Property<String> bankCode() {
    return metaBean().bankCode().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the agentCode.
   * @return the value of the property
   */
  public String getAgentCode() {
    return agentCode;
  }

  /**
   * Sets the agentCode.
   * @param agentCode  the new value of the property
   */
  public void setAgentCode(String agentCode) {
    this.agentCode = agentCode;
  }

  /**
   * Gets the the {@code agentCode} property.
   * @return the property, not null
   */
  public final Property<String> agentCode() {
    return metaBean().agentCode().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the currency.
   * @return the value of the property
   */
  public CurrencyUnit getCurrency() {
    return currency;
  }

  /**
   * Sets the currency.
   * @param currency  the new value of the property
   */
  public void setCurrency(CurrencyUnit currency) {
    this.currency = currency;
  }

  /**
   * Gets the the {@code currency} property.
   * @return the property, not null
   */
  public final Property<CurrencyUnit> currency() {
    return metaBean().currency().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the valueEdited.
   * @return the value of the property
   */
  public String getValueEdited() {
    return valueEdited;
  }

  /**
   * Sets the valueEdited.
   * @param valueEdited  the new value of the property
   */
  public void setValueEdited(String valueEdited) {
    this.valueEdited = valueEdited;
  }

  /**
   * Gets the the {@code valueEdited} property.
   * @return the property, not null
   */
  public final Property<String> valueEdited() {
    return metaBean().valueEdited().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the oldValue.
   * @return the value of the property
   */
  public BigDecimal getOldValue() {
    return oldValue;
  }

  /**
   * Sets the oldValue.
   * @param oldValue  the new value of the property
   */
  public void setOldValue(BigDecimal oldValue) {
    this.oldValue = oldValue;
  }

  /**
   * Gets the the {@code oldValue} property.
   * @return the property, not null
   */
  public final Property<BigDecimal> oldValue() {
    return metaBean().oldValue().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the updatedValue.
   * @return the value of the property
   */
  public BigDecimal getUpdatedValue() {
    return updatedValue;
  }

  /**
   * Sets the updatedValue.
   * @param updatedValue  the new value of the property
   */
  public void setUpdatedValue(BigDecimal updatedValue) {
    this.updatedValue = updatedValue;
  }

  /**
   * Gets the the {@code updatedValue} property.
   * @return the property, not null
   */
  public final Property<BigDecimal> updatedValue() {
    return metaBean().updatedValue().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the statusType.
   * @return the value of the property
   */
  public AuthorizationStatusType getStatusType() {
    return statusType;
  }

  /**
   * Sets the statusType.
   * @param statusType  the new value of the property
   */
  public void setStatusType(AuthorizationStatusType statusType) {
    this.statusType = statusType;
  }

  /**
   * Gets the the {@code statusType} property.
   * @return the property, not null
   */
  public final Property<AuthorizationStatusType> statusType() {
    return metaBean().statusType().createProperty(this);
  }

  //-----------------------------------------------------------------------
  @Override
  public AuthorizationQueueResponse clone() {
    return JodaBeanUtils.cloneAlways(this);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj != null && obj.getClass() == this.getClass()) {
      AuthorizationQueueResponse other = (AuthorizationQueueResponse) obj;
      return JodaBeanUtils.equal(getRateType(), other.getRateType()) &&
          JodaBeanUtils.equal(getRateLayerType(), other.getRateLayerType()) &&
          JodaBeanUtils.equal(getServiceProvider(), other.getServiceProvider()) &&
          JodaBeanUtils.equal(getBankCode(), other.getBankCode()) &&
          JodaBeanUtils.equal(getAgentCode(), other.getAgentCode()) &&
          JodaBeanUtils.equal(getCurrency(), other.getCurrency()) &&
          JodaBeanUtils.equal(getValueEdited(), other.getValueEdited()) &&
          JodaBeanUtils.equal(getOldValue(), other.getOldValue()) &&
          JodaBeanUtils.equal(getUpdatedValue(), other.getUpdatedValue()) &&
          JodaBeanUtils.equal(getStatusType(), other.getStatusType());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int hash = getClass().hashCode();
    hash = hash * 31 + JodaBeanUtils.hashCode(getRateType());
    hash = hash * 31 + JodaBeanUtils.hashCode(getRateLayerType());
    hash = hash * 31 + JodaBeanUtils.hashCode(getServiceProvider());
    hash = hash * 31 + JodaBeanUtils.hashCode(getBankCode());
    hash = hash * 31 + JodaBeanUtils.hashCode(getAgentCode());
    hash = hash * 31 + JodaBeanUtils.hashCode(getCurrency());
    hash = hash * 31 + JodaBeanUtils.hashCode(getValueEdited());
    hash = hash * 31 + JodaBeanUtils.hashCode(getOldValue());
    hash = hash * 31 + JodaBeanUtils.hashCode(getUpdatedValue());
    hash = hash * 31 + JodaBeanUtils.hashCode(getStatusType());
    return hash;
  }

  @Override
  public String toString() {
    StringBuilder buf = new StringBuilder(352);
    buf.append("AuthorizationQueueResponse{");
    int len = buf.length();
    toString(buf);
    if (buf.length() > len) {
      buf.setLength(buf.length() - 2);
    }
    buf.append('}');
    return buf.toString();
  }

  protected void toString(StringBuilder buf) {
    buf.append("rateType").append('=').append(JodaBeanUtils.toString(getRateType())).append(',').append(' ');
    buf.append("rateLayerType").append('=').append(JodaBeanUtils.toString(getRateLayerType())).append(',').append(' ');
    buf.append("serviceProvider").append('=').append(JodaBeanUtils.toString(getServiceProvider())).append(',').append(' ');
    buf.append("bankCode").append('=').append(JodaBeanUtils.toString(getBankCode())).append(',').append(' ');
    buf.append("agentCode").append('=').append(JodaBeanUtils.toString(getAgentCode())).append(',').append(' ');
    buf.append("currency").append('=').append(JodaBeanUtils.toString(getCurrency())).append(',').append(' ');
    buf.append("valueEdited").append('=').append(JodaBeanUtils.toString(getValueEdited())).append(',').append(' ');
    buf.append("oldValue").append('=').append(JodaBeanUtils.toString(getOldValue())).append(',').append(' ');
    buf.append("updatedValue").append('=').append(JodaBeanUtils.toString(getUpdatedValue())).append(',').append(' ');
    buf.append("statusType").append('=').append(JodaBeanUtils.toString(getStatusType())).append(',').append(' ');
  }

  //-----------------------------------------------------------------------
  /**
   * The meta-bean for {@code AuthorizationQueueResponse}.
   */
  public static class Meta extends DirectMetaBean {
    /**
     * The singleton instance of the meta-bean.
     */
    static final Meta INSTANCE = new Meta();

    /**
     * The meta-property for the {@code rateType} property.
     */
    private final MetaProperty<RMType> _rateType = DirectMetaProperty.ofReadWrite(
        this, "rateType", AuthorizationQueueResponse.class, RMType.class);
    /**
     * The meta-property for the {@code rateLayerType} property.
     */
    private final MetaProperty<RateLayerType> _rateLayerType = DirectMetaProperty.ofReadWrite(
        this, "rateLayerType", AuthorizationQueueResponse.class, RateLayerType.class);
    /**
     * The meta-property for the {@code serviceProvider} property.
     */
    private final MetaProperty<String> _serviceProvider = DirectMetaProperty.ofReadWrite(
        this, "serviceProvider", AuthorizationQueueResponse.class, String.class);
    /**
     * The meta-property for the {@code bankCode} property.
     */
    private final MetaProperty<String> _bankCode = DirectMetaProperty.ofReadWrite(
        this, "bankCode", AuthorizationQueueResponse.class, String.class);
    /**
     * The meta-property for the {@code agentCode} property.
     */
    private final MetaProperty<String> _agentCode = DirectMetaProperty.ofReadWrite(
        this, "agentCode", AuthorizationQueueResponse.class, String.class);
    /**
     * The meta-property for the {@code currency} property.
     */
    private final MetaProperty<CurrencyUnit> _currency = DirectMetaProperty.ofReadWrite(
        this, "currency", AuthorizationQueueResponse.class, CurrencyUnit.class);
    /**
     * The meta-property for the {@code valueEdited} property.
     */
    private final MetaProperty<String> _valueEdited = DirectMetaProperty.ofReadWrite(
        this, "valueEdited", AuthorizationQueueResponse.class, String.class);
    /**
     * The meta-property for the {@code oldValue} property.
     */
    private final MetaProperty<BigDecimal> _oldValue = DirectMetaProperty.ofReadWrite(
        this, "oldValue", AuthorizationQueueResponse.class, BigDecimal.class);
    /**
     * The meta-property for the {@code updatedValue} property.
     */
    private final MetaProperty<BigDecimal> _updatedValue = DirectMetaProperty.ofReadWrite(
        this, "updatedValue", AuthorizationQueueResponse.class, BigDecimal.class);
    /**
     * The meta-property for the {@code statusType} property.
     */
    private final MetaProperty<AuthorizationStatusType> _statusType = DirectMetaProperty.ofReadWrite(
        this, "statusType", AuthorizationQueueResponse.class, AuthorizationStatusType.class);
    /**
     * The meta-properties.
     */
    private final Map<String, MetaProperty<?>> _metaPropertyMap$ = new DirectMetaPropertyMap(
        this, null,
        "rateType",
        "rateLayerType",
        "serviceProvider",
        "bankCode",
        "agentCode",
        "currency",
        "valueEdited",
        "oldValue",
        "updatedValue",
        "statusType");

    /**
     * Restricted constructor.
     */
    protected Meta() {
    }

    @Override
    protected MetaProperty<?> metaPropertyGet(String propertyName) {
      switch (propertyName.hashCode()) {
        case 422305850:  // rateType
          return _rateType;
        case 226498347:  // rateLayerType
          return _rateLayerType;
        case 243182534:  // serviceProvider
          return _serviceProvider;
        case -1859605943:  // bankCode
          return _bankCode;
        case -1701553518:  // agentCode
          return _agentCode;
        case 575402001:  // currency
          return _currency;
        case -1840446214:  // valueEdited
          return _valueEdited;
        case 189903754:  // oldValue
          return _oldValue;
        case -481755786:  // updatedValue
          return _updatedValue;
        case 248023628:  // statusType
          return _statusType;
      }
      return super.metaPropertyGet(propertyName);
    }

    @Override
    public BeanBuilder<? extends AuthorizationQueueResponse> builder() {
      return new DirectBeanBuilder<>(new AuthorizationQueueResponse());
    }

    @Override
    public Class<? extends AuthorizationQueueResponse> beanType() {
      return AuthorizationQueueResponse.class;
    }

    @Override
    public Map<String, MetaProperty<?>> metaPropertyMap() {
      return _metaPropertyMap$;
    }

    //-----------------------------------------------------------------------
    /**
     * The meta-property for the {@code rateType} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<RMType> rateType() {
      return _rateType;
    }

    /**
     * The meta-property for the {@code rateLayerType} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<RateLayerType> rateLayerType() {
      return _rateLayerType;
    }

    /**
     * The meta-property for the {@code serviceProvider} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> serviceProvider() {
      return _serviceProvider;
    }

    /**
     * The meta-property for the {@code bankCode} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> bankCode() {
      return _bankCode;
    }

    /**
     * The meta-property for the {@code agentCode} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> agentCode() {
      return _agentCode;
    }

    /**
     * The meta-property for the {@code currency} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CurrencyUnit> currency() {
      return _currency;
    }

    /**
     * The meta-property for the {@code valueEdited} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> valueEdited() {
      return _valueEdited;
    }

    /**
     * The meta-property for the {@code oldValue} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<BigDecimal> oldValue() {
      return _oldValue;
    }

    /**
     * The meta-property for the {@code updatedValue} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<BigDecimal> updatedValue() {
      return _updatedValue;
    }

    /**
     * The meta-property for the {@code statusType} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<AuthorizationStatusType> statusType() {
      return _statusType;
    }

    //-----------------------------------------------------------------------
    @Override
    protected Object propertyGet(Bean bean, String propertyName, boolean quiet) {
      switch (propertyName.hashCode()) {
        case 422305850:  // rateType
          return ((AuthorizationQueueResponse) bean).getRateType();
        case 226498347:  // rateLayerType
          return ((AuthorizationQueueResponse) bean).getRateLayerType();
        case 243182534:  // serviceProvider
          return ((AuthorizationQueueResponse) bean).getServiceProvider();
        case -1859605943:  // bankCode
          return ((AuthorizationQueueResponse) bean).getBankCode();
        case -1701553518:  // agentCode
          return ((AuthorizationQueueResponse) bean).getAgentCode();
        case 575402001:  // currency
          return ((AuthorizationQueueResponse) bean).getCurrency();
        case -1840446214:  // valueEdited
          return ((AuthorizationQueueResponse) bean).getValueEdited();
        case 189903754:  // oldValue
          return ((AuthorizationQueueResponse) bean).getOldValue();
        case -481755786:  // updatedValue
          return ((AuthorizationQueueResponse) bean).getUpdatedValue();
        case 248023628:  // statusType
          return ((AuthorizationQueueResponse) bean).getStatusType();
      }
      return super.propertyGet(bean, propertyName, quiet);
    }

    @Override
    protected void propertySet(Bean bean, String propertyName, Object newValue, boolean quiet) {
      switch (propertyName.hashCode()) {
        case 422305850:  // rateType
          ((AuthorizationQueueResponse) bean).setRateType((RMType) newValue);
          return;
        case 226498347:  // rateLayerType
          ((AuthorizationQueueResponse) bean).setRateLayerType((RateLayerType) newValue);
          return;
        case 243182534:  // serviceProvider
          ((AuthorizationQueueResponse) bean).setServiceProvider((String) newValue);
          return;
        case -1859605943:  // bankCode
          ((AuthorizationQueueResponse) bean).setBankCode((String) newValue);
          return;
        case -1701553518:  // agentCode
          ((AuthorizationQueueResponse) bean).setAgentCode((String) newValue);
          return;
        case 575402001:  // currency
          ((AuthorizationQueueResponse) bean).setCurrency((CurrencyUnit) newValue);
          return;
        case -1840446214:  // valueEdited
          ((AuthorizationQueueResponse) bean).setValueEdited((String) newValue);
          return;
        case 189903754:  // oldValue
          ((AuthorizationQueueResponse) bean).setOldValue((BigDecimal) newValue);
          return;
        case -481755786:  // updatedValue
          ((AuthorizationQueueResponse) bean).setUpdatedValue((BigDecimal) newValue);
          return;
        case 248023628:  // statusType
          ((AuthorizationQueueResponse) bean).setStatusType((AuthorizationStatusType) newValue);
          return;
      }
      super.propertySet(bean, propertyName, newValue, quiet);
    }

  }

  //-------------------------- AUTOGENERATED END --------------------------
}
