package com.unimoni.pricingengine.application.service.amigo.event;

import java.io.Serializable;

import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;

@SuppressWarnings("serial")
@Getter
@ToString
public class AmigoStandardChargeEvent implements Serializable {

    @NonNull
    private Type type;
    
    protected AmigoStandardChargeEvent(final Type type) {
        this.type = type;     
    }

    public static enum Type {
        STANDARD_CHARGES;
    }
}
