package com.unimoni.pricingengine.domain.model.common.dto;

public interface ViewModel<I> {

    public I id();
}
