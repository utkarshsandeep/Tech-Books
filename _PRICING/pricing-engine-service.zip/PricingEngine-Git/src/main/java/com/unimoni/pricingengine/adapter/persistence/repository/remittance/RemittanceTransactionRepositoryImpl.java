package com.unimoni.pricingengine.adapter.persistence.repository.remittance;

import java.util.Optional;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.remittance.AbstractRemittanceTransaction;
import com.unimoni.pricingengine.domain.model.remittance.AbstractRemittanceTransaction_;

@Repository
public class RemittanceTransactionRepositoryImpl extends AbstractJPA implements RemittanceTransactionRepository {

    @Override
    public <T extends AbstractRemittanceTransaction> Optional<T> findLatestByTransactionUUID(Class<T> clazz,
            String transactionUUID) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<T> query = criteriaQuery(clazz);
        Root<T> txn = query.from(clazz);
        query.where(criteriaBuilder.equal(txn.get(AbstractRemittanceTransaction_.transactionUUID.getName()),
                transactionUUID));
        query.orderBy(criteriaBuilder.desc(txn.get(AbstractRemittanceTransaction_.createdOn.getName())));
        TypedQuery<T> typedQuery = typedQuery(query);
        typedQuery.setMaxResults(1);
        return getSingleResultSafely(typedQuery);
    }

}
