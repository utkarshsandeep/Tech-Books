package com.unimoni.pricingengine.domain.model.bp.dto;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.bp.BranchProcessSourceType;
import com.unimoni.pricingengine.domain.model.bp.StatusType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ApiModel(value = "branchProcessUpdateRequest", description = "Update BP deal Request")
@ToString
public class BranchProcessUpdateRequest {
	@NotNull
	@ApiModelProperty(name = "deal", allowEmptyValue = false, dataType = "String", required = true)
	private String deal;

	@ApiModelProperty(name = "offeredRate", allowEmptyValue = false, dataType = "BigDecimal", required = false)
	private BigDecimal offeredRate;

	@NotNull
	@ApiModelProperty(name = "status", allowEmptyValue = false, dataType = "Enum", required = true)
	private StatusType status;

	@ApiModelProperty(name = "amountConsumed", allowEmptyValue = false, dataType = "BigDecimal", required = false)
	private BigDecimal amountConsumed;
	
	@ApiModelProperty(name = "sourceType", value = "AMIGOG", required = true)
    @NotNull
    private BranchProcessSourceType sourceType;
	
}
