package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.application.service.onboarding.model.Product;

import lombok.ToString;

@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductPaylaodWrapper {

    private List<ProductPayload> payload;

    public ProductPaylaodWrapper(@JsonProperty("response") List<ProductPayload> response) {
        this.payload = response;
    }

    public List<Product> products() {
        return this.payload != null & !this.payload.isEmpty()
                ? this.payload.stream().distinct().sorted(Comparator.comparing(ProductPayload::getName))
                        .map(ProductPayload::product).collect(Collectors.toList())
                : Collections.emptyList();
    }
}
