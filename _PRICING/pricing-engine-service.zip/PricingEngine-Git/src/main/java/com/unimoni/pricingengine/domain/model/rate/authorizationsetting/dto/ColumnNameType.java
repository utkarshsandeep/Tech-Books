package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "columnNameType", description = "Column Name")
public enum ColumnNameType {
    SETTLEMENT("Settlement"),
    
    SELL_MARGIN("Sell Margin"),
    BUY_MARGIN("Buy Margin"),
    ASK_MARGIN("Ask Margin"),
    BID_MARGIN("Bid Margin"),
    BUY("Buy"),
    SELL("Sell"),
    ASK_VALUE("Ask Value"),
    BID_VALUE("Bid Value");

    private final String description;

    private ColumnNameType(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }
}
