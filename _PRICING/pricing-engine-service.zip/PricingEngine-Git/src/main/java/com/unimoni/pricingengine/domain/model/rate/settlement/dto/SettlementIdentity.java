package com.unimoni.pricingengine.domain.model.rate.settlement.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.*;

import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.base.dto.CurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.composable.CurrencyExchange;
import com.unimoni.pricingengine.domain.model.rate.var.dto.AllInstrumentsDTO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode
@ToString
public class SettlementIdentity {

    private AllInstrumentsDTO instruments;

    private String agent;

    @JsonInclude(NON_NULL)
    private String bank;

    private CurrencyDTO currency;

    public static SettlementIdentity ofNormal(final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final String agent, final CurrencyDTO currency) {
        SettlementIdentity settlementAllIdentity = new SettlementIdentity();
        settlementAllIdentity.instruments = AllInstrumentsDTO.of(serviceProvider, product, subProduct, serviceType);
        settlementAllIdentity.agent = agent;
        settlementAllIdentity.currency = currency;
        return settlementAllIdentity;
    }

    public static SettlementIdentity ofBankWise(final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final String agent, final String bank,
            final CurrencyDTO currency) {
        SettlementIdentity settlementAllIdentity = ofNormal(serviceProvider, product, subProduct, serviceType, agent,
                currency);
        settlementAllIdentity.bank = bank;
        return settlementAllIdentity;
    }

    public static SettlementIdentity of(final RMType rmType, final SettlementBasicIdentity basicIdentity,
            final CurrencyExchange currency) {
        return rmType.isNormal()
                ? ofNormal(basicIdentity.getServiceProvider(), basicIdentity.getProduct(),
                        basicIdentity.getSubProduct(), basicIdentity.getServiceType(), basicIdentity.getAgent(),
                        CurrencyDTO.of(currency))
                : ofBankWise(basicIdentity.getServiceProvider(), basicIdentity.getProduct(),
                        basicIdentity.getSubProduct(), basicIdentity.getServiceType(), basicIdentity.getAgent(),
                        basicIdentity.getBank().get(), CurrencyDTO.of(currency));
    }

    public Optional<String> getBank() {
        return Optional.ofNullable(this.bank);
    }
}
