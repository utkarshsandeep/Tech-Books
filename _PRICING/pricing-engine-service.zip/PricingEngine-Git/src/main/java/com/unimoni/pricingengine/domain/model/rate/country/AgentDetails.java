package com.unimoni.pricingengine.domain.model.rate.country;

import java.util.Map;
import java.util.NoSuchElementException;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.joda.beans.Bean;
import org.joda.beans.ImmutableBean;
import org.joda.beans.JodaBeanUtils;
import org.joda.beans.MetaBean;
import org.joda.beans.MetaProperty;
import org.joda.beans.gen.BeanDefinition;
import org.joda.beans.gen.PropertyDefinition;
import org.joda.beans.impl.direct.DirectFieldsBeanBuilder;
import org.joda.beans.impl.direct.DirectMetaBean;
import org.joda.beans.impl.direct.DirectMetaProperty;
import org.joda.beans.impl.direct.DirectMetaPropertyMap;
import org.zalando.problem.Status;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.country.AgentItem.Type;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;

@BeanDefinition
@ApiModel(value = "agentWithRateDisplayMechanism", description = "Agent with Rate Display Mechanisms and Type")
public class AgentDetails implements ImmutableBean, Comparable<AgentDetails> {

    @PropertyDefinition
    @Download(columnName = "Agent Code")
    @NotEmpty
    @ApiModelProperty(name = "code", dataType = "String", value = "The agent code", required = true, allowEmptyValue = false, example = "SMITH")
    private final String code;

    @Getter
    @ApiModelProperty(name = "rateDisplayMechanism", dataType = "String", value = "Rate display machenism", required = true, allowEmptyValue = false, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC")
    @NotNull
    private RateDisplayMachenism rateDisplayMechanism;

    @Getter
    @ApiModelProperty(name = "type", dataType = "String", value = "Whether its an agent or branch", example = "AGENT", allowableValues = "AGENT,BRANCH", position = 4)
    @NotNull
    private Type type;

    public boolean isBranch() {
        return this.type == Type.BRANCH;
    }

    private static final String SEPERATOR = ",";

    private AgentDetails(final String agentCode, final RateDisplayMachenism rateDisplayMechanism,
            final AgentItem.Type type) {
        this.code = agentCode;
        this.rateDisplayMechanism = rateDisplayMechanism;
        this.type = type;
    }

    @JsonCreator
    public static AgentDetails of(final @JsonProperty("code") String agentCode,
            final @JsonProperty("rateDisplayMechanism") String rateDisplayMechanismName,
            final @JsonProperty("type") String typeName) {
        return new AgentDetails(agentCode, RateDisplayMachenism.of(rateDisplayMechanismName),
                AgentItem.Type.valueOf(typeName));
    }

    public static AgentDetails ofAgent(final String agentCode, final RateDisplayMachenism rateDisplayMechanism) {
        return new AgentDetails(agentCode, rateDisplayMechanism, AgentItem.Type.AGENT);
    }

    public static AgentDetails ofBranch(final String agentBranchCode, final RateDisplayMachenism rateDisplayMechanism) {
        return new AgentDetails(agentBranchCode, rateDisplayMechanism, AgentItem.Type.BRANCH);
    }

    public static AgentDetails of(final String agentCode, final String rateDisplayMechanismName,
            final AgentItem.Type type) {
        return new AgentDetails(agentCode, RateDisplayMachenism.of(rateDisplayMechanismName), type);
    }

    public static AgentDetails of(final String agentCode, final RateDisplayMachenism rateDisplayMechanism,
            final AgentItem.Type type) {
        return new AgentDetails(agentCode, rateDisplayMechanism, type);
    }

    public AgentItem agentItem() {
        return AgentItem.of(this.code, this.type);
    }

    public String convertToString() {
        return this.code + SEPERATOR + rateDisplayMechanism.name() + SEPERATOR + type.name();
    }

    public static AgentDetails fromString(final String stringValue) {
        String[] params = stringValue.split(SEPERATOR);
        if (params == null || params.length != 3
                || !(params[1].trim().equals(RateDisplayMachenism.BC_TO_FC.name())
                        || params[1].trim().equals(RateDisplayMachenism.FC_TO_BC.name()))
                || !(params[2].trim().equals(AgentItem.Type.AGENT.name())
                        || params[2].trim().equals(AgentItem.Type.BRANCH.name()))) {
            throw new RateException(RateExceptionExceptionType.ILLEGAL_AGENT_DETAILS_REQUEST_PARAMETER,
                    Status.BAD_REQUEST, stringValue);
        }
        else {
            return of(params[0].trim(), params[1].trim(), params[2].trim());
        }
    }

    @Override
    public int compareTo(AgentDetails o) {
        return this.code.compareTo(o.code);
    }

  //------------------------- AUTOGENERATED START -------------------------
  /**
   * The meta-bean for {@code AgentDetails}.
   * @return the meta-bean, not null
   */
  public static AgentDetails.Meta meta() {
    return AgentDetails.Meta.INSTANCE;
  }

  static {
    MetaBean.register(AgentDetails.Meta.INSTANCE);
  }

  /**
   * Returns a builder used to create an instance of the bean.
   * @return the builder, not null
   */
  public static AgentDetails.Builder builder() {
    return new AgentDetails.Builder();
  }

  /**
   * Restricted constructor.
   * @param builder  the builder to copy from, not null
   */
  protected AgentDetails(AgentDetails.Builder builder) {
    this.code = builder.code;
  }

  @Override
  public AgentDetails.Meta metaBean() {
    return AgentDetails.Meta.INSTANCE;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the code.
   * @return the value of the property
   */
  public String getCode() {
    return code;
  }

  //-----------------------------------------------------------------------
  /**
   * Returns a builder that allows this bean to be mutated.
   * @return the mutable builder, not null
   */
  public Builder toBuilder() {
    return new Builder(this);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj != null && obj.getClass() == this.getClass()) {
      AgentDetails other = (AgentDetails) obj;
      return JodaBeanUtils.equal(code, other.code);
    }
    return false;
  }

  @Override
  public int hashCode() {
    int hash = getClass().hashCode();
    hash = hash * 31 + JodaBeanUtils.hashCode(code);
    return hash;
  }

  @Override
  public String toString() {
    StringBuilder buf = new StringBuilder(64);
    buf.append("AgentDetails{");
    int len = buf.length();
    toString(buf);
    if (buf.length() > len) {
      buf.setLength(buf.length() - 2);
    }
    buf.append('}');
    return buf.toString();
  }

  protected void toString(StringBuilder buf) {
    buf.append("code").append('=').append(JodaBeanUtils.toString(code)).append(',').append(' ');
  }

  //-----------------------------------------------------------------------
  /**
   * The meta-bean for {@code AgentDetails}.
   */
  public static class Meta extends DirectMetaBean {
    /**
     * The singleton instance of the meta-bean.
     */
    static final Meta INSTANCE = new Meta();

    /**
     * The meta-property for the {@code code} property.
     */
    private final MetaProperty<String> _code = DirectMetaProperty.ofImmutable(
        this, "code", AgentDetails.class, String.class);
    /**
     * The meta-properties.
     */
    private final Map<String, MetaProperty<?>> _metaPropertyMap$ = new DirectMetaPropertyMap(
        this, null,
        "code");

    /**
     * Restricted constructor.
     */
    protected Meta() {
    }

    @Override
    protected MetaProperty<?> metaPropertyGet(String propertyName) {
      switch (propertyName.hashCode()) {
        case 3059181:  // code
          return _code;
      }
      return super.metaPropertyGet(propertyName);
    }

    @Override
    public AgentDetails.Builder builder() {
      return new AgentDetails.Builder();
    }

    @Override
    public Class<? extends AgentDetails> beanType() {
      return AgentDetails.class;
    }

    @Override
    public Map<String, MetaProperty<?>> metaPropertyMap() {
      return _metaPropertyMap$;
    }

    //-----------------------------------------------------------------------
    /**
     * The meta-property for the {@code code} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> code() {
      return _code;
    }

    //-----------------------------------------------------------------------
    @Override
    protected Object propertyGet(Bean bean, String propertyName, boolean quiet) {
      switch (propertyName.hashCode()) {
        case 3059181:  // code
          return ((AgentDetails) bean).getCode();
      }
      return super.propertyGet(bean, propertyName, quiet);
    }

    @Override
    protected void propertySet(Bean bean, String propertyName, Object newValue, boolean quiet) {
      metaProperty(propertyName);
      if (quiet) {
        return;
      }
      throw new UnsupportedOperationException("Property cannot be written: " + propertyName);
    }

  }

  //-----------------------------------------------------------------------
  /**
   * The bean-builder for {@code AgentDetails}.
   */
  public static class Builder extends DirectFieldsBeanBuilder<AgentDetails> {

    private String code;

    /**
     * Restricted constructor.
     */
    protected Builder() {
    }

    /**
     * Restricted copy constructor.
     * @param beanToCopy  the bean to copy from, not null
     */
    protected Builder(AgentDetails beanToCopy) {
      this.code = beanToCopy.getCode();
    }

    //-----------------------------------------------------------------------
    @Override
    public Object get(String propertyName) {
      switch (propertyName.hashCode()) {
        case 3059181:  // code
          return code;
        default:
          throw new NoSuchElementException("Unknown property: " + propertyName);
      }
    }

    @Override
    public Builder set(String propertyName, Object newValue) {
      switch (propertyName.hashCode()) {
        case 3059181:  // code
          this.code = (String) newValue;
          break;
        default:
          throw new NoSuchElementException("Unknown property: " + propertyName);
      }
      return this;
    }

    @Override
    public Builder set(MetaProperty<?> property, Object value) {
      super.set(property, value);
      return this;
    }

    @Override
    public AgentDetails build() {
      return new AgentDetails(this);
    }

    //-----------------------------------------------------------------------
    /**
     * Sets the code.
     * @param code  the new value
     * @return this, for chaining, not null
     */
    public Builder code(String code) {
      this.code = code;
      return this;
    }

    //-----------------------------------------------------------------------
    @Override
    public String toString() {
      StringBuilder buf = new StringBuilder(64);
      buf.append("AgentDetails.Builder{");
      int len = buf.length();
      toString(buf);
      if (buf.length() > len) {
        buf.setLength(buf.length() - 2);
      }
      buf.append('}');
      return buf.toString();
    }

    protected void toString(StringBuilder buf) {
      buf.append("code").append('=').append(JodaBeanUtils.toString(code)).append(',').append(' ');
    }

  }

  //-------------------------- AUTOGENERATED END --------------------------
}
