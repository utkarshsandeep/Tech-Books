package com.unimoni.pricingengine.domain.model.remittance.dto;

import java.math.BigDecimal;

import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.remittance.RemittanceTransactionCancellationRequest;
import com.unimoni.pricingengine.domain.model.remittance.TxnCancellationReason;
import com.unimoni.pricingengine.domain.model.standardcharges.types.TransactionType;

import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
public class TxnCancellationChargeCalculationRequest extends TxnSDChargeCalculationRequest {

    private TxnCancellationReason reasonForCancellation;

    private TxnCancellationChargeCalculationRequest(
            final RemittanceTransactionCancellationRequest txnCancellationRequest,
            final RateDisplayMachenism rateDisplayMachenism, final VDWType valueDateWise, final BigDecimal rate) {
        super(txnCancellationRequest.txnInitRequest(), rateDisplayMachenism, valueDateWise,
                TransactionType.of(txnCancellationRequest.transactionStatus()), rate);
        this.reasonForCancellation = txnCancellationRequest.reasonForCancellation();
    }

    public static TxnCancellationChargeCalculationRequest of(
            final RemittanceTransactionCancellationRequest txnCancellationRequest,
            final RateDisplayMachenism rateDisplayMachenism, final VDWType valueDateWise, final BigDecimal rate) {
        return new TxnCancellationChargeCalculationRequest(txnCancellationRequest, rateDisplayMachenism, valueDateWise, rate);
    }
}
