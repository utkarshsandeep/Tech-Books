package com.unimoni.pricingengine.domain.model.enquiry;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@ToString
public abstract class StreamRequest {

    public static final int MAX_BATCH_SIZE = 1000;

    public static final int DEFAULT_BATCH_SIZE = 200;

    private int nextIndex;

    private int batchSize;
    
    protected abstract int endIndex();
}
