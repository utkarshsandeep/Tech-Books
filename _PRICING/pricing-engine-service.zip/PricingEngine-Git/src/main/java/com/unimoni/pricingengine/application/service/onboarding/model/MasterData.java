package com.unimoni.pricingengine.application.service.onboarding.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.money.CurrencyUnit;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.unimoni.pricingengine.application.service.onboarding.client.AgentOnboardingClient;
import com.unimoni.pricingengine.application.service.onboarding.client.BankOnboardingClient;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.BankWiseAgentPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.BankWiseAgentRequest;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.BankWiseDataPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.BankWiseDataRequest;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.CountryPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.CurrencyPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.NormalDataPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.NormalDataRequest;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.ServiceProviderPayload;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.common.enums.standard.CurrencyCode;
import com.unimoni.pricingengine.common.exception.MasterDataValidationException;
import com.unimoni.pricingengine.common.exception.MasterDataValidationException.MasterDataValidationExceptionType;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;
import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;
import com.unimoni.pricingengine.domain.model.common.dto.Triplet;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.standardcharges.OriginDestination.ODType;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MasterData {

    @Autowired
    private BankOnboardingClient bankOnboardingClient;

    @Autowired
    private AgentOnboardingClient agentOnboardingClient;

    private Map<String, String> allCurrenciesMap;

    private Map<String, String> allCountriesMap;

    private List<Product> allInstruments;

    private BiMap<Long, String> agentIdDisplayCodeBiMap;

    private Map<Long, Long> agentIdByAgentBranchIdMap;

    private BiMap<Long, String> agentBranchIdDisplayCodeBiMap;

    private Map<String, Optional<BranchRateSetting>> agentBranchDisplayCodeBranchRateSettingMap;

    private Map<String, Optional<RateDisplayMachenism>> agentDisplayCodeRateDisplayMechanismMap;

    private Map<String, ServiceProvider> serviceProviderByCodeMap = new ConcurrentHashMap<>();

    private boolean agentDataInitialized;

    private boolean bankDataInitialized;

    private boolean beanInitialized;

    public boolean isAgentDataInitialized() {
        return this.agentDataInitialized;
    }

    public boolean isBankDataInitialized() {
        return this.bankDataInitialized;
    }

    public boolean isBeanInitialized() {
        return this.beanInitialized;
    }

    public String getAgentCodeByBranchCode(final String branchCode) {
        Long agentBranchId = this.agentBranchIdDisplayCodeBiMap.inverse().get(branchCode);
        Long agentId = this.agentIdByAgentBranchIdMap.get(agentBranchId);
        return this.agentIdDisplayCodeBiMap.get(agentId);
    }

    public Optional<String> getAgentBranchCode(final Long agentBranchId) {
        return Optional.ofNullable(this.agentBranchIdDisplayCodeBiMap.get(agentBranchId));
    }

    public Optional<Long> getAgentBranchId(final String agentBranchCode) {
        return Optional.ofNullable(this.agentBranchIdDisplayCodeBiMap.inverse().get(agentBranchCode));
    }

    public Optional<BranchRateSetting> getAgentBranchRateSettings(final String agentBranchCode) {
        return this.agentBranchDisplayCodeBranchRateSettingMap.containsKey(agentBranchCode)
                ? this.agentBranchDisplayCodeBranchRateSettingMap.get(agentBranchCode)
                : Optional.empty();
    }

    public Optional<String> getAgentCode(final Long agentId) {
        return Optional.ofNullable(this.agentIdDisplayCodeBiMap.get(agentId));
    }

    public Optional<Long> getAgentId(final String agentCode) {
        return Optional.ofNullable(this.agentIdDisplayCodeBiMap.inverse().get(agentCode));
    }

    public Optional<Long> getAgentIdByBranchId(final Long agentBranchId) {
        return Optional.ofNullable(this.agentIdByAgentBranchIdMap.get(agentBranchId));
    }

    public Optional<Pair<Long, String>> getAgentIdAndCodeByBranchId(final Long agentBranchId) {
        Long agentId = this.agentIdByAgentBranchIdMap.get(agentBranchId);
        if (agentId == null) {
            return Optional.empty();
        }
        String agentCode = this.agentIdDisplayCodeBiMap.get(agentId);
        if (agentCode == null) {
            return Optional.empty();
        }

        return Optional.ofNullable(ImmutablePair.of(agentId, agentCode));
    }

    public RateDisplayMachenism getAgentOrBranchRateDisplayMechanism(final String agentOrBranchCode) {
        Optional<RateDisplayMachenism> rateDisplayMechanism = this.agentDisplayCodeRateDisplayMechanismMap
                .get(agentOrBranchCode);
        if (rateDisplayMechanism != null && rateDisplayMechanism.isPresent()) {
            return rateDisplayMechanism.get();
        }
        else {
            Optional<BranchRateSetting> branchRateSetting = this.agentBranchDisplayCodeBranchRateSettingMap
                    .get(agentOrBranchCode);
            if (branchRateSetting != null && branchRateSetting.isPresent()) {
                return branchRateSetting.get().getRateDisplayMachenism();
            }
            else {
                return RateDisplayMachenism.BC_TO_FC;
            }
        }
    }

    public synchronized void initialize() throws InterruptedException, ExecutionException {
        log.info("******************* Initializing master data starts *******************");

        this.beanInitialized = false;

        StopWatch watch = new StopWatch();
        watch.start();

        CompletableFuture<Map<String, String>> initializeCurrenciesFuture = initializeCurrencies();
        CompletableFuture<Map<String, String>> initializeCountriesFuture = initializeCountries();

        initializeInstruments();

        this.allCurrenciesMap = initializeCurrenciesFuture.get();
        this.allCountriesMap = initializeCountriesFuture.get();

        List<CodeNamePair<String, String>> allServiceProviderPairs = initializeServiceProviders().get();

        List<String> allServiceProviderCodes = allServiceProviderPairs.stream().map(CodeNamePair::getCode)
                .collect(Collectors.toList());

        Map<String, List<Agent>> normalAgentsByServiceProviderCodeMap = initializeAgents(allServiceProviderCodes);

        Map<String, List<Bank>> bankItemsByServiceProviderCode = initializeBanks(allServiceProviderCodes);

        initializeServiceProviderMap(allServiceProviderPairs, normalAgentsByServiceProviderCodeMap,
                bankItemsByServiceProviderCode);

        watch.split();
        watch.stop();
        log.info("************ Master Data initialization completed in: " + watch.toSplitString()
                + " *******************");
    }

    public synchronized void initializeInstruments() {
        this.allInstruments = this.bankOnboardingClient.getAllInstruments().products();
    }

    private synchronized CompletableFuture<Map<String, String>> initializeCountries()
            throws InterruptedException, ExecutionException {
        log.info("------------- Initializing countries -----------------");
        StopWatch watch = new StopWatch();
        watch.start();

        CompletableFuture<Map<String, String>> results = CompletableFuture
                .supplyAsync(() -> this.bankOnboardingClient.getAllCountries())
                .thenApplyAsync(x -> x.stream().filter(CountryPayload::isEnabled).distinct()
                        .collect(Collectors.toMap(country -> country.getCode(), country -> country.getName(),
                                (e1, e2) -> e1, ConcurrentHashMap::new)));

        watch.split();
        watch.stop();
        log.info("------------- Countries initialization completed in: " + watch.toSplitString() + "------------- ");

        return results;
    }

    private synchronized CompletableFuture<Map<String, String>> initializeCurrencies()
            throws InterruptedException, ExecutionException {
        log.info("------------- Initializing Currencies -----------------");
        StopWatch watch = new StopWatch();
        watch.start();

        CompletableFuture<Map<String, String>> results = CompletableFuture
                .supplyAsync(() -> this.bankOnboardingClient.getAllCurrencies())
                .thenApplyAsync(x -> x.stream().filter(CurrencyPayload::isEnabled).distinct()
                        .collect(Collectors.toMap(currency -> currency.getCode(), currency -> currency.getName(),
                                (e1, e2) -> e1, ConcurrentHashMap::new)));

        watch.split();
        watch.stop();
        log.info("------------- Currencies initialization completed in: " + watch.toSplitString() + "------------- ");

        return results;
    }

    private synchronized CompletableFuture<List<CodeNamePair<String, String>>> initializeServiceProviders() {
        log.info("------------- Initializing Service Providers -----------------");
        StopWatch watch = new StopWatch();
        watch.start();

        CompletableFuture<List<CodeNamePair<String, String>>> results = CompletableFuture
                .supplyAsync(() -> this.bankOnboardingClient.getAllServiceProviders())
                .thenApplyAsync(x -> x.stream().distinct().filter(ServiceProviderPayload::isEnabled).map(sp -> {
                    return sp.pair();
                }).collect(Collectors.toCollection(CopyOnWriteArrayList::new)));

        watch.split();
        watch.stop();
        log.info("------------- Service Providers initialization completed in: " + watch.toSplitString()
                + "------------- ");
        return results;
    }

    public synchronized Map<String, List<Agent>> initializeAgents(final List<String> allServiceProviderCodes) {
        log.info("------------- Initializing Agents data -----------------");

        this.agentDataInitialized = false;
        try {
            StopWatch watch = new StopWatch();
            watch.start();

            NormalDataRequest normalDataRequest = NormalDataRequest.of(allServiceProviderCodes);

            List<NormalDataPayload> allNormalDataPayload = this.agentOnboardingClient
                    .getAllNormalData(normalDataRequest).getPayload();

            BiMap<Long, String> tempAgentBranchIdDisplayCodeBiMap = HashBiMap.create(new ConcurrentHashMap<>());
            Map<String, Optional<BranchRateSetting>> tempAgentBranchDisplayCodeBranchRateSettingMap = new ConcurrentHashMap<>();
            Map<Long, Long> tempAgentIdByAgentBranchIdMap = new ConcurrentHashMap<>();
            BiMap<Long, String> tempAgentIdDisplayCodeBiMap = HashBiMap.create(new ConcurrentHashMap<>());
            Map<String, Optional<RateDisplayMachenism>> tempAgentDisplayCodeRateDisplayMechanismMap = new ConcurrentHashMap<>();

            Map<Pair<String, Long>, Set<Triple<String, String, String>>> normalInstrumentsByServiceProviderAndAgentIdMap = new ConcurrentHashMap<>();
            Map<Pair<String, Long>, List<AgentBranch>> normalAgentBranchesByServiceProviderAndAgentIdMap = allNormalDataPayload
                    .stream().filter(NormalDataPayload::isEnabled).map(x -> {
                        AgentBranch agentBranch = x.agentBranch(this.agentOnboardingClient, this.allCountriesMap);
                        if (!tempAgentBranchIdDisplayCodeBiMap.containsValue(agentBranch.getBranchDisplayCode())) {
                            tempAgentBranchIdDisplayCodeBiMap.put(agentBranch.getAgentBranchId(),
                                    agentBranch.getBranchDisplayCode());
                            Optional<BranchRateSetting> rateSettings = agentBranch.getBranchRateSetting();
                            tempAgentBranchDisplayCodeBranchRateSettingMap.put(agentBranch.getBranchDisplayCode(),
                                    rateSettings);
                        }
                        // else {
                        // log.info("Duplicate agentBranchDisplayCode -->" + agentBranch.getBranchDisplayCode());
                        // }
                        tempAgentIdByAgentBranchIdMap.put(x.getAgentBranchId(), x.getAgentId());
                        Pair<String, Long> spAgentKey = Pair.of(x.getServiceProviderCode(), x.getAgentId());
                        if (normalInstrumentsByServiceProviderAndAgentIdMap.containsKey(spAgentKey)) {
                            normalInstrumentsByServiceProviderAndAgentIdMap.get(spAgentKey).add(x.instruments());
                        }
                        else {
                            Set<Triple<String, String, String>> instruments = new HashSet<>();
                            instruments.add(x.instruments());
                            normalInstrumentsByServiceProviderAndAgentIdMap.put(spAgentKey, instruments);
                        }
                        return Pair.of(spAgentKey, agentBranch);
                    }).collect(Collectors.groupingBy(p -> p.getKey(),
                            Collectors.mapping(p -> p.getValue(), Collectors.toList())));

            Map<String, List<Agent>> normalAgentsByServiceProviderCodeMap = allNormalDataPayload.stream()
                    .filter(NormalDataPayload::isEnabled).map(x -> {
                        Pair<String, Long> serviceProviderAgentKey = Pair.of(x.getServiceProviderCode(),
                                x.getAgentId());
                        Agent agent = x.agent(this.allCountriesMap, // Was a bug, allCurrenciesMap was being passed
                                                                    // earlier, verify now
                                normalAgentBranchesByServiceProviderAndAgentIdMap.get(serviceProviderAgentKey),
                                normalInstrumentsByServiceProviderAndAgentIdMap.get(serviceProviderAgentKey));
                        if (!tempAgentIdDisplayCodeBiMap.containsValue(agent.getAgentDisplayCode())) {
                            tempAgentIdDisplayCodeBiMap.put(agent.getAgentId(), agent.getAgentDisplayCode());
                            tempAgentDisplayCodeRateDisplayMechanismMap.put(agent.getAgentDisplayCode(),
                                    Optional.ofNullable(agent.getRateDisplayMechanism()));
                        }
                        // else {
                        // log.info("Duplicate agentDisplayCode -->" + agent.getAgentDisplayCode());
                        // }
                        return Pair.of(x.getServiceProviderCode(), agent);
                    }).collect(Collectors.groupingBy(p -> p.getKey(),
                            Collectors.mapping(p -> p.getValue(), Collectors.toList())));

            this.agentBranchIdDisplayCodeBiMap = tempAgentBranchIdDisplayCodeBiMap;
            this.agentBranchDisplayCodeBranchRateSettingMap = tempAgentBranchDisplayCodeBranchRateSettingMap;
            this.agentIdByAgentBranchIdMap = tempAgentIdByAgentBranchIdMap;
            this.agentIdDisplayCodeBiMap = tempAgentIdDisplayCodeBiMap;
            this.agentDisplayCodeRateDisplayMechanismMap = tempAgentDisplayCodeRateDisplayMechanismMap;

            watch.split();
            watch.stop();
            log.info("------------- Agents data initialization completed in: " + watch.toSplitString()
                    + "------------- ");

            this.agentDataInitialized = true;
            return normalAgentsByServiceProviderCodeMap;
        }
        catch (final Exception e) {
            log.error("Error while agents data initialization", e);
            // e.printStackTrace();
        }
        return Collections.emptyMap();
    }

    public synchronized Map<String, List<Bank>> initializeBanks(final List<String> allServiceProviderCodes) {
        log.info("------------- Initializing Banks data -----------------");

        this.bankDataInitialized = false;
        try {
            StopWatch watch = new StopWatch();
            watch.start();

            List<BankWiseDataPayload> allBankWiseDataPayload = this.bankOnboardingClient
                    .getAllBankWiseData(BankWiseDataRequest.of(allServiceProviderCodes)).getPayload();

            Map<Pair<String, Long>, Set<Triple<String, String, String>>> bankWiseInstrumentsByServiceProviderAndBankIdMap = new ConcurrentHashMap<>();
            Map<Long, String> bankProductProfileIdToBankDisplayCodeMap = new HashMap<>();
            List<Long> allBankProductProfileIds = allBankWiseDataPayload.stream().filter(BankWiseDataPayload::isEnabled)
                    .map(x -> {
                        Pair<String, Long> spBankKey = Pair.of(x.getServiceProviderCode(), x.getDraweeBankId());
                        if (bankWiseInstrumentsByServiceProviderAndBankIdMap.containsKey(spBankKey)) {
                            bankWiseInstrumentsByServiceProviderAndBankIdMap.get(spBankKey).add(x.instruments());
                        }
                        else {
                            Set<Triple<String, String, String>> instruments = new HashSet<>();
                            instruments.add(x.instruments());
                            bankWiseInstrumentsByServiceProviderAndBankIdMap.put(spBankKey, instruments);
                        }
                        bankProductProfileIdToBankDisplayCodeMap.put(x.getDraweeBankProductProfileId(),
                                x.getBankDisplayCode());
                        return x.getDraweeBankProductProfileId();
                    }).collect(Collectors.toList());

            if (allBankProductProfileIds != null && !allBankProductProfileIds.isEmpty()) {
                BankWiseAgentRequest bankWiseAgentRequest = BankWiseAgentRequest.of(allBankProductProfileIds,
                        allServiceProviderCodes);

                List<BankWiseAgentPayload> allBankWiseAgentsPayload = this.bankOnboardingClient
                        .getBankWiseAgents(bankWiseAgentRequest).getPayload();

                Map<String, Map<String, List<String>>> bankWiseAgentIdToAgentBranchIdsByBankDisplayCodeMap = allBankWiseAgentsPayload
                        .stream().filter(x -> {
                            if (!x.isEnabled()) {
                                return false;
                            }
                            // BankWiseAgentPayload payload = x;
                            String agentDisplayCode = this.agentIdDisplayCodeBiMap.get(x.getAgentId());
                            String agentBranchDisplayCode = this.agentBranchIdDisplayCodeBiMap
                                    .get(x.getAgentBranchId());
                            if (agentDisplayCode == null || agentBranchDisplayCode == null) {
                                // log.info("Invalid Bankwise agent payload -->" + payload);
                                // log.info("Agent id:" + payload.getAgentId() + ", agentDisplayCode -->" +
                                // agentDisplayCode
                                // + " | agent branch Id: " + payload.getAgentBranchId() + " agentBranchDisplayCode -->"
                                // + agentBranchDisplayCode);
                                return false;
                            }
                            else {
                                return true;
                            }
                        }).map(x -> {
                            return Pair.of(
                                    bankProductProfileIdToBankDisplayCodeMap.get(x.getDraweeBankProductProfileId()),
                                    Pair.of(this.agentIdDisplayCodeBiMap.get(x.getAgentId()),
                                            this.agentBranchIdDisplayCodeBiMap.get(x.getAgentBranchId())));
                        })
                        .collect(Collectors.groupingBy(p -> p.getKey(),
                                Collectors.mapping(p -> p.getValue(), Collectors.toList())))
                        .entrySet().stream()
                        .collect(Collectors.toMap(e -> e.getKey(),
                                e -> e.getValue().stream().collect(Collectors.groupingBy(p -> p.getKey(),
                                        Collectors.mapping(p -> p.getValue(), Collectors.toList())))));

                Map<String, List<Bank>> bankItemsByServiceProviderCode = allBankWiseDataPayload.stream()
                        .filter(x -> x.isEnabled()).map(x -> {
                            Pair<String, Long> serviceProviderBankKey = Pair.of(x.getServiceProviderCode(),
                                    x.getDraweeBankId());
                            return Pair.of(x.getServiceProviderCode(), x.bank(this.allCurrenciesMap,
                                    bankWiseAgentIdToAgentBranchIdsByBankDisplayCodeMap.get(x.getBankDisplayCode()),
                                    bankWiseInstrumentsByServiceProviderAndBankIdMap.get(serviceProviderBankKey)));
                        }).collect(Collectors.groupingBy(p -> p.getKey(),
                                Collectors.mapping(p -> p.getValue(), Collectors.toList())));

                watch.split();
                watch.stop();
                log.info("------------- Banks data initialization completed in: " + watch.toSplitString()
                        + "------------- ");

                this.bankDataInitialized = true;
                return bankItemsByServiceProviderCode;
            }
            this.bankDataInitialized = true;
        }
        catch (final Exception e) {
            log.error("Error while banks data initialization", e);
            // e.printStackTrace();
        }
        return Collections.emptyMap();
    }

    public synchronized void initializeServiceProviderMap(
            final List<CodeNamePair<String, String>> allServiceProviderPairs,
            final Map<String, List<Agent>> normalAgentsByServiceProviderCodeMap,
            final Map<String, List<Bank>> bankItemsByServiceProviderCode) {

        log.info("------------- Initializing Service Providers Data Map -----------------");
        StopWatch watch = new StopWatch();
        watch.start();

        if (!isBeanInitialized() || (isAgentDataInitialized() && isBankDataInitialized())) {
            Map<String, ServiceProvider> tempServiceProviderByCodeMap = new ConcurrentHashMap<>();
            allServiceProviderPairs.stream().forEach(sp -> {
                ServiceProvider serviceProvider = ServiceProvider.of(sp.getCode(), sp.getName(),
                        bankItemsByServiceProviderCode.get(sp.getCode()),
                        normalAgentsByServiceProviderCodeMap.get(sp.getCode()));
                tempServiceProviderByCodeMap.put(sp.getCode(), serviceProvider);
            });

            this.serviceProviderByCodeMap = tempServiceProviderByCodeMap;
            this.beanInitialized = true;
        }
        watch.split();
        watch.stop();
        log.info("------------- Service Providers Data Map initialization completed in: " + watch.toSplitString()
                + "------------- ");
    }

    public synchronized void refreshAgentsAndBanksData() {
        if (isBeanInitialized()) {
            log.info("******************* Refreshing Agents and Banks data starts *******************");
            StopWatch watch = new StopWatch();
            watch.start();

            List<String> allServiceProviderCodes = this.serviceProviderByCodeMap.keySet().stream()
                    .collect(Collectors.toList());
            Map<String, List<Agent>> normalAgentsByServiceProviderCodeMap = initializeAgents(allServiceProviderCodes);
            Map<String, List<Bank>> bankItemsByServiceProviderCode = initializeBanks(allServiceProviderCodes);

            List<CodeNamePair<String, String>> allServiceProviderPairs = this.serviceProviderByCodeMap.values().stream()
                    .map(ServiceProvider::pair).collect(Collectors.toList());
            initializeServiceProviderMap(allServiceProviderPairs, normalAgentsByServiceProviderCodeMap,
                    bankItemsByServiceProviderCode);

            watch.split();
            watch.stop();
            log.info("************ Agents and Banks Data Refresh completed in: " + watch.toSplitString()
                    + " *******************");
        }
        else {
            log.info("Ignoring refreshAgentsAndBanksData on event as Master data is not initialized yet");
        }
    }

    public synchronized void refreshAgentsData() {
        log.info("******************* Refreshing Agents data starts *******************");
        StopWatch watch = new StopWatch();
        watch.start();

        List<String> allServiceProviderCodes = this.serviceProviderByCodeMap.keySet().stream()
                .collect(Collectors.toList());
        Map<String, List<Agent>> normalAgentsByServiceProviderCodeMap = initializeAgents(allServiceProviderCodes);

        this.serviceProviderByCodeMap.values()
                .forEach(sp -> sp.refreshAgents(normalAgentsByServiceProviderCodeMap.get(sp.getCode())));

        watch.split();
        watch.stop();
        log.info("************ Agents Data Refresh completed in: " + watch.toSplitString() + " *******************");
    }

    public synchronized void refreshBanksData() {
        log.info("******************* Refreshing Banks data starts *******************");
        StopWatch watch = new StopWatch();
        watch.start();

        List<String> allServiceProviderCodes = this.serviceProviderByCodeMap.keySet().stream()
                .collect(Collectors.toList());
        Map<String, List<Bank>> bankItemsByServiceProviderCode = initializeBanks(allServiceProviderCodes);

        this.serviceProviderByCodeMap.values()
                .forEach(sp -> sp.refreshBanks(bankItemsByServiceProviderCode.get(sp.getCode())));

        watch.split();
        watch.stop();
        log.info("************ Banks Data Refresh completed in: " + watch.toSplitString() + " *******************");
    }

    public List<CodeNamePair<String, String>> getAllServiceProviderPairs(final boolean includeAllOption) {
        List<CodeNamePair<String, String>> allSps = this.serviceProviderByCodeMap.values().stream()
                .map(ServiceProvider::pair).distinct().sorted().collect(ImmutableCollectors.toImmutableList());
        if (allSps != null && !allSps.isEmpty()) {
            if (includeAllOption) {
                List<CodeNamePair<String, String>> results = new ArrayList<>();
                results.add(CodeNamePair.ofAll());
                results.addAll(allSps);
                return results;
            }
            else {
                return allSps;
            }
        }
        else {
            return Collections.emptyList();
        }
    }

    public List<CodeNamePair<String, String>> getAllServiceProviderCodePairs(final boolean includeAllOption) {
        List<CodeNamePair<String, String>> allSps = this.serviceProviderByCodeMap.values().stream()
                .map(sp -> CodeNamePair.of(sp.getCode(), sp.getCode())).distinct().sorted().distinct().sorted()
                .collect(ImmutableCollectors.toImmutableList());
        if (allSps != null && !allSps.isEmpty()) {
            if (includeAllOption) {
                List<CodeNamePair<String, String>> results = new ArrayList<>();
                results.add(CodeNamePair.ofAll());
                results.addAll(allSps);
                return results;
            }
            else {
                return allSps;
            }
        }
        else {
            return Collections.emptyList();
        }
    }

    public List<CodeNamePair<String, String>> getAllCurrencyPairs(final boolean nameAsLabel,
            final boolean includeAllOption) {
        List<CodeNamePair<String, String>> currencies = this.allCurrenciesMap.entrySet().stream().map(e -> {
            return nameAsLabel ? CodeNamePair.of(e.getKey(), e.getValue()) : CodeNamePair.of(e.getKey(), e.getKey());
        }).distinct().sorted().collect(ImmutableCollectors.toImmutableList());
        if (includeAllOption && !currencies.isEmpty()) {
            List<CodeNamePair<String, String>> results = new ArrayList<>(currencies.size() + 1);
            results.add(CodeNamePair.ofAll());
            results.addAll(currencies);
            return results;
        }
        else {
            return currencies;
        }
    }

    public List<CodeNamePair<String, String>> getAllCountryPairs(final boolean nameAsLabel) {
        return this.allCountriesMap.entrySet().stream().map(e -> {
            return nameAsLabel ? CodeNamePair.of(e.getKey(), e.getValue()) : CodeNamePair.of(e.getKey(), e.getKey());
        }).distinct().sorted().collect(ImmutableCollectors.toImmutableList());
    }

    public List<CodeNamePair<String, String>> getAllProducts() {
        List<CodeNamePair<String, String>> products = this.allInstruments.stream().map(Product::pair).distinct()
                .sorted().collect(ImmutableCollectors.toImmutableList());
        if (products != null && !products.isEmpty()) {
            List<CodeNamePair<String, String>> results = new ArrayList<>();
            results.add(CodeNamePair.ofAll());
            results.addAll(products);
            return results;
        }
        else {
            return Collections.emptyList();
        }
    }

    public List<CodeNamePair<String, String>> getAllSubProducts(final List<String> products) {
        boolean filterProduct = products != null && !products.isEmpty();

        List<CodeNamePair<String, String>> subProducts = this.allInstruments.stream().filter(p -> {
            return filterProduct ? products.contains(p.getCode()) : true;
        }).map(Product::getSubProducts).flatMap(x -> x.stream()).distinct().sorted().map(SubProduct::pair)
                .collect(ImmutableCollectors.toImmutableList());
        if (subProducts != null && !subProducts.isEmpty()) {
            List<CodeNamePair<String, String>> results = new ArrayList<>();
            results.add(CodeNamePair.ofAll());
            results.addAll(subProducts);
            return results;
        }
        else {
            return Collections.emptyList();
        }
    }

    public List<CodeNamePair<String, String>> getAllServiceTypes(final List<String> products,
            final List<String> subProducts) {
        boolean filterProduct = products != null && !products.isEmpty();
        boolean filterSubProduct = subProducts != null && !subProducts.isEmpty();

        List<CodeNamePair<String, String>> serviceTypes = this.allInstruments.stream().filter(p -> {
            return filterProduct ? products.contains(p.getCode()) : true;
        }).map(Product::getSubProducts).flatMap(x -> x.stream()).filter(sp -> {
            return filterSubProduct ? subProducts.contains(sp.getCode()) : true;
        }).map(SubProduct::getServiceTypes).flatMap(x -> x.stream()).distinct().sorted().map(ServiceType::pair)
                .collect(ImmutableCollectors.toImmutableList());
        if (serviceTypes != null && !serviceTypes.isEmpty()) {
            List<CodeNamePair<String, String>> results = new ArrayList<>();
            results.add(CodeNamePair.ofAll());
            results.addAll(serviceTypes);
            return results;
        }
        else {
            return Collections.emptyList();
        }
    }

    public List<CodeNamePair<String, String>> getNormalAgentDisplayCodePairs(final List<String> serviceProviders) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        List<CodeNamePair<String, String>> agents = this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).distinct().sorted().map(Agent::pair)
                .collect(ImmutableCollectors.toImmutableList());
        if (agents != null && !agents.isEmpty()) {
            List<CodeNamePair<String, String>> results = new ArrayList<>();
            results.add(CodeNamePair.ofAll());
            results.addAll(agents);
            return results;
        }
        else {
            return Collections.emptyList();
        }
    }

    public List<CodeNamePair<String, String>> getBankWiseAgentDisplayCodePairs(final List<String> serviceProviders,
            final List<String> banks) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        boolean filterBank = banks != null && !banks.isEmpty();
        List<CodeNamePair<String, String>> agents = this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> e.getValue().getBanks()).flatMap(x -> x.stream()).filter(b -> {
            // System.out.println("Bank ->>" + b);
            return filterBank ? banks.contains(b.getBankDisplayCode()) : true;
        }).map(b -> b.getAgentsWithBranches().keySet()).flatMap(x -> x.stream()).sorted().map(a -> {
            // System.out.println("Agent ->>" + a);
            return CodeNamePair.of(a, a);
        }).distinct().collect(ImmutableCollectors.toImmutableList());
        if (agents != null && !agents.isEmpty()) {
            List<CodeNamePair<String, String>> results = new ArrayList<>();
            results.add(CodeNamePair.ofAll());
            results.addAll(agents);
            return results;
        }
        else {
            return Collections.emptyList();
        }
    }

    public List<CodeNamePair<String, String>> getBankDisplayCodePairs(final List<String> serviceProviders,
            final Boolean isAllExcluded) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();

        List<CodeNamePair<String, String>> banks = this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> e.getValue().getBanks()).flatMap(x -> x.stream()).distinct().sorted().map(Bank::pair)
                .collect(ImmutableCollectors.toImmutableList());
        if (banks != null && !banks.isEmpty()) {
            List<CodeNamePair<String, String>> results = new ArrayList<>();
            if (isAllExcluded == null || !isAllExcluded) {
                results.add(CodeNamePair.ofAll());
            }
            results.addAll(banks);
            return results;
        }
        else {
            return Collections.emptyList();
        }
    }

    public List<CodeNamePair<String, String>> getNormalForeignCurrencyPairs(final List<String> serviceProviders,
            final boolean nameAsLabel) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        return this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> e.getValue().getBanks()).flatMap(x -> x.stream()).map(Bank::getForiegnCurrency).map(x -> {
            return nameAsLabel ? x : CodeNamePair.of(x.getCode(), x.getCode());
        }).distinct().sorted().collect(ImmutableCollectors.toImmutableList());
    }

    public List<CodeNamePair<String, String>> getBankWiseForeignCurrencyPairs(final List<String> serviceProviders,
            final List<String> banks, final boolean nameAsLabel) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        boolean filterBank = banks != null && !banks.isEmpty();
        return this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> e.getValue().getBanks()).flatMap(x -> x.stream()).filter(Bank::isSpecificPricing).filter(b -> {
            return filterBank ? banks.contains(b.getBankDisplayCode()) : true;
        }).map(Bank::getForiegnCurrency).map(x -> {
            return nameAsLabel ? x : CodeNamePair.of(x.getCode(), x.getCode());
        }).distinct().sorted().collect(ImmutableCollectors.toImmutableList());
    }

    public List<CodeNamePair<String, String>> getBaseCurrencyPairs(final List<String> serviceProviders,
            final List<String> agents, final boolean nameAsLabel) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        boolean applyAgentsFilter = agents != null && !agents.isEmpty();
        final List<String> agentFilters = new ArrayList<>(applyAgentsFilter ? agents.size() : 0);
        final List<String> agentBranchFilters = new ArrayList<>(applyAgentsFilter ? agents.size() : 0);
        if (applyAgentsFilter) {
            agents.forEach(x -> {
                if (this.agentIdDisplayCodeBiMap.containsValue(x)) {
                    agentFilters.add(x);
                }
                if (this.agentBranchIdDisplayCodeBiMap.containsValue(x)) {
                    agentBranchFilters.add(x);
                }
            });
        }
        boolean filterAgent = agentFilters != null && !agentFilters.isEmpty();
        boolean filterAgentBranch = agentBranchFilters != null && !agentBranchFilters.isEmpty();

        return this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).filter(a -> {
            return filterAgent ? agentFilters.contains(a.getAgentDisplayCode()) : true;
        }).map(a -> a.getBranches()).flatMap(x -> x.stream()).filter(ab -> {
            return filterAgentBranch ? agentBranchFilters.contains(ab.getBranchDisplayCode()) : true;
        }).map(AgentBranch::getBaseCurrencies).flatMap(x -> x.stream()).distinct().sorted().map(x -> {
            return nameAsLabel ? x : CodeNamePair.of(x.getCode(), x.getCode());
        }).collect(ImmutableCollectors.toImmutableList());
    }

    public List<AgentListItem> getNormalAgentAndBranchItemsWithRDM(final List<String> serviceProviders) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        return this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).sorted().map(a -> {
            AgentListItem agentListItem = a.agentListItem();
            List<AgentBranch> branches = a.getBranches();
            if (branches != null && !branches.isEmpty()) {
                List<AgentListItem> listItems = new ArrayList<>(branches.size() + 1);
                listItems.add(agentListItem);
                branches.stream().sorted().forEach(b -> {
                    listItems.add(b.agentListItem());
                });
                return listItems;
            }
            else {
                List<AgentListItem> listItems = new ArrayList<>(1);
                listItems.add(agentListItem);
                return listItems;
            }
        }).flatMap(x -> x.stream()).distinct().collect(ImmutableCollectors.toImmutableList());
    }

    public List<AgentListItem> getBankWiseAgentAndBranchItemsWithRDM(final List<String> serviceProviders,
            final List<String> banks) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        boolean filterBank = banks != null && !banks.isEmpty();
        return this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> e.getValue().getBanks()).flatMap(x -> x.stream()).filter(b -> {
            return filterBank ? banks.contains(b.getBankDisplayCode()) : true;
        }).map(bank -> bank.getAgentsWithBranches().entrySet()).flatMap(x -> x.stream())
                .sorted(Map.Entry.comparingByKey()).map(a -> {
                    AgentListItem agentListItem = AgentListItem.ofAgent(
                            this.agentIdDisplayCodeBiMap.inverse().get(a.getKey()), a.getKey(), a.getKey(),
                            this.agentDisplayCodeRateDisplayMechanismMap.get(a.getKey()).orElse(null));
                    List<String> branches = a.getValue();
                    if (branches != null && !branches.isEmpty()) {
                        List<AgentListItem> listItems = new ArrayList<>(branches.size() + 1);
                        listItems.add(agentListItem);
                        branches.stream().sorted().forEach(b -> {
                            RateDisplayMachenism rdm = this.agentBranchDisplayCodeBranchRateSettingMap.get(b)
                                    .isPresent()
                                            ? this.agentBranchDisplayCodeBranchRateSettingMap.get(b).get()
                                                    .getRateDisplayMachenism()
                                            : null;
                            AgentListItem branchListItem = AgentListItem.ofBranch(
                                    this.agentBranchIdDisplayCodeBiMap.inverse().get(b), b, b, rdm,
                                    agentListItem.getId());
                            listItems.add(branchListItem);
                        });
                        return listItems;
                    }
                    else {
                        List<AgentListItem> listItems = new ArrayList<>(1);
                        listItems.add(agentListItem);
                        return listItems;
                    }
                }).flatMap(x -> x.stream()).distinct().collect(ImmutableCollectors.toImmutableList());
    }

    public List<CodeNamePair<String, String>> getSources() {
        List<CodeNamePair<String, String>> sources = new ArrayList<>();
        sources.add(CodeNamePair.ofAll());

        List<CodeNamePair<String, String>> agents = this.serviceProviderByCodeMap.entrySet().stream()
                .map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).sorted().map(a -> {
                    CodeNamePair<String, String> agentListItem = a.pair();
                    List<AgentBranch> branches = a.getBranches();
                    if (branches != null && !branches.isEmpty()) {
                        List<CodeNamePair<String, String>> listItems = new ArrayList<>(branches.size() + 1);
                        listItems.add(agentListItem);
                        branches.stream().sorted().forEach(b -> {
                            listItems.add(b.pair());
                        });
                        return listItems;
                    }
                    else {
                        List<CodeNamePair<String, String>> listItems = new ArrayList<>(1);
                        listItems.add(agentListItem);
                        return listItems;
                    }
                }).flatMap(x -> x.stream()).distinct().collect(Collectors.toList());

        // List<CodeNamePair<String, String>> agents = this.serviceProviderByCodeMap.entrySet().stream()
        // .map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).distinct().sorted().map(Agent::pair)
        // .collect(ImmutableCollectors.toImmutableList());

        sources.addAll(agents);

        sources.addAll(this.allCountriesMap.entrySet().stream()
                .map(e -> CodeNamePair.of(e.getKey(), e.getKey() + "(" + e.getValue() + ")")).distinct().sorted()
                .collect(ImmutableCollectors.toImmutableList()));
        return sources;
    }

    public List<Triplet<String, String, ODType>> getSourceTriplets() {
        List<Triplet<String, String, ODType>> sources = new ArrayList<>();
        sources.add(Triplet.allOD());

        List<Triplet<String, String, ODType>> agents = this.serviceProviderByCodeMap.entrySet().stream()
                .map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).sorted().map(a -> {
                    Triplet<String, String, ODType> agentListItem = Triplet.ofAgent(a.pair());
                    List<AgentBranch> branches = a.getBranches();
                    if (branches != null && !branches.isEmpty()) {
                        List<Triplet<String, String, ODType>> listItems = new ArrayList<>(branches.size() + 1);
                        listItems.add(agentListItem);
                        branches.stream().sorted().forEach(b -> {
                            listItems.add(Triplet.ofOD(b.pair(), ODType.BRANCH));
                        });
                        return listItems;
                    }
                    else {
                        List<Triplet<String, String, ODType>> listItems = new ArrayList<>(1);
                        listItems.add(agentListItem);
                        return listItems;
                    }
                }).flatMap(x -> x.stream()).distinct().collect(Collectors.toList());

        sources.addAll(agents);

        sources.addAll(this.allCountriesMap.entrySet().stream()
                .map(e -> CodeNamePair.of(e.getKey(), e.getKey() + "(" + e.getValue() + ")")).distinct().sorted()
                .map(Triplet::ofCountry).collect(ImmutableCollectors.toImmutableList()));
        return sources;
    }

    public List<Triplet<String, String, ODType>> getDestinationTriplets() {
        List<Triplet<String, String, ODType>> sources = new ArrayList<>();
        sources.add(Triplet.allOD());

        List<Triplet<String, String, ODType>> agents = this.serviceProviderByCodeMap.entrySet().stream()
                .map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).distinct().sorted().map(Agent::pair)
                .map(Triplet::ofAgent).collect(ImmutableCollectors.toImmutableList());

        sources.addAll(agents);

        sources.addAll(this.serviceProviderByCodeMap.entrySet().stream().map(e -> e.getValue().getBanks())
                .flatMap(x -> x.stream()).filter(distinctByKey(Bank::getBankDisplayCode)).sorted().map(Bank::pair)
                .map(Triplet::ofBank).collect(ImmutableCollectors.toImmutableList()));

        sources.addAll(this.allCountriesMap.entrySet().stream()
                .map(e -> CodeNamePair.of(e.getKey(), e.getKey() + " (" + e.getValue() + ")")).distinct().sorted()
                .map(Triplet::ofCountry).collect(ImmutableCollectors.toImmutableList()));
        return sources;
    }

    public List<CodeNamePair<String, String>> getDestinations() {
        List<CodeNamePair<String, String>> sources = new ArrayList<>();
        sources.add(CodeNamePair.ofAll());

        // List<CodeNamePair<String, String>> agents = this.serviceProviderByCodeMap.entrySet().stream()
        // .map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).sorted().map(a -> {
        // CodeNamePair<String, String> agentListItem = a.pair();
        // List<AgentBranch> branches = a.getBranches();
        // if (branches != null && !branches.isEmpty()) {
        // List<CodeNamePair<String, String>> listItems = new ArrayList<>(branches.size() + 1);
        // listItems.add(agentListItem);
        // branches.forEach(b -> {
        // listItems.add(b.pair());
        // });
        // return listItems;
        // }
        // else {
        // List<CodeNamePair<String, String>> listItems = new ArrayList<>(1);
        // listItems.add(agentListItem);
        // return listItems;
        // }
        // }).flatMap(x -> x.stream()).distinct().collect(Collectors.toList());

        List<CodeNamePair<String, String>> agents = this.serviceProviderByCodeMap.entrySet().stream()
                .map(e -> e.getValue().getAgents()).flatMap(x -> x.stream()).distinct().sorted().map(Agent::pair)
                .collect(ImmutableCollectors.toImmutableList());

        sources.addAll(agents);

        sources.addAll(this.serviceProviderByCodeMap.entrySet().stream().map(e -> e.getValue().getBanks())
                .flatMap(x -> x.stream()).filter(distinctByKey(Bank::getBankDisplayCode)).sorted().map(Bank::pair)
                .collect(ImmutableCollectors.toImmutableList()));

        sources.addAll(this.allCountriesMap.entrySet().stream()
                .map(e -> CodeNamePair.of(e.getKey(), e.getKey() + " (" + e.getValue() + ")")).distinct().sorted()
                .collect(ImmutableCollectors.toImmutableList()));
        return sources;
    }

    /**
     * @param bankCode
     * @return
     * @return matched bankcode on customer fee UI, for Swift charge type
     */
    public List<CodeNamePair<String, String>> getMatchedBankCode(List<String> bankCodeList) {
        return this.serviceProviderByCodeMap.entrySet().stream().map(e -> e.getValue().getBanks())
                .flatMap(x -> x.stream()).filter(distinctByKey(Bank::getBankDisplayCode)).sorted().map(Bank::pair)
                .filter(e -> bankCodeList.contains(e.getCode())).collect(ImmutableCollectors.toImmutableList());
    }

    public static <T> Predicate<T> distinctByKey(final Function<? super T, ?> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    private List<String> replaceBranchesWithAgentCodes(final List<String> agentOrBranches) {
        if (agentOrBranches != null && !agentOrBranches.isEmpty()) {
            return agentOrBranches.stream().map(x -> {
                if (this.agentIdDisplayCodeBiMap.containsValue(x)) {
                    return x;
                }
                else {
                    return getAgentCodeByBranchCode(x);
                }
            }).distinct().collect(Collectors.toList());
        }
        else {
            return agentOrBranches;
        }
    }

    public List<CodeNamePair<String, String>> getPartnerProducts(final RMType rmType,
            final List<String> serviceProviders, final List<String> partners) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        final List<String> validPartners = rmType.isNormal() ? replaceBranchesWithAgentCodes(partners) : partners;
        boolean filterPartner = validPartners != null && !validPartners.isEmpty();

        List<CodeNamePair<String, String>> results = new ArrayList<>();
        results.add(CodeNamePair.ofAll());
        results.addAll(this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> rmType.isNormal() ? e.getValue().getAgents() : e.getValue().getBanks()).flatMap(x -> x.stream())
                .filter(p -> {
                    return filterPartner ? validPartners.contains(p.getCode()) : true;
                }).map(Partner::productPairs).flatMap(x -> x.stream()).distinct().sorted()
                .collect(ImmutableCollectors.toImmutableList()));

        return results;
    }

    public List<CodeNamePair<String, String>> getPartnerSubProducts(final RMType rmType,
            final List<String> serviceProviders, final List<String> partners, final List<String> products) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        final List<String> validPartners = rmType.isNormal() ? replaceBranchesWithAgentCodes(partners) : partners;
        boolean filterPartner = validPartners != null && !validPartners.isEmpty();

        List<CodeNamePair<String, String>> results = new ArrayList<>();
        results.add(CodeNamePair.ofAll());
        results.addAll(this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> rmType.isNormal() ? e.getValue().getAgents() : e.getValue().getBanks()).flatMap(x -> x.stream())
                .filter(p -> {
                    return filterPartner ? validPartners.contains(p.getCode()) : true;
                }).map(partner -> partner.subProductPairs(products)).flatMap(x -> x.stream()).distinct().sorted()
                .collect(ImmutableCollectors.toImmutableList()));

        return results;
    }

    public List<CodeNamePair<String, String>> getPartnerServiceTypes(final RMType rmType,
            final List<String> serviceProviders, final List<String> partners, final List<String> products,
            final List<String> subProducts) {
        boolean filterSP = serviceProviders != null && !serviceProviders.isEmpty();
        final List<String> validPartners = rmType.isNormal() ? replaceBranchesWithAgentCodes(partners) : partners;
        boolean filterPartner = validPartners != null && !validPartners.isEmpty();

        List<CodeNamePair<String, String>> results = new ArrayList<>();
        results.add(CodeNamePair.ofAll());
        results.addAll(this.serviceProviderByCodeMap.entrySet().stream().filter(e -> {
            return filterSP ? serviceProviders.contains(e.getKey()) : true;
        }).map(e -> rmType.isNormal() ? e.getValue().getAgents() : e.getValue().getBanks()).flatMap(x -> x.stream())
                .filter(p -> {
                    return filterPartner ? validPartners.contains(p.getCode()) : true;
                }).map(partner -> partner.serviceTypePairs(products, subProducts)).flatMap(x -> x.stream()).distinct()
                .sorted().collect(ImmutableCollectors.toImmutableList()));

        return results;
    }

    public List<CodeNamePair<String, String>> getBankWiseOrNomalWiseUniqueAgentDisplayCodePairs(
            final List<String> serviceProviders, final List<String> banks, final String bankWise,
            final String normalWise) {
        final Set<CodeNamePair<String, String>> setCodeName = new LinkedHashSet<CodeNamePair<String, String>>();

        if (normalWise == null && bankWise == null) {
            setCodeName.addAll(getNormalAgentDisplayCodePairs(serviceProviders));
        }
        else {
            if (normalWise != null && RMType.NORMAL.name().equals(normalWise)) {
                setCodeName.addAll(getNormalAgentDisplayCodePairs(serviceProviders));
            }

            if (bankWise != null && RMType.BANK_WISE.name().equals(bankWise)) {
                setCodeName.addAll(getBankWiseAgentDisplayCodePairs(serviceProviders, banks));
            }
        }

        setCodeName.removeIf(item -> item.equals(CodeNamePair.ofAll()));

        return new ArrayList<>(setCodeName);
    }

    public List<String> validateServiceProviders(final Set<String> serviceProviders) {
        if (serviceProviders == null || serviceProviders.isEmpty()
                || serviceProviders.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return this.serviceProviderByCodeMap.keySet().stream().sorted()
                    .collect(ImmutableCollectors.toImmutableList());
        }
        else {
            SetView<String> difference = Sets.difference(serviceProviders, this.serviceProviderByCodeMap.keySet());
            if (difference.isEmpty()) {
                return serviceProviders.stream().sorted().collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_SERVICE_PROVIDERS,
                        difference.toString());
            }
        }
    }

    public List<String> validateProducts(final Set<String> products) {
        if (products == null || products.isEmpty() || products.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return this.allInstruments.stream().map(Product::getCode).distinct().sorted()
                    .collect(ImmutableCollectors.toImmutableList());
        }
        else {
            Set<String> allProducts = this.allInstruments.stream().map(Product::getCode).collect(Collectors.toSet());
            SetView<String> difference = Sets.difference(products, allProducts);
            if (difference.isEmpty()) {
                return products.stream().sorted().collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_PRODUCTS,
                        difference.toString());
            }
        }
    }

    public List<String> validateSubProducts(final Set<String> subProducts) {
        if (subProducts == null || subProducts.isEmpty()
                || subProducts.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return this.allInstruments.stream().map(Product::getSubProducts).flatMap(x -> x.stream())
                    .map(SubProduct::getCode).distinct().sorted().collect(ImmutableCollectors.toImmutableList());
        }
        else {
            Set<String> allSubProducts = this.allInstruments.stream().map(Product::getSubProducts)
                    .flatMap(x -> x.stream()).map(SubProduct::getCode).distinct().collect(Collectors.toSet());
            SetView<String> difference = Sets.difference(subProducts, allSubProducts);
            if (difference.isEmpty()) {
                return subProducts.stream().sorted().collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_SUB_PRODUCTS,
                        difference.toString());
            }
        }
    }

    public List<String> validateServiceTypes(final Set<String> serviceTypes) {
        if (serviceTypes == null || serviceTypes.isEmpty()
                || serviceTypes.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return this.allInstruments.stream().map(Product::getSubProducts).flatMap(x -> x.stream())
                    .map(SubProduct::getServiceTypes).flatMap(x -> x.stream()).map(ServiceType::getCode).distinct()
                    .sorted().collect(ImmutableCollectors.toImmutableList());
        }
        else {
            Set<String> allServiceTypes = this.allInstruments.stream().map(Product::getSubProducts)
                    .flatMap(x -> x.stream()).map(SubProduct::getServiceTypes).flatMap(x -> x.stream())
                    .map(ServiceType::getCode).distinct().collect(Collectors.toSet());
            SetView<String> difference = Sets.difference(serviceTypes, allServiceTypes);
            if (difference.isEmpty()) {
                return serviceTypes.stream().sorted().collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_SERVICE_TYPES,
                        difference.toString());
            }
        }
    }

    public List<String> validateBanks(final Set<String> banks) {
        if (banks == null || banks.isEmpty() || banks.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return this.serviceProviderByCodeMap.values().stream().map(ServiceProvider::getBanks)
                    .flatMap(x -> x.stream()).map(Bank::getCode).distinct().sorted()
                    .collect(ImmutableCollectors.toImmutableList());
        }
        else {
            Set<String> allBanks = this.serviceProviderByCodeMap.values().stream().map(ServiceProvider::getBanks)
                    .flatMap(x -> x.stream()).map(Bank::getCode).distinct().collect(Collectors.toSet());
            SetView<String> difference = Sets.difference(banks, allBanks);
            if (difference.isEmpty()) {
                return banks.stream().sorted().collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_SUB_PRODUCTS,
                        difference.toString());
            }
        }
    }

    public List<String> validateNormalAgent(final Set<String> agents) {
        if (agents == null || agents.isEmpty() || agents.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return this.serviceProviderByCodeMap.values().stream().map(ServiceProvider::getAgents)
                    .flatMap(x -> x.stream()).map(Agent::getCode).distinct().sorted()
                    .collect(ImmutableCollectors.toImmutableList());
        }
        else {
            Set<String> allAgents = this.serviceProviderByCodeMap.values().stream().map(ServiceProvider::getAgents)
                    .flatMap(x -> x.stream()).map(Agent::getCode).distinct().collect(Collectors.toSet());
            SetView<String> difference = Sets.difference(agents, allAgents);
            if (difference.isEmpty()) {
                return agents.stream().sorted().collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_AGENTS,
                        difference.toString());
            }
        }
    }

    public List<AgentDetails> validateNormalAgentOrBranch(final Set<String> agentsOrBranches) {
        List<AgentDetails> allAgentOrBranchDetails = this.serviceProviderByCodeMap.values().stream()
                .map(v -> v.getAgents()).flatMap(x -> x.stream()).sorted().map(a -> {
                    AgentDetails agentListItem = a.details();
                    List<AgentBranch> branches = a.getBranches();
                    if (branches != null && !branches.isEmpty()) {
                        List<AgentDetails> listItems = new ArrayList<>(branches.size() + 1);
                        listItems.add(agentListItem);
                        branches.stream().forEach(b -> {
                            listItems.add(b.details());
                        });
                        return listItems;
                    }
                    else {
                        List<AgentDetails> listItems = new ArrayList<>(1);
                        listItems.add(agentListItem);
                        return listItems;
                    }
                }).flatMap(x -> x.stream()).filter(a -> a.getRateDisplayMechanism() != null).distinct().sorted()
                .collect(ImmutableCollectors.toImmutableList());

        if (agentsOrBranches == null || agentsOrBranches.isEmpty()
                || agentsOrBranches.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return allAgentOrBranchDetails;
        }
        else {
            Set<String> allAgentOrBranchCodes = allAgentOrBranchDetails.stream().map(AgentDetails::getCode)
                    .collect(Collectors.toSet());

            SetView<String> difference = Sets.difference(agentsOrBranches, allAgentOrBranchCodes);
            if (difference.isEmpty()) {
                return allAgentOrBranchDetails.stream().filter(a -> agentsOrBranches.contains(a.getCode())).sorted()
                        .collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_AGENTS_OR_BRANCHES,
                        difference.toString());
            }
        }
    }

    public List<AgentDetails> validateBankWiseAgentOrBranch(final Set<String> agentsOrBranches) {
        List<AgentDetails> allAgentOrBranchDetails = this.serviceProviderByCodeMap.values().stream()
                .map(x -> x.getBanks()).flatMap(x -> x.stream()).map(bank -> bank.getAgentsWithBranches().entrySet())
                .flatMap(x -> x.stream()).sorted(Map.Entry.comparingByKey()).map(a -> {
                    AgentDetails agentDetails = AgentDetails.ofAgent(a.getKey(),
                            this.agentDisplayCodeRateDisplayMechanismMap.get(a.getKey()).orElse(null));
                    List<String> branches = a.getValue();
                    if (branches != null && !branches.isEmpty()) {
                        List<AgentDetails> results = new ArrayList<>(branches.size() + 1);
                        results.add(agentDetails);
                        branches.stream().sorted().forEach(b -> {
                            RateDisplayMachenism rateDisplayMechanism = this.agentBranchDisplayCodeBranchRateSettingMap
                                    .get(b).isPresent()
                                            ? this.agentBranchDisplayCodeBranchRateSettingMap.get(b).get()
                                                    .getRateDisplayMachenism()
                                            : null;
                            results.add(AgentDetails.ofBranch(b, rateDisplayMechanism));
                        });
                        return results;
                    }
                    else {
                        List<AgentDetails> results = Collections.singletonList(agentDetails);
                        return results;
                    }
                }).flatMap(x -> x.stream()).filter(a -> a.getRateDisplayMechanism() != null).distinct()
                .collect(ImmutableCollectors.toImmutableList());

        if (agentsOrBranches == null || agentsOrBranches.isEmpty()
                || agentsOrBranches.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return allAgentOrBranchDetails;
        }
        else {
            Set<String> allAgentOrBranchCodes = allAgentOrBranchDetails.stream().map(AgentDetails::getCode)
                    .collect(Collectors.toSet());

            SetView<String> difference = Sets.difference(agentsOrBranches, allAgentOrBranchCodes);
            if (difference.isEmpty()) {
                return allAgentOrBranchDetails.stream().filter(a -> agentsOrBranches.contains(a.getCode())).sorted()
                        .collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_AGENTS_OR_BRANCHES,
                        difference.toString());
            }
        }
    }

    public List<String> validateBankWiseAgent(final Set<String> agents) {
        if (agents == null || agents.isEmpty() || agents.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return this.serviceProviderByCodeMap.values().stream().map(ServiceProvider::getBanks)
                    .flatMap(x -> x.stream()).map(bank -> bank.getAgentsWithBranches().keySet())
                    .flatMap(x -> x.stream()).distinct().sorted().collect(ImmutableCollectors.toImmutableList());
        }
        else {
            Set<String> allAgents = this.serviceProviderByCodeMap.values().stream().map(ServiceProvider::getBanks)
                    .flatMap(x -> x.stream()).map(bank -> bank.getAgentsWithBranches().keySet())
                    .flatMap(x -> x.stream()).distinct().collect(Collectors.toSet());
            SetView<String> difference = Sets.difference(agents, allAgents);
            if (difference.isEmpty()) {
                return agents.stream().sorted().collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_AGENTS,
                        difference.toString());
            }
        }
    }

    public List<CurrencyUnit> validateCurrencies(final Set<CurrencyUnit> currencies) {
        if (currencies == null || currencies.isEmpty() || currencies.contains(CurrencyCode.getAllCurrencyUnit())) {
            return this.allCurrenciesMap.keySet().stream().map(CurrencyCode::toCurrencyUnit).sorted()
                    .collect(ImmutableCollectors.toImmutableList());
        }
        else {
            Set<CurrencyUnit> allCurrrencies = this.allCurrenciesMap.keySet().stream().map(CurrencyCode::toCurrencyUnit)
                    .collect(Collectors.toSet());
            SetView<CurrencyUnit> difference = Sets.difference(currencies, allCurrrencies);
            if (difference.isEmpty()) {
                return currencies.stream().sorted().collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_CURRENCIES,
                        difference.toString());
            }
        }
    }

    public List<CurrencyUnit> validateCurrencies(final Set<CurrencyUnit> currencies,
            final Set<CurrencyUnit> availableCurrencies) {
        if (currencies == null || currencies.isEmpty() || currencies.contains(CurrencyCode.getAllCurrencyUnit())) {
            return availableCurrencies.stream().sorted().collect(ImmutableCollectors.toImmutableList());
        }
        else {
            Set<CurrencyUnit> allCurrrencies = this.allCurrenciesMap.keySet().stream().distinct()
                    .map(CurrencyCode::toCurrencyUnit).collect(Collectors.toSet());
            SetView<CurrencyUnit> difference = Sets.difference(currencies, allCurrrencies);
            if (difference.isEmpty()) {
                return Sets.intersection(currencies, availableCurrencies).stream().sorted()
                        .collect(ImmutableCollectors.toImmutableList());
            }
            else {
                throw new MasterDataValidationException(MasterDataValidationExceptionType.INVALID_CURRENCIES,
                        difference.toString());
            }
        }
    }

    public boolean validateBankWiseInstruments(final String serviceProvider, final String bank, final String agent) {
        ServiceProvider sp = this.serviceProviderByCodeMap.get(serviceProvider);
        for (Bank b : sp.getBanks()) {
            if (b.getBankDisplayCode().equals(bank) && b.getAgentsWithBranches().keySet().contains(agent)) {
                return true;
            }
        }
        return false;
    }

    public boolean validateNormalInstruments(final String serviceProvider, final String agent, final String product,
            final String subProduct, final String serviceType) {
        ServiceProvider sp = this.serviceProviderByCodeMap.get(serviceProvider);
        for (Agent a : sp.getAgents()) {
            if (a.getAgentDisplayCode().equals(agent)) {
                for (Product p : a.getProducts()) {
                    if (p.getCode().equals(product)) {
                        for (SubProduct subPrd : p.getSubProducts()) {
                            if (subPrd.getCode().equals(subProduct)) {
                                for (ServiceType st : subPrd.getServiceTypes()) {
                                    if (st.getCode().equals(serviceType)) {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean validateBankWiseInstruments(final String serviceProvider, final String bank, final String agent,
            final String product, final String subProduct, final String serviceType) {
        ServiceProvider sp = this.serviceProviderByCodeMap.get(serviceProvider);
        for (Bank b : sp.getBanks()) {
            if (b.getBankDisplayCode().equals(bank) && b.getAgentsWithBranches().keySet().contains(agent)) {
                for (Product p : b.getProducts()) {
                    if (p.getCode().equals(product)) {
                        for (SubProduct subPrd : p.getSubProducts()) {
                            if (subPrd.getCode().equals(subProduct)) {
                                for (ServiceType st : subPrd.getServiceTypes()) {
                                    if (st.getCode().equals(serviceType)) {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }
}
