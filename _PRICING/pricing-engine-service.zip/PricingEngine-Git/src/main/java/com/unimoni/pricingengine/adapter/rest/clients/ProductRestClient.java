package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.fasterxml.jackson.annotation.JsonProperty;

@FeignClient(name = "productClient", url = "http://bank-onboarding-service-snap.integration.apps.ocp.uaeexchange.com/api/v1/onboarding/productTypes")
public interface ProductRestClient {

    @GetMapping("/")
    GenericResponse<Product> getProductResponse();

    default List<Product> allProducts() {
        return getProductResponse().response;
    }

    class GenericResponse<T> {

        List<T> response;

        public GenericResponse(@JsonProperty("response") List<T> response) {
            this.response = response;
        }
    }
}
