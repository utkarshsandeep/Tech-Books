package com.unimoni.pricingengine.common.enums;

public interface MessageCodeType {

    public String key();

    public String defaultMessage();
}
