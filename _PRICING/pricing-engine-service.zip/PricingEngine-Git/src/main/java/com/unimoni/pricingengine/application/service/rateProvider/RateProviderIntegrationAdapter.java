package com.unimoni.pricingengine.application.service.rateProvider;

import java.io.IOException;
import java.util.Optional;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unimoni.pricingengine.application.events.ProvidedRateEvent;
import com.unimoni.pricingengine.common.annotation.spring.RateProviderIntegration;
import com.unimoni.pricingengine.domain.model.event.ProvidedRateDisabledEvent;
import com.unimoni.pricingengine.domain.model.event.ProvidedRateEnabledEvent;
import com.unimoni.pricingengine.domain.model.event.ProvidedRateFrequencyChangedEvent;
import com.unimoni.pricingengine.domain.model.rate.base.NormalBaseRate;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;
import com.unimoni.pricingengine.domain.service.rm.RateManagementService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Conditional(value = RateProviderIntegration.class)
@Component
public class RateProviderIntegrationAdapter {

    @Autowired
    private JmsTemplate jmsQueueTemplate;

    @Autowired
    private RateManagementService rateManagementService;

    private static final String NORMAL_BASE_RATE_CHANGE_EVENT_QUEUE = "PRICING.NORMAL_BASE_RATE_CHANGE_EVENTS";

    private static final String RATE_PROVIDER_RATE_CHANGE_QUEUE = "PRICING.RATE_PROVIDER_RATE_CHANGE_EVENTS";

//    @Autowired
//    private RateManagementRepository rateManagementRepository;
//
//    @PostConstruct
//    private void fireRateProviderEvents() {
//        List<NormalBaseRate> activeNonManualBaseRates = this.rateManagementRepository
//                .findEnabledNonManualNormalBaseRates();
//        activeNonManualBaseRates.forEach(rate -> {
//            publishEventToActiveMQ(
//                    ProvidedRateEnabledEvent.of(rate.rateProvider().id(), rate.id(), rate.ricId(), rate.frequency()));
//        });
//    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleThomsonProvidedRateEnabledEvent(final ProvidedRateEnabledEvent event) {
        log.info("RateProviderEventListner handleThomsonProvidedRateEnabledEvent for rateProviderId: {} "
                + "rateId: {}, ricId: {}", event.getRateProviderId(), event.getRateId(), event.getRicId());
        publishEventToActiveMQ(event);
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleThomsonProvidedRateDisabledEvent(final ProvidedRateDisabledEvent event) {
        log.info("RateProviderEventListner handleThomsonProvidedRateDisabledEvent for rateProviderId: {} "
                + "rateId: {}, ricId: {}", event.getRateProviderId(), event.getRateId(), event.getRicId());
        publishEventToActiveMQ(event);
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleThomsonProvidedRateFrequencyChangedEvent(final ProvidedRateFrequencyChangedEvent event) {
        log.info("RateProviderEventListner handleThomsonProvidedRateFrequencyChangedEvent for rateProviderId: {} "
                + "rateId: {}, ricId: {}", event.getRateProviderId(), event.getRateId(), event.getRicId());
        publishEventToActiveMQ(event);
    }

    private <T> void publishEventToActiveMQ(final T event) {
        this.jmsQueueTemplate.convertAndSend(NORMAL_BASE_RATE_CHANGE_EVENT_QUEUE, event);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @JmsListener(destination = RATE_PROVIDER_RATE_CHANGE_QUEUE, containerFactory = "queueListenerFactory")
    public void onProvidedRateEvent(final Message message) {
        if (message instanceof TextMessage) {
            try {
                ProvidedRateEvent providedRate = new ObjectMapper().readValue(((ActiveMQTextMessage) message).getText(),
                        ProvidedRateEvent.class);
                log.info(
                        "Event received for rateId: {} "
                                + "ricId: {}, askValue: {}, bidValue: {}",
                        providedRate.getRateId(), providedRate.getRicId(), providedRate.getAskValue(),
                        providedRate.getBidValue());

                Optional<NormalBaseRate> normalBaseRate = this.rateManagementService
                        .getNormalBaseRateById(providedRate.getRateId());
                if (normalBaseRate.isPresent()) {
                    normalBaseRate.get()
                            .updateRate(ExchangeRate.of(providedRate.getAskValue(), providedRate.getBidValue()));
                }
            }
            catch (IOException | JMSException e) {
                log.error("Exception occured while JMS event from  {} \n {}", RATE_PROVIDER_RATE_CHANGE_QUEUE, e);
            }
        }
        else {
            log.error("Message {} received from {} is not of type TextMessage", message,
                    RATE_PROVIDER_RATE_CHANGE_QUEUE);
        }
    }
}
