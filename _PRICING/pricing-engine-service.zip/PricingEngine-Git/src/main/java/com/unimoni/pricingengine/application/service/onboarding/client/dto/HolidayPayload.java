package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HolidayPayload {

    private boolean holiday;

    public HolidayPayload(final @JsonProperty("holiday") boolean holiday) {
        this.holiday = holiday;
    }

    public boolean isHoliday() {
        return this.holiday;
    }
}
