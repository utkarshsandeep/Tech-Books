package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
public class ColumnValueEdited {
    
    protected VDWType vdwType;
    
    @NotNull
    protected ColumnNameType columnName;
    
    protected BigDecimal oldValue;

    protected BigDecimal updatedValue;

}
