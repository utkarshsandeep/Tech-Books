package com.unimoni.pricingengine.domain.model.remittance;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "txnCancellationReason", description = "Remittance transaction Cancellation reasons")
public enum TxnCancellationReason {

    // @formatter:off
    AGENT_FAULT("Agent Fault"),
    CUSTOMER_WISH("Customer Wish"),
    SP_FAULT("Service Provider fault");
    // @formatter:on

    private final String description;
    
    private TxnCancellationReason(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }
    
    public boolean isAgentFault() {
        return this == AGENT_FAULT;
    }

    public boolean isCustomerWish() {
        return this == CUSTOMER_WISH;
    }

    public boolean isSPFault() {
        return this == SP_FAULT;
    }
}
