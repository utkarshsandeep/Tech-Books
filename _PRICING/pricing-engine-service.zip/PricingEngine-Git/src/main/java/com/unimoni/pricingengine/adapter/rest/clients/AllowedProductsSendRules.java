package com.unimoni.pricingengine.adapter.rest.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "ServiceProviderDetails", url = "http://agent-onboarding-service-snap.integration.apps.ocp.uaeexchange.com/onboarding/api/v1/agents/allowedProductsSendRules")
public interface AllowedProductsSendRules {

    @RequestMapping(path = "/", method = RequestMethod.POST, consumes = "application/json")
    ServiceProviderResponse getServiceProviderDetailsResponse(@RequestBody ServiceProviderPayload payload);

}
