package com.unimoni.pricingengine.domain.model.rate.var;

import java.util.Map;

import com.unimoni.pricingengine.domain.model.rate.Layer;

public interface ValueAtRisk extends Layer {
    
    public Map<VDWType, VaRValueDateWise> valueDateWises();
}
