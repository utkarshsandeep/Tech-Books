package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryCurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.var.dto.AllInstrumentsDTO;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode
@ToString
public class AgentRateIdentity {

    private AllInstrumentsDTO instruments;

    private AgentDetails agent;

    @JsonInclude(NON_NULL)
    private String bank;

    private CountryCurrencyDTO currency;

    public static AgentRateIdentity ofNormal(final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final AgentDetails agent,
            final CountryCurrencyDTO currency) {
        AgentRateIdentity agentAllIdentity = new AgentRateIdentity();
        agentAllIdentity.instruments = AllInstrumentsDTO.of(serviceProvider, product, subProduct, serviceType);
        agentAllIdentity.agent = agent;
        agentAllIdentity.currency = currency;
        return agentAllIdentity;
    }

    public static AgentRateIdentity ofBankWise(final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final AgentDetails agent, final String bank,
            final CountryCurrencyDTO currency) {
        AgentRateIdentity agentAllIdentity = ofNormal(serviceProvider, product, subProduct, serviceType, agent,
                currency);
        agentAllIdentity.bank = bank;
        return agentAllIdentity;
    }

    public Optional<String> getBank() {
        return Optional.ofNullable(this.bank);
    }

    @JsonIgnore
    public Optional<String> agentCodeIfBranch() {
        return agent.getType().isBranch()
                ? Optional.of(BeanFactory.masterData().getAgentCodeByBranchCode(this.agent.getCode()))
                : Optional.empty();
    }

    @JsonIgnore
    public boolean isAgent() {
        return this.getAgent().getType().isAgent();
    }

    @JsonIgnore
    public boolean isBranch() {
        return this.getAgent().getType().isBranch();
    }
}
