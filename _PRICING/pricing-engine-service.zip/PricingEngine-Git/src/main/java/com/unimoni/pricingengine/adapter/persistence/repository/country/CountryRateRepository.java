package com.unimoni.pricingengine.adapter.persistence.repository.country;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.rate.country.CountryRate;

public interface CountryRateRepository extends JpaRepository<CountryRate, String>, CountryRateRepositoryJPA {

}
