package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.application.service.onboarding.model.ServiceType;
import com.unimoni.pricingengine.application.service.onboarding.model.SubProduct;

import lombok.ToString;

@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubProductPayload {

    private String code;

    private List<String> serviceTypes;

    public SubProductPayload(@JsonProperty("subProduct") String subProduct,
            @JsonProperty("serviceTypes") List<String> serviceTypes) {
        this.code = subProduct;
        this.serviceTypes = serviceTypes;
    }

    public List<ServiceType> serviceTypes() {
        return this.serviceTypes != null & !this.serviceTypes.isEmpty()
                ? this.serviceTypes.stream().distinct().sorted().map(ServiceType::of).collect(Collectors.toList())
                : Collections.emptyList();
    }

    public SubProduct subProduct() {
        return SubProduct.of(this.code, this.serviceTypes());
    }
    
    public String getName() {
        return this.code;
    }
}
