package com.unimoni.pricingengine.adapter.rest.clients;

import com.unimoni.pricingengine.common.constants.ApplicationConstants;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "of")
@ToString
@EqualsAndHashCode(of = { "code" })
@ApiModel(value = "codeLabelPair", description = "Code and Name pair")
public class CodeLabelPair<T, S> {

    @NonNull
    @ApiModelProperty(name = "code", dataType = "String", value = "Code", example = "XYD112")
    private T code;

    @NonNull
    @ApiModelProperty(name = "name", dataType = "String", value = "Name", example = "UAE Exchange")
    private S name;

    public static CodeLabelPair<String, String> ofAll() {
        return of(ApplicationConstants.ALL_INSTRUMENTS, ApplicationConstants.ALL_INSTRUMENTS);
    }
}
