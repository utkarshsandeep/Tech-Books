package com.unimoni.pricingengine.domain.model.builder;

public interface Builder<T> {

    public T build();
}
