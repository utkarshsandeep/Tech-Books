package com.unimoni.pricingengine.application.service.amigo.event;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.io.Serializable;
import java.time.ZonedDateTime;

import javax.money.CurrencyUnit;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class VDWRateAmigoEvent extends AmigoEvent implements Serializable {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;

    @NonNull
    private String agentCode;

    @JsonInclude(NON_NULL)
    private String bankCode;

    @NonNull
    private String subProductCode;

    @NonNull
    private String serviceTypeCode;

    protected VDWRateAmigoEvent(final Type type, final String agentCode, final String bankCode,
            final String serviceProviderCode, final String productCode, final String subProductCode,
            final String serviceTypeCode, final CurrencyUnit sourceCcy, final CurrencyUnit targetCcy,
            final boolean status, final ZonedDateTime updatedOn) {
        super(type, serviceProviderCode, productCode, sourceCcy, targetCcy, status, updatedOn);
        this.agentCode = agentCode;
        this.bankCode = bankCode;
        this.subProductCode = subProductCode;
        this.serviceTypeCode = serviceTypeCode;
    }
}
