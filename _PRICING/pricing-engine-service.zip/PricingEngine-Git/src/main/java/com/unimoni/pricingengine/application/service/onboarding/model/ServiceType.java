package com.unimoni.pricingengine.application.service.onboarding.model;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode(of = { "code" })
@ToString
@ApiModel(value = "serviceType", description = "Service Type")
public class ServiceType implements PairItem<String, String> {

    @ApiModelProperty(name = "code", dataType = "String", value = "Service Type Code", example = "Flash")
    private String code;

    @Override
    public int compareTo(final PairItem<String, String> other) {
        return this.code.compareTo(other.pair().getCode());
    }

    @Override
    public CodeNamePair<String, String> pair() {
        return CodeNamePair.of(this.code, this.code);
    }

    public static List<ServiceType> of(final Set<String> serviceTypesData) {
        return serviceTypesData != null && !serviceTypesData.isEmpty() ? serviceTypesData.stream()
                .filter(x -> x != null && !x.isEmpty()).map(ServiceType::of).collect(Collectors.toList())
                : Collections.emptyList();
    }
}
