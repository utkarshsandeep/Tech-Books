package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public class AgentRateMetaData {

    private int nonMatchingCountryRatesCount;

    private List<AgentRateIdentity> nonMatchingCountryRates;

    private int duplicateAgentRatesCount;

    private List<AgentRateIdentity> duplicateAgentRates;

    private int newAgentRatesCount;

    private List<AgentRateResponse> newAgentRates;

    public static AgentRateMetaData of(final List<AgentRateIdentity> nonMatchingSettlements,
            final List<AgentRateIdentity> duplicateCountryRates, final List<AgentRateResponse> newAgentRates) {
        AgentRateMetaData agentMetaData = new AgentRateMetaData();
        agentMetaData.nonMatchingCountryRates = nonMatchingSettlements;
        agentMetaData.nonMatchingCountryRatesCount = nonMatchingSettlements != null ? nonMatchingSettlements.size()
                : 0;
        agentMetaData.duplicateAgentRates = duplicateCountryRates;
        agentMetaData.duplicateAgentRatesCount = duplicateCountryRates != null ? duplicateCountryRates.size()
                : 0;
        agentMetaData.newAgentRates = newAgentRates;
        agentMetaData.newAgentRatesCount = newAgentRates != null ? newAgentRates.size() : 0;
        return agentMetaData;
    }
}

