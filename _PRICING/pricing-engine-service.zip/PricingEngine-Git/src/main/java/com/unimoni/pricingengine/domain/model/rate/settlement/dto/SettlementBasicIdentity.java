package com.unimoni.pricingengine.domain.model.rate.settlement.dto;

import java.util.Optional;

import javax.money.CurrencyUnit;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "ofBankWise")
@EqualsAndHashCode
@ToString
public class SettlementBasicIdentity {

    private String serviceProvider;

    private String product;

    private String subProduct;

    private String serviceType;

    private String agent;

    @Getter(value = AccessLevel.NONE)
    private String bank;

    private CurrencyUnit currency;

    public static SettlementBasicIdentity ofNormal(final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final String agent, final CurrencyUnit currency) {
        return ofBankWise(serviceProvider, product, subProduct, serviceType, agent, null, currency);
    }

    public Optional<String> getBank() {
        return Optional.ofNullable(this.bank);
    }
}
