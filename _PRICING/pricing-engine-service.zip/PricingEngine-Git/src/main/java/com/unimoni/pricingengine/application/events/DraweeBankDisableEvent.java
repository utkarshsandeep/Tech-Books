package com.unimoni.pricingengine.application.events;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DraweeBankDisableEvent {

    private Integer draweeBankId;

    private Integer draweeBankProductId;

    @JsonCreator
    public DraweeBankDisableEvent(@JsonProperty Integer draweeBankId, @JsonProperty Integer draweeBankProductId) {
        this.draweeBankId = draweeBankId;
        this.draweeBankProductId = draweeBankProductId;
    }

}
