package com.unimoni.pricingengine.common.constants;

import com.unimoni.pricingengine.common.enums.MessageCodeType;

public enum RateMessageConstants implements MessageCodeType {

    // @formatter:off
	NORMAL_RATE_CREATED_SUCCESSFULLY("normal.rate.created.successfully", "{0} New Normal base rates created successfully"),
    NORMAL_RATE_CREATED_PARTIALLY("normal.rate.created.partially", "{0} New Normal base rates created successfully, {1} already exists"),
    BANK_WISE_RATE_CREATED_SUCCESSFULLY("bankWise.rate.created.successfully", "{0} New Bank wise base rates created successfully"),
    BANK_WISE_RATE_CREATED_PARTIALLY("bankWise.rate.created.partially", "{0} New Bank wise base rates created successfully, {1} already exists"),
    NORMAL_RATE_UPDATED_SUCCESSFULLY("normal.rate.updated.successfully", "Normal Rate updated successfully"),
    BANK_WISE_RATE_UPDATED_SUCCESSFULLY("bankWise.rate.updated.successfully", "Bank wise Rate updated successfully"),
    NORMAL_IBR_UPDATED_SUCCESSFULLY("normal.ibr.updated.successfully", "Normal IBR updated successfully"),
	BANK_WISE_IBR_UPDATED_SUCCESSFULLY("bankWise.ibr.updated.successfully", "Bank wise IBR updated successfully"),
    IBR_UPDATED_SUCCESSFULLY("ibr.updated.successfully", "IBR updated successfully"),
	BANK_WISE_IBR_UPDATED_PARTIALLY("bankWise.ibr.updated.partially", "Bank wise IBR updated Partially"),
	VAR_CREATED_SUCCESSFULLY("var.created.successfully", "{0} New VaRs created successfully"),
    VAR_CREATION_FAILED("var.creation.failed", "Could not create New Normal VaRs"),
    VAR_UPDATED_SUCCESSFULLY("var.updated.successfully", "VaRs updated successfully"),
    SETTLEMENT_RATE_CREATED_SUCCESSFULLY("settlement.rate.created.successfully", "{0} New Settlement rates created successfully"),
    SETTLEMENT_RATE_CREATION_FAILED("settlement.rate.creation.failed", "Could not create New Settlement rates"),
    SETTLEMENT_RATE_UPDATED_SUCCESSFULLY("settlement.rate.updated.successfully", "{0} Settlement rates updated successfully"),
    COUNTRY_RATE_CREATED_SUCCESSFULLY("country.rate.created.successfully", "{0} New Settlement rates created successfully"),
    COUNTRY_RATE_CREATION_FAILED("country.rate.creation.failed", "Could not create New Settlement rates"),
    COUNTRY_RATE_UPDATED_SUCCESSFULLY("country.rate.updated.successfully", "{0} Settlement rates updated successfully"),
    AGENT_RATE_CREATED_SUCCESSFULLY("agent.rate.created.successfully", "{0} New Agent rates created successfully"),
    AGENT_RATE_CREATION_FAILED("agent.rate.creation.failed", "Could not create New Agent rates"),
    AGENT_RATE_UPDATED_SUCCESSFULLY("agent.rate.updated.successfully", "{0} Agent rates updated successfully"),
    BRANCH_PROCESS_DEAL_CREATED("branch.process.created.successfully", "{0} New Deal created successfully"),
    BRANCH_PROCESS_DEAL_UPDATED("branch.process.updated.successfully", "{0} Deal updated successfully"),
    AUTHORIZATION_SETTING_CREATED_SUCCESSFULLY("authorization.setting.created.successfully", "{0} New Authorization Setting created successfully, {1} already exists, {2} non-matching records"),
    AUTHORIZATION_SETTING_UPDATED_SUCCESSFULLY("authorization.setting.updated.successfully", "{0} Authorization setting rates updated successfully"),
    AUTHORIZATION_SETTING_NON_MATCHED_RECORD("authorization.setting.non.mathced.records", "{0} non-matching records found"),
    AUTHORIZATION_QUEUE_UPDATED_SUCCESSFULLY("authorization.queue.updated.successfully", "{0} Selected Queue records rates updated successfully");

	// @formatter:on

    private String key;

    private String defaultMessage;

    private RateMessageConstants(final String messageCode, final String defaultMessage) {
        this.key = messageCode;
        this.defaultMessage = defaultMessage;
    }

    @Override
    public String key() {
        return this.key;
    }

    @Override
    public String defaultMessage() {
        return this.defaultMessage;
    }
}
