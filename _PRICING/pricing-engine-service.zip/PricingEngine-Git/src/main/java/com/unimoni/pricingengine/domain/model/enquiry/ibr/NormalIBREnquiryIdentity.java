package com.unimoni.pricingengine.domain.model.enquiry.ibr;

import javax.money.CurrencyUnit;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
@ToString
public class NormalIBREnquiryIdentity {

    private int index;

    private String serviceProvider;

    private String product;

    private CurrencyUnit currency;

}
