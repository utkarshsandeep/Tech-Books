package com.unimoni.pricingengine.adapter.persistence.repository.remittance;

import java.util.Optional;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.remittance.AbstractRemittanceTransaction;

public interface RemittanceTransactionRepository extends JPA {

    public <T extends AbstractRemittanceTransaction> Optional<T> findLatestByTransactionUUID(final Class<T> clazz,
            final String transactionUUID);
}
