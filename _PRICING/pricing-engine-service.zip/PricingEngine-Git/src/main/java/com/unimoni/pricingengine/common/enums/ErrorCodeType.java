package com.unimoni.pricingengine.common.enums;

public interface ErrorCodeType {

    public String errorCode();

    public String title();
}
