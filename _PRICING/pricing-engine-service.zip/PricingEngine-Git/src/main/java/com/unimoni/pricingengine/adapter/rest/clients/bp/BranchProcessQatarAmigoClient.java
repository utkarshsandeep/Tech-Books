package com.unimoni.pricingengine.adapter.rest.clients.bp;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "abAmigoQatarClient", url = "${amigo-url.qatar-base-url}")
public interface BranchProcessQatarAmigoClient {
    @RequestMapping(path = "/Paas_Integration/specialDeal/updateDealOfferedRate", method = RequestMethod.POST, consumes = "application/json")
    BranchProcessAmigoResponse updateOfferedRateQatarAmigo(@RequestBody BranchProcessAmigoQatarRequest payload);

    @RequestMapping(path = "/Paas_Integration/specialDeal/updateDealStatus", method = RequestMethod.POST, consumes = "application/json")
    BranchProcessAmigoResponse updateDealStatusQatarAmigo(@RequestBody BranchProcessAmigoQatarRequest payload);
}
