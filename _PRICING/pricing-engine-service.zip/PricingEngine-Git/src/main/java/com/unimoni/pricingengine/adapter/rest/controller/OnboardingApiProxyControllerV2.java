package com.unimoni.pricingengine.adapter.rest.controller;

import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_API_V2;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_ALL_COUNTRY_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_ALL_CURRENCY_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_ALL_PRODUCTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_ALL_SERVICE_PROVIDER_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_ALL_SERVICE_TYPES;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_ALL_SUB_PRODUCTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_BANK_DISPLAY_CODE_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_BANK_WISE_AGENTS_WITH_BRANCHES;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_BANK_WISE_AGENT_DISPLAY_CODE_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_BANK_WISE_FOREIGN_CURRENCY_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_BASE_CURRENCY_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_DESTINATIONS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_DESTINATION_TRIPLETS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_NORMAL_AGENTS_WITH_BRANCHES;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_NORMAL_AGENT_DISPLAY_CODE_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_NORMAL_BANKWISE_AGENT_CODE;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_NORMAL_FOREIGN_BASE_CURRENCY_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_NORMAL_FOREIGN_CURRENCY_PAIRS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_PARTNER_PRODUCTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_PARTNER_SERVICE_TYPES;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_PARTNER_SUB_PRODUCTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_SOURCES;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterData.MASTER_DATA_SOURCE_TRIPLETS;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unimoni.pricingengine.application.service.onboarding.model.AgentListItem;
import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;
import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;
import com.unimoni.pricingengine.domain.model.common.dto.Triplet;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.standardcharges.OriginDestination.ODType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(value = "master-data-apis", description = "All master data fetching APIs", tags = "Master Data")
@RestController
@RequestMapping(MASTER_API_V2)
@Validated
public class OnboardingApiProxyControllerV2 {

    @Autowired
    private MasterData masterData;

    @GetMapping(MASTER_DATA_ALL_SERVICE_PROVIDER_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-service-provider-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Service Providers, each element containing Service Provider code and name pair.<br>"
                + "Used to render the <b> Provider dropdown on all screens<b>", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<CodeNamePair<String, String>>> getAllServiceProviderPairs(
            @ApiParam(value = "Whether or not to include \"All\" as first option", example = "true", allowableValues = "true,false")
            @RequestParam(value = "includeAllOption", required = false, defaultValue = "false") final boolean includeAllOption) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getAllServiceProviderPairs(includeAllOption));
    }

    @GetMapping(MASTER_DATA_ALL_CURRENCY_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-currency-code-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All currencies each element containing Currency code and name pair", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "To be used to populate Currency dropdown on RMUI normal and IBR Normal")
    public ResponseEntity<List<CodeNamePair<String, String>>> getAllCurrencyPairs(
            @ApiParam(value = "Whether or not to get Currency name as Label, "
                    + "pass <b>true</b> if you need Currency name as Option elements Label otherwise false."
                    + "Default value is <b>false</b>, So both code and label would be currency code", 
                    example = "true", allowableValues = "true,false")
            @RequestParam(value = "nameAsLabel", required = false, defaultValue = "false") final boolean nameAsLabel,
            @ApiParam(value = "Whether or not to include \"All\" as first option", example = "true", allowableValues = "true,false")
            @RequestParam(value = "includeAllOption", required = false, defaultValue = "false") final boolean includeAllOption) {
    // @formatter:on
        return ResponseEntity.ok(this.masterData.getAllCurrencyPairs(nameAsLabel, includeAllOption));
    }

    @GetMapping(MASTER_DATA_ALL_COUNTRY_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-currency-code-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All currencies, each element containing Currency code and name pair", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<CodeNamePair<String, String>>> getAllCountryPairs(
            @ApiParam(value = "Whether or not to get Country name as Label, "
                    + "pass <b>true</b> if you need Country name as Option elements Label otherwise false."
                    + "Default value is <b>false</b>, So both code and label would be Country code", 
                    example = "true", allowableValues = "true,false")
            @RequestParam(value = "nameAsLabel", required = false, defaultValue = "false") final boolean nameAsLabel) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getAllCountryPairs(nameAsLabel));
    }

    @GetMapping(MASTER_DATA_ALL_PRODUCTS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-products", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Products", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<CodeNamePair<String, String>>> getAllProducts() {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getAllProducts());
    }

    @GetMapping(MASTER_DATA_ALL_SUB_PRODUCTS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-sub-products", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Sub Products matching input Products", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<CodeNamePair<String, String>>> getAllSubProducts(
            @ApiParam(allowMultiple = true, type = "String", value = "Product such as Remittance", example = "Remittance")
            @RequestParam(value = "products", required = false) @Valid final List<@NotEmpty String> products) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getAllSubProducts(products));
    }

    @GetMapping(MASTER_DATA_ALL_SERVICE_TYPES)
    // @formatter:off
    @ApiOperation(nickname = "get-all-service-types", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Service Types matching input Products and Sub Products", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<CodeNamePair<String, String>>> getAllServiceTypes(
            @ApiParam(allowMultiple = true, type = "String", value = "Product such as Remittance", example = "Remittance")
            @RequestParam(value = "products", required = false) @Valid final List<@NotEmpty String> products,
            @ApiParam(allowMultiple = true, type = "String", value = "Sub Product such as Account Credit", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) @Valid final List<@NotEmpty String> subProducts) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getAllServiceTypes(products, subProducts));
    }

    @GetMapping(MASTER_DATA_PARTNER_PRODUCTS)
    // @formatter:off
    @ApiOperation(nickname = "get-products", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Products, supported for input service providers, partners and rmType", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "query",
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<List<CodeNamePair<String, String>>> getPartnerProducts(final RMType rmType,
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Agent or Bank Display Codes if rmType is NORMAL or BANK_WISE respectively", example = "XYZ123")
            @RequestParam(value = "partners", required = false) @Valid final List<@NotEmpty String> partners) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getPartnerProducts(rmType, serviceProviders, partners));
    }

    @GetMapping(MASTER_DATA_PARTNER_SUB_PRODUCTS)
    // @formatter:off
    @ApiOperation(nickname = "get-sub-products", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
                value = "Gets List of All Sub Products, supported for input service providers, partners, products and rmType", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "query",
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<List<CodeNamePair<String, String>>> getPartnerSubProducts(final RMType rmType,
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Agent or Bank Display Codes if rmType is NORMAL or BANK_WISE respectively", example = "XYZ123")
            @RequestParam(value = "partners", required = false) @Valid final List<@NotEmpty String> partners,
            @ApiParam(allowMultiple = true, type = "String", value = "Product such as Remittance", example = "Remittance")
            @RequestParam(value = "products", required = false) @Valid final List<@NotEmpty String> products) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getPartnerSubProducts(rmType, serviceProviders, partners, products));
    }

    @GetMapping(MASTER_DATA_PARTNER_SERVICE_TYPES)
    // @formatter:off
    @ApiOperation(nickname = "get-products", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
                value = "Gets List of All Service Types, supported for input service providers, partners, products, sub products and rmType", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "query",
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<List<CodeNamePair<String, String>>> getPartnerServiceTypes(final RMType rmType,
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Agent or Bank Display Codes if rmType is NORMAL or BANK_WISE respectively", example = "XYZ123")
            @RequestParam(value = "partners", required = false) @Valid final List<@NotEmpty String> partners,
            @ApiParam(allowMultiple = true, type = "String", value = "Product such as Remittance", example = "Remittance")
            @RequestParam(value = "products", required = false) @Valid final List<@NotEmpty String> products,
            @ApiParam(allowMultiple = true, type = "String", value = "Sub Product such as Account Credit", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) @Valid final List<@NotEmpty String> subProducts) {
        // @formatter:on
        return ResponseEntity
                .ok(this.masterData.getPartnerServiceTypes(rmType, serviceProviders, partners, products, subProducts));
    }

    @GetMapping(MASTER_DATA_NORMAL_AGENT_DISPLAY_CODE_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-normal-agent-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Normal Agents, each element containing a pair with both code and name as Agent Display Code only", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "To be used to populate the Agent dropdown on all <b>Normal</b> rate screen, "
                + "except <b>Agent Margin</b> and <b>Agent Branch Margin</b> screens")
    public ResponseEntity<List<CodeNamePair<String, String>>> getNormalAgentDisplayCodePairs(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getNormalAgentDisplayCodePairs(serviceProviders));
    }

    @GetMapping(MASTER_DATA_BANK_WISE_AGENT_DISPLAY_CODE_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-bank-wise-agent-code-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Bank Wise Agents, each element containing a pair with both code and name as Agent Display Code only", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "To be used to populate the Agent dropdown on all <b>Bankwise</b> rate screen, "
                + "except <b>Agent Margin</b> and <b>Agent Branch Margin</b> screens")
    public ResponseEntity<List<CodeNamePair<String, String>>> getBankWiseAgentDisplayCodePairs(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Bank Display Codes such as HDFC etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) @Valid final List<@NotEmpty String> banks) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getBankWiseAgentDisplayCodePairs(serviceProviders, banks));
    }

    @GetMapping(MASTER_DATA_BANK_DISPLAY_CODE_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-bank-code-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Banks, each element containing a pair with both code and name as Bank Display Code only", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "To be used to populate the Bank dropdown on all <b>Bankwise</b> rate screens. Set flag to excluded 'All' as an option in drop-down. default is false")
    public ResponseEntity<List<CodeNamePair<String, String>>> getBankDisplayCodePairs(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(type = "Boolean", value = "true or false", allowableValues = "true,false")
            @RequestParam(value = "isAllExcluded", required = false) final Boolean isAllExcluded) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getBankDisplayCodePairs(serviceProviders, isAllExcluded));
    }

    @GetMapping(MASTER_DATA_NORMAL_FOREIGN_CURRENCY_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-foreign-currency-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Normal Foreign currencies, each element containing Currency code and name pair", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "Currency List of banks matching input service providers, irrespective of <b>specific pricing</b>. "
                + "To be used to populate Currency dropdown on all <b>Normal</b> screens, "
                + "Normal VaR and Normal Settlement screens "
                + "and Foreign Currency dropdown on <b>Agent Margin<b> and <b>Agent Branch Margin</b> screens")
    public ResponseEntity<List<CodeNamePair<String, String>>> getNormalForeignCurrencies(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(value = "Whether or not to get Currency name as Label, "
                    + "pass <b>true</b> if you need Currency name as Option elements Label otherwise false."
                    + "Default value is <b>false</b>, So both code and label would be Currency code", 
                    example = "true", allowableValues = "true,false")
            @RequestParam(value = "nameAsLabel", required = false, defaultValue = "false") final boolean nameAsLabel) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getNormalForeignCurrencyPairs(serviceProviders, nameAsLabel));
    }

    @GetMapping(MASTER_DATA_NORMAL_FOREIGN_BASE_CURRENCY_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-foreign-base-currency-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Normal Foreign base currencies, each element containing Currency code and name pair", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "Currency List of banks matching input service providers, agents , irrespective of <b>specific pricing</b>. "
                + "To be used to populate Currency dropdown on all <b>Normal</b> screens, "
                + "Normal VaR and Normal Settlement screens "
                + "and Foreign Currency dropdown on <b>Agent Margin<b> and <b>Agent Branch Margin</b> screens")
    public ResponseEntity<List<CodeNamePair<String, String>>> getNormalForeignBaseCurrencies(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Agent Display Codes such as AGNT001 etc.", example = "AGNT001")
            @RequestParam(value = "agents", required = false) @Valid final List<@NotEmpty String> agents,
            @ApiParam(value = "Whether or not to get Currency name as Label, "
                    + "pass <b>true</b> if you need Currency name as Option elements Label otherwise false."
                    + "Default value is <b>false</b>, So both code and label would be Currency code", 
                    example = "true", allowableValues = "true,false")
            @RequestParam(value = "nameAsLabel", required = false, defaultValue = "false") final boolean nameAsLabel) {
        // @formatter:on
        List<CodeNamePair<String, String>> foreignCurrencies = this.masterData
                .getNormalForeignCurrencyPairs(serviceProviders, nameAsLabel);
        List<CodeNamePair<String, String>> baseCurrencies = this.masterData.getBaseCurrencyPairs(serviceProviders,
                agents, nameAsLabel);

        List<CodeNamePair<String, String>> allCurrencies = new ArrayList<CodeNamePair<String, String>>();
        foreignCurrencies.stream().forEach(pair -> {
            if (!allCurrencies.contains(pair))
                allCurrencies.add(pair);
        });

        baseCurrencies.stream().forEach(pair -> {
            if (!allCurrencies.contains(pair))
                allCurrencies.add(pair);
        });

        Collections.sort(allCurrencies);
        return ResponseEntity.ok(allCurrencies);
    }

    @GetMapping(MASTER_DATA_BANK_WISE_FOREIGN_CURRENCY_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-bank-wise-foreign-currency-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Bank Wise Foreign currencies, each element containing Currency code and name pair", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "Currency List of banks matching input service providers and banks, for which <b>specific pricing is true</b>. "
                + "To be used to populate Currency dropdown on all <b>Bankwise</b> screens, "
                + "Bankwise VaR and Bankwise Settlement screens "
                + "and Foreign Currency dropdown on <b>Agent Margin<b> and <b>Agent Branch Margin</b> screens")
    public ResponseEntity<List<CodeNamePair<String, String>>> getBankWiseForeignCurrencies(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Bank Display Codes such as HDFC etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) @Valid final List<@NotEmpty String> banks,
            @ApiParam(value = "Whether or not to get Currency name as Label, "
                    + "pass <b>true</b> if you need Currency name as Option elements Label otherwise false."
                    + "Default value is <b>false</b>, So both code and label would be Currency code", 
                    example = "true", allowableValues = "true,false")
            @RequestParam(value = "nameAsLabel", required = false, defaultValue = "false") final boolean nameAsLabel) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getBankWiseForeignCurrencyPairs(serviceProviders, banks, nameAsLabel));
    }

    @GetMapping(MASTER_DATA_BASE_CURRENCY_PAIRS)
    // @formatter:off
    @ApiOperation(nickname = "get-all-base-currency-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Base currencies each element containing Currency code and name pair", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "To be used to populate Currency dropdown on Base Currency dropdown on <b>Agent Margin<b> and <b>Agent Branch Margin</b> screens")
    public ResponseEntity<List<CodeNamePair<String, String>>> getBaseCurrencyPairs(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Agent Display Codes such as AGNT001 etc.", example = "AGNT001")
            @RequestParam(value = "agents", required = false) @Valid final List<@NotEmpty String> agents,
            @ApiParam(value = "Whether or not to get Currency name as Label, "
                    + "pass <b>true</b> if you need Currency name as Option elements Label otherwise false."
                    + "Default value is <b>false</b>, So both code and label would be Currency code", 
                    example = "true", allowableValues = "true,false")
            @RequestParam(value = "nameAsLabel", required = false, defaultValue = "false") final boolean nameAsLabel) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getBaseCurrencyPairs(serviceProviders, agents, nameAsLabel));
    }

    @GetMapping(MASTER_DATA_NORMAL_AGENTS_WITH_BRANCHES)
    // @formatter:off
    @ApiOperation(nickname = "get-normal-agents-branches-with-rdm", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of Normal Agents along with associated Branches, "
                + "each element containing Agent/Branch Display code, Type(AGENT|BRANCH) and Rate display Machenism(BC_TO_FC|FC_TO_BC)", 
        response = AgentListItem.class, 
        responseContainer = "List",
        notes = "Each agent and its associated branches are grouped togeather. "
                + "So the list contains an agent first, followed by its branches and "
                + "subsequently another agent along with the branches and so on"
                + "User can create a record by selecting either an agent or branch."
                + "But only if <b>rateDisplayMachenism<b> for selected agent or branch is <b>not null</b>. "
                + "If the rateDisplayMachenism is null than an error should be displayed to user, "
                + "that can not create record for seleceted agent/branch")
    public ResponseEntity<List<AgentListItem>> getNormalAgentAndBranchItemsWithRDM(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getNormalAgentAndBranchItemsWithRDM(serviceProviders));
    }

    @GetMapping(MASTER_DATA_BANK_WISE_AGENTS_WITH_BRANCHES)
    // @formatter:off
    @ApiOperation(nickname = "get-bank-wise-agents-branches-with-rdm", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of Bank Wise Agents along with associated Branches, "
                + "each element containing Agent/Branch Display code, Type(AGENT|BRANCH) and Rate display Machenism(BC_TO_FC|FC_TO_BC)", 
        response = AgentListItem.class, 
        responseContainer = "List",
        notes = "Each agent and its associated branches are grouped togeather. "
                + "So the list contains an agent first, followed by its branches and "
                + "subsequently another agent along with the branches and so on"
                + "User can create a record by selecting either an agent or branch."
                + "But only if <b>rateDisplayMachenism<b> for selected agent or branch is <b>not null</b>. "
                + "If the rateDisplayMachenism is null than an error should be displayed to user, "
                + "that can not create record for selected agent/branch")
    public ResponseEntity<List<AgentListItem>> getBankWiseAgentAndBranchItemsWithRDM(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Bank Display Codes such as HDFC etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) @Valid final List<@NotEmpty String> banks) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getBankWiseAgentAndBranchItemsWithRDM(serviceProviders, banks));
    }

    @GetMapping(MASTER_DATA_SOURCES)
    // @formatter:off
    @ApiOperation(nickname = "get-sources", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of Sources pair (code, name) i.e. Agents along with Branches followed by Countries for Standard Charges", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<CodeNamePair<String, String>>> getSources() {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getSources());
    }

    @GetMapping(MASTER_DATA_SOURCE_TRIPLETS)
    // @formatter:off
    @ApiOperation(nickname = "get-source-triplets", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of Source Triplet (code, name, type) i.e. Agents along with Branches followed by Countries for Standard Charges", 
        response = Triplet.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<Triplet<String, String, ODType>>> getSourceTriplets() {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getSourceTriplets());
    }

    @GetMapping(MASTER_DATA_DESTINATIONS)
    // @formatter:off
    @ApiOperation(nickname = "get-destinations", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
                value = "Gets List of Destination pair (code, name) i.e.Bank, Countries for Standard Charges", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<CodeNamePair<String, String>>> getDestinations() {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getDestinations());
    }

    @GetMapping(MASTER_DATA_DESTINATION_TRIPLETS)
    // @formatter:off
    @ApiOperation(nickname = "get-destination-triplets", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of Destination Triplet (code, name, type) i.e.Bank, Countries for Standard Charges", 
        response = Triplet.class, 
        responseContainer = "List",
        notes = "")
    public ResponseEntity<List<Triplet<String, String, ODType>>> getDestinationTriplets() {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getDestinationTriplets());
    }

    @GetMapping(MASTER_DATA_NORMAL_BANKWISE_AGENT_CODE)
    // @formatter:off
    @ApiOperation(nickname = "get-normal-or-bank-wise-agent-code-pairs", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets List of All Unique Bank Wise and Normal Agents, each element containing a pair with both code and name as Agent Display Code only", 
        response = CodeNamePair.class, 
        responseContainer = "List",
        notes = "To be used to populate the Unique Agent dropdown on all <b>Bankwise and Normal</b> rate screen, "
                + "except <b>Agent Margin</b> and <b>Agent Branch Margin</b> screens")
    public ResponseEntity<List<CodeNamePair<String, String>>> getBankWiseOrNomalWiseAgentDisplayCodePairs(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Provider codes such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) @Valid final List<String> serviceProviders,
            @ApiParam(allowMultiple = true, type = "String", value = "Bank Display Codes such as HDFC etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) @Valid final List<String> banks,
            @ApiParam(allowMultiple = false, type = "String", value = "BANK_WISE", example = "BANK_WISE")
            @RequestParam(value = "bankwise", required = false) @Valid final String bankWise,
            @ApiParam(allowMultiple = false, type = "Boolean",  value = "NORMAL", example = "NORMAL")
            @RequestParam(value = "normalWise", required = false) @Valid final String normalWise) {
        // @formatter:on
        return ResponseEntity.ok(this.masterData.getBankWiseOrNomalWiseUniqueAgentDisplayCodePairs(serviceProviders,
                banks, bankWise, normalWise));
    }
}