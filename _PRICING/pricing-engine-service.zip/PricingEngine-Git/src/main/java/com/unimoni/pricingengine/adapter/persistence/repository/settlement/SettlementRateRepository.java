package com.unimoni.pricingengine.adapter.persistence.repository.settlement;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;

public interface SettlementRateRepository extends JpaRepository<SettlementRate, String>, SettlementRateRepositoryJPA {

}
