package com.unimoni.pricingengine.adapter.persistence.repository.rm;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;
import static com.unimoni.pricingengine.common.constants.ApplicationConstants.CURRENCY_UNIT_USD;

import java.util.ArrayList;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer_;
import com.unimoni.pricingengine.domain.model.rate.RateSourceType;
import com.unimoni.pricingengine.domain.model.rate.base.BankWiseBaseRate_;
import com.unimoni.pricingengine.domain.model.rate.base.NormalBaseRate_;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateIdentity;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchBankWiseBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchNormalBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.composable.CurrencyExchange;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments_;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR_;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR_;
import com.unimoni.pricingengine.domain.model.rate.var.VaR_;

// This class is just as helper having static helper methods, never supposed to be instantiated, so marked abstract
public abstract class BaseRatePredicates {

    public static Predicate[] getSearchNormalRatesPredicates(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final SearchNormalBaseRateRequest request) {

        List<Predicate> predicates = new ArrayList<>();

        if (request.serviceProviders() != null && !request.serviceProviders().isEmpty()) {
            predicates.add(root.get(NormalBaseRate_.instruments.getName())
                    .get(RateInstruments_.serviceProvider.getName()).in(request.serviceProviders()));
        }
        if (request.products() != null && !request.products().isEmpty()) {
            predicates.add(root.get(NormalBaseRate_.instruments.getName()).get(RateInstruments_.product.getName())
                    .in(request.products()));
        }
        if (request.currencies() != null) {
            Predicate usdCurrencyPredicate = null;
            if (request.usdCurrency()) {
                usdCurrencyPredicate = criteriaBuilder.and(
                        criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency").get("source"),
                                CURRENCY_UNIT_USD),
                        criteriaBuilder.equal(root.get(VaR_.exchange.getName()).get("currency").get("target"),
                                CURRENCY_UNIT_USD));
            }

            Predicate nonUSDCurrenciesPredicate = null;
            if (request.currencies() != null && !request.currencies().isEmpty()) {
                nonUSDCurrenciesPredicate = criteriaBuilder.or(
                        root.get(NormalBaseRate_.exchange.getName()).get("currency").get("source")
                                .in(request.currencies()),
                        root.get(NormalBaseRate_.exchange.getName()).get("currency").get("target")
                                .in(request.currencies()));
            }
            predicates
                    .add(criteriaBuilder.or(usdCurrencyPredicate != null ? usdCurrencyPredicate : criteriaBuilder.or(),
                            nonUSDCurrenciesPredicate != null ? nonUSDCurrenciesPredicate : criteriaBuilder.or()));
        }
        if (request.status() != null) {
            predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), request.status()));
        }
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getSearchBankWiseRatesPredicates(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final SearchBankWiseBaseRateRequest request) {
        List<Predicate> predicates = new ArrayList<>();
        if (request.banks() != null && !request.banks().isEmpty()) {
            predicates.add(root.get(BankWiseBaseRate_.bank.getName()).in(request.banks()));
        }
        if (request.agents() != null && !request.agents().isEmpty()) {
            predicates.add(root.get(BankWiseBaseRate_.agent.getName()).in(request.agents()));
        }
        if (request.serviceProviders() != null && !request.serviceProviders().isEmpty()) {
            predicates.add(root.get(BankWiseBaseRate_.instruments.getName())
                    .get(RateInstruments_.serviceProvider.getName()).in(request.serviceProviders()));
        }
        if (request.products() != null && !request.products().isEmpty()) {
            predicates.add(root.get(BankWiseBaseRate_.instruments.getName()).get(RateInstruments_.product.getName())
                    .in(request.products()));
        }
        if (request.currencies() != null) {
            Predicate usdCurrencyPredicate = null;
            if (request.usdCurrency()) {
                usdCurrencyPredicate = criteriaBuilder.and(
                        criteriaBuilder.equal(
                                root.get(BankWiseBaseRate_.exchange.getName()).get("currency").get("source"),
                                CURRENCY_UNIT_USD),
                        criteriaBuilder.equal(
                                root.get(BankWiseBaseRate_.exchange.getName()).get("currency").get("target"),
                                CURRENCY_UNIT_USD));
            }
            Predicate nonUSDCurrenciesPredicate = null;
            if (request.currencies() != null && !request.currencies().isEmpty()) {
                nonUSDCurrenciesPredicate = criteriaBuilder.or(
                        root.get(BankWiseBaseRate_.exchange.getName()).get("currency").get("source")
                                .in(request.currencies()),
                        root.get(BankWiseBaseRate_.exchange.getName()).get("currency").get("target")
                                .in(request.currencies()));
            }
            predicates
                    .add(criteriaBuilder.or(usdCurrencyPredicate != null ? usdCurrencyPredicate : criteriaBuilder.or(),
                            nonUSDCurrenciesPredicate != null ? nonUSDCurrenciesPredicate : criteriaBuilder.or()));
        }
        if (request.status() != null) {
            predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), request.status()));
        }
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getIdentityNormalRatesPredicates(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final RateIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(
                root.get(NormalBaseRate_.instruments.getName()).get(RateInstruments_.serviceProvider.getName()),
                identity.getServiceProvider()));
        predicates.add(criteriaBuilder.equal(
                root.get(NormalBaseRate_.instruments.getName()).get(RateInstruments_.product.getName()),
                identity.getProduct()));
        predicates.add(criteriaBuilder.equal(root.get(NormalBaseRate_.exchange.getName()).get("currency").get("source"),
                identity.getSourceCurrency()));
        predicates.add(criteriaBuilder.equal(root.get(NormalBaseRate_.exchange.getName()).get("currency").get("target"),
                identity.getTargetCurrency()));
        predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), true));
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getIdentityBankWiseRatesPredicates(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final BankRateIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(BankWiseBaseRate_.bank.getName()), identity.getBank()));
        predicates.add(criteriaBuilder.equal(root.get(BankWiseBaseRate_.agent.getName()), identity.getAgent()));
        predicates.add(criteriaBuilder.equal(
                root.get(BankWiseBaseRate_.instruments.getName()).get(RateInstruments_.serviceProvider.getName()),
                identity.getServiceProvider()));
        predicates.add(criteriaBuilder.equal(
                root.get(BankWiseBaseRate_.instruments.getName()).get(RateInstruments_.product.getName()),
                identity.getProduct()));
        predicates
                .add(criteriaBuilder.equal(root.get(BankWiseBaseRate_.exchange.getName()).get("currency").get("source"),
                        identity.getSourceCurrency()));
        predicates
                .add(criteriaBuilder.equal(root.get(BankWiseBaseRate_.exchange.getName()).get("currency").get("target"),
                        identity.getTargetCurrency()));
        predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), true));
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getIdentityNormalIBRPredicates(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final RateIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(
                root.get(NormalIBR_.instruments.getName()).get(RateInstruments_.serviceProvider.getName()),
                identity.getServiceProvider()));
        predicates.add(criteriaBuilder.equal(
                root.get(NormalIBR_.instruments.getName()).get(RateInstruments_.product.getName()),
                identity.getProduct()));
        predicates.add(criteriaBuilder.equal(root.get(NormalIBR_.exchange.getName()).get("currency").get("source"),
                identity.getSourceCurrency()));
        predicates.add(criteriaBuilder.equal(root.get(NormalIBR_.exchange.getName()).get("currency").get("target"),
                identity.getTargetCurrency()));
        predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), true));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getIdentityBankWiseIBRPredicates(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final BankRateIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(BankWiseIBR_.bank.getName()), identity.getBank()));
        predicates.add(criteriaBuilder.equal(root.get(BankWiseIBR_.agent.getName()), identity.getAgent()));
        predicates.add(criteriaBuilder.equal(
                root.get(BankWiseIBR_.instruments.getName()).get(RateInstruments_.serviceProvider.getName()),
                identity.getServiceProvider()));
        predicates.add(criteriaBuilder.equal(
                root.get(BankWiseIBR_.instruments.getName()).get(RateInstruments_.product.getName()),
                identity.getProduct()));
        predicates.add(criteriaBuilder.equal(root.get(BankWiseIBR_.exchange.getName()).get("currency").get("source"),
                identity.getSourceCurrency()));
        predicates.add(criteriaBuilder.equal(root.get(BankWiseIBR_.exchange.getName()).get("currency").get("target"),
                identity.getTargetCurrency()));
        predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), true));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getSearchNormalIBRPredicates(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final SearchNormalBaseRateRequest request) {
        List<Predicate> predicates = new ArrayList<>();
        if (request.serviceProviders() != null && !request.serviceProviders().isEmpty()) {
            predicates.add(root.get(NormalIBR_.instruments.getName()).get(RateInstruments_.serviceProvider.getName())
                    .in(request.serviceProviders()));
        }
        if (request.products() != null && !request.products().isEmpty()) {
            predicates.add(root.get(NormalIBR_.instruments.getName()).get(RateInstruments_.product.getName())
                    .in(request.products()));
        }
        if (request.currencies() != null) {
            Predicate usdCurrencyPredicate = null;
            if (request.usdCurrency()) {
                usdCurrencyPredicate = criteriaBuilder.and(
                        criteriaBuilder.equal(root.get(NormalIBR_.exchange.getName()).get("currency").get("source"),
                                CURRENCY_UNIT_USD),
                        criteriaBuilder.equal(root.get(NormalIBR_.exchange.getName()).get("currency").get("target"),
                                CURRENCY_UNIT_USD));
            }

            Predicate nonUSDCurrenciesPredicate = null;
            if (request.currencies() != null && !request.currencies().isEmpty()) {
                nonUSDCurrenciesPredicate = criteriaBuilder.or(
                        root.get(NormalIBR_.exchange.getName()).get("currency").get("source").in(request.currencies()),
                        root.get(NormalIBR_.exchange.getName()).get("currency").get("target").in(request.currencies()));
            }
            predicates
                    .add(criteriaBuilder.or(usdCurrencyPredicate != null ? usdCurrencyPredicate : criteriaBuilder.or(),
                            nonUSDCurrenciesPredicate != null ? nonUSDCurrenciesPredicate : criteriaBuilder.or()));
        }
        if (request.status() != null) {
            predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), request.status()));
        }
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getSearchBankWiseIBRRatesPredicates(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final SearchBankWiseBaseRateRequest request) {
        List<Predicate> predicates = new ArrayList<>();
        if (request.banks() != null && !request.banks().isEmpty()) {
            predicates.add(root.get(BankWiseIBR_.bank.getName()).in(request.banks()));
        }
        if (request.agents() != null && !request.agents().isEmpty()) {
            predicates.add(root.get(BankWiseIBR_.agent.getName()).in(request.agents()));
        }
        if (request.serviceProviders() != null && !request.serviceProviders().isEmpty()) {
            predicates.add(root.get(BankWiseIBR_.instruments.getName()).get(RateInstruments_.serviceProvider.getName())
                    .in(request.serviceProviders()));
        }
        if (request.products() != null && !request.products().isEmpty()) {
            predicates.add(root.get(BankWiseIBR_.instruments.getName()).get(RateInstruments_.product.getName())
                    .in(request.products()));
        }
        if (request.currencies() != null) {

            Predicate usdCurrencyPredicate = null;
            if (request.usdCurrency()) {
                usdCurrencyPredicate = criteriaBuilder.and(
                        criteriaBuilder.equal(root.get(BankWiseIBR_.exchange.getName()).get("currency").get("source"),
                                CURRENCY_UNIT_USD),
                        criteriaBuilder.equal(root.get(BankWiseIBR_.exchange.getName()).get("currency").get("target"),
                                CURRENCY_UNIT_USD));
            }
            Predicate nonUSDCurrenciesPredicate = null;
            if (request.currencies() != null && !request.currencies().isEmpty()) {
                nonUSDCurrenciesPredicate = criteriaBuilder.or(
                        root.get(BankWiseIBR_.exchange.getName()).get("currency").get("source")
                                .in(request.currencies()),
                        root.get(BankWiseIBR_.exchange.getName()).get("currency").get("target")
                                .in(request.currencies()));
            }
            predicates
                    .add(criteriaBuilder.or(usdCurrencyPredicate != null ? usdCurrencyPredicate : criteriaBuilder.or(),
                            nonUSDCurrenciesPredicate != null ? nonUSDCurrenciesPredicate : criteriaBuilder.or()));
        }

        if (request.status() != null) {
            predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), request.status()));
        }
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate getBankWiseIBRBasicPredicatesForHighestPriorityFetch(
            final Root<? extends AbstractLayer> root, final CriteriaBuilder criteriaBuilder,
            final String serviceProvider, final String product, final String bank, final String agent) {
        return criteriaBuilder.and(
                criteriaBuilder.or(criteriaBuilder.equal(root.get(BankWiseIBR_.bank.getName()), bank),
                        criteriaBuilder.equal(root.get(BankWiseIBR_.bank.getName()), ALL_INSTRUMENTS)),

                criteriaBuilder.or(criteriaBuilder.equal(root.get(BankWiseIBR_.agent.getName()), agent),
                        criteriaBuilder.equal(root.get(BankWiseIBR_.agent.getName()), ALL_INSTRUMENTS)),

                criteriaBuilder.or(
                        criteriaBuilder.equal(root.get(BankWiseIBR_.instruments.getName())
                                .get(RateInstruments_.serviceProvider.getName()), serviceProvider),
                        criteriaBuilder.equal(root.get(BankWiseIBR_.instruments.getName())
                                .get(RateInstruments_.serviceProvider.getName()), ALL_INSTRUMENTS)),

                criteriaBuilder.or(criteriaBuilder.equal(
                        root.get(BankWiseIBR_.instruments.getName()).get(RateInstruments_.product.getName()), product),
                        criteriaBuilder.equal(
                                root.get(BankWiseIBR_.instruments.getName()).get(RateInstruments_.product.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), true));
    }

    public static Predicate getNormalIBRBasicPredicatesForHighestPriorityFetch(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final String serviceProvider, final String product) {
        return criteriaBuilder.and(
                criteriaBuilder.or(
                        criteriaBuilder.equal(root.get(NormalIBR_.instruments.getName())
                                .get(RateInstruments_.serviceProvider.getName()), serviceProvider),
                        criteriaBuilder.equal(root.get(NormalIBR_.instruments.getName())
                                .get(RateInstruments_.serviceProvider.getName()), ALL_INSTRUMENTS)),
                criteriaBuilder.or(criteriaBuilder.equal(
                        root.get(NormalIBR_.instruments.getName()).get(RateInstruments_.product.getName()), product),
                        criteriaBuilder.equal(
                                root.get(NormalIBR_.instruments.getName()).get(RateInstruments_.product.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), true));
    }

    public static Predicate getIBRCurrencyPredicateForHighestPriorityFetch(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final CurrencyUnit currency) {
        if (CURRENCY_UNIT_USD == currency) {
            return criteriaBuilder.and(criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(AbstractLayer_.exchange.getName()).get("currency").get("source"),
                            CURRENCY_UNIT_USD),
                    criteriaBuilder.equal(root.get(AbstractLayer_.exchange.getName()).get("currency").get("target"),
                            CURRENCY_UNIT_USD)));
        }
        else {
            return criteriaBuilder.and(criteriaBuilder.or(
                    criteriaBuilder.equal(root.get(AbstractLayer_.exchange.getName()).get("currency").get("source"),
                            currency),
                    criteriaBuilder.equal(root.get(AbstractLayer_.exchange.getName()).get("currency").get("target"),
                            currency)));
        }
    }

    public static Predicate getIBRCurrencyPairPredicateForHighestPriorityFetch(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final CurrencyExchange currencyExchange) {
        return criteriaBuilder.equal(root.get(AbstractLayer_.exchange.getName()).get("currency"), currencyExchange);
    }

    // Added for BankOnboard Event in RM bank
    public static Predicate[] getSearchNormalIBRPredicatesforEvent(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final CurrencyUnit currency) {
        List<Predicate> predicates = new ArrayList<>();

        if (currency != null) {
            predicates.add(criteriaBuilder.or(
                    root.get(NormalIBR_.exchange.getName()).get("currency").get("source").in(currency),
                    root.get(NormalIBR_.exchange.getName()).get("currency").get("target").in(currency)));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    // Added for BankOnboard Event in RM bank , to check if record exist in RM Bank
    // with product , serviceProvider ,
    // source , target

    public static Predicate[] getCountNormalIBRPredicatesforEvent(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final String product, final String serviceProvider,
            CurrencyUnit source, CurrencyUnit target, Boolean status, String agentDisplayCode, String bankDisplayCode) {

        List<Predicate> predicates = new ArrayList<>();
        if (serviceProvider != null) {
            predicates.add(root.get(BankWiseIBR_.instruments.getName()).get(RateInstruments_.serviceProvider.getName())
                    .in(serviceProvider));
        }
        if (product != null) {
            predicates.add(
                    root.get(BankWiseIBR_.instruments.getName()).get(RateInstruments_.product.getName()).in(product));
        }
        if (agentDisplayCode != null) {
            predicates.add(root.get(BankWiseIBR_.agent.getName()).in(agentDisplayCode));
        }
        if (bankDisplayCode != null) {
            predicates.add(root.get(BankWiseIBR_.bank.getName()).in(bankDisplayCode));
        }
        if (CURRENCY_UNIT_USD == source && CURRENCY_UNIT_USD == target) {
            predicates.add(criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(BankWiseIBR_.exchange.getName()).get("currency").get("source"),
                            CURRENCY_UNIT_USD),
                    criteriaBuilder.equal(root.get(BankWiseIBR_.exchange.getName()).get("currency").get("target"),
                            CURRENCY_UNIT_USD)));

        }
        else if (source != null && target != null) {
            predicates.add(criteriaBuilder.or(
                    root.get(BankWiseIBR_.exchange.getName()).get("currency").get("source").in(source),
                    root.get(BankWiseIBR_.exchange.getName()).get("currency").get("target").in(target)));
        }
        if (status != null) {
            predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), status));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getIdentityBankWiseRatesPredicatesByRateIdentity(final Root<? extends AbstractLayer> root,
            final CriteriaBuilder criteriaBuilder, final RateIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(
                root.get(BankWiseBaseRate_.instruments.getName()).get(RateInstruments_.serviceProvider.getName()),
                identity.getServiceProvider()));
        predicates.add(criteriaBuilder.equal(
                root.get(BankWiseBaseRate_.instruments.getName()).get(RateInstruments_.product.getName()),
                identity.getProduct()));
        predicates
                .add(criteriaBuilder.equal(root.get(BankWiseBaseRate_.exchange.getName()).get("currency").get("source"),
                        identity.getSourceCurrency()));
        predicates
                .add(criteriaBuilder.equal(root.get(BankWiseBaseRate_.exchange.getName()).get("currency").get("target"),
                        identity.getTargetCurrency()));
        predicates.add(criteriaBuilder.equal(root.get(AbstractLayer_.enabled.getName()), true));
        predicates.add(
                criteriaBuilder.equal(root.get(BankWiseBaseRate_.rateSourceType.getName()), RateSourceType.IBR_NORMAL));
        return predicates.toArray(new Predicate[predicates.size()]);
    }

}
