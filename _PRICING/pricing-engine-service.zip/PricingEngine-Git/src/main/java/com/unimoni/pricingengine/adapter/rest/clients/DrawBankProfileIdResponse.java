package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DrawBankProfileIdResponse {

    private String message;

    private List<DraweeBankProductProfileId> data;

    public DrawBankProfileIdResponse(@JsonProperty("message") String message,
            @JsonProperty("data") List<DraweeBankProductProfileId> data) {
        super();
        this.message = message;
        this.data = data;
    }

}
