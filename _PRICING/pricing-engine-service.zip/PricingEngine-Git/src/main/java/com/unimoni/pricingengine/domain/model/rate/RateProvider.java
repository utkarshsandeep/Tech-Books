package com.unimoni.pricingengine.domain.model.rate;

import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;
import com.unimoni.pricingengine.domain.model.common.type.BaseIdentifiableVersionableEntity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString(of = { "name", "apiType" }, callSuper = true)
@Entity
// @formatter:off
@Table(name = "RATE_PROVIDERS", 
    uniqueConstraints = @UniqueConstraint(name = "UNQ_RP_NAME", columnNames = { "name" })
)
//@formatter:on
@Audited
public class RateProvider extends BaseIdentifiableVersionableEntity<Integer, Integer> {

    public static final String MANUAL = "Manual";

    public static final String THOMSON_REUTERS = "Thomson Reuters";

    public static final String FUTURE_SOURCE = "Future Source";

    @NotNull
    @Column(name = "NAME", nullable = false, length = 150)
    @JsonProperty
    private String name;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "API_TYPE", nullable = false, length = 50)
    @JsonProperty
    private ApiType apiType;

    public static RateProvider manual() {
        return new RateProvider(MANUAL, ApiType.MANUAL);
    }

    public static RateProvider thomsonReuters() {
        return new RateProvider(THOMSON_REUTERS, ApiType.PUSH);
    }

    public static RateProvider futureSource() {
        return new RateProvider(FUTURE_SOURCE, ApiType.PULL);
    }
    
    @JsonIgnore
    public boolean isManual() {
        return this.apiType == ApiType.MANUAL;
    }

    @JsonIgnore
    public boolean isThomson() {
        return this.name.equals(THOMSON_REUTERS);
    }

    @JsonIgnore
    public boolean isFutureSource() {
        return this.name.equals(FUTURE_SOURCE);
    }

    @JsonFormat(shape = JsonFormat.Shape.OBJECT)
    public enum ApiType {

        // @formatter:off
        MANUAL("Manual entry from UI"),
        PULL("Pull based API to hit as and when required"),
        PUSH("Push based API to get the latest updated data feed in real time");
        // @formatter:on

        private final String description;

        private ApiType(final String description) {
            this.description = description;
        }

        public String description() {
            return this.description;
        }

        @JsonValue
        public Pair<String, String> toPair() {
            return ImmutablePair.of(this.name(), this.description());
        }

        public static List<Pair<String, String>> listItems() {
            return Arrays.stream(values()).map(ApiType::toPair).collect(ImmutableCollectors.toImmutableList());
        }
    }
}
