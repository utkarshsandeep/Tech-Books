package com.unimoni.pricingengine.domain.model.rate.country.dto;

import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "countryFormulaDTO", description = "Formula calculated Buy and Sell values")
public class CountryFormulaDTO {

    @ApiModelProperty(name = "sellValue", dataType = "BigDecimal", value = "Sell Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @NotNull
    private BigDecimal sellValue;

    @ApiModelProperty(name = "buyValue", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @NotNull
    private BigDecimal buyValue;

    public static CountryFormulaDTO of(final Cost settlement) {
        return of(settlement.sellValue(), settlement.buyValue());
    }

    public static CountryFormulaDTO zero() {
        return CountryFormulaDTO.of(RateValue.ZERO, RateValue.ZERO);
    }

    public static CountryFormulaDTO one() {
        return CountryFormulaDTO.of(RateValue.ONE, RateValue.ONE);
    }

    public Cost toModel() {
        return Cost.of(this.sellValue, this.buyValue);
    }

    public static CountryFormulaDTO byAgentFormula(final RateDisplayMachenism rmType, final BigDecimal costRateSell,
            final BigDecimal costRateBuy, final BigDecimal marginSell, final BigDecimal marginBuy) {
        CountryFormulaDTO countryFormulaDTO = CountryFormulaDTO.zero();
        if (rmType.isBCtoFC()) {
            BigDecimal askMargin = costRateSell.subtract(marginSell);
            BigDecimal bidMargin = costRateBuy.add(marginBuy);
            countryFormulaDTO = CountryFormulaDTO.of(askMargin, bidMargin);
        }
        else {
            BigDecimal askMargin = costRateSell.add(marginSell);
            BigDecimal bidMargin = costRateBuy.subtract(marginBuy);
            countryFormulaDTO = CountryFormulaDTO.of(askMargin, bidMargin);
        }

        validatePositive(countryFormulaDTO.getBuyValue(), "Agent Buy");
        validatePositive(countryFormulaDTO.getSellValue(), "Agent Sell");

        return countryFormulaDTO;
    }

    public static CountryFormulaDTO byMarginFormula(final RateDisplayMachenism rmType, final BigDecimal costRateSell,
            final BigDecimal costRateBuy, final BigDecimal agentSell, final BigDecimal agentBuy) {
        CountryFormulaDTO countryFormulaDTO = CountryFormulaDTO.zero();
        if (rmType.isBCtoFC()) {
            BigDecimal askMargin = costRateSell.subtract(agentSell);
            BigDecimal bidMargin = agentBuy.subtract(costRateBuy);
            countryFormulaDTO = CountryFormulaDTO.of(askMargin, bidMargin);
        }
        else {
            BigDecimal askMargin = agentSell.subtract(costRateSell);
            BigDecimal bidMargin = costRateBuy.subtract(agentBuy);
            countryFormulaDTO = CountryFormulaDTO.of(askMargin, bidMargin);
        }

        validatePositive(countryFormulaDTO.getBuyValue(), "Margin Buy");
        validatePositive(countryFormulaDTO.getSellValue(), "Margin Sell");

        return countryFormulaDTO;
    }
}
