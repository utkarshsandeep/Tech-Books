package com.unimoni.pricingengine.adapter.persistence.repository.standardcharges;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.remittance.dto.TxnSDChargeCalculationRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardCharge;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardChargeAmountRangeDateWise;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardChargeAmountRangeWise;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.SearchStandardChargesRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargesIdentity;

public interface StandardChargesRepositoryJPA  extends JPA {
    
    public List<StandardCharge> findAllStandardCharges();
    
	public List<StandardCharge> getAllStandardCharges(final SearchStandardChargesRequest searchRequest);
	 
    public List<StandardCharge> findStandardChargesByIds(final List<String> ids, boolean eagerFetchIbr);

    public Optional<StandardCharge> findActiveStandardChargesByIdentity(final StandardChargesIdentity identity);
    
    public List<StandardChargeAmountRangeWise> findStandardChargeAmountRangeByIds(List<String> ids, boolean eagerFetchIbrAndVar);
    
    public List<StandardChargeAmountRangeDateWise> findStandardChargeAmountRangeDateByIds(List<String> ids, boolean eagerFetchIbrAndVar);

    public List<StandardCharge> getAllStandardChargesOnCurrencies(String currencyFrom, String currencyTo);

    public Optional<StandardCharge> findStandardChargesById(String scId);
    
    public List<StandardCharge> getStandardChargesForRemittance(TxnSDChargeCalculationRequest request, boolean isCancel,
            final BigDecimal calculatedPayInAmount, final BigDecimal calculatedPayOutAmount);
    
    public Optional<StandardCharge> findActiveStandardChargesByStandardCharge(final StandardCharge sc);

}
