package com.unimoni.pricingengine.adapter.persistence.repository.country;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments_;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments_;
import com.unimoni.pricingengine.domain.model.rate.country.AgentItem_;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate_;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.country.dto.SearchCountryRatesRequest;

public abstract class CountryRatePredicates {

    public static Predicate[] getCountryRateByIdentityPredicates(final Root<CountryRate> root,
            final CriteriaBuilder criteriaBuilder, final RMType rmType, final CountryRateIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(CountryRate_.instruments.getName()),
                identity.getInstruments().toModel()));
        predicates.add(criteriaBuilder.equal(root.get(CountryRate_.agent.getName()).get(AgentItem_.code.getName()),
                identity.getAgent().getCode()));
        if (rmType.isBankWise()) {
            predicates.add(criteriaBuilder.equal(root.get(CountryRate_.bank.getName()), identity.getBank().get()));
        }
        predicates.add(
                criteriaBuilder.equal(root.get(CountryRate_.currency.getName()), identity.getCurrency().toModel()));
        predicates.add(criteriaBuilder.equal(root.get(CountryRate_.rmType.getName()), rmType));
        predicates.add(criteriaBuilder.equal(root.get(CountryRate_.enabled.getName()), true));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getSearchCountryRatesPredicates(final Root<CountryRate> root,
            final CriteriaBuilder criteriaBuilder, final SearchCountryRatesRequest searchRequest) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(CountryRate_.rmType.getName()), searchRequest.getRmType()));
        if (searchRequest.getAgents() != null && !searchRequest.getAgents().isEmpty()) {
            predicates.add(root.get(CountryRate_.agent.getName()).get(AgentItem_.code.getName())
                    .in(searchRequest.getAgents()));
        }
        if (searchRequest.getRmType().isBankWise() && searchRequest.getBanks() != null
                && !searchRequest.getBanks().isEmpty()) {
            predicates.add(root.get(CountryRate_.bank.getName()).in(searchRequest.getBanks()));
        }
        if (searchRequest.getServiceProviders() != null && !searchRequest.getServiceProviders().isEmpty()) {
            predicates.add(root.get(CountryRate_.instruments.getName()).get(AllInstruments_.serviceProvider.getName())
                    .in(searchRequest.getServiceProviders()));
        }
        if (searchRequest.getProducts() != null && !searchRequest.getProducts().isEmpty()) {
            predicates.add(root.get(CountryRate_.instruments.getName()).get(AllInstruments_.product.getName())
                    .in(searchRequest.getProducts()));
        }
        if (searchRequest.getSubProducts() != null && !searchRequest.getSubProducts().isEmpty()) {
            predicates.add(root.get(CountryRate_.instruments.getName()).get(AllInstruments_.subProduct.getName())
                    .in(searchRequest.getSubProducts()));
        }
        if (searchRequest.getServiceTypes() != null && !searchRequest.getServiceTypes().isEmpty()) {
            predicates.add(root.get(CountryRate_.instruments.getName()).get(AllInstruments_.serviceType.getName())
                    .in(searchRequest.getServiceTypes()));
        }
        if (searchRequest.getBaseCurrencies() != null && !searchRequest.getBaseCurrencies().isEmpty()) {
            predicates.add(root.get(CountryRate_.currency.getName()).get("base").in(searchRequest.getBaseCurrencies()));
        }
        if (searchRequest.getForeignCurrencies() != null && !searchRequest.getForeignCurrencies().isEmpty()) {
            predicates.add(
                    root.get(CountryRate_.currency.getName()).get("foreign").in(searchRequest.getForeignCurrencies()));
        }
        if (searchRequest.getStatus() != null) {
            predicates.add(criteriaBuilder.equal(root.get(CountryRate_.enabled.getName()), searchRequest.getStatus()));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate getCountryRatesByAgentIdentitiesPredicates(final Root<CountryRate> root,
            final CriteriaBuilder criteriaBuilder, final RMType rmType, final AgentRateIdentity identity) {
        Predicate basicPredicate = criteriaBuilder.and(
                criteriaBuilder.equal(root.get(CountryRate_.rmType.getName()), rmType),
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(CountryRate_.instruments.getName())
                                        .get(AllInstruments_.serviceProvider.getName()),
                                identity.getInstruments().getServiceProvider()),
                        criteriaBuilder.equal(root.get(CountryRate_.instruments.getName())
                                .get(RateInstruments_.serviceProvider.getName()), ALL_INSTRUMENTS)),
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(CountryRate_.instruments.getName()).get(AllInstruments_.product.getName()),
                                identity.getInstruments().getProduct()),
                        criteriaBuilder.equal(
                                root.get(CountryRate_.instruments.getName()).get(AllInstruments_.product.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(CountryRate_.instruments.getName()).get(AllInstruments_.subProduct.getName()),
                                identity.getInstruments().getSubProduct()),
                        criteriaBuilder.equal(
                                root.get(CountryRate_.instruments.getName()).get(AllInstruments_.subProduct.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(CountryRate_.instruments.getName()).get(AllInstruments_.serviceType.getName()),
                                identity.getInstruments().getServiceType()),
                        criteriaBuilder.equal(
                                root.get(CountryRate_.instruments.getName()).get(AllInstruments_.serviceType.getName()),
                                ALL_INSTRUMENTS)),
                criteriaBuilder.and(
                        criteriaBuilder.equal(root.get(CountryRate_.currency.getName()).get("base"),
                                identity.getCurrency().getBase()),
                        criteriaBuilder.equal(root.get(CountryRate_.currency.getName()).get("foreign"),
                                identity.getCurrency().getForiegn())),
                criteriaBuilder.equal(root.get(CountryRate_.enabled.getName()), true));

        Predicate predicate = null;
        if (identity.isAgent()) {
            predicate = criteriaBuilder.and(basicPredicate,
                    criteriaBuilder.equal(root.get(CountryRate_.agent.getName()).get(AgentItem_.code.getName()),
                            identity.getAgent().getCode()));
        }
        else {
            predicate = criteriaBuilder.and(basicPredicate,
                    criteriaBuilder.or(
                            criteriaBuilder.equal(root.get(CountryRate_.agent.getName()).get(AgentItem_.code.getName()),
                                    identity.getAgent().getCode()),
                            criteriaBuilder.equal(root.get(CountryRate_.agent.getName()).get(AgentItem_.code.getName()),
                                    identity.agentCodeIfBranch().get())));
        }

        if (rmType.isBankWise()) {
            return criteriaBuilder.and(predicate,
                    criteriaBuilder.equal(root.get(CountryRate_.bank.getName()), identity.getBank().get()));
        }
        else {
            return predicate;
        }
    }

    public static Predicate[] getCountryRateByRmTypeAndId(Root<CountryRate> root, CriteriaBuilder criteriaBuilder,
            RMType rmType, String countryRateId) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(CountryRate_.id.getName()), countryRateId));
        predicates.add(criteriaBuilder.equal(root.get(CountryRate_.rmType.getName()), rmType));
        predicates.add(criteriaBuilder.equal(root.get(CountryRate_.enabled.getName()), true));

        return predicates.toArray(new Predicate[predicates.size()]);
    }
}
