package com.unimoni.pricingengine.domain.model.rate.country;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.money.CurrencyUnit;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyClass;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.envers.AuditMappedBy;
import org.hibernate.envers.Audited;

import com.unimoni.pricingengine.application.event.listner.EntityChangeListener;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.builder.Builder;
import com.unimoni.pricingengine.domain.model.common.type.BaseUUIDIdentifiableVersionableEntity;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryCurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@Slf4j
@Entity
@EntityListeners(EntityChangeListener.class)
//@formatter:off
@Table(name = "COUNTRY_RATES",   
    indexes = {
        @Index(name = "IDX_COUNTRY_RATES_BANK_CODE", columnList = "BANK_CODE"),
        @Index(name = "IDX_COUNTRY_RATES_RM_TYPE", columnList = "RM_TYPE"),            
        @Index(name = "IDX_COUNTRY_RATES_BASE_CURRENCY", columnList = "BASE_CURRENCY"),
        @Index(name = "IDX_COUNTRY_RATES_FOREIGN_CURRENCY", columnList = "FOREIGN_CURRENCY"),
        @Index(name = "IDX_COUNTRY_RATES_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
        @Index(name = "IDX_COUNTRY_RATES_PRODUCT_CODE", columnList = "PRODUCT_CODE"),
        @Index(name = "IDX_COUNTRY_RATES_SUB_PRODUCT_CODE", columnList = "SUB_PRODUCT_CODE"),
        @Index(name = "IDX_COUNTRY_RATES_SERVICE_TYPE_CODE", columnList = "SERVICE_TYPE_CODE"),
        @Index(name = "IDX_COUNTRY_RATE_ENABLED", columnList = "ENABLED"),
        @Index(name = "IDX_COUNTRY_RATE_PRIORITY", columnList = "PRIORITY")
    }
)
//@formatter:on
@Audited
public class CountryRate extends BaseUUIDIdentifiableVersionableEntity<String, Long> {

    @NotNull
    private AgentItem agent;

    @Getter(value = AccessLevel.NONE)
    @Column(name = "BANK_CODE", updatable = false, length = 100)
    private String bank;

    public Optional<String> bank() {
        return Optional.ofNullable(this.bank);
    }

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RM_TYPE", nullable = false, updatable = false, length = 20)
    private RMType rmType;

    @NotNull
    private CountryCurrency currency;

    @NotNull
    @Embedded
    private AllInstruments instruments;

    // @formatter:off
    @ElementCollection(targetClass = CountryRateValueDateWise.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "COUNTRY_VALUE_DATE_WISES", 
        joinColumns = { @JoinColumn(name = "COUNTRY_RATE_ID", referencedColumnName = "ID") },
        foreignKey = @ForeignKey(name = "FK_COUNTRY_VALUE_DATE_WISES_COUNTRY_RATE_ID"))
    @MapKeyClass(VDWType.class)
//    @MapKeyEnumerated(EnumType.STRING)
    @MapKeyColumn(name = "VDW_TYPE", nullable = false)
    @org.hibernate.annotations.OrderBy(clause = "VDW_TYPE asc")
    // @formatter:on
    @Getter(value = AccessLevel.NONE)
    @NotNull
    @Size(min = 4, max = 4)
    private Map<@NotNull VDWType, @NotNull CountryRateValueDateWise> valueDateWises = new LinkedHashMap<VDWType, CountryRateValueDateWise>();

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    // @formatter:off
    @JoinColumn(name = "BASE_SETTLEMENT_ID", unique = false, nullable = false, 
            foreignKey = @ForeignKey(name = "FK_COUNTRY_RATES_BASE_SETTLEMENT_ID"))
    //@formatter:on
    @Audited
    private SettlementRate baseSettlement;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    // @formatter:off
    @JoinColumn(name = "FOREIGN_SETTLEMENT_ID", unique = false, nullable = false, 
            foreignKey = @ForeignKey(name = "FK_COUNTRY_RATES_FOREIGN_SETTLEMENT_ID"))
    //@formatter:on
    @Audited
    private SettlementRate foreignSettlement;

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "PRIORITY", nullable = false, updatable = false, length = 20)
    private CountryRatePriority priority;

    @Getter(value = AccessLevel.NONE)
    @NotNull
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "ENABLED", length = 1)
    private boolean enabled;

    @OneToMany(mappedBy = "countryRate", fetch = FetchType.LAZY)
    @AuditMappedBy(mappedBy = "countryRate")
    private Set<AgentRate> agentRate;

    public boolean isEnabled() {
        return this.enabled;
    }

    @NotNull
    // @formatter:off
    @Column(name = "UPDATED_ON", 
            columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    // @formatter:on
    protected ZonedDateTime updatedOn;

    @Column(name = "REASON", length = 256)
    private String reason;

    public void updateReason(final String reason) {
        this.reason = reason;
    }

    public void updatedNow() {
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public void updatedOn(final ZonedDateTime zonedDateTime) {
        this.updatedOn = zonedDateTime;
    }

    public boolean updateCountryCostFromBaseSettlement(final Map<VDWType, Cost> vdwCountryCostsBaseSettlement,
            final ZonedDateTime updatedOn) {
        log.debug("Country rate, updating country cost rate on Base Settlement");

        Map<VDWType, Cost> agentCostVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwCountryCostsBaseSettlement.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateCountryAndAgentCostFromSettlement(vdwEntry.getValue(),
                    this.foreignSettlement.valueDateWises(vdwEntry.getKey()).country(),
                    this.agent.rateDisplayMechanism())) {
                agentCostVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).agent());
            }
        }
        if (!agentCostVdws.isEmpty()) {
            this.updatedOn = updatedOn;
            propagateRateChangeToAgentRates(agentCostVdws);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCountryCostFromForiegnSettlement(final Map<VDWType, Cost> vdwCountryCostsForiegnSettlement,
            final ZonedDateTime updatedOn) {
        log.debug("Country rate, updating country cost rate on Foriegn Settlement");

        Map<VDWType, Cost> agentCostVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwCountryCostsForiegnSettlement.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateCountryAndAgentCostFromSettlement(
                    this.baseSettlement.valueDateWises(vdwEntry.getKey()).country(), vdwEntry.getValue(),
                    this.agent.rateDisplayMechanism())) {
                agentCostVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).agent());
            }
        }
        if (!agentCostVdws.isEmpty()) {
            this.updatedOn = updatedOn;
            propagateRateChangeToAgentRates(agentCostVdws);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCostMargin(final Map<VDWType, Cost> vdwMargins) {
        Map<VDWType, Cost> newMarginVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwMargins.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateCostMargin(vdwMargins.get(vdwEntry.getKey()))) {
                newMarginVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).margin());
            }
        }
        if (!newMarginVdws.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateCostAgent(final Map<VDWType, Cost> vdwAgents) {
        Map<VDWType, Cost> newAgentCostVdws = new HashMap<>(4);
        for (Entry<VDWType, Cost> vdwEntry : vdwAgents.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateCostAgent(vdwAgents.get(vdwEntry.getKey()))) {
                newAgentCostVdws.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).agent());
            }
        }
        if (!newAgentCostVdws.isEmpty()) {
            propagateRateChangeToAgentRates(newAgentCostVdws);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateStatus(final boolean status) {
        if (this.enabled == status) {
            return false;
        }
        else {
            this.enabled = status;
            if (status == false) { // Propagate only when record is being disabled.
                propagateStatusChangeToAgentRates();
            }
            return true;
        }
    }

    private void propagateRateChangeToAgentRates(final Map<VDWType, Cost> agentCostVdws) {
        if (this.agentRate != null && !this.agentRate.isEmpty()) {
            this.agentRate.forEach(agentRate -> {
                if (agentRate.isEnabled()) {
                    agentRate.updateCostFromCountryRate(agentCostVdws, this.updatedOn);
                }
                else {
                    log.debug("Linked Agent Rate record is disabled, So can not propagate rate changes");
                }
            });
        }
    }

    private void propagateStatusChangeToAgentRates() {
        if (this.agentRate != null && !this.agentRate.isEmpty()) {
            this.agentRate.forEach(agentRate -> agentRate.updateStatus(this.enabled));
        }
    }

    public Map<VDWType, CountryRateValueDateWise> valueDateWises() {
        return Collections.unmodifiableMap(this.valueDateWises);
    }

    public void valueDateWises(final Map<VDWType, CountryRateValueDateWise> newValueDateWises) {
        this.valueDateWises = newValueDateWises;
    }

    public CountryRateValueDateWise valueDateWises(final VDWType vdwType) {
        return this.valueDateWises.get(vdwType);
    }

    public BigDecimal layerCharge(final VDWType vdwType) {
        return this.valueDateWises.get(vdwType).agent().sellValue();
    }

    public void setZeroValueDateWises() {
        cash(CountryRateValueDateWise.zero());
        tom(CountryRateValueDateWise.zero());
        spot(CountryRateValueDateWise.zero());
        future(CountryRateValueDateWise.zero());
    }

    public Optional<CountryRateValueDateWise> cash() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.CASH));
    }

    public Optional<CountryRateValueDateWise> tom() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.TOM));
    }

    public Optional<CountryRateValueDateWise> spot() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.SPOT));
    }

    public Optional<CountryRateValueDateWise> future() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.FUTURE));
    }

    public void cash(final CountryRateValueDateWise cash) {
        this.valueDateWises.put(VDWType.CASH, cash);
    }

    public void tom(final CountryRateValueDateWise tom) {
        this.valueDateWises.put(VDWType.TOM, tom);
    }

    public void spot(final CountryRateValueDateWise spot) {
        this.valueDateWises.put(VDWType.SPOT, spot);
    }

    public void future(final CountryRateValueDateWise future) {
        this.valueDateWises.put(VDWType.FUTURE, future);
    }

    public CountryRateValueDateWise removeValueDateWise(final VDWType vdwType) {
        return this.valueDateWises.remove(vdwType);
    }

    public void updateValueDateWise(final VDWType vdwType, final CountryRateValueDateWise vdw) {
        this.valueDateWises.put(vdwType, vdw);
    }

    public CountryRateIdentity identity() {
        return this.rmType.isNormal()
                ? CountryRateIdentity.ofNormal(this.instruments().serviceProvider(), this.instruments().product(),
                        this.instruments().subProduct(), this.instruments().serviceType(), this.agent().details(),
                        CountryCurrencyDTO.of(this.currency))
                : CountryRateIdentity.ofBankWise(this.instruments().serviceProvider(), this.instruments().product(),
                        this.instruments().subProduct(), this.instruments().serviceType(), this.agent().details(),
                        this.bank().get(), CountryCurrencyDTO.of(this.currency));
    }

    public static SettlementBuilder normal(final AgentItem agent) {
        return new CountryRateBuilder(agent, null, RMType.NORMAL);
    }

    public static SettlementBuilder bankWise(final String bank, final AgentItem agent) {
        return new CountryRateBuilder(agent, bank, RMType.BANK_WISE);
    }

    public interface SettlementBuilder {
        public BaseCurrencyBuilder settlement(final SettlementRate baseSettlement,
                final SettlementRate foreignSettlement);
    }

    public interface CountryExchangeBuilder {
        public InstrumentsBuilder currency(final CountryCurrency currency);
    }

    public interface BaseCurrencyBuilder extends CountryExchangeBuilder {
        public ForeignCurrencyBuilder base(final CurrencyUnit baseCurrency);
    }

    public interface ForeignCurrencyBuilder {
        public ValueDateWiseCashBuilder foreign(final CurrencyUnit foreignCurrency);
    }

    public interface InstrumentsBuilder {
        public ValueDateWiseCashBuilder instruments(final AllInstruments instruments);
    }

    public interface InstrumentsServiceProviderBuilder extends InstrumentsBuilder {
        public ProductBuilder serviceProvider(final String serviceProvider);
    }

    public interface ProductBuilder {
        public SubProductBuilder product(final String product);
    }

    public interface SubProductBuilder {
        public ServiceTypeBuilder subProduct(final String subProduct);
    }

    public interface ServiceTypeBuilder {
        public ValueDateWiseCashBuilder serviceType(final String serviceType);
    }

    public interface ValueDateWiseCashBuilder {
        public ReasonForChangeBuilder valueDateWises(final Map<VDWType, CountryRateValueDateWise> valueDateWises);

        public TomBuilder cash(final CountryRateValueDateWise cash);
    }

    public interface TomBuilder extends Builder<CountryRate> {
        public SpotBuilder tom(final CountryRateValueDateWise tom);
    }

    public interface SpotBuilder extends Builder<CountryRate> {
        public FutureBuilder spot(final CountryRateValueDateWise spot);
    }

    public interface FutureBuilder extends Builder<CountryRate> {
        public ReasonForChangeBuilder future(final CountryRateValueDateWise future);
    }

    public interface ReasonForChangeBuilder extends Builder<CountryRate> {
        public Builder<CountryRate> reason(final String reason);
    }

    public static class CountryRateBuilder implements SettlementBuilder, BaseCurrencyBuilder, ForeignCurrencyBuilder,
            InstrumentsServiceProviderBuilder, ProductBuilder, SubProductBuilder, ServiceTypeBuilder,
            ValueDateWiseCashBuilder, TomBuilder, SpotBuilder, FutureBuilder, ReasonForChangeBuilder {

        private AgentItem agent;

        private String bank;

        private RMType rmType;

        private SettlementRate baseSettlement;

        private SettlementRate foreignSettlement;

        private CountryCurrency currency;

        private CurrencyUnit baseCurrency;

        private AllInstruments settlementInstruments;

        private String serviceProvider;

        private String product;

        private String subProduct;

        private Map<VDWType, CountryRateValueDateWise> vdws;

        private String reason;

        CountryRateBuilder(final AgentItem agent, final String bank, final RMType rmType) {
            this.agent = agent;
            this.bank = bank;
            this.rmType = rmType;
        }

        @Override
        public CountryRateBuilder settlement(final SettlementRate settlementbase,
                final SettlementRate settlementForeign) {
            this.baseSettlement = settlementbase;
            this.foreignSettlement = settlementForeign;
            return this;
        }

        @Override
        public InstrumentsBuilder currency(CountryCurrency currency) {
            this.currency = currency;
            return this;
        }

        @Override
        public ForeignCurrencyBuilder base(CurrencyUnit baseCurrency) {
            this.baseCurrency = baseCurrency;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder foreign(CurrencyUnit foreignCurrency) {
            this.currency = CountryCurrency.of(this.baseCurrency, foreignCurrency);
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder instruments(AllInstruments instruments) {
            this.settlementInstruments = instruments;
            return this;
        }

        @Override
        public ProductBuilder serviceProvider(String serviceProvider) {
            this.serviceProvider = serviceProvider;
            return this;
        }

        @Override
        public SubProductBuilder product(String product) {
            this.product = product;
            return this;
        }

        @Override
        public ServiceTypeBuilder subProduct(String subProduct) {
            this.subProduct = subProduct;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder serviceType(String serviceType) {
            this.settlementInstruments = AllInstruments.of(this.serviceProvider, this.product, this.subProduct,
                    serviceType);
            return this;
        }

        @Override
        public ReasonForChangeBuilder valueDateWises(Map<VDWType, CountryRateValueDateWise> valueDateWises) {
            this.vdws = valueDateWises;
            return this;
        }

        @Override
        public TomBuilder cash(CountryRateValueDateWise cash) {
            this.vdws = new LinkedHashMap<VDWType, CountryRateValueDateWise>(4);
            this.vdws.put(VDWType.CASH, cash);
            return this;
        }

        @Override
        public SpotBuilder tom(CountryRateValueDateWise tom) {
            this.vdws.put(VDWType.TOM, tom);
            return this;
        }

        @Override
        public FutureBuilder spot(CountryRateValueDateWise spot) {
            this.vdws.put(VDWType.SPOT, spot);
            return this;
        }

        @Override
        public ReasonForChangeBuilder future(CountryRateValueDateWise future) {
            this.vdws.put(VDWType.FUTURE, future);
            return this;
        }

        @Override
        public Builder<CountryRate> reason(String reason) {
            this.reason = reason;
            return this;
        }

        @Override
        public CountryRate build() {
            CountryRate countryRate = new CountryRate();
            countryRate.rmType = this.rmType;
            countryRate.currency = this.currency;
            countryRate.instruments = this.settlementInstruments;
            countryRate.valueDateWises = this.vdws;
            if (this.rmType.isNormal()) {
                countryRate.agent = this.agent;
                countryRate.priority = CountryRatePriority.ofNormal(countryRate.instruments, this.agent.code());
            }
            else {
                countryRate.bank = this.bank;
                countryRate.agent = this.agent;
                countryRate.priority = CountryRatePriority.ofBankWise(countryRate.instruments, this.bank,
                        this.agent.code());
            }
            countryRate.reason = this.reason;
            countryRate.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
            countryRate.enabled = true;
            countryRate.baseSettlement = this.baseSettlement;
            countryRate.foreignSettlement = this.foreignSettlement;
            return countryRate;
        }
    }
}
