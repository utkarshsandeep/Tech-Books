package com.unimoni.pricingengine.domain.model.rate.var;

import java.util.EnumSet;
import java.util.Set;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.common.enums.Describable;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "vdwType", description = "Enum for Value Date Wise Type")
public enum VDWType implements Describable {

    // @formatter:off
    CASH("Cash"),
    TOM("Tom"),
    SPOT("Spot"),
    FUTURE("Future");
    // @formatter:on

    private final String description;

    private static final EnumSet<VDWType> ALL = EnumSet.allOf(VDWType.class);

    private VDWType(final String description) {
        this.description = description;
    }

    @Override
    public String value() {
        return this.name();
    }

    @Override
    public String description() {
        return this.description;
    }

    @JsonCreator
    public static VDWType of(final String name) {
        for (VDWType e : values())
            if (e.name().equals(name))
                return e;
        throw new IllegalArgumentException();
    }

    public static EnumSet<VDWType> all() {
        return ALL;
    }

    public boolean isCash() {
        return this == CASH;
    }

    public static EnumSet<VDWType> validate(final Set<String> valueDateWises) {
        if (valueDateWises == null || valueDateWises.isEmpty()
                || valueDateWises.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            return VDWType.all();
        }
        else {
            return valueDateWises.stream().map(VDWType::valueOf)
                    .collect(Collectors.toCollection(() -> EnumSet.noneOf(VDWType.class)));
        }
    }
}
