package com.unimoni.pricingengine.adapter.rest.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "agentDraweeBank4RatesClient", url = "http://bank-onboarding-service-snap.integration.apps.ocp.uaeexchange.com/api/v1/onboarding/draweeBankProductProfiles/agentDraweeBank4Rates")
public interface AgentDraweeBank4RatesClient {
    @RequestMapping(path = "/", method = RequestMethod.POST, consumes = "application/json")
    AgentDraweeBankResponse getAgentDraweeBank4Rates(@RequestBody AgentDraweeBankPayload payload);
}
