package com.unimoni.pricingengine.adapter.rest.controller.settlement;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addError;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.SETTLEMENT_RATE_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.SETTLEMENT_RATE_CREATION_FAILED;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.SETTLEMENT_RATE_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.BANK_WISE_SETTLEMENT_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.NORMAL_SETTLEMENT_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.SETTLEMENT_RATE_BANK_WISE_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.SETTLEMENT_RATE_BANK_WISE_META_DATA_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.SETTLEMENT_RATE_BANK_WISE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.SETTLEMENT_RATE_NORMAL_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.SETTLEMENT_RATE_NORMAL_META_DATA_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.SETTLEMENT_RATE_NORMAL_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Settlement.SETTLEMENT_RATE_RM_TYPE_URI;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.money.CurrencyUnit;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CreateSettlementRateRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SearchSettlementRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementMetaData;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementRateRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementRateResponse;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.UpdateSettlementRateRequest;
import com.unimoni.pricingengine.domain.service.settlement.SettlementRateService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.annotations.ApiIgnore;

@Validated
@Api(value = "Settlement", description = "Settlement Margin (Settlement Rate Layer)", tags = "4th Layer")
@RestController
@RequestMapping(PRICING_API)
public class SettlementRateController {

    @Autowired
    private SettlementRateService settlementService;

    @Autowired
    private PaginatedResourceAssembler<SettlementRateResponse, String> settlementPageAssembler;

    private final CopyOnWriteArrayList<SseEmitter> normalSettlementEmitters = new CopyOnWriteArrayList<>();

    private final CopyOnWriteArrayList<SseEmitter> bankWiseSettlementEmitters = new CopyOnWriteArrayList<>();

    @GetMapping(SETTLEMENT_RATE_NORMAL_META_DATA_URI)
    // @formatter:off
    @ApiOperation( nickname = "get-meta-data-to-create-settlements", 
        value = "Checks if VaRs exist, duplicate records exists "
                + "and accordingly return the meta data to create new Settlement records", 
        notes = "", 
        response = SettlementMetaData.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", required = true,
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public ResponseEntity<SettlementMetaData> reviewNormalSettlements(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", required = true, example = "AGNT00X1")
            @RequestParam(value = "agents", required = true) @NotEmpty final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", required = true, example = "UAE")
            @RequestParam(value = "serviceProviders", required = true) @NotEmpty final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", required = true, example = "Remittance")
            @RequestParam(value = "products", required = true) @NotEmpty final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", required = true, example = "Account Credit")
            @RequestParam(value = "subProducts", required = true) @NotEmpty final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", required = true, example = "Flash")
            @RequestParam(value = "serviceTypes", required = true) @NotEmpty final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> currencies) {
    // @formatter:on 

        return ResponseEntity.ok(settlementService.createSettlementRateMetaData(RMType.NORMAL, SettlementRateRequest
                .ofNormal(serviceProviders, products, subProducts, serviceTypes, currencies, agents)));
    }

    @GetMapping(SETTLEMENT_RATE_BANK_WISE_META_DATA_URI)
    // @formatter:off
    @ApiOperation( nickname = "get-meta-data-to-create-settlements", 
        value = "Checks if VaRs exist, duplicate records exists "
                + "and accordingly return the meta data to create new Settlement records", 
        notes = "", 
        response = SettlementMetaData.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", required = true,
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public ResponseEntity<SettlementMetaData> reviewBankWiseSettlements(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", required = true, example = "HDFC")
            @RequestParam(value = "banks", required = true) @NotEmpty final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1etc.", required = true, example = "AGNT00X1")
            @RequestParam(value = "agents", required = true) @NotEmpty final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", required = true, example = "UAE")
            @RequestParam(value = "serviceProviders", required = true) @NotEmpty final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", required = true, example = "Remittance")
            @RequestParam(value = "products", required = true) @NotEmpty final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", required = true, example = "Account Credit")
            @RequestParam(value = "subProducts", required = true) @NotEmpty final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", required = true, example = "Flash")
            @RequestParam(value = "serviceTypes", required = true) @NotEmpty final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> currencies) {
    // @formatter:on 

        return ResponseEntity.ok(settlementService.createSettlementRateMetaData(RMType.BANK_WISE, SettlementRateRequest
                .ofBankWise(serviceProviders, products, subProducts, serviceTypes, currencies, banks, agents)));
    }

    @PostMapping(SETTLEMENT_RATE_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "create-settlement-rates", 
        value = "Creates one or multiple new Settlement rate records", 
        notes = "",  
        response = SettlementRateResponse.class,
        responseContainer = "List"
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    @ApiResponses(value = { 
            @ApiResponse(response = SettlementRateResponse.class, responseContainer = "List", code = 201, 
                    message = "One or more records created successfully"),
            @ApiResponse(code = 400, message = "Could not create records for supplied input") 
        }
    )
    @Valid
    public ResponseEntity<List<SettlementRateResponse>> createSettlementRates(
            final @PathVariable(name = "rmType", required = true) RMType rmType,
            @ApiParam(required = true, name = "createRequests", value = "A List of create Settlement rate requests")
            @RequestBody @Valid @NotEmpty final List<@NotNull CreateSettlementRateRequest> createRequests) {
    // @formatter:on 

        if (rmType.isBankWise()) {
            createRequests.forEach((createRequest) -> {
                if (!createRequest.getBank().isPresent()) {
                    throw new RateException(RateExceptionExceptionType.BANK_REQUIRED_FOR_BANK_WISE_REQUEST,
                            Status.BAD_REQUEST);
                }
            });
        }
        List<SettlementRateResponse> newVars = settlementService.createSettlementRates(rmType, createRequests);
        if (!newVars.isEmpty()) { // All created
            return ResponseEntity.status(HttpStatus.CREATED)
                    .headers(addSuccess(getMessage(SETTLEMENT_RATE_CREATED_SUCCESSFULLY, newVars.size())))
                    .body(newVars);
        }
        else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .headers(addError(getMessage(SETTLEMENT_RATE_CREATION_FAILED))).build();
        }
    }

    @PatchMapping(SETTLEMENT_RATE_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-settlement-rates", 
        value = "Updates one or multiple Settlement rate records", 
        notes = "Request should only contain the updated values "
                + "If a value is not changed the respective value should not be there in request."
                + "<b>You can only update the status of record and Margin sell and Margin buy value</b>", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = SettlementRateResponse.class,
        responseContainer = "List"
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    @Valid
    public ResponseEntity<List<SettlementRateResponse>> updateSettlementRates(
            final @PathVariable(name = "rmType", required = true) RMType rmType,
            @ApiParam(value = "Updates map with record id as key and updated properties as values")
            @RequestBody @Valid @NotEmpty final Map<@NotEmpty String, @NotNull UpdateSettlementRateRequest> updates) {
    // @formatter:on

        List<SettlementRateResponse> results = settlementService.updateSettlementRates(rmType, updates, Optional.of(true));
        return ResponseEntity.ok().headers(addSuccess(getMessage(SETTLEMENT_RATE_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }

    @GetMapping(SETTLEMENT_RATE_NORMAL_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-normal-settlement-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Normal Settlement rate records matching the selection filters and sort criteria", 
        notes = "",
        response = SettlementRateResponse.class,
        responseContainer = "PaginatedResource"
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Paginated
    @Valid
    public ResponseEntity<PaginatedResource<Resource<SettlementRateResponse>>> getAllNormalSettlementRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @ApiParam(allowMultiple = true, type = "array", allowEmptyValue = false, value = "ISO Currency Code e.g. USD", example = "USD")
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @ApiIgnore @RequestParam Map<String, Object> requestParams) {
    // @formatter:on

        List<SettlementRateResponse> results = settlementService.getAllSettlementRates(SearchSettlementRatesRequest
                .ofNormal(agents, serviceProviders, products, subProducts, serviceTypes, currencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(settlementPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(SETTLEMENT_RATE_NORMAL_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-normal-settlement-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download Normal Settlement rate records matching the selection filters and sort criteria", 
        notes = "",
        response = Void.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    //@Valid
    public void downloadNormalSettlementRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @ApiParam(allowMultiple = true, type = "array", allowEmptyValue = false, value = "ISO Currency Code e.g. USD", example = "USD")
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on

        FileDownloadHelper.downloadFile(
                SearchSettlementRatesRequest.ofNormalDownload(agents, serviceProviders, products, subProducts,
                        serviceTypes, currencies, status),
                settlementService::getAllSettlementRates, downloadFileType, fileName,
                DownloadContext.NORMAL_SETTLEMENT_RATE, response);
    }

    @GetMapping(SETTLEMENT_RATE_BANK_WISE_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-bank-wise-settlement-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Settlement rate records matching the selection filters and sort criteria", 
        notes = "",
        response = SettlementRateResponse.class,
        responseContainer = "PaginatedResource"
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Paginated
    @Valid
    public ResponseEntity<PaginatedResource<Resource<SettlementRateResponse>>> getAllBankWiseSettlementRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @ApiIgnore @RequestParam Map<String, Object> requestParams) {
    // @formatter:on

        List<SettlementRateResponse> results = settlementService
                .getAllSettlementRates(SearchSettlementRatesRequest.ofBankWise(agents, banks, serviceProviders,
                        products, subProducts, serviceTypes, currencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(settlementPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(SETTLEMENT_RATE_BANK_WISE_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-bank-wise-settlement-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Bank wise Settlement rate records matching the selection filters and sort criteria", 
        notes = "",
        response = Void.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    //@Valid
    public void downloadBankWiseSettlementRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "currencies", required = false) final List<@NotNull CurrencyUnit> currencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on

        FileDownloadHelper.downloadFile(
                SearchSettlementRatesRequest.ofBankWiseDownload(agents, banks, serviceProviders, products, subProducts,
                        serviceTypes, currencies, status),
                settlementService::getAllSettlementRates, downloadFileType, fileName,
                DownloadContext.BANK_WISE_SETTLEMENT_RATE, response);
    }

    // --------------------- Server Sent Events Code Start --------------------------

    @GetMapping(NORMAL_SETTLEMENT_SERVER_SENT_EVENTS)
    public SseEmitter sendNormalVARSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.normalSettlementEmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.normalSettlementEmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.normalSettlementEmitters.remove(emitter);
        });

        return emitter;
    }

    @GetMapping(BANK_WISE_SETTLEMENT_SERVER_SENT_EVENTS)
    public SseEmitter sendBankWiseVARSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.bankWiseSettlementEmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.bankWiseSettlementEmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.bankWiseSettlementEmitters.remove(emitter);
        });

        return emitter;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleServerSentEvents(SettlementRateResponse settlementRateResponse) {
        List<SseEmitter> normalDeadEmitters = new ArrayList<>();
        List<SseEmitter> bankDeadEmitters = new ArrayList<>();

        if (settlementRateResponse.getBank() != null && !settlementRateResponse.getBank().isEmpty()) {
            this.bankWiseSettlementEmitters.forEach(emitter -> {
                try {
                    emitter.send(settlementRateResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    bankDeadEmitters.add(emitter);
                }
            });

            this.bankWiseSettlementEmitters.removeAll(bankDeadEmitters);
        }
        else {
            this.normalSettlementEmitters.forEach(emitter -> {
                try {
                    emitter.send(settlementRateResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    normalDeadEmitters.add(emitter);
                }
            });

            this.normalSettlementEmitters.removeAll(normalDeadEmitters);
        }
    }

    // --------------------- Server Sent Events Code Ends --------------------------
}
