package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
public class AuthorizationRateSettingRequest {

    private RMType rateTypes;

    private RateLayerType rateLayerTypes;

    private String serviceProvider;

    private String bankCode;

    private String agentCode;

    private CurrencyUnit currencies;

    private Boolean status;

    public static AuthorizationRateSettingRequest of(RMType rmType, RateLayerType rateLayerTypes,
            String serviceProvider, String bankCode, String agentCode, CurrencyUnit currencies) {

        return AuthorizationRateSettingRequest.of(rmType, rateLayerTypes, serviceProvider, bankCode, agentCode,
                currencies, true);
    }

}
