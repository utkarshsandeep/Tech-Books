package com.unimoni.pricingengine.domain.model.rate.composable;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.CURRENCY_UNIT_USD;

import javax.money.CurrencyUnit;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.springframework.util.Assert;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
@org.hibernate.annotations.Immutable
public class CurrencyExchange {

    @NotNull
    @Column(name = "SOURCE_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit source;

    @NotNull
    @Column(name = "TARGET_CURRENCY", nullable = false, updatable = false, length = 3)
    private CurrencyUnit target;

    @Transient
    private static final String SEPERATOR = "";

    public static CurrencyExchange of(final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency) {
        Assert.notNull(sourceCurrency, "sourceCurrency must not be null!");
        Assert.notNull(targetCurrency, "targetCurrency must not be null!");
        CurrencyExchange currencyExchange = new CurrencyExchange();
        currencyExchange.source = sourceCurrency;
        currencyExchange.target = targetCurrency;
        return currencyExchange;
    }

    public String ccy() {
        return ccy(SEPERATOR);
    }

    public String ccy(final String seperator) {
        return this.source.getCurrencyCode() + seperator + this.target.getCurrencyCode();
    }

    public boolean isContainingUSD() {
        return isContaining(CURRENCY_UNIT_USD);
    }

    public boolean isContaining(final CurrencyUnit currency) {
        return this.source == currency || this.target == currency;
    }
}
