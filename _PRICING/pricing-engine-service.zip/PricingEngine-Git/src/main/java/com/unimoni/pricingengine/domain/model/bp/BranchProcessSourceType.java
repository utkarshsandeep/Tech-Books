package com.unimoni.pricingengine.domain.model.bp;

public enum BranchProcessSourceType {
    AMIGOG,
    AMIGOQ;
}
