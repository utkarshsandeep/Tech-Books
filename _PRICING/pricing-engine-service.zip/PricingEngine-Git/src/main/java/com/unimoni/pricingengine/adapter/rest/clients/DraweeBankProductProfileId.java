package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class DraweeBankProductProfileId {

    private Long draweeBankProductProfileId;

    private Long draweeBankId;

    private String serviceProviderCode;

    private String productType;

    private String subProductType;

    private String serviceType;

    public boolean notIn(final List<String> serviceProviders) {

        return serviceProviders.stream().anyMatch(sp -> sp.equals(this.serviceProviderCode));
    }

    public boolean notPresent(List<MappingMasterData> mappingMasterData) {

        for (MappingMasterData mappingData : mappingMasterData) {
            if (mappingData.getServiceProviderCode().equals(this.serviceProviderCode)
                    && mappingData.getDraweeBankProductProfileId().equals(this.draweeBankProductProfileId)) {
                return true;
            }
        }
        return false;
    }

    public boolean notAvaliable(List<MappingMasterData> mappingMasterData) {
        for (MappingMasterData mappingData : mappingMasterData) {
            if (mappingData.getServiceProviderCode().equals(this.serviceProviderCode)
                    && mappingData.getDraweeBankProductProfileId().equals(this.draweeBankProductProfileId)
                    && mappingData.getProductType().equals(this.productType)) {
                return true;
            }
        }
        return false;

    }

    public boolean notInMaster(List<MappingMasterData> mappingMasterData) {
        for (MappingMasterData mappingData : mappingMasterData) {
            if (mappingData.getServiceProviderCode().equals(this.serviceProviderCode)
                    && mappingData.getDraweeBankProductProfileId().equals(this.draweeBankProductProfileId)
                    && mappingData.getProductType().equals(this.productType)
                    && mappingData.getSubProduct().equals(this.subProductType)) {
                return true;
            }
        }
        return false;

    }

    public CodeLabelPair<String, String> draweeBankProductProfileIdItem() {

        return CodeLabelPair.of("" + this.draweeBankProductProfileId, "" + this.draweeBankId);

    }

    public CodeLabelPair<String, String> productItem() {

        return CodeLabelPair.of(this.productType, this.productType);
    }

    public CodeLabelPair<String, String> productSubTypeItem() {

        return CodeLabelPair.of(this.subProductType, this.subProductType);
    }

    public CodeLabelPair<String, String> serviceTypeItem() {

        return CodeLabelPair.of(this.serviceType, this.serviceType);
    }

    public DraweeBankProductProfileId(@JsonProperty("draweeBankProductProfileId") long draweeBankProductProfileId,
            @JsonProperty("draweeBankId") long draweeBankId,
            @JsonProperty("serviceProviderCode") String serviceProviderCode,
            @JsonProperty("productType") String productType, @JsonProperty("subProductType") String subProductType,
            @JsonProperty("serviceType") String serviceType) {
        this.draweeBankProductProfileId = draweeBankProductProfileId;
        this.draweeBankId = draweeBankId;
        this.serviceProviderCode = serviceProviderCode;
        this.productType = productType;
        this.subProductType = subProductType;
        this.serviceType = serviceType;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof DraweeBankProductProfileId) {
            return ((DraweeBankProductProfileId) obj).draweeBankId == draweeBankId;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
