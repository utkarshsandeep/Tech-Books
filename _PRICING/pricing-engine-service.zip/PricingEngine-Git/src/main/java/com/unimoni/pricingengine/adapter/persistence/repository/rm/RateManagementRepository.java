package com.unimoni.pricingengine.adapter.persistence.repository.rm;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;

public interface RateManagementRepository extends JpaRepository<AbstractLayer, String>, RateManagementRepositoryJPA {

}
