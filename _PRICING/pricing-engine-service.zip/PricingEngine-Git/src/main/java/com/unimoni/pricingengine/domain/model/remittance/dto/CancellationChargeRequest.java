package com.unimoni.pricingengine.domain.model.remittance.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.remittance.TxnCancellationReason;
import com.unimoni.pricingengine.domain.model.standardcharges.types.TransactionStatus;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "cancellationChargeRequest", description = "Cancellation Charge Response")
public class CancellationChargeRequest {

    @NotEmpty
    private String transactionUUID;

    @NotNull
    private TransactionStatus transactionStatus;

    @NotNull
    private TxnCancellationReason reasonForCancellation;
}
