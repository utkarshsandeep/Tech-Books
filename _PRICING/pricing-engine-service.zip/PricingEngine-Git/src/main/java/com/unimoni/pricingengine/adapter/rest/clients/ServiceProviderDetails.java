package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class ServiceProviderDetails {

    private long id;

    private String serviceProviderCode;

    private String serviceProviderName;

    private String productType;

    private String subProductType;

    private String serviceType;

    private Long payInLimit;

    private List<CurrencyCode> currencyCodes;

    private DefaultCurrencyCode defaultCurrencyCode;

    private String status;

    private Long agentId;

    private Long agentBranchId;

    private String agentName;

    private String agentBranchCode;

    private String agentDisplayName;

    public boolean notIn(final List<String> serviceProviders) {

        return serviceProviders.stream().anyMatch(sp -> sp.equals(this.serviceProviderCode));
    }

    public boolean notPresent(List<MappingMasterData> mappingMasterData) {
        for (MappingMasterData mappingData : mappingMasterData) {
            if (mappingData.getServiceProviderCode().equals(this.serviceProviderCode)
                    && mappingData.getAgentBranchIds().equals(this.agentBranchId)) {
                return true;
            }
        }
        return false;

    }

    public boolean notAvaliable(List<MappingMasterData> mappingMasterData) {
        for (MappingMasterData mappingData : mappingMasterData) {
            if (mappingData.getServiceProviderCode().equals(this.serviceProviderCode)
                    && mappingData.getAgentBranchIds().equals(this.agentBranchId)
                    && mappingData.getProductType().equals(this.productType)) {
                return true;
            }
        }
        return false;

    }

    public boolean notInMasterData(List<MappingMasterData> mappingMasterData) {
        for (MappingMasterData mappingData : mappingMasterData) {
            if (mappingData.getServiceProviderCode().equals(this.serviceProviderCode)
                    && mappingData.getAgentBranchIds().equals(this.agentBranchId)
                    && mappingData.getProductType().equals(this.productType)
                    && mappingData.getSubProduct().equals(this.subProductType)) {
                return true;
            }
        }
        return false;

    }

    public CodeLabelPair<String, String> agentItem() {

        return CodeLabelPair.of("" + this.agentBranchId, "" + this.agentId);

    }

    public CodeLabelPair<String, String> productItem() {

        return CodeLabelPair.of(this.productType, this.productType);
    }

    public CodeLabelPair<String, String> productSubTypesItem() {

        return CodeLabelPair.of(this.subProductType, this.subProductType);
    }

    public CodeLabelPair<String, String> productServiceTypesItem() {

        return CodeLabelPair.of(this.serviceType, this.serviceType);
    }

    public ServiceProviderDetails(@JsonProperty("id") long id,
            @JsonProperty("serviceProviderCode") String serviceProviderCode,
            @JsonProperty("serviceProviderName") String serviceProviderName,
            @JsonProperty("productType") String productType, @JsonProperty("subProductType") String subProductType,
            @JsonProperty("serviceType") String serviceType, @JsonProperty("payInLimit") Long payInLimit,
            @JsonProperty("currencyCodes") List<CurrencyCode> currencyCodes,
            @JsonProperty("defaultCurrencyCode") DefaultCurrencyCode defaultCurrencyCode,
            @JsonProperty("status") String status, @JsonProperty("agentId") Long agentId,
            @JsonProperty("agentBranchId") Long agentBranchId, @JsonProperty("agentName") String agentName,
            @JsonProperty("agentBranchCode") String agentBranchCode,
            @JsonProperty("agentDisplayName") String agentDisplayName) {
        super();
        this.id = id;
        this.serviceProviderCode = serviceProviderCode;
        this.serviceProviderName = serviceProviderName;
        this.productType = productType;
        this.subProductType = subProductType;
        this.serviceType = serviceType;
        this.payInLimit = payInLimit;
        this.currencyCodes = currencyCodes;
        this.defaultCurrencyCode = defaultCurrencyCode;
        this.status = status;
        this.agentId = agentId;
        this.agentBranchId = agentBranchId;
        this.agentName = agentName;
        this.agentBranchCode = agentBranchCode;
        this.agentDisplayName = agentDisplayName;
    }

}