package com.unimoni.pricingengine.application.service.amigo.dto;

import java.math.BigDecimal;
import java.util.Optional;

import com.unimoni.pricingengine.domain.model.rate.base.dto.BankRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateIdentity;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "amigoUpdateIBRRequest", description = "Update IBR Request by Amigo, Atleast one of askValue, bidValue or status is mandatory")
public class UpdateIBRRequest extends AmigoRequest {

    @Getter
    @ApiModelProperty(name = "agentCode", value = "Agent code", required = true, example = "AGENT001", position = 1)
    private String agentCode;

    @Getter
    @ApiModelProperty(name = "bankCode", value = "Bank code, required only if rmType is BANK_WISE", required = false, example = "HDFC", position = 2)
    private String bankCode;

    @ApiModelProperty(name = "askValue", dataType = "BigDecimal", value = "New Ask Value in BigDecimal with 8 decimal points precision (Optional)", required = false, example = "75.32560000", position = 9)
    private BigDecimal askValue;

    @ApiModelProperty(name = "bidValue", dataType = "BigDecimal", value = "New Bid Value in BigDecimal with 8 decimal points precision (Optional)", required = false, example = "75.32560000", position = 10)
    private BigDecimal bidValue;

    public Optional<String> agent() {
        return Optional.ofNullable(this.agentCode);
    }

    public Optional<String> bank() {
        return Optional.ofNullable(this.bankCode);
    }

    public Optional<BigDecimal> askValue() {
        return Optional.ofNullable(this.askValue);
    }

    public Optional<BigDecimal> bidValue() {
        return Optional.ofNullable(this.bidValue);
    }

    public Optional<ExchangeRate> exchangeRate() {
        return askValue().isPresent() && bidValue().isPresent()
                ? Optional.of(ExchangeRate.of(this.askValue, this.bidValue))
                : Optional.empty();
    }

    public RateIdentity normalIdentity() {
        return RateIdentity.of(this.sourceCcy, this.targetCcy, this.serviceProviderCode, this.productCode);
    }

    public BankRateIdentity bankWsieidentity() {
        return BankRateIdentity.of(this.sourceCcy, this.targetCcy, this.serviceProviderCode, this.productCode,
                this.agentCode, this.bankCode);
    }
}
