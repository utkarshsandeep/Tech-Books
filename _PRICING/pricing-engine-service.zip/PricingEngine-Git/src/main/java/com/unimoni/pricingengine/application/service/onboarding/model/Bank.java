package com.unimoni.pricingengine.application.service.onboarding.model;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode(of = "bankId")
@ToString
public class Bank implements Partner {

    private long bankId;

    private String bankDisplayCode;

    private boolean specificPricing;

    private CodeNamePair<String, String> foriegnCurrency;

    private Map<String, List<String>> agentsWithBranches;

    private List<Product> products;
    
    @Getter(value = AccessLevel.NONE)
    private CodeNamePair<String, String> pair;

    private Bank(final long bankId, final String bankDisplayCode, final boolean specificPricing,
            final CodeNamePair<String, String> foriegnCurrency, final Map<String, List<String>> agentsWithBranches,
            final List<Product> products) {
        this.bankId = bankId;
        this.bankDisplayCode = bankDisplayCode;
        this.specificPricing = specificPricing;
        this.foriegnCurrency = foriegnCurrency;
        this.agentsWithBranches = agentsWithBranches == null ? Collections.emptyMap() : agentsWithBranches;
        this.products = products == null ? Collections.emptyList() : products;
        this.pair = CodeNamePair.of(this.bankDisplayCode, this.bankDisplayCode);
    }

    public static Bank of(final long bankId, final String bankDisplayCode, final boolean specificPricing,
            final CodeNamePair<String, String> foriegnCurrency, final Map<String, List<String>> agentsWithBranches,
            final List<Product> products) {
        return new Bank(bankId, bankDisplayCode, specificPricing, foriegnCurrency, agentsWithBranches, products);
    }

    @Override
    public CodeNamePair<String, String> pair() {
        return this.pair;
    }

    @Override
    public int compareTo(final PairItem<String, String> other) {
        return this.bankDisplayCode.compareTo(other.pair().getName());
    }

    @Override
    public String getCode() {
        return this.bankDisplayCode;
    }
}
