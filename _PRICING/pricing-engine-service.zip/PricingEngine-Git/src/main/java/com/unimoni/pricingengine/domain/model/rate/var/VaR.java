package com.unimoni.pricingengine.domain.model.rate.var;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.money.CurrencyUnit;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyClass;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.envers.AuditMappedBy;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.unimoni.pricingengine.application.event.listner.EntityChangeListener;
import com.unimoni.pricingengine.application.service.amigo.event.VaRUpdatedEvent;
import com.unimoni.pricingengine.application.service.event.EventPublisher;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.builder.Builder;
import com.unimoni.pricingengine.domain.model.common.type.BaseUUIDIdentifiableVersionableEntity;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.base.dto.CurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.rate.composable.Exchange;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;
import com.unimoni.pricingengine.domain.model.rate.composable.Settlement;
import com.unimoni.pricingengine.domain.model.rate.ibr.InterBankRate;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRValueDateWiseDTO;
import com.unimoni.pricingengine.domain.model.remittance.AskBidMargin;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@Slf4j
@Entity
@EntityListeners(EntityChangeListener.class)
//@formatter:off
@Table(name = "VARS", 
    indexes = { 
        @Index(name = "IDX_VARS_BANK_CODE", columnList = "BANK_CODE"),
        @Index(name = "IDX_VARS_AGENT_CODE", columnList = "AGENT_CODE"),
        @Index(name = "IDX_VARS_SOURCE_CURRENCY", columnList = "SOURCE_CURRENCY"),
        @Index(name = "IDX_VARS_TARGET_CURRENCY", columnList = "TARGET_CURRENCY"),
        @Index(name = "IDX_VARS_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
        @Index(name = "IDX_VARS_PRODUCT_CODE", columnList = "PRODUCT_CODE"),
        @Index(name = "IDX_VARS_SUB_PRODUCT_CODE", columnList = "SUB_PRODUCT_CODE"),
        @Index(name = "IDX_VARS_SERVICE_TYPE_CODE", columnList = "SERVICE_TYPE_CODE"),
        @Index(name = "IDX_VARS_RM_TYPE", columnList = "RM_TYPE"),
        @Index(name = "IDX_VARS_ENABLED", columnList = "ENABLED"),
        @Index(name = "IDX_VARS_PRIORITY", columnList = "PRIORITY") 
    }
)
//@formatter:on
@Audited
public class VaR extends BaseUUIDIdentifiableVersionableEntity<String, Long> implements ValueAtRisk {

    @NotNull
    @Column(name = "AGENT_CODE", updatable = false, nullable = false, length = 100)
    private String agent;

    @Getter(value = AccessLevel.NONE)
    @Column(name = "BANK_CODE", updatable = false, length = 100)
    private String bank;

    public Optional<String> bank() {
        return Optional.ofNullable(this.bank);
    }

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RM_TYPE", nullable = false, updatable = false, length = 20)
    private RMType rmType;

    @NotNull
    private Exchange exchange;

    @NotNull
    @Embedded
    private AllInstruments instruments;

    // @formatter:off
    @ElementCollection(targetClass = VaRValueDateWise.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "VAR_VALUE_DATE_WISES", 
        joinColumns = { @JoinColumn(name = "VAR_ID", referencedColumnName = "ID") },
        foreignKey = @ForeignKey(name = "FK_VAR_VALUE_DATE_WISES_VAR_ID"))
    @MapKeyClass(VDWType.class)
//    @MapKeyEnumerated(EnumType.STRING)
    @MapKeyColumn(name = "VDW_TYPE", nullable = false)
    @org.hibernate.annotations.OrderBy(clause = "VDW_TYPE asc")
    // @formatter:on
    @Getter(value = AccessLevel.NONE)
    @NotNull
    @Size(min = 4, max = 4)
    private Map<@NotNull VDWType, @NotNull VaRValueDateWise> valueDateWises = new LinkedHashMap<VDWType, VaRValueDateWise>();

    @Column(name = "REASON")
    private String reason;

    @Getter(value = AccessLevel.NONE)
    @NotNull
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "ENABLED", length = 1)
    private boolean enabled;

    public boolean isEnabled() {
        return this.enabled;
    }

    @NotNull
    // @formatter:off
    @Column(name = "UPDATED_ON", 
            columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    // @formatter:on
    private ZonedDateTime updatedOn;

    @NotNull
    @ManyToOne(targetEntity = AbstractLayer.class, fetch = FetchType.LAZY, optional = false)
    // @formatter:off
    @JoinColumn(name = "IBR_ID", unique = false, updatable = false, nullable = false, 
            foreignKey = @ForeignKey(name = "FK_VARS_IBR_ID"))
    //@formatter:on
    @Audited
    private InterBankRate ibr;

    @OneToMany(mappedBy = "var", fetch = FetchType.LAZY)
    @AuditMappedBy(mappedBy = "var")
    private Set<SettlementRate> settlements = new HashSet<>();

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "PRIORITY", nullable = false, updatable = false, length = 20)
    private VaRPriority priority;

    @ElementCollection(targetClass = VaRValueDateWise.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "VAR_VALUE_DATE_WISES_T", 
        joinColumns = { @JoinColumn(name = "VAR_ID", referencedColumnName = "ID") },
        foreignKey = @ForeignKey(name = "FK_VAR_VALUE_DATE_WISES_T_VAR_ID"))
    @MapKeyClass(VDWType.class)
    @MapKeyColumn(name = "VDW_TYPE", nullable = false)
    @org.hibernate.annotations.OrderBy(clause = "VDW_TYPE asc")
    @Getter(value = AccessLevel.NONE)
    @Size(min = 0, max = 4)
    @NotAudited
    private Map<VDWType, VaRValueDateWise> valueDateWisesTemp = new LinkedHashMap<VDWType, VaRValueDateWise>();

    public boolean updateFromIBR(final ExchangeRate rate, final ZonedDateTime updatedOn) {
        if (exchange().updateRate(rate)) {
            // Update Value Date Wise Settlement
            Map<VDWType, Settlement> vdwSettlements = new HashMap<>(4);
            for (Entry<VDWType, VaRValueDateWise> vdwEntry : this.valueDateWises.entrySet()) {
                if (vdwEntry.getValue().updateFromIBR(exchange())) {
                    vdwSettlements.put(vdwEntry.getKey(), vdwEntry.getValue().settlement());
                }
            }
            if (!vdwSettlements.isEmpty()) {
                propagateRateChangeToSettlements(vdwSettlements);
                this.updatedOn = updatedOn;
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public boolean updateRates(final Map<VDWType, VaRValueDateWiseDTO> vdws) {
        Map<VDWType, Settlement> vdwSettlements = new HashMap<>(4);
        for (Entry<VDWType, VaRValueDateWiseDTO> vdwEntry : vdws.entrySet()) {
            if (this.valueDateWises.get(vdwEntry.getKey()).updateMargin(vdwEntry.getValue().marginAsk(),
                    vdwEntry.getValue().marginBid()) && vdwEntry.getKey().isCash()) {
                EventPublisher.publishAmigoEvent(VaRUpdatedEvent.forRateChange(this));
            }
            if (this.valueDateWises.get(vdwEntry.getKey()).updateSettlement(vdwEntry.getValue().settlementSell(),
                    vdwEntry.getValue().settlementBuy())) {
                vdwSettlements.put(vdwEntry.getKey(), this.valueDateWises.get(vdwEntry.getKey()).settlement());
            }
        }
        if (!vdwSettlements.isEmpty()) {
            propagateRateChangeToSettlements(vdwSettlements);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateStatus(final boolean status) {
        if (this.enabled == status) {
            return false;
        }
        else {
            this.enabled = status;
            if (status == false) { // Propagate only when record is being disabled.
                propagateStatusChangeToSettlements();
            }
            return true;
        }
    }

    public void updateReason(final String reason) {
        this.reason = reason;
    }

    public void updatedNow() {
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public void updatedOn(final ZonedDateTime zonedDateTime) {
        this.updatedOn = zonedDateTime;
    }

    private void propagateRateChangeToSettlements(final Map<VDWType, Settlement> vdwSettlements) {
        if (this.settlements != null && !this.settlements.isEmpty()) {
            this.settlements.forEach(settlement -> {
                if (settlement.isEnabled()) {
                    settlement.updateSettlementCostFromVaR(vdwSettlements, this.updatedOn);
                }
                else {
                    log.debug("Linked Settlement Rate record is disabled, So can not propagate rate changes");
                }
            });
        }
    }

    private void propagateStatusChangeToSettlements() {
        if (this.settlements != null && !this.settlements.isEmpty()) {
            this.settlements.forEach(settlement -> settlement.updateStatus(this.enabled));
        }
    }

    @Override
    public Map<VDWType, VaRValueDateWise> valueDateWises() {
        return Collections.unmodifiableMap(this.valueDateWises);
    }

    public Map<VDWType, VaRValueDateWise> valueDateWisesTemp() {
        return this.valueDateWisesTemp;
    }
    
    public void valueDateWisesTemp(Map<VDWType, VaRValueDateWise> varValueDateWise) {
        this.valueDateWisesTemp = varValueDateWise;
    }
    
    public VaRValueDateWise valueDateWises(final VDWType vdwType) {
        return this.valueDateWises.get(vdwType);
    }

    public AskBidMargin layerCharge(final VDWType vdwType) {
        return AskBidMargin.of(this.valueDateWises.get(vdwType).margin());
    }

    public void defaultValueDateWises(final Exchange ibrExchange) {
        cash(VaRValueDateWise.byDefault(ibrExchange));
        tom(VaRValueDateWise.byDefault(ibrExchange));
        spot(VaRValueDateWise.byDefault(ibrExchange));
        future(VaRValueDateWise.byDefault(ibrExchange));
    }

    public Optional<VaRValueDateWise> cash() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.CASH));
    }

    public Optional<VaRValueDateWise> tom() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.TOM));
    }

    public Optional<VaRValueDateWise> spot() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.SPOT));
    }

    public Optional<VaRValueDateWise> future() {
        return Optional.ofNullable(this.valueDateWises.get(VDWType.FUTURE));
    }

    public void cash(final VaRValueDateWise cash) {
        this.valueDateWises.put(VDWType.CASH, cash);
    }

    public void tom(final VaRValueDateWise tom) {
        this.valueDateWises.put(VDWType.TOM, tom);
    }

    public void spot(final VaRValueDateWise spot) {
        this.valueDateWises.put(VDWType.SPOT, spot);
    }

    public void future(final VaRValueDateWise future) {
        this.valueDateWises.put(VDWType.FUTURE, future);
    }

    public VaRIdentity identity() {
        return this.rmType.isNormal()
                ? VaRIdentity.ofNormal(this.instruments().serviceProvider(), this.instruments().product(),
                        this.instruments().subProduct(), this.instruments().serviceType(), this.agent(),
                        CurrencyDTO.of(this.exchange().currency()))
                : VaRIdentity.ofBankWise(this.instruments().serviceProvider(), this.instruments().product(),
                        this.instruments().subProduct(), this.instruments().serviceType(), this.agent(),
                        this.bank().get(), CurrencyDTO.of(this.exchange().currency()));

    }

    public static IBRBuilder normal(final String agent) {
        return new VaRBuilder(agent, null, RMType.NORMAL);
    }

    public static IBRBuilder bankWise(final String bank, final String agent) {
        return new VaRBuilder(agent, bank, RMType.BANK_WISE);
    }

    public interface IBRBuilder {
        public SourceCurrencyBuilder ibr(final InterBankRate ibr);
    }

    public interface ExchangeBuilder {
        public InstrumentsBuilder exchange(final Exchange exchange);
    }

    public interface SourceCurrencyBuilder extends ExchangeBuilder {
        public TargetCurrencyBuilder source(final CurrencyUnit sourceCurrency);
    }

    public interface InstrumentsBuilder {
        public ValueDateWiseCashBuilder instruments(final AllInstruments instruments);
    }

    public interface TargetCurrencyBuilder {
        public AskValueBuilder target(final CurrencyUnit targetCurrency);
    }

    public interface AskValueBuilder {
        public BidValueBuilder ibrAsk(final BigDecimal askValue);
    }

    public interface BidValueBuilder {
        public ValueDateWiseCashBuilder ibrBid(final BigDecimal bidValue);
    }

    public interface InstrumentsServiceProviderBuilder extends InstrumentsBuilder {
        public ProductBuilder serviceProvider(final String serviceProvider);
    }

    public interface ProductBuilder {
        public SubProductBuilder product(final String product);
    }

    public interface SubProductBuilder {
        public ServiceTypeBuilder subProduct(final String subProduct);
    }

    public interface ServiceTypeBuilder {
        public ValueDateWiseCashBuilder serviceType(final String serviceType);
    }

    public interface ValueDateWiseCashBuilder {
        public ReasonForChangeBuilder valueDateWises(final Map<VDWType, VaRValueDateWise> valueDateWises);

        public TomBuilder cash(final VaRValueDateWise cash);
    }

    public interface TomBuilder {
        public SpotBuilder tom(final VaRValueDateWise tom);
    }

    public interface SpotBuilder {
        public FutureBuilder spot(final VaRValueDateWise spot);
    }

    public interface FutureBuilder {
        public ReasonForChangeBuilder future(final VaRValueDateWise future);
    }

    public interface ReasonForChangeBuilder extends Builder<VaR> {
        public Builder<VaR> reasonForChange(final String reason);
    }

    public static class VaRBuilder
            implements IBRBuilder, SourceCurrencyBuilder, InstrumentsBuilder, TargetCurrencyBuilder, AskValueBuilder,
            BidValueBuilder, InstrumentsServiceProviderBuilder, ProductBuilder, SubProductBuilder, ServiceTypeBuilder,
            ValueDateWiseCashBuilder, TomBuilder, SpotBuilder, FutureBuilder, ReasonForChangeBuilder {

        private String agent;

        private String bank;

        private RMType rmType;

        private InterBankRate ibr;

        private Exchange exchange;

        private CurrencyUnit sourceCurrency;

        private CurrencyUnit targetCurrency;

        private BigDecimal askValue;

        private BigDecimal bidValue;

        private AllInstruments varInstruments;

        private String serviceProvider;

        private String product;

        private String subProduct;

        private Map<VDWType, VaRValueDateWise> vdws;

        private String reason;

        VaRBuilder(final String agent, final String bank, final RMType rmType) {
            this.agent = agent;
            this.bank = bank;
            this.rmType = rmType;
        }

        public SourceCurrencyBuilder ibr(final InterBankRate ibr) {
            this.ibr = ibr;
            return this;
        }

        @Override
        public InstrumentsBuilder exchange(Exchange exchange) {
            this.exchange = exchange;
            return this;
        }

        @Override
        public TargetCurrencyBuilder source(CurrencyUnit sourceCurrency) {
            this.sourceCurrency = sourceCurrency;
            return this;
        }

        @Override
        public AskValueBuilder target(CurrencyUnit targetCurrency) {
            this.targetCurrency = targetCurrency;
            return this;
        }

        @Override
        public BidValueBuilder ibrAsk(BigDecimal askValue) {
            this.askValue = askValue;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder ibrBid(BigDecimal bidValue) {
            this.bidValue = bidValue;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder instruments(AllInstruments instruments) {
            this.varInstruments = instruments;
            return this;
        }

        @Override
        public ProductBuilder serviceProvider(String serviceProvider) {
            this.serviceProvider = serviceProvider;
            return this;
        }

        @Override
        public SubProductBuilder product(String product) {
            this.product = product;
            return this;
        }

        @Override
        public ServiceTypeBuilder subProduct(String subProduct) {
            this.subProduct = subProduct;
            return this;
        }

        @Override
        public ValueDateWiseCashBuilder serviceType(String serviceType) {
            this.varInstruments = AllInstruments.of(this.serviceProvider, this.product, this.subProduct, serviceType);
            return this;
        }

        @Override
        public ReasonForChangeBuilder valueDateWises(Map<VDWType, VaRValueDateWise> valueDateWises) {
            this.vdws = valueDateWises;
            return this;
        }

        @Override
        public TomBuilder cash(VaRValueDateWise cash) {
            this.vdws = new LinkedHashMap<VDWType, VaRValueDateWise>(4);
            this.vdws.put(VDWType.CASH, cash);
            return this;
        }

        @Override
        public SpotBuilder tom(VaRValueDateWise tom) {
            this.vdws.put(VDWType.TOM, tom);
            return this;
        }

        @Override
        public FutureBuilder spot(VaRValueDateWise spot) {
            this.vdws.put(VDWType.SPOT, spot);
            return this;
        }

        @Override
        public ReasonForChangeBuilder future(VaRValueDateWise future) {
            this.vdws.put(VDWType.FUTURE, future);
            return this;
        }

        @Override
        public Builder<VaR> reasonForChange(String reason) {
            this.reason = reason;
            return this;
        }

        @Override
        public VaR build() {
            VaR var = new VaR();
            var.rmType = this.rmType;
            var.exchange = this.exchange != null ? this.exchange
                    : Exchange.of(this.sourceCurrency, this.targetCurrency, this.askValue, this.bidValue);
            var.instruments = this.varInstruments;
            var.valueDateWises = this.vdws;
            var.agent = this.agent;
            if (this.rmType.isNormal()) {
                var.priority = VaRPriority.ofNormal(var.instruments, this.agent);
            }
            else {
                var.bank = this.bank;
                var.priority = VaRPriority.ofBankWise(varInstruments, this.bank, this.agent);
            }
            var.reason = this.reason;
            var.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
            var.enabled = true;
            var.ibr = this.ibr;
            return var;
        }
    }
}
