package com.unimoni.pricingengine.domain.model.rate.base.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BankOnBoardResponse {

	//"id":534,
	//"currencyCode":"INR",
	//"status":"DISABLED",
	//"productType":"Remittance",
	//"displayName":"Uaex134###",
	//"draweeBankId":351,
	//"createdDate":"2019-02-22T00:00:00Z",
	//"modifiedDate":"2019-06-07T11:40:12Z",
	//"serviceProviderCode":"UAEECMY#####",
	//"bankName":"Bank of India",
	//"country":"India",
	//"countryCode":"IN",
	//"productSubType":"Cash payout",
	//"serviceType":"Normal",
	//"swiftCode":"BAVCFDE54",
	//"accountNumber":"ABFDCREHD",
	//"uaexBankWiseRateCcy":true,
	//"deleted":false
	private Integer id;
	private String currencyCode;
	private String status;
	private String productType;
	private String displayName;
	private String draweeBankId;
	private String createdDate;
	private String modifiedDate;
	private String serviceProviderCode;
	private String bankName;
	private String country;
	private String countryCode;
	private String productSubType;
	private String serviceType;
	private String swiftCode;
	private String accountNumber ;
	private String uaexBankWiseRateCcy;
    private Boolean deleted;
    
    public BankOnBoardResponse(
    		
    		 @JsonProperty Integer id,
    		 @JsonProperty String currencyCode,
    		 @JsonProperty String status,
    		 @JsonProperty String productType,
    		 @JsonProperty String displayName,
    		 @JsonProperty String draweeBankId,
    		 @JsonProperty String createdDate,
    		 @JsonProperty String modifiedDate,
    		 @JsonProperty String serviceProviderCode,
    		 @JsonProperty String bankName,
    		 @JsonProperty String country,
    		 @JsonProperty String countryCode,
    		 @JsonProperty String productSubType,
    		 @JsonProperty String serviceType,
    		 @JsonProperty String swiftCode,
    		 @JsonProperty String accountNumber ,
    		 @JsonProperty String uaexBankWiseRateCcy,
    		 @JsonProperty Boolean deleted) {
    	
    	this.id= id;
    	this.currencyCode= currencyCode;
    	this.status = status;
    	this.productType= productType;
    	this.displayName= displayName;
    	this.draweeBankId = draweeBankId;
    	this.createdDate= createdDate;
    	this.modifiedDate = modifiedDate;
    	this.serviceProviderCode= serviceProviderCode;
    	this.bankName= bankName;
    	this.country = country;
    	this.countryCode = countryCode;
    	this.productSubType= productSubType;
    	this.serviceType=serviceType;
    	this.swiftCode= swiftCode;
    	this.accountNumber= accountNumber;
    	this.uaexBankWiseRateCcy= uaexBankWiseRateCcy;
    	this.deleted = deleted;
    	
    }
	
}
