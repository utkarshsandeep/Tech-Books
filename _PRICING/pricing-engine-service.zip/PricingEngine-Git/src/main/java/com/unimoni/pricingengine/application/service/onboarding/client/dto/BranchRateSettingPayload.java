package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.application.service.onboarding.model.BranchRateSetting;

import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class BranchRateSettingPayload {

    private String rateDisplayMachenism;

    private String roundOffCutOffRate;

    private int value;

    private boolean status;

    public BranchRateSettingPayload(final @JsonProperty("rateDisplayMechanism") String rateDisplayMachenism,
            final @JsonProperty("roundOffCutOffRate") String roundOffCutOffRate, final @JsonProperty("value") int value,
            final @JsonProperty("status") String status) {
        this.rateDisplayMachenism = rateDisplayMachenism;
        this.roundOffCutOffRate = roundOffCutOffRate;
        this.value = value;
        this.status = status != null && status.equalsIgnoreCase("ENABLED");
    }
    
    public BranchRateSetting branchRateSetting() {
        return BranchRateSetting.of(this.rateDisplayMachenism, roundOffCutOffRate, value);
    }
    
    public boolean isEnabled() {
        return this.status;
    }
}
