package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryCurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.rate.var.dto.AllInstrumentsDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "createAgentRate", description = "The request to create one or multiple new Agent rates")
public class CreateAgentRateRequest {

    @ApiModelProperty(name = "countryRateId", value = "The Country Rate object ID to be linked with Agent Rate, as recieved in metadata API response", required = true, allowEmptyValue = false, example = "c0a85bc6-692d-1835-8169-2de8e9fa000b")
    @NotEmpty
    private String countryRateId;

    @NotNull
    private AgentDetails agent;

    @ApiModelProperty(name = "bank", dataType = "String", value = "Bank, required only if rmType is BANK_WISE", required = false)
    private String bank;

    @Valid
    @NotNull
    private CountryCurrencyDTO currency;

    @NotNull
    @Valid
    private AllInstrumentsDTO instruments;

    @Size(min = 4, max = 4)
    @Valid
    private Map<@NotNull VDWType, @NotNull AgentValueDateWiseDTO> valueDateWises;

    @ApiModelProperty(name = "reasonForChange", value = "The reason for change of this rate", allowEmptyValue = false, example = "High volatility")
    private String reasonForChange;

    public Optional<String> getBank() {
        return Optional.ofNullable(this.bank);
    }
}
