package com.unimoni.pricingengine;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ApplicationLifecycleHooks implements ApplicationRunner {

    @Autowired
    private MasterData masterData;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        startUp();
    }

    public void startUp() {
        log.info(">>>>>>>>>>>>>>>>>> Application startup hook starts >>>>>>>>>>>>>>>>>>");

        initializeMasterData();

        log.info(">>>>>>>>>>>>>>>>>> Application startup hook ends... >>>>>>>>>>>>>>>>>>");
    }

    @Async
    private void initializeMasterData() {

        while (!this.masterData.isBeanInitialized()) {
            try {
                log.info("Trying to initialize master data......");
                this.masterData.initialize();
            }
            catch (final Exception e) {
                log.error("Error while master data initialization, So will be re-tried in 2 mins", e);
            }
            try {
                Thread.sleep(2 * 60 * 1000);
            }
            catch (InterruptedException e) {
                log.error("InterruptedException while waiting to retry master data initialization", e);
            }
        }
    }

    @PreDestroy
    public void shutDown() {
        log.info("<<<<<<<<<<<<<<<<<< Application shutdown hook starts <<<<<<<<<<<<<<<<<");

        log.info("<<<<<<<<<<<<<<<<<< Application shutdown hook ends... <<<<<<<<<<<<<<<<<");
    }

    @Scheduled(cron = "0 0/30 * * * *")
    public void executeSystemGarbageCollector() {
        // log.info(">>>>>>>>>>>>>>>>>> Performing Application Garbage Collector starts >>>>>>>>>>>>>>>>>>");
        System.gc();
        // log.info(">>>>>>>>>>>>>>>>>> Performing Application Garbage Collector ends >>>>>>>>>>>>>>>>>>");
    }

}
