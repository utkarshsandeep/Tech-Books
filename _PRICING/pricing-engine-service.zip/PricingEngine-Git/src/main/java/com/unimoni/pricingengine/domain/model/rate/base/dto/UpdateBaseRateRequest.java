package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.math.BigDecimal;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.unimoni.pricingengine.domain.model.common.dto.Frequency;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
public class UpdateBaseRateRequest {

    private RateDTO rate;

    private Frequency frequency;

    private Boolean live;

    private Boolean status;

    public Optional<BigDecimal> askValue() {
        return this.rate != null ? Optional.ofNullable(this.rate.getAskValue()) : Optional.empty();
    }

    public Optional<BigDecimal> bidValue() {
        return this.rate != null ? Optional.ofNullable(this.rate.getBidValue()) : Optional.empty();
    }

    @JsonIgnore
    public boolean isRateUpdated() {
        return askValue().isPresent() && bidValue().isPresent();
    }

    public Optional<ExchangeRate> exchangeRate() {
        return isRateUpdated() ? Optional.of(ExchangeRate.of(this.rate.getAskValue(), this.rate.getBidValue()))
                : Optional.empty();
    }

    public Optional<Frequency> frequency() {
        return this.frequency == null ? Optional.empty() : Optional.of(this.frequency);
    }

    public Optional<Boolean> status() {
        return this.status == null ? Optional.empty() : Optional.of(this.status);
    }

    public Optional<Boolean> isLive() {
        return this.live == null ? Optional.empty() : Optional.of(this.live);
    }
}