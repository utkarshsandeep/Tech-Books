package com.unimoni.pricingengine.domain.model.rate.composable;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.CURRENCY_UNIT_USD;
import static com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType.NON_USD_CUURENCY_PAIR_INVALID;

import java.math.BigDecimal;
import java.util.Optional;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.base.dto.FormulaValue;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
@Access(AccessType.FIELD)
public class Margin implements RateValue {

    @NotNull
    @Column(name = "ASK_MARGIN", columnDefinition = "NUMBER(*,10)")
    private BigDecimal askValue;

    @NotNull
    @Column(name = "BID_MARGIN", columnDefinition = "NUMBER(*,10)")
    private BigDecimal bidValue;

    public static Margin of(final BigDecimal askValue, final BigDecimal bidValue) {
        Margin margin = new Margin();
        margin.askValue = RateValue.preciseTo8Decimals(askValue);
        margin.bidValue = RateValue.preciseTo8Decimals(bidValue);
        return margin;
    }

    public static final Margin ZERO = Margin.of(RateValue.ZERO, RateValue.ZERO);

    public static final Margin ONE = Margin.of(RateValue.ONE, RateValue.ONE);

    public static Margin byFormula(final Exchange exchange, final Settlement settlement) {
        if (exchange.currency().source() == CURRENCY_UNIT_USD) {
            BigDecimal askMargin = settlement.buyValue().subtract(exchange.rate().askValue());
            BigDecimal bidMargin = exchange.rate().bidValue().subtract(settlement.sellValue());
            return Margin.of(askMargin, bidMargin);
        }
        else if (exchange.currency().target() == CURRENCY_UNIT_USD) {
            BigDecimal askMargin = settlement.sellValue().subtract(exchange.rate().askValue());
            BigDecimal bidMargin = exchange.rate().bidValue().subtract(settlement.buyValue());
            return Margin.of(askMargin, bidMargin);
        }
        else {
            throw new RateException(NON_USD_CUURENCY_PAIR_INVALID, exchange.currency().source(),
                    exchange.currency().target());
        }
    }

    public static FormulaValue byFormula(final Exchange exchange, final Optional<BigDecimal> settlementSell,
            final Optional<BigDecimal> settlementBuy) {
        if (exchange.currency().source() == CURRENCY_UNIT_USD) {
            return settlementBuy.isPresent()
                    ? FormulaValue.ofMarginAsk(settlementBuy.get().subtract(exchange.rate().askValue()))
                    : FormulaValue.ofMarginBid(exchange.rate().bidValue().subtract(settlementSell.get()));
        }
        else if (exchange.currency().target() == CURRENCY_UNIT_USD) {
            return settlementBuy.isPresent()
                    ? FormulaValue.ofMarginBid(exchange.rate().bidValue().subtract(settlementBuy.get()))
                    : FormulaValue.ofMarginAsk(settlementSell.get().subtract(exchange.rate().askValue()));
        }
        else {
            throw new RateException(NON_USD_CUURENCY_PAIR_INVALID, exchange.currency().source(),
                    exchange.currency().target());
        }
    }
}
