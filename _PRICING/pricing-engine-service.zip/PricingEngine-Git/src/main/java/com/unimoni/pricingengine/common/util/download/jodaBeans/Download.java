package com.unimoni.pricingengine.common.util.download.jodaBeans;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.unimoni.pricingengine.common.util.download.DownloadContext;

@Target({ ElementType.FIELD, ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface Download {

    String columnName();

    DownloadContext[] contexts() default {};
}
