package com.unimoni.pricingengine.domain.model.rate.agent;

import static com.unimoni.pricingengine.domain.model.rate.RatePriority.isAll;
import static com.unimoni.pricingengine.domain.model.rate.RatePriority.isSpecific;

import com.unimoni.pricingengine.domain.model.rate.RatePriority;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;

public enum AgentRatePriority implements RatePriority {

    // @formatter:off
    // ZERO is lowest priority and SIXTY_THREE is highest
    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    ZERO,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    ONE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWO,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    THREE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    FOUR,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    FIVE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    SIX,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    SEVEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    EIGHT,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    NINE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    ELEVEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWELVE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    THIRTEEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    FOURTEEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    FIFTEEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    SIXTEEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    SEVENTEEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    EIGHTEEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    NINETEEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_ONE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_TWO,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_THREE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_FOUR,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_FIVE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_SIX,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_SEVEN,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_EIGHT,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    TWENTY_NINE,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    THIRTY,

    /**
     * "If SP = “All” and Product =“All” and SubProduct = “All” and ServiceType = “All” and [for normal, Agent = “All” | for bank wise, Bank = “All”]
     */
    THIRTY_ONE, 
    
    THIRTY_TWO, 
    
    THIRTY_THREE, 
    
    THIRTY_FOUR, 
    
    THIRTY_FIVE, 
    
    THIRTY_SIX, 
    
    THIRTY_SEVEN, 
    
    THIRTY_EIGHT, 
    
    THIRTY_NINE, 
    
    FOURTY, 
    
    FOURTY_ONE, 
    
    FOURTY_TWO, 
    
    FOURTY_THREE, 
    
    FOURTY_FOUR, 
    
    FOURTY_FIVE, 
    
    FOURTY_SIX, 
    
    FOURTY_SEVAN, 
    
    FOURTY_EIGHT, 
    
    FOURTY_NINE, 
    
    FIFTY, 
    
    FIFTY_ONE, 
    
    FIFTY_TWO, 
    
    FIFTY_THREE, 
    
    FIFTY_FOUR, 
    
    FIFTY_FIVE, 
    
    FIFTY_SIX, 
    
    FIFTY_SEVAN, 
    
    FIFTY_EIGHT, 
    
    FIFTY_NINE, 
    
    SIXTY, 
    
    SIXTY_ONE, 
    
    SIXTY_TWO, 
    
    SIXTY_THREE;
    // @formatter:on

    public static AgentRatePriority ofNormal(final AllInstruments instruments, final String agent) {

        String serviceProvider = instruments.serviceProvider();
        String product = instruments.product();
        String subProduct = instruments.subProduct();
        String serviceType = instruments.serviceType();

        if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType) && isAll(agent)) {
            return ZERO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType)
                && isAll(agent)) {
            return ONE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(agent)) {
            return TWO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(agent)) {
            return THREE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isAll(agent)) {
            return FOUR;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isAll(agent)) {
            return FIVE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(agent)) {
            return SIX;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(agent)) {
            return SEVEN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(agent)) {
            return EIGHT;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(agent)) {
            return NINE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(agent)) {
            return TEN;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(agent)) {
            return ELEVEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(agent)) {
            return TWELVE;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(agent)) {
            return THIRTEEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(agent)) {
            return FOURTEEN;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(agent)) {
            return FIFTEEN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(agent)) {
            return SIXTEEN;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(agent)) {
            return SEVENTEEN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(agent)) {
            return EIGHTEEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(agent)) {
            return NINETEEN;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(agent)) {
            return TWENTY;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(agent)) {
            return TWENTY_ONE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(agent)) {
            return TWENTY_TWO;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(agent)) {
            return TWENTY_THREE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(agent)) {
            return TWENTY_FOUR;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(agent)) {
            return TWENTY_FIVE;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(agent)) {
            return TWENTY_SIX;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(agent)) {
            return TWENTY_SEVEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(agent)) {
            return TWENTY_EIGHT;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(agent)) {
            return TWENTY_NINE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(agent)) {
            return THIRTY;
        }
        else {
            return THIRTY_ONE;
        }
    }

    public static AgentRatePriority ofBankWise(final AllInstruments instruments, final String bank,
            final String agent) {
        String serviceProvider = instruments.serviceProvider();
        String product = instruments.product();
        String subProduct = instruments.subProduct();
        String serviceType = instruments.serviceType();

        if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType) && isAll(bank)
                && isAll(agent)) {
            return ZERO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType) && isAll(bank)
                && isAll(agent)) {
            return ONE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType) && isAll(bank)
                && isSpecific(agent)) {
            return TWO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType) && isAll(bank)
                && isSpecific(agent)) {
            return THREE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType) && isSpecific(bank)
                && isAll(agent)) {
            return FOUR;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return FIVE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType) && isSpecific(bank)
                && isSpecific(agent)) {
            return SIX;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return SEVEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType) && isAll(bank)
                && isAll(agent)) {
            return EIGHT;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isAll(bank) && isAll(agent)) {
            return NINE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType) && isAll(bank)
                && isSpecific(agent)) {
            return TEN;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return ELEVEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return TWELVE;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return THIRTEEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FOURTEEN;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FIFTEEN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType) && isAll(bank)
                && isAll(agent)) {
            return SIXTEEN;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(bank) && isAll(agent)) {
            return SEVENTEEN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType) && isAll(bank)
                && isSpecific(agent)) {
            return EIGHTEEN;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return NINETEEN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return TWENTY;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return TWENTY_ONE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return TWENTY_TWO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return TWENTY_THREE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(bank) && isAll(agent)) {
            return TWENTY_FOUR;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(bank) && isAll(agent)) {
            return TWENTY_FIVE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return TWENTY_SIX;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return TWENTY_SEVEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return TWENTY_EIGHT;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return TWENTY_NINE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return THIRTY;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return THIRTY_ONE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType) && isAll(bank)
                && isAll(agent)) {
            return THIRTY_TWO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isAll(agent)) {
            return THIRTY_THREE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType) && isAll(bank)
                && isSpecific(agent)) {
            return THIRTY_FOUR;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return THIRTY_FIVE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return THIRTY_SIX;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return THIRTY_SEVEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isAll(agent)) {
            return THIRTY_EIGHT;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isAll(agent)) {
            return THIRTY_NINE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return FOURTY;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return FOURTY_ONE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FOURTY_TWO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FOURTY_THREE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return FOURTY_FOUR;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return FOURTY_FIVE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FOURTY_SIX;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FOURTY_SEVAN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isAll(agent)) {
            return FOURTY_EIGHT;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isAll(agent)) {
            return FOURTY_NINE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return FIFTY;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(subProduct) && isAll(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FIFTY_ONE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FIFTY_TWO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return FIFTY_THREE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return FIFTY_FOUR;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return FIFTY_FIVE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isAll(agent)) {
            return FIFTY_SIX;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isAll(agent)) {
            return FIFTY_SEVAN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return FIFTY_EIGHT;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isAll(bank) && isSpecific(agent)) {
            return FIFTY_NINE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return SIXTY;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isAll(agent)) {
            return SIXTY_ONE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(subProduct) && isSpecific(serviceType)
                && isSpecific(bank) && isSpecific(agent)) {
            return SIXTY_TWO;
        }
        else {
            return SIXTY_THREE;
        }
    }
}
