package com.unimoni.pricingengine.domain.model.rate.country.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;

import io.swagger.annotations.ApiParam;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class CountryRateRequest {

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Service Providers such as UAE, UK etc.")
    private List<@NotEmpty String> serviceProviders;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Products such as Remittance, Forex etc.")
    private List<@NotEmpty String> products;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.")
    private List<@NotEmpty String> subProducts;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Service types such as Flash, Normal etc.")
    private List<@NotEmpty String> serviceTypes;

    @Valid
    @NotEmpty
    private List<AgentDetails> agents;

    @NotEmpty
    private List<@NotEmpty String> banks;

    @NotEmpty
    private List<@NotNull CurrencyUnit> baseCurrencies;

    @NotEmpty
    private List<@NotNull CurrencyUnit> foreignCurrencies;

    public static CountryRateRequest ofNormal(final List<@NotNull String> serviceProviders,
            final List<@NotNull String> products, final List<@NotNull String> subProducts,
            final List<@NotNull String> serviceTypes, final List<@NotNull CurrencyUnit> baseCurrencies,
            final List<@NotNull CurrencyUnit> foreignCurrencies, final List<com.unimoni.pricingengine.domain.model.rate.country.AgentDetails> agents) {
        CountryRateRequest countryRateRequest = new CountryRateRequest();
        countryRateRequest.serviceProviders = serviceProviders;
        countryRateRequest.products = products;
        countryRateRequest.subProducts = subProducts;
        countryRateRequest.serviceTypes = serviceTypes;
        countryRateRequest.baseCurrencies = baseCurrencies;
        countryRateRequest.foreignCurrencies = foreignCurrencies;
        countryRateRequest.agents = agents;
        return countryRateRequest;
    }

    public static CountryRateRequest ofBankWise(final List<@NotNull String> serviceProviders,
            final List<@NotNull String> products, final List<@NotNull String> subProducts,
            final List<@NotNull String> serviceTypes, final List<@NotNull CurrencyUnit> baseCurrencies,
            final List<@NotNull CurrencyUnit> foreignCurrencies, final List<@NotNull String> banks,
            final List<AgentDetails> agents) {
        CountryRateRequest countryRateRequest = ofNormal(serviceProviders, products, subProducts, serviceTypes,
                baseCurrencies, foreignCurrencies, agents);
        countryRateRequest.banks = banks;
        return countryRateRequest;
    }

    @Getter(value = AccessLevel.NONE)
    @Setter(value = AccessLevel.NONE)
    private List<CountryRateIdentity> identities;

    @SuppressWarnings("unchecked")
    public List<CountryRateIdentity> identities(final RMType rmType) {
        if (this.identities == null) {
            ImmutableList<String> sps = ImmutableList.copyOf(this.serviceProviders);
            ImmutableList<String> prds = ImmutableList.copyOf(this.products);
            ImmutableList<String> subPrds = ImmutableList.copyOf(this.subProducts);
            ImmutableList<String> srvcTyps = ImmutableList.copyOf(this.serviceTypes);
            ImmutableList<AgentDetails> agnts = ImmutableList.copyOf(this.agents);
            ImmutableList<CurrencyUnit> baseCurrs = ImmutableList.copyOf(this.baseCurrencies);
            ImmutableList<CurrencyUnit> frnCurrs = ImmutableList.copyOf(this.foreignCurrencies);
            if (rmType.isNormal()) {
                List<List<Object>> combinations = Lists.cartesianProduct(sps, prds, subPrds, srvcTyps, agnts, baseCurrs,
                        frnCurrs);
                List<CountryRateIdentity> identities = new ArrayList<>(combinations.size());
                for (List<Object> combination : combinations) {
                    identities.add(CountryRateIdentity.ofNormal((String) combination.get(0),
                            (String) combination.get(1), (String) combination.get(2), (String) combination.get(3),
                            (AgentDetails) combination.get(4), CountryCurrencyDTO
                                    .of((CurrencyUnit) combination.get(5), (CurrencyUnit) combination.get(6))));
                }
                return this.identities = Collections.unmodifiableList(identities);
            }
            else {
                ImmutableList<String> bnks = ImmutableList.copyOf(this.banks);
                List<List<Object>> combinations = Lists.cartesianProduct(sps, prds, subPrds, srvcTyps, agnts, bnks,
                        baseCurrs, frnCurrs);
                List<CountryRateIdentity> identities = new ArrayList<>(combinations.size());
                for (List<Object> combination : combinations) {
                    identities.add(CountryRateIdentity.ofBankWise((String) combination.get(0),
                            (String) combination.get(1), (String) combination.get(2), (String) combination.get(3),
                            (AgentDetails) combination.get(4), (String) combination.get(5), CountryCurrencyDTO
                                    .of((CurrencyUnit) combination.get(6), (CurrencyUnit) combination.get(7))));
                }
                return this.identities = Collections.unmodifiableList(identities);
            }
        }
        else {
            return this.identities;
        }
    }
}
