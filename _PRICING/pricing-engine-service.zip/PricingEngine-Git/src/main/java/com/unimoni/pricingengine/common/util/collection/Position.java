package com.unimoni.pricingengine.common.util.collection;

public interface Position<E> extends Level {
    
    /**
     * Returns the element stored at this position.
     * 
     * @return An element
     * @throws IllegalStateException if position no longer valid
     */
    E element() throws IllegalStateException;

    boolean isLevel(final int level);
}
