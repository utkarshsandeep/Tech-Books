package com.unimoni.pricingengine.adapter.persistence.repository.bp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.domain.model.bp.BranchProcess;
import com.unimoni.pricingengine.domain.model.bp.BranchProcess_;
import com.unimoni.pricingengine.domain.model.bp.StatusType;

public abstract class BPPredicates {
    
	public static Predicate[] getBPDealPredictaes(final CriteriaBuilder criteriaBuilder, 
	        final Root<BranchProcess> root, final String deal, final StatusType status) {
		final List<Predicate> predicates = new ArrayList<>();
		
		if(deal != null) {
		    predicates.add(root.get(BranchProcess_.deal).in(deal));
		}
		if(status != null) {
		    predicates.add(criteriaBuilder.equal(root.get(BranchProcess_.status.getName()), 
		            status));
		}
		
		return predicates.toArray(new Predicate[predicates.size()]);
	}
	
	public static Predicate[] getBPDealPredictaesWithCreationDate(final CriteriaBuilder criteriaBuilder, 
            final Root<BranchProcess> root) {
        final List<Predicate> predicates = new ArrayList<>();
       
        predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get(BranchProcess_.createDateTime.getName()), 
                    LocalDate.now()));
       
        return predicates.toArray(new Predicate[predicates.size()]);
    }
	
	public static Predicate[] getBPPredictaesForRequestedOrAccepted(final CriteriaBuilder criteriaBuilder, 
            final Root<BranchProcess> root, final EnumSet<StatusType> status) {
        final List<Predicate> predicates = new ArrayList<>();
       
        if(status != null) {            
            predicates.add(root.get(BranchProcess_.status.getName()).in(StatusType.REQUEST_RECEIVED, StatusType.ACCEPTED));                   
        }
        
        return predicates.toArray(new Predicate[predicates.size()]);
    }
}
