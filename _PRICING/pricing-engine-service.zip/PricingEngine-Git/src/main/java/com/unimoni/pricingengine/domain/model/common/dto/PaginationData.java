package com.unimoni.pricingengine.domain.model.common.dto;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PaginationData extends ResourceSupport {

    // private static DEFAULT_PAGE_SIZE =

    @Setter(value = AccessLevel.NONE)
    private int currentPage;

    @Setter(value = AccessLevel.NONE)
    private int pageSize;

    @Setter(value = AccessLevel.NONE)
    @JsonIgnore
    private Sort sort;

    @Setter(value = AccessLevel.NONE)
    private int totalPages;

    @Setter(value = AccessLevel.NONE)
    private long totalRecords;

    private PaginationData(final int currentPage, final int pageSize, final Sort sort) {
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.sort = sort;
    }

    public static PaginationData of(final int currentPage, final int pageSize, final Sort sort) {
        return new PaginationData(currentPage, pageSize, sort);
    }

    public static PaginationData of(final int currentPage, final int pageSize) {
        return new PaginationData(currentPage, pageSize, null);
    }

    public static PaginationData ofFirstPage(final int pageSize) {
        return new PaginationData(0, pageSize, null);
    }

    public static PaginationData of(final Pageable pageable) {
        // int pgSize = pageable.getPageSize() == 0 ? BeanFactory.applicationProperties().getDefaultPageSize()
        // : pageable.getPageSize();
        // return new PaginationData(pageable.getPageNumber(), pgSize, pageable.getSort());
        return new PaginationData(pageable.getPageNumber(), pageable.getPageSize(), pageable.getSort());
    }

    public void update(final Pageable pageable) {
        this.currentPage = pageable.getPageNumber();
        // int pgSize = pageable.getPageSize() == 0 ? BeanFactory.applicationProperties().getDefaultPageSize()
        // : pageable.getPageSize();
        // this.pageSize = pgSize;
        this.pageSize = pageable.getPageSize();
        this.sort = pageable.getSort();
    }

    public void totalRecords(final long totalRecords) {
        this.totalRecords = totalRecords;
        this.totalPages = this.pageSize == 0 ? 1 : (int) Math.ceil((double) this.totalRecords / (double) this.pageSize);
    }

    @JsonProperty("isFirst")
    public boolean isFirst() {
        return !hasPrevious();
    }

    @JsonProperty("isLast")
    public boolean isLast() {
        return !hasNext();
    }

    @JsonProperty("hasNext")
    public boolean hasNext() {
        return getCurrentPage() + 1 < getTotalPages();
    }

    public PaginationData next() {
        if (getCurrentPage() > getTotalPages()) {
            throw new IllegalStateException("Next page not available, call this method only if hasNext() return true");
        }
        else {
            return PaginationData.of(getCurrentPage() + 1, this.getPageSize(), this.getSort());
        }
    }

    public PaginationData previous() {
        if (getCurrentPage() == 0) {
            throw new IllegalStateException(
                    "Previous page not available, call this method only if hasPrevious() return true");
        }
        else {
            return PaginationData.of(getCurrentPage() - 1, this.getPageSize(), this.getSort());
        }
    }

    @JsonProperty("hasPrevious")
    public boolean hasPrevious() {
        return getCurrentPage() > 0;
    }

    public int queryFirstResult() {
        return this.getCurrentPage() * this.getPageSize();
    }

    public int queryMaxResults() {
        return this.getPageSize();
    }

    @JsonProperty("header")
    @Override
    public String toString() {
        return String.format("Page %s of %d", getCurrentPage() + 1, getTotalPages());
    }
}
