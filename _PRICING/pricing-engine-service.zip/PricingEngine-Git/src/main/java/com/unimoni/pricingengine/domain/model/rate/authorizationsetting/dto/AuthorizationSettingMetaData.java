package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public class AuthorizationSettingMetaData {

    private int nonMatchingAuthorizationSettingCount;

    private List<AuthorizationSettingIdentity> nonMatchingAuthorizationSetting;

    private int duplicateAuthorizationSettingCount;

    private List<AuthorizationSettingResponse> duplicateAuthorizationSetting;

    private int newAuthorizationSettingCount;

    private List<AuthorizationSettingResponse> newAuthorizationSetting;

    private String message;
    
    public AuthorizationSettingMetaData setMessage(String message) {
        this.message = message;
        return this;
    }
    
    public static AuthorizationSettingMetaData of(
            final List<AuthorizationSettingIdentity> nonMatchingAuthorizationSetting,
            final List<AuthorizationSettingResponse> duplicateAuthorizationSetting,
            final List<AuthorizationSettingResponse> newAuthorizationSetting) {
        AuthorizationSettingMetaData authMetaData = new AuthorizationSettingMetaData();
        authMetaData.nonMatchingAuthorizationSetting = nonMatchingAuthorizationSetting;
        authMetaData.nonMatchingAuthorizationSettingCount = nonMatchingAuthorizationSetting != null
                ? nonMatchingAuthorizationSetting.size()
                : 0;
        authMetaData.duplicateAuthorizationSetting = duplicateAuthorizationSetting;
        authMetaData.duplicateAuthorizationSettingCount = duplicateAuthorizationSetting != null
                ? duplicateAuthorizationSetting.size()
                : 0;
        authMetaData.newAuthorizationSetting = newAuthorizationSetting;
        authMetaData.newAuthorizationSettingCount = newAuthorizationSetting != null ? newAuthorizationSetting.size()
                : 0;

        return authMetaData;
    }
}
