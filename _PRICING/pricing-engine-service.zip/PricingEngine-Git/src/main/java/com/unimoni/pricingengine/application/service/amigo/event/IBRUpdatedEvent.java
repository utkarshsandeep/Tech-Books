package com.unimoni.pricingengine.application.service.amigo.event;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;
import java.time.ZonedDateTime;

import javax.money.CurrencyUnit;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class IBRUpdatedEvent extends AmigoEvent {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;

    @JsonInclude(NON_NULL)
    private String agentCode;

    @JsonInclude(NON_NULL)
    private String bankCode;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal askValue;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal bidValue;

    private IBRUpdatedEvent(final String serviceProviderCode, final String productCode, final CurrencyUnit sourceCcy,
            final CurrencyUnit targetCcy, final BigDecimal askValue, final BigDecimal bidValue, final boolean status,
            final ZonedDateTime updatedOn) {
        super(Type.IBR_NORMAL, serviceProviderCode, productCode, sourceCcy, targetCcy, status, updatedOn);
        this.askValue = askValue;
        this.bidValue = bidValue;
    }

    private IBRUpdatedEvent(final String agentCode, final String bankCode, final String serviceProviderCode,
            final String productCode, final CurrencyUnit sourceCcy, final CurrencyUnit targetCcy,
            final BigDecimal askValue, final BigDecimal bidValue, final boolean status, final ZonedDateTime updatedOn) {
        super(Type.IBR_BANK_WISE, serviceProviderCode, productCode, sourceCcy, targetCcy, status, updatedOn);
        this.askValue = askValue;
        this.bidValue = bidValue;
        this.agentCode = agentCode;
        this.bankCode = bankCode;
    }

    public static IBRUpdatedEvent normalIBRForStatusChange(final NormalIBR normalIBR) {
        return new IBRUpdatedEvent(normalIBR.instruments().serviceProvider(), normalIBR.instruments().product(),
                normalIBR.exchange().currency().source(), normalIBR.exchange().currency().target(),
                normalIBR.exchange().rate().askValue(), normalIBR.exchange().rate().bidValue(), normalIBR.isEnabled(),
                normalIBR.updatedOn());
    }

    public static IBRUpdatedEvent normalIBRForRateChange(final NormalIBR normalIBR) {
        return new IBRUpdatedEvent(normalIBR.instruments().serviceProvider(), normalIBR.instruments().product(),
                normalIBR.exchange().currency().source(), normalIBR.exchange().currency().target(),
                normalIBR.exchange().rate().askValue(), normalIBR.exchange().rate().bidValue(), normalIBR.isEnabled(),
                normalIBR.updatedOn());
    }

    public static IBRUpdatedEvent bankWiseIBRForStatusChange(final BankWiseIBR bankWiseIBR) {
        return new IBRUpdatedEvent(bankWiseIBR.agent(), bankWiseIBR.bank(), bankWiseIBR.instruments().serviceProvider(),
                bankWiseIBR.instruments().product(), bankWiseIBR.exchange().currency().source(),
                bankWiseIBR.exchange().currency().target(), bankWiseIBR.exchange().rate().askValue(),
                bankWiseIBR.exchange().rate().bidValue(), bankWiseIBR.isEnabled(), bankWiseIBR.updatedOn());
    }

    public static IBRUpdatedEvent bankWiseIBRForRateChange(final BankWiseIBR bankWiseIBR) {
        return new IBRUpdatedEvent(bankWiseIBR.agent(), bankWiseIBR.bank(), bankWiseIBR.instruments().serviceProvider(),
                bankWiseIBR.instruments().product(), bankWiseIBR.exchange().currency().source(),
                bankWiseIBR.exchange().currency().target(), bankWiseIBR.exchange().rate().askValue(),
                bankWiseIBR.exchange().rate().bidValue(), bankWiseIBR.isEnabled(), bankWiseIBR.updatedOn());
    }
}
