package com.unimoni.pricingengine.application.event.listner;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.unimoni.pricingengine.adapter.rest.controller.events.AgentOnBoard;
import com.unimoni.pricingengine.application.events.AgentDeleteOnboardEvent;
import com.unimoni.pricingengine.common.annotation.spring.OnboardingIntegration;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateResponse;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.SearchAgentRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardResponse;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateResponse;
import com.unimoni.pricingengine.domain.model.rate.country.dto.SearchCountryRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SearchSettlementRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementRateResponse;
import com.unimoni.pricingengine.domain.model.rate.var.dto.SearchVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRResponse;
import com.unimoni.pricingengine.domain.service.agent.AgentRateService;
import com.unimoni.pricingengine.domain.service.country.CountryRateService;
import com.unimoni.pricingengine.domain.service.settlement.SettlementRateService;
import com.unimoni.pricingengine.domain.service.var.VaRService;

import lombok.extern.slf4j.Slf4j;

@Conditional(value = OnboardingIntegration.class)
@Component
@Slf4j
public class AgentDisabledListener {

	@Autowired
	private VaRService varService;

	@Autowired
	private AgentOnBoard agentOnBoard;

	@Autowired
	private Gson gson;

	@Autowired
	private SettlementRateService settlementRateService;

	@Autowired
	private CountryRateService countryRateService;

	@Autowired
	private AgentRateService agentRateService;

	@JmsListener(destination = "AGENT_DELETED", containerFactory = "topicListenerFactory")
	public void agentDeletedEvent(final Message agentDeletedEventMessage) {
		AgentDeleteOnboardEvent agentDeleteOnboard;
		String agentDeletedEventPayload = null;
		List<String> agentList = new ArrayList<String>();
		log.info("*********AGENT_DELETED EVENT*********" + agentDeletedEventMessage);
		if (agentDeletedEventMessage == null) {
			return;
		}

		try {
			TextMessage agentDeletedMessage = (TextMessage) agentDeletedEventMessage;
			agentDeletedEventPayload = agentDeletedMessage.getText();
			log.info("*****Agent Deleted event payload*****" + agentDeletedEventPayload);
		} catch (JMSException exception) {
			log.error("****Jms exception ******" + exception.getStackTrace());
			return;
		}

		if (agentDeletedEventPayload != null && !agentDeletedEventPayload.isEmpty()) {
			agentDeleteOnboard = gson.fromJson(agentDeletedEventPayload, AgentDeleteOnboardEvent.class);
			Integer agentId = agentDeleteOnboard.getAgentId();
			log.info("****AgentID****" + agentId);
			log.info("*****AgentDisplayCode******" + agentDeleteOnboard.getAgentDisplayCode());
			if (agentDeleteOnboard.getAgentDisplayCode() != null
					&& !agentDeleteOnboard.getAgentDisplayCode().isEmpty()) {
				agentList.add(agentDeleteOnboard.getAgentDisplayCode());
			}

			if (!agentList.isEmpty() && agentList != null) {
				updateAgentStatus(agentList);
			}
		}

	}

	@JmsListener(destination = "AGENT_DISABLED", containerFactory = "topicListenerFactory")
	public void agentDisabledEvent(final Message agentDisabledEventMessage) {

		log.info("*****AGENT_DISABLED EVENT*****" + agentDisabledEventMessage);

		if (agentDisabledEventMessage == null) {
			return;
		}
		TextMessage agentDisabledMessage = (TextMessage) agentDisabledEventMessage;

		String agentDisabledEventPayload = null;
		AgentDeleteOnboardEvent agentDeleteOnboard;
		try {
			agentDisabledEventPayload = agentDisabledMessage.getText();
			log.info("******Agent Deleted event payload******" + agentDisabledEventPayload);
		} catch (JMSException exception) {
			log.error("*****Jms exception ******" + exception.getStackTrace());
			return;
		}

		if (agentDisabledEventPayload != null && !agentDisabledEventPayload.isEmpty()) {
			agentDeleteOnboard = gson.fromJson(agentDisabledEventPayload, AgentDeleteOnboardEvent.class);
			Integer agentId = agentDeleteOnboard.getAgentId();
			log.info("*****AgentID*****" + agentId);
			AgentOnboardResponse agentOnboardResponse = agentOnBoard.agentOnBoard(agentId);
			log.info("*****get display code response*****" + agentOnboardResponse);
			if (agentOnboardResponse != null) {
				String agentDisplayCode = agentOnboardResponse.getCode();
				log.info("*****AgentDisplayCode to disable******" + agentDisplayCode);
				List<String> agentList = new ArrayList<String>();
				agentList.add(agentDisplayCode);
				if (!agentList.isEmpty() && agentList != null) {
					updateAgentStatus(agentList);
				}
			}

		}

	}

	public void updateAgentStatus(List<String> listOfAgents) {

		log.info("*****Updating Status*****" + listOfAgents);

		updateAgentEventsForVarLayer(listOfAgents);

	}

	public void updateAgentEventsForVarLayer(List<String> listOfAgents) {
		PaginationData page = PaginationData.of(0, 10000, null);

		List<VaRResponse> listOfNormalVaRResponse = varService
				.getAllVaRs(SearchVaRRequest.ofNormal(listOfAgents, null, null, null, null, null, true, page));

		log.info("***VAR AGENT DISPLAY CODE TO BE DISABLED FOR NORMAL***" + listOfNormalVaRResponse);

		if (listOfNormalVaRResponse.size() > 0) {
			List<String> listOfIds = listOfNormalVaRResponse.stream().map(VaRResponse::getVarId)
					.collect(Collectors.toList());
			varService.updateVarStatus(listOfIds);
			updateAgentEventsForSettlementLayer(listOfIds);

		}

		List<VaRResponse> listOfBankVarResponse = varService
				.getAllVaRs(SearchVaRRequest.ofBankWise(listOfAgents, null, null, null, null, null, null, true, page));

		log.info("***VAR AGENT DISPLAY CODE TO BE DISABLED FOR BANK***" + listOfBankVarResponse);

		if (listOfBankVarResponse.size() > 0) {
			List<String> listOfIds = listOfNormalVaRResponse.stream().map(VaRResponse::getVarId)
					.collect(Collectors.toList());
			varService.updateBanktEvents(listOfIds);
			updateAgentEventsForSettlementLayer(listOfIds);

		}
	}

	public void updateAgentEventsForSettlementLayer(List<String> listOfAgents) {
		PaginationData page = PaginationData.of(0, 10000, null);
		List<SettlementRateResponse> listOfNormalSettlementResponse = settlementRateService.getAllSettlementRates(
				SearchSettlementRatesRequest.ofNormal(listOfAgents, null, null, null, null, null, true, page));

		log.info("***SETTLEMENT AGENT DISPLAY CODE TO BE DISABLED FOR NORMAL***" + listOfNormalSettlementResponse);

		if (listOfNormalSettlementResponse.size() > 0) {
			List<String> listOfSettlementIds = listOfNormalSettlementResponse.stream()
					.map(SettlementRateResponse::getSettlementId).collect(Collectors.toList());
			settlementRateService.updateAgentEvents(listOfSettlementIds);
			updateAgentEventsForCountryLayer(listOfSettlementIds);
		}

		List<SettlementRateResponse> listOfBankSettlementResponse = settlementRateService.getAllSettlementRates(
				SearchSettlementRatesRequest.ofBankWise(listOfAgents, null, null, null, null, null, null, true, page));
		log.info("***SETTLEMENT AGENT DISPLAY CODE TO BE DISABLED FOR BANK***" + listOfBankSettlementResponse);

		if (listOfBankSettlementResponse.size() > 0) {
			List<String> listOfSettlementIds = listOfBankSettlementResponse.stream()
					.map(SettlementRateResponse::getSettlementId).collect(Collectors.toList());

			settlementRateService.updateAgentBankEvents(listOfSettlementIds);
			updateAgentEventsForCountryLayer(listOfSettlementIds);
		}
	}

	public void updateAgentEventsForCountryLayer(List<String> listOfAgents) {
		PaginationData page = PaginationData.of(0, 10000, null);
		List<CountryRateResponse> listOfNormalCountryResponse = countryRateService.getAllCountryRates(
				SearchCountryRatesRequest.ofNormal(listOfAgents, null, null, null, null, null, null, true, page));
		log.info("***COUNTRY AGENT DISPLAY CODE TO BE DISABLED FOR NORMAL***" + listOfNormalCountryResponse);
		if (listOfNormalCountryResponse.size() > 0) {

			List<String> listOfCountryIds = listOfNormalCountryResponse.stream()
					.map(CountryRateResponse::getCountryRateId).collect(Collectors.toList());
			countryRateService.updateAgentEvents(listOfCountryIds);
			updateAgentEventsForAgentLayer(listOfCountryIds);

		}

		List<CountryRateResponse> listOfBankCountryResponse = countryRateService
				.getAllCountryRates(SearchCountryRatesRequest.ofBankWise(listOfAgents, null, null, null, null, null,
						null, null, true, page));

		log.info("***COUNTRY AGENT DISPLAY CODE TO BE DISABLED FOR BANK***" + listOfBankCountryResponse);
		if (listOfBankCountryResponse.size() > 0) {

			List<String> listOfCountryIds = listOfBankCountryResponse.stream()
					.map(CountryRateResponse::getCountryRateId).collect(Collectors.toList());
			countryRateService.updateBankEvents(listOfCountryIds);
			updateAgentEventsForAgentLayer(listOfCountryIds);

		}

	}

	public void updateAgentEventsForAgentLayer(List<String> listOfAgents) {
		PaginationData page = PaginationData.of(0, 10000, null);
		List<AgentRateResponse> listOfNormalAgentResponse = agentRateService.getAllAgentRates(
				SearchAgentRatesRequest.ofNormal(listOfAgents, null, null, null, null, null, null, true, page));

		log.info("***AGENT AGENT DISPLAY CODE TO BE DISABLED FOR NORMAL***" + listOfNormalAgentResponse);

		if (listOfNormalAgentResponse.size() > 0) {

			List<String> listOfAgentIds = listOfNormalAgentResponse.stream().map(AgentRateResponse::getAgentRateId)
					.collect(Collectors.toList());
			agentRateService.updateAgentEvents(listOfAgentIds);

		}

		List<AgentRateResponse> listOfBankAgentResponse = agentRateService.getAllAgentRates(
				SearchAgentRatesRequest.ofBankWise(listOfAgents, null, null, null, null, null, null, null, true, page));

		log.info("***AGENT AGENT DISPLAY CODE TO BE DISABLED FOR BANK***" + listOfNormalAgentResponse);

		if (listOfBankAgentResponse.size() > 0) {

			List<String> listOfAgentIds = listOfBankAgentResponse.stream().map(AgentRateResponse::getAgentRateId)
					.collect(Collectors.toList());

			agentRateService.updateBankEvents(listOfAgentIds);

		}

	}

}