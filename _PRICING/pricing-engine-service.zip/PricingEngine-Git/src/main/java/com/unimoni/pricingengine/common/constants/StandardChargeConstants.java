package com.unimoni.pricingengine.common.constants;

public interface StandardChargeConstants {

    public static String SOURCE = "SOURCE";
    public static String SOURCE_BRANCH = "SOURCE_BRANCH";
    public static String SOURCE_AGENT = "SOURCE_AGENT";
    public static String SOURCE_COUNTRY = "SOURCE_COUNTRY";
    public static String SOURCE_ALL = "SOURCE_ALL";
    public static String DESTINATION = "DESTINATION";
    
    public static String DESTINATION_AGENT = "DESTINATION_AGENT";
    public static String DESTINATION_BANK = "DESTINATION_BANK";
    public static String DESTINATION_COUNTRY = "DESTINATION_COUNTRY";
    public static String DESTINATION_ALL = "DESTINATION_ALL";
    public static String BANK_CODE = "BANK_CODE";
    public static String COUNTRY_CODE = "COUNTRY_CODE";
    public static String SERVICE_TYPE = "SERVICE_TYPE";
    public static String SUB_PRODUCT = "SUB_PRODUCT";
    public static String PRODUCT = "PRODUCT";
    public static String SERVICE_PROVIDER = "SERVICE_PROVIDER";
    public static String YES = "Yes";
    public static String NO = "No";
    
}
