package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import javax.money.CurrencyUnit;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode
@ToString
public class AuthorizationSettingIdentity {

    @JsonInclude(NON_NULL)
    private RMType rateType;

    @JsonInclude(NON_NULL)
    private RateLayerType rateLayerType;

    @JsonInclude(NON_NULL)
    private String serviceProvider;

    @JsonInclude(NON_NULL)
    private String bankCode;

    @JsonInclude(NON_NULL)
    private String agentCode;

    @JsonInclude(NON_NULL)
    private CurrencyUnit currency;

    private Boolean enabled;

    public static AuthorizationSettingIdentity of(final RMType rateType, final RateLayerType rateLayerType,
            final String serviceProvider, final String bankCode, final String agentCode, final CurrencyUnit currency) {

        final AuthorizationSettingIdentity identity = new AuthorizationSettingIdentity();
        identity.rateType = rateType;
        identity.rateLayerType = rateLayerType;
        identity.serviceProvider = serviceProvider;
        identity.bankCode = bankCode;
        identity.agentCode = agentCode;
        identity.currency = currency;

        return identity;
    }
}
