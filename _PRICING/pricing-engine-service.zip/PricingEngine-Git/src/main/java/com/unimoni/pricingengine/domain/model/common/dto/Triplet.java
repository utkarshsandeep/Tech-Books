package com.unimoni.pricingengine.domain.model.common.dto;

import com.unimoni.pricingengine.common.constants.ApplicationConstants;

import com.unimoni.pricingengine.domain.model.standardcharges.OriginDestination.ODType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "of")
@ToString
@EqualsAndHashCode(of = { "code" })
@ApiModel(value = "triplet", description = "Code, Name and Type triplet")
public class Triplet<T, S, U> {

    @NonNull
    @ApiModelProperty(name = "code", dataType = "String", value = "Code", example = "XYD112")
    private T code;

    @NonNull
    @ApiModelProperty(name = "name", dataType = "String", value = "Name", example = "Foo Bar")
    private S name;

    @NonNull
    @ApiModelProperty(name = "type", dataType = "String", value = "Type", example = "AGENT")
    private U type;

    public static Triplet<String, String, ODType> allOD() {
        return Triplet.of(ApplicationConstants.ALL_INSTRUMENTS, ApplicationConstants.ALL_INSTRUMENTS, ODType.ALL);
    }

    public static Triplet<String, String, ODType> ofOD(final CodeNamePair<String, String> pair, final ODType type) {
        return Triplet.of(pair.getCode(), pair.getName(), type);
    }

    public static Triplet<String, String, ODType> ofAgent(final CodeNamePair<String, String> pair) {
        return Triplet.of(pair.getCode(), pair.getName(), ODType.AGENT);
    }

    public static Triplet<String, String, ODType> ofBranch(final CodeNamePair<String, String> pair) {
        return Triplet.of(pair.getCode(), pair.getName(), ODType.BRANCH);
    }

    public static Triplet<String, String, ODType> ofBank(final CodeNamePair<String, String> pair) {
        return Triplet.of(pair.getCode(), pair.getName(), ODType.BANK);
    }

    public static Triplet<String, String, ODType> ofCountry(final CodeNamePair<String, String> pair) {
        return Triplet.of(pair.getCode(), pair.getName(), ODType.COUNTRY);
    }
}
