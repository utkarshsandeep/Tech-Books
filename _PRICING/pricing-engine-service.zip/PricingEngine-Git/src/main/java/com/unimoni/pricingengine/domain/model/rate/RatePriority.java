package com.unimoni.pricingengine.domain.model.rate;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;

public interface RatePriority {

    public static boolean isAll(String instrument) {
        return instrument.equals(ALL_INSTRUMENTS);
    }

    public static boolean isSpecific(String instrument) {
        return !instrument.equals(ALL_INSTRUMENTS);
    }
}
