package com.unimoni.pricingengine.adapter.persistence.repository.standardcharges;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.domain.model.remittance.dto.TxnSDChargeCalculationRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.SCInstruments_;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardCharge;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardCharge_;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.SearchStandardChargesRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargesIdentity;
import com.unimoni.pricingengine.domain.model.standardcharges.types.BeneficiaryType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.ChargeBasisType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.ChargeType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.CustomerType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.PaymentMode;
import com.unimoni.pricingengine.domain.model.standardcharges.types.SwiftChargeType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.TransactionType;

public abstract class StandardChargesPredicates {

    public static Predicate[] getSCByIdentityPredicates(final Root<StandardCharge> root,
            final CriteriaBuilder criteriaBuilder, final StandardChargesIdentity scIdentity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.serviceProvider.getName()),
                scIdentity.getServiceProvider()));
        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.product.getName()),
                scIdentity.getProduct()));

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.subProduct.getName()),
                scIdentity.getSubProduct()));

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.serviceType.getName()),
                scIdentity.getServiceType()));

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.sourceCode.getName()).get("code"),
                scIdentity.getSourceCode()));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.instruments.getName())
                .get(SCInstruments_.destinationCode.getName()).get("code"), scIdentity.getDestinationCode()));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.chargeType.getName()),
                ChargeType.valueOf(scIdentity.getChargeType())));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.transactionType.getName()),
                TransactionType.valueOf(scIdentity.getTransactionType())));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.beneficiaryType.getName()),
                BeneficiaryType.valueOf(scIdentity.getBeneficiaryType())));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.customerType.getName()),
                CustomerType.valueOf(scIdentity.getCustomerType())));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.chargeBasisType.getName()),
                ChargeBasisType.valueOf(scIdentity.getChargeBasisType())));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.paymentMode.getName()),
                PaymentMode.valueOf(scIdentity.getPaymentMode())));

        predicates.add(
                criteriaBuilder.equal(root.get(StandardCharge_.currencyFrom.getName()), scIdentity.getCurrencyFrom()));

        predicates
                .add(criteriaBuilder.equal(root.get(StandardCharge_.currencyTo.getName()), scIdentity.getCurrencyTo()));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.enabled.getName()), true));

        if (scIdentity.getSwiftChargeType() != null && !scIdentity.getSwiftChargeType().isEmpty()) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.swiftChargeType.getName()),
                    SwiftChargeType.valueOf(scIdentity.getSwiftChargeType())));
        }
        else {
            predicates.add(criteriaBuilder.isNull(root.get(StandardCharge_.swiftChargeType.getName())));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getSearchStandardChargesPredicates(final Root<StandardCharge> root,
            final CriteriaBuilder criteriaBuilder, final SearchStandardChargesRequest request) {
        List<Predicate> predicates = new ArrayList<>();

        if (request.serviceProviders() != null && !request.serviceProviders().isEmpty()) {
            predicates.add(root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.serviceProvider.getName())
                    .in(request.serviceProviders()));
        }
        if (request.products() != null && !request.products().isEmpty()) {
            predicates.add(root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.product.getName())
                    .in(request.products()));
        }
        if (request.subProducts() != null && !request.subProducts().isEmpty()) {
            predicates.add(root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.subProduct.getName())
                    .in(request.subProducts()));
        }
        if (request.serviceTypes() != null && !request.serviceTypes().isEmpty()) {
            predicates.add(root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.serviceType.getName())
                    .in(request.serviceTypes()));
        }
        if (request.sourceCode() != null && !request.sourceCode().isEmpty()) {
            predicates.add(root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.sourceCode.getName())
                    .get("code").in(request.sourceCode()));
        }
        if (request.destinationCode() != null && !request.destinationCode().isEmpty()) {
            predicates.add(root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.destinationCode.getName())
                    .get("code").in(request.destinationCode()));
        }
        if (request.chargeType() != null) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.chargeType.getName()), request.chargeType()));
        }
        if (request.transactionType() != null) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.transactionType.getName()),
                    request.transactionType()));
        }
        if (request.beneficiaryType() != null) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.beneficiaryType.getName()),
                    request.beneficiaryType()));
        }
        if (request.customerType() != null) {
            predicates.add(
                    criteriaBuilder.equal(root.get(StandardCharge_.customerType.getName()), request.customerType()));
        }
        if (request.paymentMode() != null) {
            predicates
                    .add(criteriaBuilder.equal(root.get(StandardCharge_.paymentMode.getName()), request.paymentMode()));
        }
        if (request.chargeBasisType() != null) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.chargeBasisType.getName()),
                    request.chargeBasisType()));
        }

        if (request.currenciesFrom() != null && !request.currenciesFrom().isEmpty()) {
            predicates.add(
                    criteriaBuilder.equal(root.get(StandardCharge_.currencyFrom.getName()), request.currenciesFrom()));
        }

        if (request.currenciesTo() != null && !request.currenciesTo().isEmpty()) {
            predicates
                    .add(criteriaBuilder.equal(root.get(StandardCharge_.currencyTo.getName()), request.currenciesTo()));
        }

        if (request.taxIncluded() != null) {
            predicates
                    .add(criteriaBuilder.equal(root.get(StandardCharge_.taxIncluded.getName()), request.taxIncluded()));
        }

        if (request.swiftChargeType() != null) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.swiftChargeType.getName()),
                    request.swiftChargeType()));
        }

        if (request.isDisabled() != null) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.enabled.getName()), !request.isDisabled()));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getStandardChargesPredicatesForRemittance(Root<StandardCharge> root,
            CriteriaBuilder criteriaBuilder, TxnSDChargeCalculationRequest request) {
        List<Predicate> predicates = new ArrayList<>();

        if (request.transactionType() != null) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.transactionType.getName()),
                    request.transactionType()));
        }

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.enabled.getName()), true));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getPredicatesByStandardCharge(Root<StandardCharge> root, CriteriaBuilder criteriaBuilder,
            StandardCharge standardCharge) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.serviceProvider.getName()),
                standardCharge.instruments().serviceProvider()));
        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.product.getName()),
                standardCharge.instruments().product()));

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.subProduct.getName()),
                standardCharge.instruments().subProduct()));

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.serviceType.getName()),
                standardCharge.instruments().serviceType()));

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.sourceCode.getName()),
                standardCharge.instruments().sourceCode()));

        predicates.add(criteriaBuilder.equal(
                root.get(StandardCharge_.instruments.getName()).get(SCInstruments_.destinationCode.getName()),
                standardCharge.instruments().destinationCode()));

        predicates.add(
                criteriaBuilder.equal(root.get(StandardCharge_.chargeType.getName()), standardCharge.chargeType()));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.transactionType.getName()),
                standardCharge.transactionType()));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.beneficiaryType.getName()),
                standardCharge.beneficiaryType()));

        predicates.add(
                criteriaBuilder.equal(root.get(StandardCharge_.customerType.getName()), standardCharge.customerType()));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.chargeBasisType.getName()),
                standardCharge.chargeBasisType()));

        predicates.add(
                criteriaBuilder.equal(root.get(StandardCharge_.paymentMode.getName()), standardCharge.paymentMode()));

        predicates.add(
                criteriaBuilder.equal(root.get(StandardCharge_.currencyFrom.getName()), standardCharge.currencyFrom()));

        predicates.add(
                criteriaBuilder.equal(root.get(StandardCharge_.currencyTo.getName()), standardCharge.currencyTo()));

        predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.enabled.getName()), true));

        if (standardCharge.swiftChargeType() != null) {
            predicates.add(criteriaBuilder.equal(root.get(StandardCharge_.swiftChargeType.getName()),
                    standardCharge.swiftChargeType()));
        }
        else {
            predicates.add(criteriaBuilder.isNull(root.get(StandardCharge_.swiftChargeType.getName())));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }
}
