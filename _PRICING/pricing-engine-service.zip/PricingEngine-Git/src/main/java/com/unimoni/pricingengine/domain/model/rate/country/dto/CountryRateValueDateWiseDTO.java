package com.unimoni.pricingengine.domain.model.rate.country.dto;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import javax.validation.constraints.NotNull;

import org.joda.beans.Bean;
import org.joda.beans.BeanBuilder;
import org.joda.beans.JodaBeanUtils;
import org.joda.beans.MetaBean;
import org.joda.beans.MetaProperty;
import org.joda.beans.Property;
import org.joda.beans.gen.BeanDefinition;
import org.joda.beans.gen.PropertyDefinition;
import org.joda.beans.impl.direct.DirectBeanBuilder;
import org.joda.beans.impl.direct.DirectMetaBean;
import org.joda.beans.impl.direct.DirectMetaProperty;
import org.joda.beans.impl.direct.DirectMetaPropertyMap;

import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverride;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverrides;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRateValueDateWise;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@BeanDefinition
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ApiModel(value = "countryValueDateWise", description = "Country Value Date Wise")
public class CountryRateValueDateWiseDTO implements Bean {

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Cost Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Cost Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "costRate", required = true, notes = "Country cost Buy and Sell values")
    private CostDTO costRate;

    @PropertyDefinition
    @DownloadOverrides({ @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Sell Margin")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Buy Margin")) })
    @NotNull
    @ApiModelProperty(value = "marginCost", required = true, notes = "Margin cost Buy and Sell values")
    private CostDTO margin;

    @PropertyDefinition
    @DownloadOverrides({ @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Agent Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Agent Buy")) })
    @NotNull
    @ApiModelProperty(value = "agentCost", required = true, notes = "Agent cost Buy and Sell values")
    private CostDTO agent;

    public static CountryRateValueDateWiseDTO of(final CountryRateValueDateWise countryValueDateWise) {
        return of(CostDTO.of(countryValueDateWise.costRate()), CostDTO.of(countryValueDateWise.margin()),
                CostDTO.of(countryValueDateWise.agent()));
    }

    public static CountryRateValueDateWiseDTO ofBase(final BigDecimal settlementSellValue) {
        CountryRateValueDateWiseDTO settlementValueDateWise = new CountryRateValueDateWiseDTO();
        settlementValueDateWise.costRate = CostDTO.of(settlementSellValue, RateValue.ZERO);
        settlementValueDateWise.margin = CostDTO.zero();
        settlementValueDateWise.agent = CostDTO.zero();
        return settlementValueDateWise;
    }

    public static CountryRateValueDateWiseDTO ofForeign(final BigDecimal settlementBuyValue) {
        CountryRateValueDateWiseDTO settlementValueDateWise = new CountryRateValueDateWiseDTO();
        settlementValueDateWise.costRate = CostDTO.of(RateValue.ZERO, settlementBuyValue);
        settlementValueDateWise.margin = CostDTO.zero();
        settlementValueDateWise.agent = CostDTO.zero();
        return settlementValueDateWise;
    }

    public static CountryRateValueDateWiseDTO byDefault(final Cost baseSettlementCountryCost,
            final Cost foreignSettlementCountryCost, final RateDisplayMachenism RDM) {
        CountryRateValueDateWiseDTO countryValueDateWise = new CountryRateValueDateWiseDTO();
        BigDecimal countryCostRateSell;
        BigDecimal countryContRateBuy;
        if (RDM.isBCtoFC()) {
            if (baseSettlementCountryCost.buyValue().compareTo(RateValue.ZERO) == 0) {
                countryCostRateSell = RateValue.ZERO;
            }
            else {
                countryCostRateSell = foreignSettlementCountryCost.sellValue()
                        .divide(baseSettlementCountryCost.buyValue(), 8, RoundingMode.CEILING);
            }
            if (baseSettlementCountryCost.sellValue().compareTo(RateValue.ZERO) == 0) {
                countryContRateBuy = RateValue.ZERO;
            }
            else {
                countryContRateBuy = foreignSettlementCountryCost.buyValue()
                        .divide(baseSettlementCountryCost.sellValue(), 8, RoundingMode.CEILING);
            }
        }
        else {
            if (foreignSettlementCountryCost.sellValue().compareTo(RateValue.ZERO) == 0) {
                countryCostRateSell = RateValue.ZERO;
            }
            else {
                countryCostRateSell = baseSettlementCountryCost.buyValue()
                        .divide(foreignSettlementCountryCost.sellValue(), 8, RoundingMode.CEILING);
            }
            if (foreignSettlementCountryCost.buyValue().compareTo(RateValue.ZERO) == 0) {
                countryContRateBuy = RateValue.ZERO;
            }
            else {
                countryContRateBuy = baseSettlementCountryCost.sellValue()
                        .divide(foreignSettlementCountryCost.buyValue(), 8, RoundingMode.CEILING);
            }
        }
        countryValueDateWise.costRate = CostDTO.of(countryCostRateSell, countryContRateBuy);
        countryValueDateWise.margin = CostDTO.zero();
        BigDecimal agentSell;
        BigDecimal agentBuy;
        if (RDM.isBCtoFC()) {
            // Agent Sell = Country Cost Rate Sell – Country Sell Margin
            // Agent Buy = Country Cost Rate Buy + Country Buy Margin

            agentSell = countryValueDateWise.costRate.getSellValue()
                    .subtract(countryValueDateWise.margin.getSellValue());
            agentBuy = countryValueDateWise.costRate.getBuyValue().add(countryValueDateWise.margin.getBuyValue());
        }
        else {
            // Agent Sell = Country Cost Rate Sell + Country Sell Margin
            // Agent Buy = Country Cost Rate Buy - Country Buy Margin

            agentSell = countryValueDateWise.costRate.getSellValue().add(countryValueDateWise.margin.getSellValue());
            agentBuy = countryValueDateWise.costRate.getBuyValue().subtract(countryValueDateWise.margin.getBuyValue());

        }
        countryValueDateWise.agent = CostDTO.of(agentSell, agentBuy);
        return countryValueDateWise;
    }

    public static CountryRateValueDateWiseDTO byDeafultForSameBaseAndForeignCurrency(
            final Cost baseSettlementCountryCost, final Cost foreignSettlementCountryCost,
            final RateDisplayMachenism RDM) {
        CountryRateValueDateWiseDTO countryValueDateWise = new CountryRateValueDateWiseDTO();
        BigDecimal countryCostRateSell = RateValue.ONE;
        BigDecimal countryContRateBuy = RateValue.ONE;

        countryValueDateWise.costRate = CostDTO.of(countryCostRateSell, countryContRateBuy);
        countryValueDateWise.margin = CostDTO.zero();

        BigDecimal agentSell;
        BigDecimal agentBuy;
        if (RDM.isBCtoFC()) {
            agentSell = countryValueDateWise.costRate.getSellValue()
                    .subtract(countryValueDateWise.margin.getSellValue());
            agentBuy = countryValueDateWise.costRate.getBuyValue().add(countryValueDateWise.margin.getBuyValue());
        }
        else {
            agentSell = countryValueDateWise.costRate.getSellValue().add(countryValueDateWise.margin.getSellValue());
            agentBuy = countryValueDateWise.costRate.getBuyValue().subtract(countryValueDateWise.margin.getBuyValue());
        }
        countryValueDateWise.agent = CostDTO.of(agentSell, agentBuy);
        return countryValueDateWise;
    }

  //------------------------- AUTOGENERATED START -------------------------
  /**
   * The meta-bean for {@code CountryRateValueDateWiseDTO}.
   * @return the meta-bean, not null
   */
  public static CountryRateValueDateWiseDTO.Meta meta() {
    return CountryRateValueDateWiseDTO.Meta.INSTANCE;
  }

  static {
    MetaBean.register(CountryRateValueDateWiseDTO.Meta.INSTANCE);
  }

  @Override
  public CountryRateValueDateWiseDTO.Meta metaBean() {
    return CountryRateValueDateWiseDTO.Meta.INSTANCE;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the costRate.
   * @return the value of the property
   */
  public CostDTO getCostRate() {
    return costRate;
  }

  /**
   * Sets the costRate.
   * @param costRate  the new value of the property
   */
  public void setCostRate(CostDTO costRate) {
    this.costRate = costRate;
  }

  /**
   * Gets the the {@code costRate} property.
   * @return the property, not null
   */
  public final Property<CostDTO> costRate() {
    return metaBean().costRate().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the margin.
   * @return the value of the property
   */
  public CostDTO getMargin() {
    return margin;
  }

  /**
   * Sets the margin.
   * @param margin  the new value of the property
   */
  public void setMargin(CostDTO margin) {
    this.margin = margin;
  }

  /**
   * Gets the the {@code margin} property.
   * @return the property, not null
   */
  public final Property<CostDTO> margin() {
    return metaBean().margin().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the agent.
   * @return the value of the property
   */
  public CostDTO getAgent() {
    return agent;
  }

  /**
   * Sets the agent.
   * @param agent  the new value of the property
   */
  public void setAgent(CostDTO agent) {
    this.agent = agent;
  }

  /**
   * Gets the the {@code agent} property.
   * @return the property, not null
   */
  public final Property<CostDTO> agent() {
    return metaBean().agent().createProperty(this);
  }

  //-----------------------------------------------------------------------
  @Override
  public CountryRateValueDateWiseDTO clone() {
    return JodaBeanUtils.cloneAlways(this);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj != null && obj.getClass() == this.getClass()) {
      CountryRateValueDateWiseDTO other = (CountryRateValueDateWiseDTO) obj;
      return JodaBeanUtils.equal(getCostRate(), other.getCostRate()) &&
          JodaBeanUtils.equal(getMargin(), other.getMargin()) &&
          JodaBeanUtils.equal(getAgent(), other.getAgent());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int hash = getClass().hashCode();
    hash = hash * 31 + JodaBeanUtils.hashCode(getCostRate());
    hash = hash * 31 + JodaBeanUtils.hashCode(getMargin());
    hash = hash * 31 + JodaBeanUtils.hashCode(getAgent());
    return hash;
  }

  @Override
  public String toString() {
    StringBuilder buf = new StringBuilder(128);
    buf.append("CountryRateValueDateWiseDTO{");
    int len = buf.length();
    toString(buf);
    if (buf.length() > len) {
      buf.setLength(buf.length() - 2);
    }
    buf.append('}');
    return buf.toString();
  }

  protected void toString(StringBuilder buf) {
    buf.append("costRate").append('=').append(JodaBeanUtils.toString(getCostRate())).append(',').append(' ');
    buf.append("margin").append('=').append(JodaBeanUtils.toString(getMargin())).append(',').append(' ');
    buf.append("agent").append('=').append(JodaBeanUtils.toString(getAgent())).append(',').append(' ');
  }

  //-----------------------------------------------------------------------
  /**
   * The meta-bean for {@code CountryRateValueDateWiseDTO}.
   */
  public static class Meta extends DirectMetaBean {
    /**
     * The singleton instance of the meta-bean.
     */
    static final Meta INSTANCE = new Meta();

    /**
     * The meta-property for the {@code costRate} property.
     */
    private final MetaProperty<CostDTO> _costRate = DirectMetaProperty.ofReadWrite(
        this, "costRate", CountryRateValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-property for the {@code margin} property.
     */
    private final MetaProperty<CostDTO> _margin = DirectMetaProperty.ofReadWrite(
        this, "margin", CountryRateValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-property for the {@code agent} property.
     */
    private final MetaProperty<CostDTO> _agent = DirectMetaProperty.ofReadWrite(
        this, "agent", CountryRateValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-properties.
     */
    private final Map<String, MetaProperty<?>> _metaPropertyMap$ = new DirectMetaPropertyMap(
        this, null,
        "costRate",
        "margin",
        "agent");

    /**
     * Restricted constructor.
     */
    protected Meta() {
    }

    @Override
    protected MetaProperty<?> metaPropertyGet(String propertyName) {
      switch (propertyName.hashCode()) {
        case -424754611:  // costRate
          return _costRate;
        case -1081309778:  // margin
          return _margin;
        case 92750597:  // agent
          return _agent;
      }
      return super.metaPropertyGet(propertyName);
    }

    @Override
    public BeanBuilder<? extends CountryRateValueDateWiseDTO> builder() {
      return new DirectBeanBuilder<>(new CountryRateValueDateWiseDTO());
    }

    @Override
    public Class<? extends CountryRateValueDateWiseDTO> beanType() {
      return CountryRateValueDateWiseDTO.class;
    }

    @Override
    public Map<String, MetaProperty<?>> metaPropertyMap() {
      return _metaPropertyMap$;
    }

    //-----------------------------------------------------------------------
    /**
     * The meta-property for the {@code costRate} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> costRate() {
      return _costRate;
    }

    /**
     * The meta-property for the {@code margin} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> margin() {
      return _margin;
    }

    /**
     * The meta-property for the {@code agent} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> agent() {
      return _agent;
    }

    //-----------------------------------------------------------------------
    @Override
    protected Object propertyGet(Bean bean, String propertyName, boolean quiet) {
      switch (propertyName.hashCode()) {
        case -424754611:  // costRate
          return ((CountryRateValueDateWiseDTO) bean).getCostRate();
        case -1081309778:  // margin
          return ((CountryRateValueDateWiseDTO) bean).getMargin();
        case 92750597:  // agent
          return ((CountryRateValueDateWiseDTO) bean).getAgent();
      }
      return super.propertyGet(bean, propertyName, quiet);
    }

    @Override
    protected void propertySet(Bean bean, String propertyName, Object newValue, boolean quiet) {
      switch (propertyName.hashCode()) {
        case -424754611:  // costRate
          ((CountryRateValueDateWiseDTO) bean).setCostRate((CostDTO) newValue);
          return;
        case -1081309778:  // margin
          ((CountryRateValueDateWiseDTO) bean).setMargin((CostDTO) newValue);
          return;
        case 92750597:  // agent
          ((CountryRateValueDateWiseDTO) bean).setAgent((CostDTO) newValue);
          return;
      }
      super.propertySet(bean, propertyName, newValue, quiet);
    }

  }

  //-------------------------- AUTOGENERATED END --------------------------
}
