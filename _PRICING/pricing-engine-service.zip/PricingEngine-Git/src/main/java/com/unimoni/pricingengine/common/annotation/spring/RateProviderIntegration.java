package com.unimoni.pricingengine.common.annotation.spring;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.unimoni.pricingengine.infra.config.SpringProfiles;

public class RateProviderIntegration implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        return context.getEnvironment().acceptsProfiles(SpringProfiles.JMS)
                && context.getEnvironment().acceptsProfiles(SpringProfiles.RATE_PROVIDER);
    }
}
