package com.unimoni.pricingengine.adapter.rest.controller.country;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addError;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.COUNTRY_RATE_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.COUNTRY_RATE_CREATION_FAILED;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.COUNTRY_RATE_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.BANK_WISE_COUNTRY_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_BANK_WISE_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_BANK_WISE_META_DATA_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_BANK_WISE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_CALCULATE_AGENT_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_CALCULATE_MARGIN_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_NORMAL_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_NORMAL_META_DATA_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_NORMAL_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.COUNTRY_RATE_RM_TYPE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.CountryMarkUpRate.NORMAL_COUNTRY_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import javax.money.CurrencyUnit;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryFormulaDTO;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateMetaData;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateRequest;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateResponse;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CreateCountryRateRequest;
import com.unimoni.pricingengine.domain.model.rate.country.dto.SearchCountryRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.country.dto.UpdateCountryRateRequest;
import com.unimoni.pricingengine.domain.service.country.CountryRateService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "Country", description = "Agent Margin (Country Rate Layer)", tags = "5th Layer")
@RestController
@RequestMapping(PRICING_API)
public class CountryRateController {

    @Autowired
    private CountryRateService countryRateService;

    @Autowired
    private PaginatedResourceAssembler<CountryRateResponse, String> settlementPageAssembler;

    private final CopyOnWriteArrayList<SseEmitter> normalCountryEmitters = new CopyOnWriteArrayList<>();

    private final CopyOnWriteArrayList<SseEmitter> bankWiseCountryEmitters = new CopyOnWriteArrayList<>();

    @GetMapping(COUNTRY_RATE_NORMAL_META_DATA_URI)
    // @formatter:off
    @ApiOperation( nickname = "get-meta-data-to-create-normal-country-rate", 
        value = "Checks if Settlement rates exist, duplicate records exists "
                + "and accordingly return the meta data to create new Country Rate records", 
        notes = "", 
        response = CountryRateMetaData.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "agents", paramType = "query", required = true,
            dataType = "String", type = "array", dataTypeClass = AgentDetails.class,
            value = "Agent in the format: code,(BC_TO_FC|FC_TO_BC),(AGENT|BRANCH) example AGT0001,BC_TO_FC,AGENT", allowMultiple = true, 
            example = "AGT0001,BC_TO_FC,AGENT"
        ),
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Base Currency Code in ISO format e.g. USD", allowMultiple = true, 
            example = "INR", required = true
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Foreign Currency Code in ISO format e.g. USD", allowMultiple = true, 
            example = "INR", required = true
        )
    })
    @Valid
    public ResponseEntity<CountryRateMetaData> reviewNormalCountryRates(
            @RequestParam(value = "agents", required = true) @NotEmpty final List<@NotNull AgentDetails> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", required = true, example = "UAE")
            @RequestParam(value = "serviceProviders", required = true) @NotEmpty final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", required = true, example = "Remittance")
            @RequestParam(value = "products", required = true) @NotEmpty final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", required = true, example = "Account Credit")
            @RequestParam(value = "subProducts", required = true) @NotEmpty final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", required = true, example = "Flash")
            @RequestParam(value = "serviceTypes", required = true) @NotEmpty final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "baseCurrencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> foreignCurrencies) {
    // @formatter:on 

        return ResponseEntity.ok(countryRateService.createCountryRateMetaData(RMType.NORMAL,
                CountryRateRequest.ofNormal(serviceProviders, products, subProducts, serviceTypes, baseCurrencies,
                        foreignCurrencies, agents.stream().distinct().collect(Collectors.toList()))));
    }

    @GetMapping(COUNTRY_RATE_BANK_WISE_META_DATA_URI)
    // @formatter:off
    @ApiOperation( nickname = "get-meta-data-to-create-normal-country-rate", 
        value = "Checks if Settlement rates exist, duplicate records exists "
                + "and accordingly return the meta data to create new Country Rate records", 
        notes = "", 
        response = CountryRateMetaData.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "agents", paramType = "query", required = true,
            dataType = "String", type = "array", dataTypeClass = AgentDetails.class,
            value = "Agent in the format: code,(BC_TO_FC|FC_TO_BC),(AGENT|BRANCH) example AGT0001,BC_TO_FC,BRANCH", allowMultiple = true, 
            example = "AGT0001,BC_TO_FC,BRANCH"
        ),
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Base Currency Code in ISO format e.g. USD", allowMultiple = true, 
            example = "INR", required = true
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Foreign Currency Code in ISO format e.g. USD", allowMultiple = true, 
            example = "INR", required = true
        )
    })
    @Valid
    public ResponseEntity<CountryRateMetaData> reviewBankWiseCountryRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", required = true, example = "HDFC")
            @RequestParam(value = "banks", required = true) @NotEmpty final List<@NotEmpty String> banks, 
            @RequestParam(value = "agents", required = true) @NotEmpty final List<@NotNull AgentDetails> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", required = true, example = "UAE")
            @RequestParam(value = "serviceProviders", required = true) @NotEmpty final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", required = true, example = "Remittance")
            @RequestParam(value = "products", required = true) @NotEmpty final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", required = true, example = "Account Credit")
            @RequestParam(value = "subProducts", required = true) @NotEmpty final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", required = true, example = "Flash")
            @RequestParam(value = "serviceTypes", required = true) @NotEmpty final List<@NotEmpty String> serviceTypes,
            @RequestParam(value = "baseCurrencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> foreignCurrencies) {
    // @formatter:on 
        return ResponseEntity.ok(countryRateService.createCountryRateMetaData(RMType.BANK_WISE,
                CountryRateRequest.ofBankWise(serviceProviders, products, subProducts, serviceTypes, baseCurrencies,
                        foreignCurrencies, banks.stream().distinct().collect(Collectors.toList()),
                        agents.stream().distinct().collect(Collectors.toList()))));
    }

    @PostMapping(COUNTRY_RATE_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "create-country-rates", 
        value = "Creates one or multiple new Country rate records", 
        notes = "",  
        response = CountryRateResponse.class,
        responseContainer = "List"
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    @ApiResponses(value = { 
            @ApiResponse(response = CountryRateResponse.class, responseContainer = "List", code = 201, 
                    message = "One or more records created successfully"),
            @ApiResponse(code = 400, message = "Could not create records for supplied input") 
        }
    )
    @Valid
    public ResponseEntity<List<CountryRateResponse>> createCountryRates(
            final @PathVariable(name = "rmType", required = true) RMType rmType,
            @ApiParam(required = true, name = "createRequests", value = "A List of create Country rate requests")
            @RequestBody @Valid @NotEmpty final List<@Valid CreateCountryRateRequest> createRequests) {
    // @formatter:on 

        if (rmType.isBankWise()) {
            createRequests.forEach((createRequest) -> {
                if (!createRequest.getBank().isPresent()) {
                    throw new RateException(RateExceptionExceptionType.BANK_REQUIRED_FOR_BANK_WISE_REQUEST,
                            Status.BAD_REQUEST);
                }
            });
        }
        List<CountryRateResponse> countryRates = countryRateService.createCountryRates(rmType, createRequests);
        if (!countryRates.isEmpty()) { // All created
            return ResponseEntity.status(HttpStatus.CREATED)
                    .headers(addSuccess(getMessage(COUNTRY_RATE_CREATED_SUCCESSFULLY, countryRates.size())))
                    .body(countryRates);
        }
        else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .headers(addError(getMessage(COUNTRY_RATE_CREATION_FAILED))).build();
        }
    }

    @GetMapping(COUNTRY_RATE_NORMAL_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-country-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Country rate records matching the selection filters and sort criteria", 
        notes = "",
        response = CountryRateResponse.class,
        responseContainer = "List"
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Base Currency ISO Code e.g. USD", allowMultiple = true, 
            example = "INR"
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Foreign Currency ISO Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Paginated
    @Valid
    public ResponseEntity<PaginatedResource<Resource<CountryRateResponse>>> getAllNormalCountryRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "baseCurrencies", required = false) final List<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = false) final List<@NotNull CurrencyUnit> foreignCurrencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @RequestParam @ApiIgnore Map<String, Object> requestParams) {
    // @formatter:on

        List<CountryRateResponse> results = countryRateService
                .getAllCountryRates(SearchCountryRatesRequest.ofNormal(agents, serviceProviders, products, subProducts,
                        serviceTypes, baseCurrencies, foreignCurrencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(settlementPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(COUNTRY_RATE_NORMAL_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-normal-country-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Normal Country rate records matching the selection filters and sort criteria", 
        notes = "",
        response = Void.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Base Currency ISO Code e.g. USD", allowMultiple = true, 
            example = "INR"
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Foreign Currency ISO Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public void downloadNormalCountryRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "baseCurrencies", required = false) final List<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = false) final List<@NotNull CurrencyUnit> foreignCurrencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on

        FileDownloadHelper.downloadFile(
                SearchCountryRatesRequest.ofNormalDownload(agents, serviceProviders, products, subProducts,
                        serviceTypes, baseCurrencies, foreignCurrencies, status),
                countryRateService::getAllCountryRates, downloadFileType, fileName, DownloadContext.NORMAL_COUNTRY_RATE,
                response);
    }

    @GetMapping(COUNTRY_RATE_BANK_WISE_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-country-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of Bank wise Country rate records matching the selection filters and sort criteria", 
        notes = "",
        response = CountryRateResponse.class,
        responseContainer = "List"
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Base Currency ISO Code e.g. USD", allowMultiple = true, 
            example = "INR"
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Foreign Currency ISO Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Paginated
    @Valid
    public ResponseEntity<PaginatedResource<Resource<CountryRateResponse>>> getAllBankWiseCountryRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "baseCurrencies", required = false) final List<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = false) final List<@NotNull CurrencyUnit> foreignCurrencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status, 
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @RequestParam @ApiIgnore Map<String, Object> requestParams) {
    // @formatter:on

        List<CountryRateResponse> results = countryRateService
                .getAllCountryRates(SearchCountryRatesRequest.ofBankWise(agents, banks, serviceProviders, products,
                        subProducts, serviceTypes, baseCurrencies, foreignCurrencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(settlementPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(COUNTRY_RATE_BANK_WISE_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-bank-wise-country-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Bank wise Country rate records matching the selection filters and sort criteria", 
        notes = "",
        response = Void.class
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Base Currency ISO Code e.g. USD", allowMultiple = true, 
            example = "INR"
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", type = "array", 
            value = "Foreign Currency ISO Code e.g. USD", allowMultiple = true, 
            example = "INR"
        )
    })
    @Valid
    public void downloadBankWiseCountryRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1etc.", example = "AGNT00X1")
            @RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents, 
            @ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC")
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.")
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.")
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.")
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes, 
            @RequestParam(value = "baseCurrencies", required = false) final List<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = false) final List<@NotNull CurrencyUnit> foreignCurrencies, 
            @ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false")
            @RequestParam(value = "status", required = false) final Boolean status,  
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
    // @formatter:on

        FileDownloadHelper.downloadFile(
                SearchCountryRatesRequest.ofBankWiseDownload(agents, banks, serviceProviders, products, subProducts,
                        serviceTypes, baseCurrencies, foreignCurrencies, status),
                countryRateService::getAllCountryRates, downloadFileType, fileName,
                DownloadContext.BANK_WISE_AGENT_RATE, response);
    }

    @PatchMapping(COUNTRY_RATE_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-country-rates", 
        value = "Updates one or multiple Country rate records", 
        notes = "Request should only contain the updated values "
                + "If a value is not changed the respective value should not be there in request."
                + "<b>You can only update the status of record and Margin/Agent sell and Margin buy value</b>", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = CountryRateResponse.class,
        responseContainer = "List"
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    @Valid
    public ResponseEntity<List<CountryRateResponse>> updateCountryRates(
            final @PathVariable(name = "rmType", required = true) RMType rmType,
            @RequestBody @Valid @NotEmpty final Map<@NotEmpty String, @NotNull UpdateCountryRateRequest> updates) {
        // @formatter:on

        List<CountryRateResponse> results = countryRateService.updateCountryRates(rmType, updates);
        return ResponseEntity.ok().headers(addSuccess(getMessage(COUNTRY_RATE_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }

    @GetMapping(COUNTRY_RATE_CALCULATE_MARGIN_URI)
    // @formatter:off
    @ApiOperation(nickname = "calculate-margin", 
        value = "Calculates and returns the Margin for Country Markup of provided Value Date Wise as per following formulas:", 
        notes = "<b>For scenario where From RateDisplay Mechanism  = Base Currency To Foreign Currency</b>" + 
                "        <ul><li> Country Sell margin= Country Cost Rate Sell – Agent Sell</li>" + 
                "        <li> Country Buy Margin= Agent Buy - Country Cost Rate Buy</li></ul>"
                + "<b>For scenario where To currency = Foreign Currency - Base Currency</b>" + 
                "        <ul><li> Country Sell margin= Agent Sell - Country Cost Rate Sell</li>" + 
                "        <li> Country Buy Margin= Country Cost Rate Buy - Agent Buy</li></ul>", 
        response = CountryFormulaDTO.class
    )
    @Valid
    public ResponseEntity<CountryFormulaDTO> calculateMargin(
            @ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String")
            @RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
            @ApiParam(name = "countrySell", value = "Country cost sell value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "countrySell", required = true) @NotNull final BigDecimal countrySell,
            @ApiParam(name = "countryBuy", value = "Country cost buy value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "countryBuy", required = true) @NotNull final BigDecimal countryBuy,
            @ApiParam(name = "agentSell", value = "Agent cost sell value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "agentSell", required = true) @NotNull final BigDecimal agentSell,
            @ApiParam(name = "agentBuy", value = "Agent cost sell value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "agentBuy", required = true) @NotNull final BigDecimal agentBuy) {
    // @formatter:on 
        return ResponseEntity.ok(CountryFormulaDTO.byMarginFormula(RDM, countrySell, countryBuy, agentSell, agentBuy));
    }

    @GetMapping(COUNTRY_RATE_CALCULATE_AGENT_URI)
    // @formatter:off
    @ApiOperation(nickname = "calculate-agent", 
            value = "Calculates and returns the Agent Rate for Country Markup of provided Value Date Wise as per following formulas:", 
            notes = "<b>For scenario where From RateDisplay Mechanism  = BC_FC</b>" + 
                    "        <ul><li> Agent Sell = Country Cost Rate Sell – Country Sell Margin</li>" + 
                    "        <li> Agent Buy = Country Cost Rate Buy + Country Buy Margin</li></ul>"
                    + "<b>For scenario where To currency = Foreign Currency To Base Currency</b>" + 
                    "        <ul><li> Agent Sell = Country Cost Rate Sell + Country Sell Margin</li>" + 
                    "        <li> Agent Buy = Country Cost Rate Buy - Country Buy Margin</li></ul>", 
        response = CountryFormulaDTO.class
    )
    @Valid
    public ResponseEntity<CountryFormulaDTO> calculateAgentRate(
            @ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String")
            @RequestParam(name = "rateDisplayMachenism", required = true) @NotNull final RateDisplayMachenism RDM,
            @ApiParam(name = "countrySell", value = "Country cost sell value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "countrySell", required = true) @NotNull final BigDecimal countrySell,
            @ApiParam(name = "countryBuy", value = "Country cost buy value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "countryBuy", required = true) @NotNull final BigDecimal countryBuy,
            @ApiParam(name = "marginSell", value = "Margin cost sell value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "marginSell", required = true) @NotNull final BigDecimal marginSell,
            @ApiParam(name = "marginBuy", value = "Margin cost buy value in BigDecimal with " + 
                    + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
            @RequestParam(value = "marginBuy", required = true) @NotNull final BigDecimal marginBuy) {
    // @formatter:on 
        return ResponseEntity.ok(CountryFormulaDTO.byAgentFormula(RDM, countrySell, countryBuy, marginSell, marginBuy));
    }

    // --------------------- Server Sent Events Code Start --------------------------

    @GetMapping(NORMAL_COUNTRY_SERVER_SENT_EVENTS)
    public SseEmitter sendNormalVARSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.normalCountryEmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.normalCountryEmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.normalCountryEmitters.remove(emitter);
        });

        return emitter;
    }

    @GetMapping(BANK_WISE_COUNTRY_SERVER_SENT_EVENTS)
    public SseEmitter sendBankWiseVARSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.bankWiseCountryEmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.bankWiseCountryEmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.bankWiseCountryEmitters.remove(emitter);
        });

        return emitter;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleServerSentEvents(CountryRateResponse countryRateResponse) {
        List<SseEmitter> normalDeadEmitters = new ArrayList<>();
        List<SseEmitter> bankDeadEmitters = new ArrayList<>();

        if (countryRateResponse.getBank() != null && !countryRateResponse.getBank().isEmpty()) {
            this.bankWiseCountryEmitters.forEach(emitter -> {
                try {
                    emitter.send(countryRateResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    bankDeadEmitters.add(emitter);
                }
            });

            this.bankWiseCountryEmitters.removeAll(bankDeadEmitters);
        }
        else {
            this.normalCountryEmitters.forEach(emitter -> {
                try {
                    emitter.send(countryRateResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    normalDeadEmitters.add(emitter);
                }
            });

            this.normalCountryEmitters.removeAll(normalDeadEmitters);
        }
    }

    // --------------------- Server Sent Events Code Ends --------------------------
}
