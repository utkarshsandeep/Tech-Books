package com.unimoni.pricingengine.adapter.rest.controller.standardcharges;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addError;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_ADD_AMOUNTRANGE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_AMOUNT_RANGE_UPDATED_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_AMOUNT_RANGE_VALIDATE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_CREATED_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_STANDARD_CHARGE_UPLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_UPDATED_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.StandardCharges.SC_VALIDATED_URI;
import static com.unimoni.pricingengine.common.constants.StandardChargeMessageConstants.AMOUNT_RANGE_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.StandardChargeMessageConstants.STANDARD_CHARGES_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.StandardChargeMessageConstants.STANDARD_CHARGES_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.StandardChargeMessageConstants.STANDARD_CHARGES_STATUS_UPDATE_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.StandardChargeMessageConstants.UPLOAD_FAILED;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static org.springframework.http.MediaType.ALL_VALUE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.exception.StandardChargeException;
import com.unimoni.pricingengine.common.exception.StandardChargeException.StandardChargeExceptionType;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.CreateAmountRangeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.CreateStandardChargeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.SearchStandardChargesRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargeAmountRangeResponse;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargeUploadResponse;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargesMetaData;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargesResponse;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargesSearchResponse;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargesVM;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StatusChangeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.UpdateAmountRangeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.ValidateAmountRangeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.types.BeneficiaryType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.ChargeBasisType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.ChargeType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.CustomerType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.PaymentMode;
import com.unimoni.pricingengine.domain.model.standardcharges.types.SwiftChargeType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.TransactionType;
import com.unimoni.pricingengine.domain.service.standardcharges.StandardChargesService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "STANDARD_CHARGES", description = "Standard Charges APIs", tags = "Standard Charges")
@RestController
@RequestMapping(PRICING_API)
public class StandardChargesController {

    @Autowired
    private StandardChargesService scService;

    @Autowired
    private PaginatedResourceAssembler<StandardChargesSearchResponse, String> scAssembler;

     @GetMapping(SC_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-page-standard-charges", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets a page of standard charges records matching the selection filters and sort criteria", 
        notes = "",
        response = StandardChargesSearchResponse.class,
        responseContainer = "PaginatedResource"
    )
    @ApiImplicitParams({        
        @ApiImplicitParam(name = "transactionType", paramType = "query",
            dataType = "String", type = "array", dataTypeClass = TransactionType.class,
            value = "Transaction Type in the format: code(SEND, RECEIVE)", allowMultiple = false, 
                    allowableValues = "SEND, RECEIVE, CANCEL_BEFORE_PROVIDER, CANCEL_AFTER_PROVIDER"
        ),
        @ApiImplicitParam(name = "chargeType", paramType = "query",
            dataType = "String", type = "array", dataTypeClass = ChargeType.class,
            value = "chargeType based on transaction type", allowMultiple = false, 
                    allowableValues = "COMMISSION, TAX, OTHER_CHARGES, ADDITIONAL_CHARGES, CARD_CHARGES, BACKEND_CHARGES, "
                            + "CANCELLATION_CHARGES, SWIFT_CHARGES"
        ),
        @ApiImplicitParam(name = "swiftChargeType", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = SwiftChargeType.class,
        value = "Swift chargeType", allowMultiple = false, 
                allowableValues = "SHA, BEN, OUR"
        ),
        @ApiImplicitParam(name = "paymentMode", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = PaymentMode.class,
        value = "paymentMode", allowMultiple = false, 
                allowableValues = "All, ACCOUNT, CASH, CHEQUE, CREDIT_CARD, DEBIT_CARD, KNET, DIRECT_DEBIT, HYBRID, ACH, DRAFT, ONLINE, NFC_PAYMENT"
        ),
        @ApiImplicitParam(name = "chargeBasisType", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = ChargeBasisType.class,
        value = "chargeBasisType", allowMultiple = false, 
                allowableValues = "PAYIN_TO_PAYOUT, PAYOUT_TO_PAYIN"
        ),
        @ApiImplicitParam(name = "customerType", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = CustomerType.class,
        value = "Customer Type", allowMultiple = false, 
                allowableValues = "All, CORPORATE, INDIVIDUAL"
        ),
        @ApiImplicitParam(name = "beneficiaryType", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = BeneficiaryType.class,
        value = "Beneficiary Type", allowMultiple = false, 
                allowableValues = "All, CORPORATE, INDIVIDUAL"
        ),
        @ApiImplicitParam(name = "currenciesFrom", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
                ),
        @ApiImplicitParam(name = "currenciesTo", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
                )
    })
    @Paginated
    public ResponseEntity<PaginatedResource<Resource<StandardChargesSearchResponse>>> getAllStandardCharges (            
            @ApiParam(allowMultiple = true, type = "String", value = "Source Code such as agent code etc.", example = "ARxxxx")
            @RequestParam(value = "source", required = false) final List<String> sourceCode,           
            @ApiParam(allowMultiple = true, type = "String", value = "Destination Code such as agent code etc.", example = "ARxxxx")
            @RequestParam(value = "destination", required = false) final List<String> destinationCode, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<String> serviceTypes,
            @ApiParam(allowMultiple = true, type = "array", allowEmptyValue = false, value = "ISO Currency From e.g. USD", example = "USD")
            @RequestParam(value = "currenciesFrom", required = false) final List<String> currenciesFrom,
            @ApiParam(allowMultiple = true, type = "array", allowEmptyValue = false, value = "ISO Currency To e.g. USD", example = "USD")
            @RequestParam(value = "currenciesTo", required = false) final List<String> currenciesTo,
            @RequestParam(value = "isDisabled", required = false) final Boolean status,
            @RequestParam(value = "paymentMode", required = false) final PaymentMode paymentMode,
            @RequestParam(value = "transactionType", required = false) final TransactionType transactionType,
            @RequestParam(value = "chargeType", required = false) final ChargeType chargeType,
            @RequestParam(value = "swiftChargeType", required = false) final SwiftChargeType swiftChargeType,
            @RequestParam(value = "beneficiaryType", required = false) final BeneficiaryType beneficiaryType,
            @RequestParam(value = "chargeBasisType", required = false) final ChargeBasisType chargeBasisType,
            @RequestParam(value = "customerType", required = false) final CustomerType customerType,
            @RequestParam(value = "taxIncluded", required = false) final Boolean taxIncluded,
            
            @ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, 
                    sort = { "SERVICE_PROVIDER_CODE" }, direction = Sort.Direction.ASC) final Pageable pageable, 
            @ApiIgnore final PaginationData page, 
            @RequestParam @ApiIgnore Map<String, Object> requestParams) {
         // @formatter:on
        List<StandardChargesVM> results = scService.getAllStandardCharges(
                SearchStandardChargesRequest.of(sourceCode, destinationCode, serviceProviders, products, subProducts,
                        serviceTypes, currenciesFrom, currenciesTo, status, paymentMode, transactionType, chargeType,
                        chargeBasisType, customerType, beneficiaryType, taxIncluded, swiftChargeType, page));

        //TODO: need to change at later stage and return directly StandardChargesVM
        return ResponseEntity.ok(scAssembler.assemble(results.stream()
                .map(StandardChargesSearchResponse::of).collect(ImmutableCollectors.toImmutableList()),
                page, requestParams));
    }

    @GetMapping(SC_DOWNLOAD_URI)
    // @formatter:off
    @ApiOperation(nickname = "download-standard-charges", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Download all Standard Charges matching the selection filters and sort criteria", 
        response = Void.class, 
        notes = "")
    @ApiImplicitParams({        
        @ApiImplicitParam(name = "transactionType", paramType = "query",
            dataType = "String", type = "array", dataTypeClass = TransactionType.class,
            value = "Transaction Type in the format: code(SEND, RECEIVE)", allowMultiple = false, 
                    allowableValues = "SEND, RECEIVE, CANCEL_BEFORE_PROVIDER, CANCEL_AFTER_PROVIDER"
        ),
        @ApiImplicitParam(name = "chargeType", paramType = "query",
            dataType = "String", type = "array", dataTypeClass = ChargeType.class,
            value = "chargeType based on transaction type", allowMultiple = false, 
                    allowableValues = "COMMISSION, TAX, OTHER_CHARGES, ADDITIONAL_CHARGES, CARD_CHARGES, BACKEND_CHARGES, "
                            + "CANCELLATION_CHARGES, SWIFT_CHARGES"
        ),
        @ApiImplicitParam(name = "swiftChargeType", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = SwiftChargeType.class,
        value = "Swift chargeType", allowMultiple = false, 
                allowableValues = "SHA, BEN, OUR"
        ),
        @ApiImplicitParam(name = "paymentMode", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = PaymentMode.class,
        value = "paymentMode", allowMultiple = false, 
                allowableValues = "All, CASH, ACCOUNT"
        ),
        @ApiImplicitParam(name = "chargeBasisType", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = ChargeBasisType.class,
        value = "chargeBasisType", allowMultiple = false, 
                allowableValues = "PAYIN_TO_PAYOUT, PAYOUT_TO_PAYIN"
        ),
        @ApiImplicitParam(name = "customerType", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = CustomerType.class,
        value = "Customer Type", allowMultiple = false, 
                allowableValues = "All, CORPORATE, INDIVIDUAL"
        ),
        @ApiImplicitParam(name = "beneficiaryType", paramType = "query",
        dataType = "String", type = "array", dataTypeClass = BeneficiaryType.class,
        value = "Beneficiary Type", allowMultiple = false, 
                allowableValues = "All, CORPORATE, INDIVIDUAL"
        ),
        @ApiImplicitParam(name = "currenciesFrom", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
                ),
        @ApiImplicitParam(name = "currenciesTo", paramType = "query", 
            dataType = "String", type = "array", 
            value = "ISO Currency Code e.g. USD", allowMultiple = true, 
            example = "INR"
                )
    })
    @Valid
    public void downloadStandardCharges(                      
            @ApiParam(allowMultiple = true, type = "String", value = "Source Code such as agent code etc.", example = "ARxxxx")
            @RequestParam(value = "source", required = false) final List<String> sourceCode,           
            @ApiParam(allowMultiple = true, type = "String", value = "Destination Code such as agent code etc.", example = "ARxxxx")
            @RequestParam(value = "destination", required = false) final List<String> destinationCode, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE")
            @RequestParam(value = "serviceProviders", required = false) final List<String> serviceProviders, 
            @ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", example = "Remittance")
            @RequestParam(value = "products", required = false) final List<String> products, 
            @ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit")
            @RequestParam(value = "subProducts", required = false) final List<String> subProducts, 
            @ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", example = "Flash")
            @RequestParam(value = "serviceTypes", required = false) final List<String> serviceTypes,
            @ApiParam(allowMultiple = true, type = "array", allowEmptyValue = false, value = "ISO Currency From e.g. USD", example = "USD")
            @RequestParam(value = "currenciesFrom", required = false) final List<String> currenciesFrom,
            @ApiParam(allowMultiple = true, type = "array", allowEmptyValue = false, value = "ISO Currency To e.g. USD", example = "USD")
            @RequestParam(value = "currenciesTo", required = false) final List<String> currenciesTo,
            @RequestParam(value = "isDisabled", required = false) final Boolean status,
            @RequestParam(value = "paymentMode", required = false) final PaymentMode paymentMode,
            @RequestParam(value = "transactionType", required = false) final TransactionType transactionType,
            @RequestParam(value = "chargeType", required = false) final ChargeType chargeType,
            @RequestParam(value = "swiftChargeType", required = false) final SwiftChargeType swiftChargeType,
            @RequestParam(value = "beneficiaryType", required = false) final BeneficiaryType beneficiaryType,
            @RequestParam(value = "chargeBasisType", required = false) final ChargeBasisType chargeBasisType,
            @RequestParam(value = "customerType", required = false) final CustomerType customerType,
            @RequestParam(value = "taxIncluded", required = false) final Boolean taxIncluded,
            @ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken")
            @RequestParam(value = "fileName", required = false) final String fileName,
            @ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true)
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
            @ApiIgnore final HttpServletResponse response) {
     // @formatter:on

        FileDownloadHelper.downloadFile(
                SearchStandardChargesRequest.ofDownload(sourceCode, destinationCode, serviceProviders, products,
                        subProducts, serviceTypes, currenciesFrom, currenciesTo, status, paymentMode, transactionType,
                        chargeType, chargeBasisType, customerType, beneficiaryType, taxIncluded, swiftChargeType),
                scService::getAllStandardCharges, downloadFileType, fileName, DownloadContext.STANDARD_CHARGE,
                response);
    }

    @PostMapping(SC_VALIDATED_URI)
    // @formatter:off
    @ApiOperation(nickname = "validate-standard-charges", 
        value = "Validate unique Standard charge", 
        notes = "Validate standard charges, will return the count of duplicate records."
    )
    public ResponseEntity<StandardChargesMetaData> validateStandardCharges(
            @ApiParam(required = true, name = "validateRequests", value = "Valid the unique standard charge")
            @RequestBody @Valid final CreateStandardChargeRequest createRequests) {
   
        return ResponseEntity.ok(scService.validateStandardCharges(createRequests));
    }


    /**
     * @param createRequests
     * @return
     */
    @PostMapping(SC_CREATED_URI)
    // @formatter:off
    @ApiOperation(nickname = "create-standard-charges", 
        value = "Creates one or multiple new Standard charges records", 
        notes = "If any duplicate standard charge exists, it will be ignored.",
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = StandardChargesResponse.class,
        responseContainer = "List"
    )
    public ResponseEntity<List<StandardChargesResponse>> createStandardCharges(
            @ApiParam(required = true, name = "createRequests", value = "A List of create Standard Charges requests")
            @RequestBody @Valid final CreateStandardChargeRequest createRequests) {
   
    	List<StandardChargesResponse> results = scService.createStandardCharges(createRequests);
    	
    	return ResponseEntity.ok().headers(addSuccess(getMessage(STANDARD_CHARGES_CREATED_SUCCESSFULLY, results.size())))
                .body(results);    
    }

    @PatchMapping(SC_ADD_AMOUNTRANGE_URI)
    // @formatter:off
    @ApiOperation(nickname = "Add-amount-range", 
        value = "Create amount range for given Standard charges", 
        notes = "Request should only contain the amount ranges values "
                + "If a value is not changed the respective value should not be there in request."
                + "<b>You can only update the status of record</b>", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = StandardChargesResponse.class,
        responseContainer = "List"
    ) 
    @ApiImplicitParam(name = "scId", dataType = "String", paramType = "path",
        value = "Standard Charge Id", required = true 
    )
    public ResponseEntity<List<StandardChargesResponse>> addAmountRanges(
            @PathVariable String scId,
            @ApiParam(value = "Add Amount Ranges records for given Standard Chagres")
            @RequestBody @Valid @NotEmpty final @NotNull CreateAmountRangeRequest addAmountRange) {
    // @formatter:on
        Map<@NotEmpty String, @NotNull CreateAmountRangeRequest> map = new HashMap<>();
        map.put(scId, addAmountRange);

        List<StandardChargesResponse> results = scService.addAmountRanges(map);
        return ResponseEntity.ok()
                .headers(addSuccess(getMessage(STANDARD_CHARGES_UPDATED_SUCCESSFULLY, results.size()))).body(results);
    }

    @PatchMapping(SC_UPDATED_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-status", 
        value = "Enable or disable records at amountRange or amountRange date wise", 
        notes = "Request should only contain the updated values "
                + "If a value is not changed the respective value should not be there in request."
                + "<b>You can only update the status of record</b>", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = Void.class
    )    
    public ResponseEntity<Void> updateStatus(
            @ApiParam(value = "Enable or disable amountRange or amountRange Date wise")
            @RequestBody @Valid @NotEmpty final StatusChangeRequest statusChangeRequest) {
    // @formatter:on
        if (statusChangeRequest.getStandardChargeId() == null) {
            throw new StandardChargeException(StandardChargeExceptionType.INVALID_IDS, Status.BAD_REQUEST);
        }
        scService.updateStatus(statusChangeRequest);

        return ResponseEntity.status(HttpStatus.OK)
                .headers(addSuccess(getMessage(STANDARD_CHARGES_STATUS_UPDATE_SUCCESSFULLY))).build();
    }

    @PostMapping(SC_AMOUNT_RANGE_VALIDATE_URI)
    // @formatter:off
    @ApiOperation(nickname = "validate-amount-range", 
        value = "validate one or multiple amount range for particular standard charges", 
        notes = "Request should only contain the updated values "
                + "If a value is not changed the respective value should not be there in request."
                + "<b>You can only update the Amount ranges</b>", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = StandardChargeAmountRangeResponse.class,
        responseContainer = "List"
    )    
    @ApiImplicitParam(name = "scId", dataType = "String", paramType = "path",
        value = "Standard Charge Id", required = true 
    )
    public ResponseEntity<List<StandardChargesResponse>> validateStandardChargeAmountRange(
            @PathVariable String scId,
            @ApiParam(value = "Validate the amount range for given standard charge")
            @RequestBody @Valid @NotNull ValidateAmountRangeRequest validateRequest) {
    // @formatter:on
        Map<@NotEmpty String, @NotNull ValidateAmountRangeRequest> map = new HashMap<>();
        // validateRequest.setStandardChargesId(scId);
        map.put(scId, validateRequest);

        return ResponseEntity.ok(scService.validateStandardChargeAmountRange(map));
    }

    @PatchMapping(SC_AMOUNT_RANGE_UPDATED_URI)
    // @formatter:off
    @ApiOperation(nickname = "update-amount-range", 
        value = "Updates one or multiple amount range for particular standard charges", 
        notes = "Request should only contain the updated values "
                + "If a value is not changed the respective value should not be there in request."
                + "<b>You can only update the Amount ranges</b>", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = StandardChargeAmountRangeResponse.class,
        responseContainer = "List"
    )    
    @ApiImplicitParams({
        @ApiImplicitParam(name = "scId", dataType = "String", paramType = "path",
            value = "Standard Charge Id", required = true 
        )
    })
    public ResponseEntity<List<StandardChargesResponse>> updateStandardChargeAmountRange(
            @PathVariable String scId,
            @ApiParam(value = "Updates map with record id as key and updated properties as values")
            @RequestBody @Valid @NotEmpty final Map<@NotEmpty String, UpdateAmountRangeRequest> updateRequest) {
    // @formatter:on

        List<StandardChargesResponse> results = scService.updateStandardChargeAmountRange(scId, updateRequest);
        return ResponseEntity.ok().headers(addSuccess(getMessage(AMOUNT_RANGE_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }
    
    
    ////////////Upload////////////////
    @PostMapping(SC_STANDARD_CHARGE_UPLOAD_URI)
    @ApiOperation(nickname = "upload-standard-charges", 
        value = "upload standard-charge from excel sheet", 
        notes = "A Valid sheet must be uploaded "
                + "If Standard charge is not present, it will create record, otherwise update existing record.",                
        consumes = "multipart/form-data", 
        produces = ALL_VALUE,
        response = StandardChargeUploadResponse.class,
        responseContainer = ""
    )    
    public ResponseEntity<StandardChargeUploadResponse> uploadStandardCharge(
            @RequestParam("file") MultipartFile readDataFile) {
        
        StandardChargeUploadResponse results;
        //try {
            results = scService.uploadStandardCharge(readDataFile);
        /*}
        catch(StandardChargeException exp) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .headers(addError(exp.getMessage())).build();
            throw exp;
        }*/
        /*if(results.getFailedList() != null && results.getFailedList().size() > 0) {      
            List<StandardChargesVM> failedList = results.getFailedList().stream()
                    .map(StandardChargesVM::of).collect(Collectors.toList());
            
            FileDownloadHelper.downloadFile(
                    failedList, DownloadFileType.EXCEL, "Failed_StandardCharge_" + LocalDate.now(), 
                    DownloadContext.STANDARD_CHARGE,
                    response);
        }*/

        if(results == null) {
//                throw new StandardChargeException(StandardChargeExceptionType.FILE_EMPTY, Status.BAD_REQUEST);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .headers(addError(getMessage(UPLOAD_FAILED))).build();
        }
        return ResponseEntity.ok().headers(addSuccess(getMessage(STANDARD_CHARGES_UPDATED_SUCCESSFULLY)))
                .body(results);
    
    }    
}
