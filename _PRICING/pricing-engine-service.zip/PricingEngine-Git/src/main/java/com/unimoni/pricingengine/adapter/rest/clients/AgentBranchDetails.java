package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class AgentBranchDetails {

    @JsonProperty("branchDisplayName")
    private String branchDisplayName;
    
    @JsonProperty("branchName")
    private String branchName;
    
    @JsonProperty("agentDisplayName")
    private String agentDisplayName;
    
    @JsonProperty("agentName")
    private String agentName;
    
    @JsonProperty("address1")
    private String address1;
    
    @JsonProperty("address2")
    private String address2;
    
    @JsonProperty("poBox")
    private String poBox;
    
    @JsonProperty("phone")
    private String phone;
    
    @JsonProperty("mobile")
    private String mobile;
    
    @JsonProperty("city")
    private String city;
    
    @JsonProperty("country")
    private String country;
    
    @JsonProperty("state")
    private String state;
    
    @JsonProperty("id")
    private Long id;
    
    @JsonProperty("zip")
    private String zip;
    
    @JsonProperty("fax")
    private String fax;
    
    @JsonProperty("email")
    private String email;
    
    @JsonProperty("createdDate")
    private String createdDate;
    
    @JsonProperty("modifiedDate")
    private String modifiedDate;
    
    @JsonProperty("status")
    private String status;
    
    @JsonProperty("agentId")
    private Integer agentId;
    
    @JsonProperty("countryCode")
    private String countryCode;
    
    @JsonProperty("agentCode")
    private String agentCode;
    
    @JsonProperty("isdCode")
    private String isdCode;

    @JsonProperty("contactPerson")
    private String contactPerson;
    
    @JsonProperty("deleted")
    private Boolean deleted;

}
