package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.domain.model.rate.RateSourceType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "bankWiseRateRequest", description = "Request to create bank wise base rate")
public class BankWiseRateRequest {

    @NotEmpty
    @ApiModelProperty(allowEmptyValue = false, required = true, value = "Bank codes such as HDFC, ICICI etc.")
    private List<@NotEmpty String> banks;

    @NotEmpty
    @ApiModelProperty(allowEmptyValue = false, required = true, value = "Agent codes such as AGNT00X1")
    private List<@NotEmpty String> agents;

    @NotEmpty
    @ApiModelProperty(allowEmptyValue = true, required = true, value = "Service Providers such as UAE, UK etc.")
    private List<@NotEmpty String> serviceProviders;

    @NotEmpty
    @ApiModelProperty(allowEmptyValue = true, required = true, value = "Products such as Remittance, Forex etc.")
    private List<@NotEmpty String> products;

    @NotNull
    private ExchangeDTO exchange;

    @ApiModelProperty(dataType = "String", allowableValues = "MANUAL, IBR_NORMAL", value = "Rate source type as either MANUAL or IBR_NORMAL", required = true)
    @NotNull
    private RateSourceType rateSourceType;

    @ApiModelProperty(hidden = true)
    @Getter(value = AccessLevel.NONE)
    @Setter(value = AccessLevel.NONE)
    private List<BankRateIdentity> identities;

    @SuppressWarnings("unchecked")
    public List<BankRateIdentity> identities() {
        if (identities == null) {
            ImmutableList<String> sps = ImmutableList.copyOf(serviceProviders);
            ImmutableList<String> prds = ImmutableList.copyOf(products);
            ImmutableList<String> agts = ImmutableList.copyOf(agents);
            ImmutableList<String> bnks = ImmutableList.copyOf(banks);
            List<List<String>> combinations = Lists.cartesianProduct(sps, prds, agts, bnks);
            List<BankRateIdentity> identities = new ArrayList<>(combinations.size());
            for (List<String> combination : combinations) {
                identities
                        .add(BankRateIdentity.of(exchange.getCurrency().getSource(), exchange.getCurrency().getTarget(),
                                combination.get(0), combination.get(1), combination.get(2), combination.get(3)));
            }
            return this.identities = identities;
        }
        else {
            return this.identities;
        }
    }

    public int identityCount() {
        return identities().size();
    }

    public static BankWiseRateRequest of(final List<String> banks, final List<String> agents,
            final List<String> serviceProviders, final List<String> products, final CurrencyUnit sourceCurrency,
            final CurrencyUnit targetCurrency, final BigDecimal askValue, final BigDecimal bidValue) {
        BankWiseRateRequest bankWiseRateRequest = new BankWiseRateRequest();
        bankWiseRateRequest.banks = banks;
        bankWiseRateRequest.serviceProviders = serviceProviders;
        bankWiseRateRequest.products = products;
        bankWiseRateRequest.agents = agents;
        bankWiseRateRequest.exchange = ExchangeDTO.of(sourceCurrency, targetCurrency, askValue, bidValue);
        return bankWiseRateRequest;
    }
}
