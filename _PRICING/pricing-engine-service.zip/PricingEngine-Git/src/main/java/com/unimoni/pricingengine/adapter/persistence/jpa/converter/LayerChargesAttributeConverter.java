package com.unimoni.pricingengine.adapter.persistence.jpa.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.unimoni.pricingengine.domain.model.remittance.LayerCharges;
import com.unimoni.pricingengine.infra.config.BeanFactory;

@Converter
public class LayerChargesAttributeConverter implements AttributeConverter<LayerCharges, String> {

    @Override
    public String convertToDatabaseColumn(LayerCharges layerCharges) {
        return BeanFactory.jodaSerializerDeserializer().xmlWriter().write(layerCharges);
    }

    @Override
    public LayerCharges convertToEntityAttribute(String dbDataXML) {
        return BeanFactory.jodaSerializerDeserializer().xmlReader().read(dbDataXML, LayerCharges.class);
    }
}
