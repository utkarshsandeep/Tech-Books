package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import java.util.Map;

import javax.validation.constraints.NotNull;

import org.joda.beans.Bean;
import org.joda.beans.BeanBuilder;
import org.joda.beans.JodaBeanUtils;
import org.joda.beans.MetaBean;
import org.joda.beans.MetaProperty;
import org.joda.beans.Property;
import org.joda.beans.gen.BeanDefinition;
import org.joda.beans.gen.PropertyDefinition;
import org.joda.beans.impl.direct.DirectBeanBuilder;
import org.joda.beans.impl.direct.DirectMetaBean;
import org.joda.beans.impl.direct.DirectMetaProperty;
import org.joda.beans.impl.direct.DirectMetaPropertyMap;

import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverride;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverrides;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRateValueDateWise;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@BeanDefinition
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ApiModel(value = "agentValueDateWise", description = "Agent Value Date Wise")
public class AgentValueDateWiseDTO implements Bean {

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Customer Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Customer Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "customerRate", required = true, notes = "Customer Rate cost Buy and Sell values")
    private CostDTO customerRate;

    @PropertyDefinition
    @DownloadOverrides({ @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Sell Margin")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Buy Margin")) })
    @NotNull
    @ApiModelProperty(value = "margin", required = true, notes = "Margin cost Buy and Sell values")
    private CostDTO margin;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Sell Margin Low")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Buy Margin Low")) })
    @NotNull
    @ApiModelProperty(value = "marginLow", required = true, notes = "Margin Low cost Buy and Sell values")
    private CostDTO marginLow;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Sell Margin High")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Buy Margin High")) })
    @NotNull
    @ApiModelProperty(value = "marginHigh", required = true, notes = "Margin High cost Buy and Sell values")
    private CostDTO marginHigh;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Cost Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Cost Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "cost", required = true, notes = "Country Cost Buy and Sell values")
    private CostDTO cost;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Lowest Transaction Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Lowest Transaction Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "customerLowest", required = true, notes = "Customer Lowest cost Buy and Sell values")
    private CostDTO customerLowest;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Maximum Discounted Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Maximum Discounted Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "maxDiscount", required = true, notes = "Max Discount cost Buy and Sell values")
    private CostDTO maxDiscount;

    public static AgentValueDateWiseDTO of(final AgentRateValueDateWise agentValueDateWise) {
        return of(CostDTO.of(agentValueDateWise.customerRate()), CostDTO.of(agentValueDateWise.margin()),
                CostDTO.of(agentValueDateWise.marginLow()), CostDTO.of(agentValueDateWise.marginHigh()),
                CostDTO.of(agentValueDateWise.cost()), CostDTO.of(agentValueDateWise.customerLowest()),
                CostDTO.of(agentValueDateWise.maxDiscount()));
    }

    public static AgentValueDateWiseDTO byDefault(final Cost countryAgentCost, final RateDisplayMachenism RDM) {
        AgentValueDateWiseDTO agentValueDateWise = new AgentValueDateWiseDTO();
        agentValueDateWise.cost = CostDTO.of(countryAgentCost);
        CostDTO marginRate = CostDTO.zero();
        agentValueDateWise.margin = marginRate;
        agentValueDateWise.marginLow = marginRate;
        agentValueDateWise.marginHigh = marginRate;

        if (RDM.isBCtoFC()) {
            // Customer Rate Sell = Cost Sell Rate – Sell Margin
            // Customer Rate Buy = Cost Buy Rate + Cash Buy Margin
            agentValueDateWise.customerRate = CostDTO.of(
                    agentValueDateWise.cost.getSellValue().subtract(marginRate.getSellValue()),
                    agentValueDateWise.cost.getBuyValue().add(marginRate.getBuyValue()));

            // Customer Maximum Discounted Sell Rate = Customer Sell Rate + Sell Margin Low
            // Customer Maximum Discounted Buy Rate = Customer Buy Rate - Buy Margin Low
            agentValueDateWise.maxDiscount = CostDTO.of(
                    agentValueDateWise.customerRate.getSellValue().add(marginRate.getSellValue()),
                    agentValueDateWise.customerRate.getBuyValue().subtract(marginRate.getBuyValue()));

            // Customer Lowest Sell Rate = Customer Sell Rate – Sell Margin High
            // Customer Lowest Buy Rate = Customer Buy Rate + Buy Margin High
            agentValueDateWise.customerLowest = CostDTO.of(
                    agentValueDateWise.customerRate.getSellValue().subtract(marginRate.getSellValue()),
                    agentValueDateWise.customerRate.getBuyValue().add(marginRate.getBuyValue()));
        }
        else {
            // Customer Rate Sell = Cost Sell Rate + Sell Margin
            // Customer Rate Buy = Cost Buy Rate - Buy Margin
            agentValueDateWise.customerRate = CostDTO.of(
                    agentValueDateWise.cost.getSellValue().add(marginRate.getSellValue()),
                    agentValueDateWise.cost.getBuyValue().subtract(marginRate.getBuyValue()));

            // Customer Maximum Discounted Sell Rate = Customer Sell Rate – Sell Margin Low
            // Customer Maximum Discounted Buy Rate = Customer Buy Rate + Buy Margin Low
            agentValueDateWise.maxDiscount = CostDTO.of(
                    agentValueDateWise.customerRate.getSellValue().subtract(marginRate.getSellValue()),
                    agentValueDateWise.customerRate.getBuyValue().add(marginRate.getBuyValue()));

            // Customer Lowest Sell Rate = Customer Sell Rate + Sell Margin High
            // Customer Lowest Buy Rate = Customer Buy Rate – Buy Margin High
            agentValueDateWise.customerLowest = CostDTO.of(
                    agentValueDateWise.customerRate.getSellValue().add(marginRate.getSellValue()),
                    agentValueDateWise.customerRate.getBuyValue().subtract(marginRate.getBuyValue()));

        }
        return agentValueDateWise;
    }

  //------------------------- AUTOGENERATED START -------------------------
  /**
   * The meta-bean for {@code AgentValueDateWiseDTO}.
   * @return the meta-bean, not null
   */
  public static AgentValueDateWiseDTO.Meta meta() {
    return AgentValueDateWiseDTO.Meta.INSTANCE;
  }

  static {
    MetaBean.register(AgentValueDateWiseDTO.Meta.INSTANCE);
  }

  @Override
  public AgentValueDateWiseDTO.Meta metaBean() {
    return AgentValueDateWiseDTO.Meta.INSTANCE;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the customerRate.
   * @return the value of the property
   */
  public CostDTO getCustomerRate() {
    return customerRate;
  }

  /**
   * Sets the customerRate.
   * @param customerRate  the new value of the property
   */
  public void setCustomerRate(CostDTO customerRate) {
    this.customerRate = customerRate;
  }

  /**
   * Gets the the {@code customerRate} property.
   * @return the property, not null
   */
  public final Property<CostDTO> customerRate() {
    return metaBean().customerRate().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the margin.
   * @return the value of the property
   */
  public CostDTO getMargin() {
    return margin;
  }

  /**
   * Sets the margin.
   * @param margin  the new value of the property
   */
  public void setMargin(CostDTO margin) {
    this.margin = margin;
  }

  /**
   * Gets the the {@code margin} property.
   * @return the property, not null
   */
  public final Property<CostDTO> margin() {
    return metaBean().margin().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the marginLow.
   * @return the value of the property
   */
  public CostDTO getMarginLow() {
    return marginLow;
  }

  /**
   * Sets the marginLow.
   * @param marginLow  the new value of the property
   */
  public void setMarginLow(CostDTO marginLow) {
    this.marginLow = marginLow;
  }

  /**
   * Gets the the {@code marginLow} property.
   * @return the property, not null
   */
  public final Property<CostDTO> marginLow() {
    return metaBean().marginLow().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the marginHigh.
   * @return the value of the property
   */
  public CostDTO getMarginHigh() {
    return marginHigh;
  }

  /**
   * Sets the marginHigh.
   * @param marginHigh  the new value of the property
   */
  public void setMarginHigh(CostDTO marginHigh) {
    this.marginHigh = marginHigh;
  }

  /**
   * Gets the the {@code marginHigh} property.
   * @return the property, not null
   */
  public final Property<CostDTO> marginHigh() {
    return metaBean().marginHigh().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the cost.
   * @return the value of the property
   */
  public CostDTO getCost() {
    return cost;
  }

  /**
   * Sets the cost.
   * @param cost  the new value of the property
   */
  public void setCost(CostDTO cost) {
    this.cost = cost;
  }

  /**
   * Gets the the {@code cost} property.
   * @return the property, not null
   */
  public final Property<CostDTO> cost() {
    return metaBean().cost().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the customerLowest.
   * @return the value of the property
   */
  public CostDTO getCustomerLowest() {
    return customerLowest;
  }

  /**
   * Sets the customerLowest.
   * @param customerLowest  the new value of the property
   */
  public void setCustomerLowest(CostDTO customerLowest) {
    this.customerLowest = customerLowest;
  }

  /**
   * Gets the the {@code customerLowest} property.
   * @return the property, not null
   */
  public final Property<CostDTO> customerLowest() {
    return metaBean().customerLowest().createProperty(this);
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the maxDiscount.
   * @return the value of the property
   */
  public CostDTO getMaxDiscount() {
    return maxDiscount;
  }

  /**
   * Sets the maxDiscount.
   * @param maxDiscount  the new value of the property
   */
  public void setMaxDiscount(CostDTO maxDiscount) {
    this.maxDiscount = maxDiscount;
  }

  /**
   * Gets the the {@code maxDiscount} property.
   * @return the property, not null
   */
  public final Property<CostDTO> maxDiscount() {
    return metaBean().maxDiscount().createProperty(this);
  }

  //-----------------------------------------------------------------------
  @Override
  public AgentValueDateWiseDTO clone() {
    return JodaBeanUtils.cloneAlways(this);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj != null && obj.getClass() == this.getClass()) {
      AgentValueDateWiseDTO other = (AgentValueDateWiseDTO) obj;
      return JodaBeanUtils.equal(getCustomerRate(), other.getCustomerRate()) &&
          JodaBeanUtils.equal(getMargin(), other.getMargin()) &&
          JodaBeanUtils.equal(getMarginLow(), other.getMarginLow()) &&
          JodaBeanUtils.equal(getMarginHigh(), other.getMarginHigh()) &&
          JodaBeanUtils.equal(getCost(), other.getCost()) &&
          JodaBeanUtils.equal(getCustomerLowest(), other.getCustomerLowest()) &&
          JodaBeanUtils.equal(getMaxDiscount(), other.getMaxDiscount());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int hash = getClass().hashCode();
    hash = hash * 31 + JodaBeanUtils.hashCode(getCustomerRate());
    hash = hash * 31 + JodaBeanUtils.hashCode(getMargin());
    hash = hash * 31 + JodaBeanUtils.hashCode(getMarginLow());
    hash = hash * 31 + JodaBeanUtils.hashCode(getMarginHigh());
    hash = hash * 31 + JodaBeanUtils.hashCode(getCost());
    hash = hash * 31 + JodaBeanUtils.hashCode(getCustomerLowest());
    hash = hash * 31 + JodaBeanUtils.hashCode(getMaxDiscount());
    return hash;
  }

  @Override
  public String toString() {
    StringBuilder buf = new StringBuilder(256);
    buf.append("AgentValueDateWiseDTO{");
    int len = buf.length();
    toString(buf);
    if (buf.length() > len) {
      buf.setLength(buf.length() - 2);
    }
    buf.append('}');
    return buf.toString();
  }

  protected void toString(StringBuilder buf) {
    buf.append("customerRate").append('=').append(JodaBeanUtils.toString(getCustomerRate())).append(',').append(' ');
    buf.append("margin").append('=').append(JodaBeanUtils.toString(getMargin())).append(',').append(' ');
    buf.append("marginLow").append('=').append(JodaBeanUtils.toString(getMarginLow())).append(',').append(' ');
    buf.append("marginHigh").append('=').append(JodaBeanUtils.toString(getMarginHigh())).append(',').append(' ');
    buf.append("cost").append('=').append(JodaBeanUtils.toString(getCost())).append(',').append(' ');
    buf.append("customerLowest").append('=').append(JodaBeanUtils.toString(getCustomerLowest())).append(',').append(' ');
    buf.append("maxDiscount").append('=').append(JodaBeanUtils.toString(getMaxDiscount())).append(',').append(' ');
  }

  //-----------------------------------------------------------------------
  /**
   * The meta-bean for {@code AgentValueDateWiseDTO}.
   */
  public static class Meta extends DirectMetaBean {
    /**
     * The singleton instance of the meta-bean.
     */
    static final Meta INSTANCE = new Meta();

    /**
     * The meta-property for the {@code customerRate} property.
     */
    private final MetaProperty<CostDTO> _customerRate = DirectMetaProperty.ofReadWrite(
        this, "customerRate", AgentValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-property for the {@code margin} property.
     */
    private final MetaProperty<CostDTO> _margin = DirectMetaProperty.ofReadWrite(
        this, "margin", AgentValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-property for the {@code marginLow} property.
     */
    private final MetaProperty<CostDTO> _marginLow = DirectMetaProperty.ofReadWrite(
        this, "marginLow", AgentValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-property for the {@code marginHigh} property.
     */
    private final MetaProperty<CostDTO> _marginHigh = DirectMetaProperty.ofReadWrite(
        this, "marginHigh", AgentValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-property for the {@code cost} property.
     */
    private final MetaProperty<CostDTO> _cost = DirectMetaProperty.ofReadWrite(
        this, "cost", AgentValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-property for the {@code customerLowest} property.
     */
    private final MetaProperty<CostDTO> _customerLowest = DirectMetaProperty.ofReadWrite(
        this, "customerLowest", AgentValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-property for the {@code maxDiscount} property.
     */
    private final MetaProperty<CostDTO> _maxDiscount = DirectMetaProperty.ofReadWrite(
        this, "maxDiscount", AgentValueDateWiseDTO.class, CostDTO.class);
    /**
     * The meta-properties.
     */
    private final Map<String, MetaProperty<?>> _metaPropertyMap$ = new DirectMetaPropertyMap(
        this, null,
        "customerRate",
        "margin",
        "marginLow",
        "marginHigh",
        "cost",
        "customerLowest",
        "maxDiscount");

    /**
     * Restricted constructor.
     */
    protected Meta() {
    }

    @Override
    protected MetaProperty<?> metaPropertyGet(String propertyName) {
      switch (propertyName.hashCode()) {
        case 900276702:  // customerRate
          return _customerRate;
        case -1081309778:  // margin
          return _margin;
        case -1044799802:  // marginLow
          return _marginLow;
        case 1970819184:  // marginHigh
          return _marginHigh;
        case 3059661:  // cost
          return _cost;
        case 1718731568:  // customerLowest
          return _customerLowest;
        case -1989485883:  // maxDiscount
          return _maxDiscount;
      }
      return super.metaPropertyGet(propertyName);
    }

    @Override
    public BeanBuilder<? extends AgentValueDateWiseDTO> builder() {
      return new DirectBeanBuilder<>(new AgentValueDateWiseDTO());
    }

    @Override
    public Class<? extends AgentValueDateWiseDTO> beanType() {
      return AgentValueDateWiseDTO.class;
    }

    @Override
    public Map<String, MetaProperty<?>> metaPropertyMap() {
      return _metaPropertyMap$;
    }

    //-----------------------------------------------------------------------
    /**
     * The meta-property for the {@code customerRate} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> customerRate() {
      return _customerRate;
    }

    /**
     * The meta-property for the {@code margin} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> margin() {
      return _margin;
    }

    /**
     * The meta-property for the {@code marginLow} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> marginLow() {
      return _marginLow;
    }

    /**
     * The meta-property for the {@code marginHigh} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> marginHigh() {
      return _marginHigh;
    }

    /**
     * The meta-property for the {@code cost} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> cost() {
      return _cost;
    }

    /**
     * The meta-property for the {@code customerLowest} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> customerLowest() {
      return _customerLowest;
    }

    /**
     * The meta-property for the {@code maxDiscount} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CostDTO> maxDiscount() {
      return _maxDiscount;
    }

    //-----------------------------------------------------------------------
    @Override
    protected Object propertyGet(Bean bean, String propertyName, boolean quiet) {
      switch (propertyName.hashCode()) {
        case 900276702:  // customerRate
          return ((AgentValueDateWiseDTO) bean).getCustomerRate();
        case -1081309778:  // margin
          return ((AgentValueDateWiseDTO) bean).getMargin();
        case -1044799802:  // marginLow
          return ((AgentValueDateWiseDTO) bean).getMarginLow();
        case 1970819184:  // marginHigh
          return ((AgentValueDateWiseDTO) bean).getMarginHigh();
        case 3059661:  // cost
          return ((AgentValueDateWiseDTO) bean).getCost();
        case 1718731568:  // customerLowest
          return ((AgentValueDateWiseDTO) bean).getCustomerLowest();
        case -1989485883:  // maxDiscount
          return ((AgentValueDateWiseDTO) bean).getMaxDiscount();
      }
      return super.propertyGet(bean, propertyName, quiet);
    }

    @Override
    protected void propertySet(Bean bean, String propertyName, Object newValue, boolean quiet) {
      switch (propertyName.hashCode()) {
        case 900276702:  // customerRate
          ((AgentValueDateWiseDTO) bean).setCustomerRate((CostDTO) newValue);
          return;
        case -1081309778:  // margin
          ((AgentValueDateWiseDTO) bean).setMargin((CostDTO) newValue);
          return;
        case -1044799802:  // marginLow
          ((AgentValueDateWiseDTO) bean).setMarginLow((CostDTO) newValue);
          return;
        case 1970819184:  // marginHigh
          ((AgentValueDateWiseDTO) bean).setMarginHigh((CostDTO) newValue);
          return;
        case 3059661:  // cost
          ((AgentValueDateWiseDTO) bean).setCost((CostDTO) newValue);
          return;
        case 1718731568:  // customerLowest
          ((AgentValueDateWiseDTO) bean).setCustomerLowest((CostDTO) newValue);
          return;
        case -1989485883:  // maxDiscount
          ((AgentValueDateWiseDTO) bean).setMaxDiscount((CostDTO) newValue);
          return;
      }
      super.propertySet(bean, propertyName, newValue, quiet);
    }

  }

  //-------------------------- AUTOGENERATED END --------------------------
}
