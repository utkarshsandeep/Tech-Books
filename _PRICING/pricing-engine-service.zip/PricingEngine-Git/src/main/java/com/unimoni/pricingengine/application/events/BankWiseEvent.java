package com.unimoni.pricingengine.application.events;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
// @JsonIgnoreProperties(ignoreUnknown = true)
public class BankWiseEvent {

	private Long draweeBankId;

    private Long draweeBankForRateId;

    private Long draweeBankProductProfileId;

    public BankWiseEvent(Long draweeBankId, Long draweeBankForRateId, Long draweeBankProductProfileId) {
        this.draweeBankId = draweeBankId;
        this.draweeBankForRateId = draweeBankForRateId;
        this.draweeBankProductProfileId = draweeBankProductProfileId;

    }

}
