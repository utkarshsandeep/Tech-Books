package com.unimoni.pricingengine.domain.model.event;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ProvidedRateDisabledEvent {

    private int rateProviderId;
    
    private String rateId;
    
    private String ricId;
    
    @JsonCreator
    public static ProvidedRateDisabledEvent off(@JsonProperty("rateProviderId") Integer rateProviderId, @JsonProperty("rateId") String rateId,
            @JsonProperty("ricId") String ricId) {
        ProvidedRateDisabledEvent providedRateDisableEvent = new ProvidedRateDisabledEvent();
        providedRateDisableEvent.rateProviderId = rateProviderId;
        providedRateDisableEvent.rateId = rateId;
        providedRateDisableEvent.ricId = ricId;
        
        return providedRateDisableEvent;
    }

    public static ProvidedRateDisabledEvent of(Integer rateProviderId, String rateId,
            String ricId) {
        ProvidedRateDisabledEvent providedRateDisableEvent = new ProvidedRateDisabledEvent();
        providedRateDisableEvent.rateProviderId = rateProviderId;
        providedRateDisableEvent.rateId = rateId;
        providedRateDisableEvent.ricId = ricId;
        
        return providedRateDisableEvent;
    }
}
