package com.unimoni.pricingengine.adapter.rest.util;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Response<T> {
	
	private Integer dealId;
    private int status;
    private String message;

}
