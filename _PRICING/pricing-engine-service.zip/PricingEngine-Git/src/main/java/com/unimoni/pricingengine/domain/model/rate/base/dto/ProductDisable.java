package com.unimoni.pricingengine.domain.model.rate.base.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ProductDisable {
	
	String productType;
	String subProduct;
	String serviceType;
	String bankName;
	
	public ProductDisable(String productType, String subProduct, String serviceType, String bankName) {
		this.productType= productType;
		this.subProduct= subProduct;
		this.serviceType = serviceType;
		this.bankName = bankName;
	}
	
	
	

}
