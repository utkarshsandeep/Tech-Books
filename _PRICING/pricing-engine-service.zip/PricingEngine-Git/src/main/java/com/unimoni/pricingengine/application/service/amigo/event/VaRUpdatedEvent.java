package com.unimoni.pricingengine.application.service.amigo.event;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;
import java.time.ZonedDateTime;

import javax.money.CurrencyUnit;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class VaRUpdatedEvent extends VDWRateAmigoEvent {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashAskMargin;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashBidMargin;

    private VaRUpdatedEvent(final Type type, final String agentCode, final String bankCode,
            final String serviceProviderCode, final String productCode, final String subProductCode,
            final String serviceTypeCode, final CurrencyUnit sourceCcy, final CurrencyUnit targetCcy,
            final BigDecimal cashAskMargin, final BigDecimal cashBidMargin, final boolean status,
            final ZonedDateTime updatedOn) {
        super(type, agentCode, bankCode, serviceProviderCode, productCode, subProductCode, serviceTypeCode, sourceCcy,
                targetCcy, status, updatedOn);
        this.cashAskMargin = cashAskMargin;
        this.cashBidMargin = cashBidMargin;
    }

    public static VaRUpdatedEvent forStatusChange(final VaR var) {
        return new VaRUpdatedEvent(var.rmType().isNormal() ? Type.VAR_NORMAL : Type.VAR_BANK_WISE, var.agent(),
                var.rmType().isBankWise() ? var.bank().get() : null, var.instruments().serviceProvider(),
                var.instruments().product(), var.instruments().subProduct(), var.instruments().serviceType(),
                var.exchange().currency().source(), var.exchange().currency().target(),
                var.cash().get().margin().askValue(), var.cash().get().margin().bidValue(), var.isEnabled(),
                var.updatedOn());
    }

    public static VaRUpdatedEvent forRateChange(final VaR var) {
        return new VaRUpdatedEvent(var.rmType().isNormal() ? Type.VAR_NORMAL : Type.VAR_BANK_WISE, var.agent(),
                var.rmType().isBankWise() ? var.bank().get() : null, var.instruments().serviceProvider(),
                var.instruments().product(), var.instruments().subProduct(), var.instruments().serviceType(),
                var.exchange().currency().source(), var.exchange().currency().target(),
                var.cash().get().margin().askValue(), var.cash().get().margin().bidValue(), var.isEnabled(),
                var.updatedOn());
    }
}
