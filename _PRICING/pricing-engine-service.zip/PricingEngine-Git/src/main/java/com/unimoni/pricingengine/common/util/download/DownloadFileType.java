package com.unimoni.pricingengine.common.util.download;

public enum DownloadFileType {

    // @formatter:off
    CSV("csv", "text/csv"),
    EXCEL("xlsx", "application/ms-excel");
    // @formatter:on

    private final String extension;

    private final String contentType;

    private DownloadFileType(final String extension, final String contentType) {
        this.extension = extension;
        this.contentType = contentType;
    }

    public String extension() {
        return this.extension;
    }

    public String contentType() {
        return this.contentType;
    }
}
