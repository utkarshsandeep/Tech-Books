package com.unimoni.pricingengine.domain.model.enquiry.ibr;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.money.CurrencyUnit;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;
import com.unimoni.pricingengine.common.util.Counter;
import com.unimoni.pricingengine.domain.model.enquiry.StreamRequest;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

@Slf4j
@Getter
@Accessors(chain = true, fluent = true)
@ToString
public class NormalIBREnquiryRequest extends StreamRequest {

    private List<String> serviceProviders;

    private List<String> products;

    private List<CurrencyUnit> currencies;

    private int endIndex;

    private NormalIBREnquiryRequest(final int nextIndex, final int batchSize, final List<String> serviceProviders,
            final List<String> products, final List<CurrencyUnit> currencies) {
        super(nextIndex, batchSize);
        this.serviceProviders = serviceProviders;
        this.products = products;
        this.currencies = currencies;
    }

    public static NormalIBREnquiryRequest of(final Integer startingIndex, final Integer batchSize,
            final Set<String> serviceProviders, final Set<String> products, final Set<CurrencyUnit> currencies,
            final Set<CurrencyUnit> ibrCurrencies) {
        MasterData masterData = BeanFactory.masterData();
        return new NormalIBREnquiryRequest(startingIndex == null ? 0 : startingIndex,
                batchSize == null ? DEFAULT_BATCH_SIZE : batchSize,
                masterData.validateServiceProviders(serviceProviders), masterData.validateProducts(products),
                masterData.validateCurrencies(currencies, ibrCurrencies));
    }

    @SuppressWarnings("unchecked")
    public Flux<NormalIBREnquiryIdentity> identities() {
        ImmutableList<String> sps = ImmutableList.copyOf(this.serviceProviders);
        ImmutableList<String> prds = ImmutableList.copyOf(this.products);
        ImmutableList<CurrencyUnit> currs = ImmutableList.copyOf(this.currencies);
        List<List<Object>> combinations = Lists.cartesianProduct(sps, prds, currs);
        this.endIndex = combinations.size() - 1;
        log.debug("NormalIBREnquiryRequest --> {} \n total combinations --> {}", this, this.endIndex + 1);

        Counter indexCounter = Counter.initialize("index-counter");
        Iterator<List<Object>> itr = combinations.iterator();
        while (itr.hasNext() && indexCounter.get() < this.nextIndex()) {
            itr.next();
            indexCounter.increment();
        }

        return Flux.generate(() -> itr, (state, sink) -> {
            if (state.hasNext()) {
                List<Object> combination = state.next();
                sink.next(NormalIBREnquiryIdentity.of(indexCounter.get(), (String) combination.get(0),
                        (String) combination.get(1), (CurrencyUnit) combination.get(2)));
                indexCounter.increment();
            }
            else {
                sink.complete();
            }
            return state;
        });
    }
}
