package com.unimoni.pricingengine.domain.model.rate.country.dto;

import java.util.Optional;

import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "updateExchangeRate", description = "Settlement, Margin or Country Cost")
public class UpdateExchangeDTO {

    @ApiModelProperty(name = "agentdto", dataType = "BigDecimal", value = "Sell Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private CostDTO agent;


    @ApiModelProperty(name = "margindto", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private CostDTO margin;

    public Optional<CostDTO> margin() {
        return Optional.ofNullable(this.margin);
    }

    public Optional<CostDTO> agent() {
        return Optional.ofNullable(this.agent);
    }
}
