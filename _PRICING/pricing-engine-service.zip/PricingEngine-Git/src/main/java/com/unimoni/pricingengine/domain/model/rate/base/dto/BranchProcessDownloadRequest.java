package com.unimoni.pricingengine.domain.model.rate.base.dto;

import com.unimoni.pricingengine.domain.model.common.dto.AbstractSearchRequest;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;

import lombok.Getter;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
public class BranchProcessDownloadRequest extends AbstractSearchRequest {
	
	private BranchProcessDownloadRequest(final PaginationData paginationData) {
		this.page = paginationData;
	}
	
	public static BranchProcessDownloadRequest of(final PaginationData paginationData) {
		return new BranchProcessDownloadRequest(paginationData);
	}
}
