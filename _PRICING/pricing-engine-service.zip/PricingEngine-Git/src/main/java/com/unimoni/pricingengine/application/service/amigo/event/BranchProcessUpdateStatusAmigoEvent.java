package com.unimoni.pricingengine.application.service.amigo.event;

import java.io.Serializable;

import com.unimoni.pricingengine.adapter.rest.clients.bp.BranchProcessAmigoUpdateRequest;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class BranchProcessUpdateStatusAmigoEvent  implements Serializable {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;
  
    private BranchProcessAmigoUpdateRequest req;
    private BranchProcessUpdateStatusAmigoEvent(BranchProcessAmigoUpdateRequest req) {
        this.req = req;
    }

    public static BranchProcessUpdateStatusAmigoEvent of(final BranchProcessAmigoUpdateRequest item) {
        return new BranchProcessUpdateStatusAmigoEvent(item);
    }
    
}
