package com.unimoni.pricingengine.application.service.onboarding.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.unimoni.pricingengine.application.service.onboarding.client.dto.BankWiseAgentPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.BankWiseAgentRequest;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.BankWiseDataPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.BankWiseDataRequest;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.CountryPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.CurrencyPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.HolidayPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.PayloadWrapper;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.ProductPaylaodWrapper;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.ServiceProviderPayload;

@FeignClient(name = "bank-onboarding-client", url = "${onboarding.base-url.bank-onboarding}")
public interface BankOnboardingClient {

    @GetMapping("${onboarding.api-path.get-all-service-providers}")
    List<ServiceProviderPayload> getAllServiceProviders();

    @GetMapping("${onboarding.api-path.get-all-countries}")
    List<CountryPayload> getAllCountries();

    @GetMapping("${onboarding.api-path.get-all-currencies}")
    List<CurrencyPayload> getAllCurrencies();

    @PostMapping("${onboarding.api-path.get-all-bank-wise-data}")
    PayloadWrapper<BankWiseDataPayload> getAllBankWiseData(final BankWiseDataRequest request);

    @PostMapping("${onboarding.api-path.get-all-bank-wise-agents}")
    PayloadWrapper<BankWiseAgentPayload> getBankWiseAgents(final BankWiseAgentRequest bankWiseAgentRequest);

    @GetMapping("${onboarding.api-path.get-all-instruments}")
    ProductPaylaodWrapper getAllInstruments();

    @GetMapping("${onboarding.api-path.check-holiday}")
    HolidayPayload checkHoliday(final @RequestParam(value = "countryCode", required = true) String countryCode,
            final @RequestParam(value = "date", required = true) String date);
}
