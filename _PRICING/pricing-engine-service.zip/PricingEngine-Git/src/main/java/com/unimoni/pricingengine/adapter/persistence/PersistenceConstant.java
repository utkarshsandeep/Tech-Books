package com.unimoni.pricingengine.adapter.persistence;

import lombok.Value;

@Value
public class PersistenceConstant {

    public static class Hibernate {

        // ID Generation strategies starts >>>
        public static final String GLOBAL_SEQ_ID_GENERATOR = "GLOBAL_SEQ_ID_GENERATOR";

        public static final String GUID_GENERATOR = "GUID_GENERATOR";

        public static final String UUID2_GENERATOR = "UUID2_GENERATOR";

        // ID Generation strategies ends >>>

        public static final String GLOBAL_SEQ_NAME = "global_sequence";

        public static final String GLOBAL_SEQ_INITIAL_VALUE = "1000";

        public static final String TYPE_DEF_JADIRA_MONEY = "jadira_money";

        public static final String TYPE_DEF_JADIRA_MONEY_CURRENCY_UNIT = "jadira_money_currency_unit";

        public static final String TYPE_DEF_JADIRA_DURATION = "jadira_duration";

        public static final String TYPE_DEF_JADIRA_PERIOD = "jadira_period";

    }

    public static class TableMetaData {

        public static final String TABLE_NORMAL_BASE_RATES = "NORMAL_BASE_RATES";

        public static final String TABLE_BANK_WISE_BASE_RATES = "BANK_WISE_BASE_RATES";

        public static final String TABLE_NORMAL_IBRS = "NORMAL_IBRS";

        public static final String TABLE_BANK_WISE_IBRS = "BANK_WISE_IBRS";

        public static final String TABLE_NORMAL_VARS = "NORMAL_VARS";

        public static final String TABLE_BANK_WISE_VARS = "BANK_WISE_VARS";
        
        public static final String TABLE_NORMAL_SETTLEMENT = "NORMAL_SETTLEMENTS";
        
        public static final String TABLE_BANK_WISE_SETTLEMENT = "BANK_WISE_SETTLEMENTS";

    }
}
