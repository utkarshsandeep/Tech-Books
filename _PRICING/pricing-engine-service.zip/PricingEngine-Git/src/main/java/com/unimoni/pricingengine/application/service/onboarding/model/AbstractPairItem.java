package com.unimoni.pricingengine.application.service.onboarding.model;

import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode(of = "code")
public abstract class AbstractPairItem implements PairItem<String, String> {

    @NonNull
    @ApiModelProperty(name = "code", value = "Code to be used in backend", example = "TRAVLX", position = 2)
    private String code;

    @NonNull
    @ApiModelProperty(name = "name", value = "Name to be used in frontend, dropdown Label", example = "TRAVLX", position = 3)
    private String name;
    
    @Getter(value = AccessLevel.NONE)
    private CodeNamePair<String, String> pair;

    protected AbstractPairItem(final String code, final String name) {
        this.code = code;
        this.name = name;
        this.pair = CodeNamePair.of(this.code, this.name);
    }

    protected AbstractPairItem(final String code, final String name, final int attributesCount) {
        this.code = code;
        this.name = name;
    }

    @Override
    public CodeNamePair<String, String> pair() {
        return this.pair;
    }

    @Override
    public int compareTo(final PairItem<String, String> other) {
        return this.name.compareTo(other.pair().getName());
    }
}
