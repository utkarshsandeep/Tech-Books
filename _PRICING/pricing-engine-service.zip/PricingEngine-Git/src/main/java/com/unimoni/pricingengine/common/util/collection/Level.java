package com.unimoni.pricingengine.common.util.collection;

public interface Level {

    int level();
}
