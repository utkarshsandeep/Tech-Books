package com.unimoni.pricingengine.domain.model.rate;

public interface NormalRate {
    // Common methods for Normal rate markup layer

//    public void updateRate(final BigDecimal askValue, final BigDecimal bidValue);
}
