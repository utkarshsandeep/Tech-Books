package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "countryClient", url = "http://bank-onboarding-service-snap.integration.apps.ocp.uaeexchange.com/api/v1/onboarding/country")
public interface CountryRestClient {
    @GetMapping("/")
    List<Country> allCountries();

}
