package com.unimoni.pricingengine.domain.model.remittance;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
public class RateSkipSetting {

    @JsonProperty
    @ApiModelProperty(name = "skipCustomerRate", value = "Whether or not to skip agent and country layer rates", position = 1)
    @NotNull
    @Getter(value = AccessLevel.NONE)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "SKIP_CUSTOMER_RATE", updatable = false, length = 1)
    private Boolean skipCustomerRate;

    @JsonProperty
    @ApiModelProperty(name = "skipCustomerFee", value = "Whether or not to skip customer fee", position = 1)
    @NotNull
    @Getter(value = AccessLevel.NONE)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "SKIP_CUSTOMER_FEE", updatable = false, length = 1)
    private Boolean skipCustomerFee;

    @JsonProperty
    @ApiModelProperty(name = "skipSwiftCharge", value = "Whether or not to skip Swift charge", position = 1)
    @NotNull
    @Getter(value = AccessLevel.NONE)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "SKIP_SWIFT_CHARGE", updatable = false, length = 1)
    private Boolean skipSwiftCharge;
    
    public boolean dontSkipAny() {
        return !this.skipCustomerRate && !this.skipCustomerFee && !this.skipSwiftCharge;
    }

    public boolean skipAll() {
        return this.skipCustomerRate && this.skipCustomerFee && this.skipSwiftCharge;
    }

    public boolean skipRatesOnly() {
        return this.skipCustomerRate;
    }

    public boolean skipCustomerFeeOnly() {
        return this.skipCustomerFee;
    }
    
    public boolean skipSwiftCharge() {
        return this.skipSwiftCharge;
    }
}
