package com.unimoni.pricingengine.domain.model.enquiry.country;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.RoundingMode;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import javax.money.CurrencyUnit;

import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.enquiry.StreamResponse;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRateValueDateWise;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.ToString;

@Getter
@ApiModel(value = "settlementRateEnquiryResponse", description = "Settlement Rate enquiry response")
@ToString(callSuper = true)
public class CountryRateEnquiryResponse extends StreamResponse {

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Service Provider such as UAE, UK etc.", required = true, example = "UAEEXNZ#####", position = 1)
    private String serviceProvider;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Product such as Remittance, Forex etc.", required = true, example = "Remittance", position = 2)
    private String product;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(name = "subProduct", dataType = "String", value = "Sub product such as Account Credit, Cash payout etc.", required = true, example = "Account Credit", position = 3)
    private String subProduct;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(name = "serviceType", dataType = "String", value = "Service type such as Flash, Normal etc.", required = true, example = "Flash", position = 4)
    private String serviceType;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Bank Code", required = true, example = "HDFCIN", position = 5)
    private String bank;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Agent Code", required = true, example = "TRVLX#######", position = 6)
    private String agent;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Currency Code of Base currency in ISO format e.g. INR", required = true, example = "INR", position = 7)
    private CurrencyUnit baseCurrency;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Currency Code of Foreign currency in ISO format e.g. INR", required = true, example = "USD", position = 8)
    private CurrencyUnit foreignCurrency;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "rateDisplayMachenism", dataType = "String", value = "Rate display machenism", example = "BC_TO_FC", allowableValues = "BC_TO_FC,FC_TO_BC", position = 9)
    private RateDisplayMachenism rateDisplayMachenism;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Settlement rate", required = true, position = 10)
    private Map<VDWType, CostDTO> rate;

    private CountryRateEnquiryResponse(final int identityIndex, final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final String bank, final String agent,
            final CurrencyUnit baseCurrency, final CurrencyUnit foreignCurrency,
            final RateDisplayMachenism rateDisplayMachenism, final Map<VDWType, CostDTO> rate) {
        super(identityIndex);
        this.serviceProvider = serviceProvider;
        this.product = product;
        this.subProduct = subProduct;
        this.serviceType = serviceType;
        this.bank = bank;
        this.agent = agent;
        this.baseCurrency = baseCurrency;
        this.foreignCurrency = foreignCurrency;
        this.rateDisplayMachenism = rateDisplayMachenism;
        this.rate = rate;
    }

    public static Optional<CountryRateEnquiryResponse> of(final CountryRateEnquiryIdentity enquiryIdentity,
            final CountryVDWRateType vdwRateType, final Map<VDWType, CountryRateValueDateWise> valueDateWises) {
        if (valueDateWises.isEmpty()) {
            return Optional.empty();
        }
        else {
            Map<VDWType, CostDTO> rate = valueDateWises.entrySet().stream()
                    .collect(Collectors.toMap(e -> e.getKey(),
                            e -> applyRDMFormula(enquiryIdentity.agent().getRateDisplayMechanism(),
                                    enquiryIdentity.rateDisplayMachenism(),
                                    vdwRateType.isCostRate() ? e.getValue().costRate() : e.getValue().agent()),
                            (e1, e2) -> e1, () -> new LinkedHashMap<VDWType, CostDTO>(valueDateWises.size())));

            CountryRateEnquiryResponse response = new CountryRateEnquiryResponse(enquiryIdentity.index(),
                    enquiryIdentity.serviceProvider(), enquiryIdentity.product(), enquiryIdentity.subProduct(),
                    enquiryIdentity.serviceType(), enquiryIdentity.bank().orElse(null),
                    enquiryIdentity.agent().getCode(), enquiryIdentity.baseCurrency(),
                    enquiryIdentity.foreignCurrency(), enquiryIdentity.rateDisplayMachenism(), rate);

            return Optional.of(response);
        }
    }

    private static CostDTO applyRDMFormula(final RateDisplayMachenism sourceRateDisplayMechanism,
            final RateDisplayMachenism targetRateDisplayMechanism, final Cost costRate) {
        return targetRateDisplayMechanism == sourceRateDisplayMechanism ? CostDTO.of(costRate)
                : CostDTO.of(RateValue.ONE.divide(costRate.sellValue(), 8, RoundingMode.CEILING),
                        RateValue.ONE.divide(costRate.buyValue(), 8, RoundingMode.CEILING));
    }

    public static CountryRateEnquiryResponse withCostRatesForSameCurrencies(
            final CountryRateEnquiryIdentity enquiryIdentity) {
        return new CountryRateEnquiryResponse(enquiryIdentity.index(), enquiryIdentity.serviceProvider(),
                enquiryIdentity.product(), enquiryIdentity.subProduct(), enquiryIdentity.serviceType(),
                enquiryIdentity.bank().orElse(null), enquiryIdentity.agent().getCode(), enquiryIdentity.baseCurrency(),
                enquiryIdentity.foreignCurrency(), enquiryIdentity.rateDisplayMachenism(),
                enquiryIdentity.valueDateWises().stream()
                        .collect(Collectors.toMap(x -> x, x -> CostDTO.one(), (e1, e2) -> e1,
                                () -> new LinkedHashMap<VDWType, CostDTO>(enquiryIdentity.valueDateWises().size()))));
    }

    public static CountryRateEnquiryResponse fromSettlement(final CountryRateEnquiryIdentity enquiryIdentity,
            final Map<VDWType, CostDTO> rates) {
        return new CountryRateEnquiryResponse(enquiryIdentity.index(), enquiryIdentity.serviceProvider(),
                enquiryIdentity.product(), enquiryIdentity.subProduct(), enquiryIdentity.serviceType(),
                enquiryIdentity.bank().orElse(null), enquiryIdentity.agent().getCode(), enquiryIdentity.baseCurrency(),
                enquiryIdentity.foreignCurrency(), enquiryIdentity.rateDisplayMachenism(), rates);
    }

    private CountryRateEnquiryResponse(final int batchSize, final int recordCount, final int endIndex,
            final int lastIndex, final Supplier<String> linkSupplier) {
        super(batchSize, recordCount, endIndex, lastIndex, linkSupplier);
    }

    public static CountryRateEnquiryResponse end(final RMType rmType, final CountryRateEnquiryRequest enquiryRequest,
            final int recordCount, final int lastIndex, final String URI) {
        return new CountryRateEnquiryResponse(enquiryRequest.batchSize(), recordCount, enquiryRequest.endIndex(),
                lastIndex, () -> moreLink(rmType, enquiryRequest, lastIndex, URI));
    }

    private static String moreLink(final RMType rmType, final CountryRateEnquiryRequest enquiryRequest,
            final int lastIndex, final String URI) {
        final Map<String, Object> paramsMap = new LinkedHashMap<>(12);
        paramsMap.put("serviceProviders", enquiryRequest.serviceProviders().toArray());
        paramsMap.put("products", enquiryRequest.products().toArray());
        paramsMap.put("subProducts", enquiryRequest.subProducts().toArray());
        paramsMap.put("serviceTypes", enquiryRequest.serviceTypes().toArray());
        if (rmType.isBankWise()) {
            paramsMap.put("banks", enquiryRequest.banks().toArray());
        }
        paramsMap.put("agents", enquiryRequest.agents().stream().map(AgentDetails::getCode).toArray());
        paramsMap.put("rateDisplayMachenism", enquiryRequest.rateDisplayMachenism().name());
        paramsMap.put("baseCurrencies",
                enquiryRequest.baseCurrencies().stream().map(CurrencyUnit::getCurrencyCode).toArray());
        paramsMap.put("foreignCurrencies",
                enquiryRequest.foreignCurrencies().stream().map(CurrencyUnit::getCurrencyCode).toArray());
        paramsMap.put("valueDateWises", enquiryRequest.valueDateWises().toArray());
        paramsMap.put("startingIndex", lastIndex);
        paramsMap.put("batchSize", enquiryRequest.batchSize());

        String queryParameters = paramsMap.entrySet().stream().map((x) -> x.getKey() + "={" + x.getKey() + "}")
                .collect(Collectors.joining("&"));
        String uri = URI + "?" + queryParameters;
        return UriComponentsBuilder.fromUriString(uri).build().expand(paramsMap).encode().toUriString();
    }
}
