package com.unimoni.pricingengine.common.util.download;

public enum DownloadContext {

    // @formatter:off
    NORMAL_BASE_RATE("Normal Base Rate"),
    BANK_WISE_BASE_RATE("Bank Wise Base Rate"),
    NORMAL_IBR("Normal IBR"),
    BANK_WISE_IBR("Bank Wise IBR"),
    NORMAL_VAR("Normal VaR"),
    BANK_WISE_VAR("Bank Wise VaR"),
    NORMAL_SETTLEMENT_RATE("Normal Settlement Rate"),
    BANK_WISE_SETTLEMENT_RATE("Bankwise Settlement Rate"),
    NORMAL_COUNTRY_RATE("Normal Country Rate"),
    BANK_WISE_COUNTRY_RATE("Bank Wise Country Rate"),
    NORMAL_AGENT_RATE("Normal Agent Rate"),
    BANK_WISE_AGENT_RATE("Bank Wise Agent Rate"),
	BRANCH_PROCESS_DOWNLOAD("Branch Processes"),
    STANDARD_CHARGE("Sandard Charges"),
    RATE_AUTHORIZATION_SETTING("Rate Authorization Setting"),
    AUTHORIZATION_QUEUE("Authorization Queue");
    // @formatter:on

    private final String fileName;

    private DownloadContext(final String fileName) {
        this.fileName = fileName;
    }

    public String defaultFileName() {
        return this.fileName;
    }
}
