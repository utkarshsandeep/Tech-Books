package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.util.List;

import javax.money.CurrencyUnit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BankWiseEventCountryRequest {
	
    private List<CurrencyUnit> SourcecurrencyCode;
    
    private List<CurrencyUnit> targetcurrencyCode;
	
	private String bankId;

	private String agentId;
	
	private String serviceProvider;
	
	private String product;
	
	private String productSubtype;
	
	private String serviceType;
	

}
