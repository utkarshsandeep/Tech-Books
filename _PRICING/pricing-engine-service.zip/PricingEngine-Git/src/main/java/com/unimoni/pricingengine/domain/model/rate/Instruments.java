package com.unimoni.pricingengine.domain.model.rate;

public interface Instruments {

}
