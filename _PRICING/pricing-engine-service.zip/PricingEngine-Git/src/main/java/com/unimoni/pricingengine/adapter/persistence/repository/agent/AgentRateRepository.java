package com.unimoni.pricingengine.adapter.persistence.repository.agent;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate;

public interface AgentRateRepository extends JpaRepository<AgentRate, String>, AgentRateRepositoryJPA {

}
