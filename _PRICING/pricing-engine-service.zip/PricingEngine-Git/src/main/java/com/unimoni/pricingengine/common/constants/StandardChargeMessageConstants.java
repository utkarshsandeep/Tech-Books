package com.unimoni.pricingengine.common.constants;

import com.unimoni.pricingengine.common.enums.MessageCodeType;

public enum StandardChargeMessageConstants implements MessageCodeType {

    STANDARD_CHARGES_CREATED_SUCCESSFULLY("standard.charges.created.successfully", "{0} New Standard Charge created successfully"),
    STANDARD_CHARGES_CREATION_FAILED("standard.charges.creation.failed", "Could not create New Standard Charge"),
    STANDARD_CHARGES_UPDATED_SUCCESSFULLY("standard.charges.updated.successfully", "{0} Standard Charge updated successfully"),
    AMOUNT_RANGE_UPDATED_SUCCESSFULLY("standard.charges.amount.range.updated.successfully", "{0} Amount Range updated successfully"),
    STANDARD_CHARGES_STATUS_UPDATE_SUCCESSFULLY("standard.charges.status.update.successfully", "Status is updated successfully"),
    UPLOAD_FAILED("upload.failed", "Could not upload Standard Charges");
    
	private String key;

    private String defaultMessage;

    private StandardChargeMessageConstants(final String messageCode, final String defaultMessage) {
        this.key = messageCode;
        this.defaultMessage = defaultMessage;
    }

    @Override
    public String key() {
        return this.key;
    }

    @Override
    public String defaultMessage() {
        return this.defaultMessage;
    }
}
