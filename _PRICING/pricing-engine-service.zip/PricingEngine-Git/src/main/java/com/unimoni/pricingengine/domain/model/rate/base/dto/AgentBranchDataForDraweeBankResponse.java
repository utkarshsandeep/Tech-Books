package com.unimoni.pricingengine.domain.model.rate.base.dto;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties
@ToString
public class AgentBranchDataForDraweeBankResponse {

    public Integer id;

    public String agentName;

    public String agentBranchName;

    public Integer agentId;

    public Integer agentBranchId;

    public String status;

    public String createdDate;

    public String modifiedDate;

    public Integer draweeBankProductProfileId;

    public String draweeBankProducProfileName;

    public Boolean deleted;

    public AgentBranchDataForDraweeBankResponse(@JsonProperty Integer id, @JsonProperty String agentName,
            @JsonProperty String agentBranchName, @JsonProperty Integer agentId, @JsonProperty Integer agentBranchId,
            @JsonProperty String status, @JsonProperty String createdDate, @JsonProperty String modifiedDate,
            @JsonProperty Integer draweeBankProductProfileId, @JsonProperty String draweeBankProducProfileName,
            @JsonProperty Boolean deleted) {
        this.id = id;
        this.agentName = agentName;
        this.agentBranchName = agentBranchName;
        this.agentId = agentId;
        this.agentBranchId = agentBranchId;
        this.status = status;
        this.createdDate = createdDate;
        this.modifiedDate = modifiedDate;
        this.draweeBankProductProfileId = draweeBankProductProfileId;
        this.draweeBankProducProfileName = draweeBankProducProfileName;
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).append("agentName", agentName)
                .append("agentBranchName", agentBranchName).append("agentId", agentId)
                .append("agentBranchId", agentBranchId).append("status", status).append("createdDate", createdDate)
                .append("modifiedDate", modifiedDate).append("draweeBankProductProfileId", draweeBankProductProfileId)
                .append("draweeBankProducProfileName", draweeBankProducProfileName).append("deleted", deleted)
                .toString();
    }

}
