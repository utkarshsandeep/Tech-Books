package com.unimoni.pricingengine.domain.model.rate.base.dto;

import javax.money.CurrencyUnit;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BankWiseEventVarRateRequest {

    private CurrencyUnit currencyCode;

    private String draweeBankId;

    private Integer agentId;

    private String serviceProvider;

    private String product;

    private String productSubtype;

    private String serviceType;

    private String bankDisplayCode;

    private String agentDisplayCode;

}
