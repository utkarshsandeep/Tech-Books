package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.math.BigDecimal;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.unimoni.pricingengine.domain.model.rate.RateSourceType;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "updateRateRequest", description = "Request to update multiple Rate records")
public class UpdateRateRequest {

    private RateDTO rate;

    @ApiModelProperty(allowEmptyValue = false, value = "New status of a record", example = "true", allowableValues = "true,false")
    private Boolean status;

    @ApiModelProperty(dataType = "String", allowableValues = "MANUAL, IBR_NORMAL", value = "Rate source type as either MANUAL or IBR_NORMAL", example = "IBR_NORMAL")
    private RateSourceType rateSourceType;

    public Optional<BigDecimal> askValue() {
        return this.rate != null ? Optional.ofNullable(this.rate.getAskValue()) : Optional.empty();
    }

    public Optional<BigDecimal> bidValue() {
        return this.rate != null ? Optional.ofNullable(this.rate.getBidValue()) : Optional.empty();
    }

    @JsonIgnore
    public boolean isRateUpdated() {
        return this.rate != null && this.rate.getAskValue() != null && this.rate.getBidValue() != null;
    }

    public Optional<ExchangeRate> exchangeRate() {
        return isRateUpdated() ? Optional.of(ExchangeRate.of(this.rate.getAskValue(), this.rate.getBidValue()))
                : Optional.empty();
    }

    public Optional<Boolean> status() {
        return this.status == null ? Optional.empty() : Optional.of(this.status);
    }

    public RateSourceType rateSourceType() {
        return this.rateSourceType;
    }

    @JsonIgnore
    public boolean isBidValueGreaterThanAskValue() {
        int value = this.rate.getAskValue().compareTo(this.rate.getBidValue());
        return value < 0;
    }
}
