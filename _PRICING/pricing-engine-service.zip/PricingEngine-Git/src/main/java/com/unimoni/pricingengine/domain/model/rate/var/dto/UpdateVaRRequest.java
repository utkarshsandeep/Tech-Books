package com.unimoni.pricingengine.domain.model.rate.var.dto;

import java.util.Map;
import java.util.Optional;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "updateVaRRequest", description = "Update VaR Request")
public class UpdateVaRRequest {

    @Getter(value = AccessLevel.NONE)
    @Size(min = 0, max = 4)
    private Map<@NotNull VDWType, @NotNull VaRValueDateWiseDTO> vdws;

    @Getter(value = AccessLevel.NONE)
    @ApiModelProperty(name = "status", allowEmptyValue = false, dataType = "Boolean", value = "New status, either true or false", required = false, example = "false", allowableValues = "true,false")
    private Boolean status;

    @NotBlank(message = "Reason cannot be empty")
    @ApiModelProperty(name = "reason", allowEmptyValue = false, dataType = "String", value = "The reson for update", required = true, example = "High volatility")
    private String reason;

    @ApiModelProperty(hidden = true)
    public Optional<Map<VDWType, VaRValueDateWiseDTO>> getValueDateWises() {
        return Optional.ofNullable(this.vdws);
    }

    public Optional<Boolean> status() {
        return Optional.ofNullable(this.status);
    }

    public String reason() {
        return this.reason;
    }
}