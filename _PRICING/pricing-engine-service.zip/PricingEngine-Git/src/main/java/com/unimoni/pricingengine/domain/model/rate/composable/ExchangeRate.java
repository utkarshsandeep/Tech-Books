package com.unimoni.pricingengine.domain.model.rate.composable;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;

import org.springframework.util.Assert;

import com.unimoni.pricingengine.domain.model.rate.RateValue;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
public class ExchangeRate implements RateValue {

    @NotNull
    @PositiveOrZero
    // @formatter:off
    @Column(name = "ASK_VALUE",  
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE")
    //@formatter:on
    private BigDecimal askValue;

    @NotNull
    @PositiveOrZero
    // @formatter:off
    @Column(name = "BID_VALUE", 
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE")
    //@formatter:on
    private BigDecimal bidValue;

    public static ExchangeRate of(final BigDecimal askValue, final BigDecimal bidValue) {
        Assert.notNull(askValue, "askValue must not be null!");
        Assert.notNull(bidValue, "bidValue must not be null!");
        Assert.isTrue(askValue.compareTo(bidValue) >= 0, "askValue must be greater than or equal to bidValue");
        ExchangeRate exchangeRate = new ExchangeRate();
        exchangeRate.askValue = RateValue.preciseTo8Decimals(askValue);
        exchangeRate.bidValue = RateValue.preciseTo8Decimals(bidValue);
        return exchangeRate;
    }

    public static final ExchangeRate ZERO = ExchangeRate.of(RateValue.ZERO, RateValue.ZERO);

    public static final ExchangeRate ONE = ExchangeRate.of(RateValue.ONE, RateValue.ONE);
}
