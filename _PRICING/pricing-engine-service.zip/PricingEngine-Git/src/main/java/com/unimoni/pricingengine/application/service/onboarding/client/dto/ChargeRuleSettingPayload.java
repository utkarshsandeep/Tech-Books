package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChargeRuleSettingPayload {

    public boolean otherCharges;

    public boolean commission;

    public boolean tax;

    public boolean cardCharges;

    public boolean additionalCharges;

    public ChargeRuleSettingPayload(final @JsonProperty("otherCharges") boolean otherCharges,
            final @JsonProperty("commission") boolean commission, final @JsonProperty("tax") boolean tax,
            final @JsonProperty("cardCharges") boolean cardCharges,
            final @JsonProperty("additionalCharges") boolean additionalCharges) {
        this.otherCharges = otherCharges;
        this.commission = commission;
        this.tax = tax;
        this.cardCharges = cardCharges;
        this.additionalCharges = additionalCharges;
    }
}
