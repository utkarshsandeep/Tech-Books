package com.unimoni.pricingengine.domain.model.rate.composable;

import java.math.BigDecimal;

import javax.money.CurrencyUnit;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import org.springframework.util.Assert;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
public class Exchange {

    @NotNull
    private CurrencyExchange currency;

    @NotNull
    private ExchangeRate rate;

    public static Exchange of(final CurrencyExchange currency, final ExchangeRate rate) {
        Assert.notNull(currency, "currency must not be null!");
        Assert.notNull(rate, "rate must not be null!");
        Exchange exchange = new Exchange();
        exchange.currency = currency;
        exchange.rate = rate;
        return exchange;
    }

    public static Exchange of(final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency,
            final BigDecimal askValue, final BigDecimal bidValue) {
        Assert.notNull(sourceCurrency, "sourceCurrency must not be null!");
        Assert.notNull(targetCurrency, "targetCurrency must not be null!");
        Assert.notNull(askValue, "askValue must not be null!");
        Assert.notNull(bidValue, "bidValue must not be null!");
        Exchange exchange = new Exchange();
        exchange.currency = CurrencyExchange.of(sourceCurrency, targetCurrency);
        exchange.rate = ExchangeRate.of(askValue, bidValue);
        return exchange;
    }

    public boolean updateRate(final BigDecimal askValue, final BigDecimal bidValue) {
        if (this.rate.askValue().compareTo(askValue) == 0 && this.rate.bidValue().compareTo(bidValue) == 0) {
            return false;
        }
        else {
            this.rate = ExchangeRate.of(askValue, bidValue);
            return true;
        }
    }

    public boolean updateRate(final ExchangeRate rate) {
        if (this.rate.askValue().compareTo(rate.askValue()) == 0
                && this.rate.bidValue().compareTo(rate.bidValue()) == 0) {
            return false;
        }
        else {
            this.rate = rate;
            return true;
        }
    }
}
