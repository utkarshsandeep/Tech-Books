package com.unimoni.pricingengine.domain.model.bp.dto;

import java.math.BigDecimal;

import javax.money.CurrencyUnit;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.bp.BranchProcessRequestType;
import com.unimoni.pricingengine.domain.model.bp.BranchProcessSourceType;
import com.unimoni.pricingengine.domain.model.bp.StatusType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "branchProcessRequest", description = "Branch process request parameter to create deal in PAAS")
public class BranchProcessCreateRequest {
	
    @ApiModelProperty(name = "dealId", value = "dealId", required = true)
    @NotNull
	private String dealId;
	
    @ApiModelProperty(name = "requestType", value = "dealType", required = true)
    @NotNull
    private BranchProcessRequestType requestType;
    
    @ApiModelProperty(name = "dealType", value = "dealType", required = true)
    @NotNull
	private String dealType;
    
    @ApiModelProperty(name = "serviceProviderCode", value = "serviceProviderCode", required = true)
	@NotNull
	private String serviceProviderCode;
    
    @ApiModelProperty(name = "dealStatus", value = "dealStatus", required = true)
	@NotNull
	private StatusType dealStatus;
	
    @ApiModelProperty(name = "agentCode", value = "agentCode", required = true)
    @NotNull
	private String agentCode;
    
    @ApiModelProperty(name = "bankCode", value = "bankCode", required = true)
    @NotNull
	private String bankCode;
    
    //when deal status is request_received it is referred as proposedRate , if status is approved it is referred as offeredRate
    @ApiModelProperty(name = "rate", value = "rate", required = true)
    @NotNull
	private String rate;
	
    //PlaceHolder to pass to Amigo GHQ
    @ApiModelProperty(name = "indicativeRate", value = "indicativeRate", required = false)
    @NotNull
    private String indicativeRate;
    
    //PlaceHolder to pass to Amigo GHQ
    @ApiModelProperty(name = "costRate", value = "costRate", required = false)
    @NotNull
    private String costRate;
    
    //PlaceHolder to pass to AMigo GhQ
    @ApiModelProperty(name = "gHQOfferedRate", value = "gHQOfferedRate", required = false)
    @NotNull
    private String gHQOfferedRate;
    
    @ApiModelProperty(name = "cardType", value = "cardType", required = true)
    @NotNull
	private String cardType;
	
    @ApiModelProperty(name = "payoutAmount", value = "payoutAmount", required = true)
	@NotNull
	private BigDecimal amount;
	
	@ApiModelProperty(name = "balanceAmount", value = "balanceAmount", required = true)
	@NotNull
	private BigDecimal balanceAmount;

	@ApiModelProperty(name = "payinCcyCode", value = "payinCcyCode", required = true)
	@NotNull
	private CurrencyUnit payInCcy;
	
	@ApiModelProperty(name = "payoutCcyCode", value = "payoutCcyCode", required = true)
	@NotNull
	private CurrencyUnit payOutCcy;
	
	@ApiModelProperty(name = "instrumentType", value = "instrumentType", required = true)
	@NotNull
	private String InstrumentType;
	
	@ApiModelProperty(name = "valueDate", value = "valueDate", required = true)
	@NotNull
	private String transmissionDate;
	
	@ApiModelProperty(name = "proposedOn", value = "proposedOn", required = true)
	@NotNull
	private String inititaionDate;
	
	@ApiModelProperty(name = "ratePublishInfo", value = "ratePublishInfo", required = false)
	@NotNull
	private String ratePublishInfo;
	
	@ApiModelProperty(name = "isSpecialStatus", value = "isSpecialStatus", required = false)
	@NotNull
	private String isSpecialStatus;
	
	@ApiModelProperty(name = "status", value = "status", required = false)
	@NotNull
	private String status;
	
    @ApiModelProperty(name = "sourceType", value = "AMIGOG", required = true)
    @NotNull
    private BranchProcessSourceType sourceType;
}
