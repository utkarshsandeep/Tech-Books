package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.money.Monetary;
import javax.validation.constraints.NotEmpty;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;

import io.swagger.annotations.ApiParam;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
//@ApiModel(value = "createAuthorizationSetting", description = "The required attributes to create one or multiple new Authorization Settings")
public class AuthorizationSettingCreateRequest {

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Rate Type such as NORMAL, BANKWISE")
    private List<RMType> rateTypes;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Layer such as IBM_MANAGEMENT, INTER_BANK_RATES, VOLATILITY_MARGIN, SETTLEMENT_MARGIN")
    private List<RateLayerType> rateLayerTypes;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Service Providers such as UAE, UK etc.")
    private List<String> serviceProviders;

    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Bank Code such as HDFC etc.")
    private List<String> bankCodes;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Agent Codes such 1234 etc.")
    private List<String> agentCodes;

    @NotEmpty
    @ApiParam(allowMultiple = true, allowEmptyValue = false, required = true, type = "String", value = "Currency such as INR, USD etc.")
    private List<String> currencies;

    @Getter(value = AccessLevel.NONE)
    @Setter(value = AccessLevel.NONE)
    private List<AuthorizationSettingIdentity> basicIdentities;

    @SuppressWarnings("unchecked")
    public List<AuthorizationSettingIdentity> basicIdentities() {
        if (this.basicIdentities == null) {
            final ImmutableList<RMType> rateTypes = ImmutableList.copyOf(this.rateTypes);
            final ImmutableList<RateLayerType> rateLayerTypes = ImmutableList.copyOf(this.rateLayerTypes);
            final ImmutableList<String> sps = ImmutableList.copyOf(this.serviceProviders);
            ImmutableList<String> banks = ImmutableList.of("");
            if (this.bankCodes != null && !this.bankCodes.isEmpty() && this.bankCodes.get(0) != null
                    && !this.bankCodes.get(0).isEmpty()) {
                banks = ImmutableList.copyOf(this.bankCodes);
            }

            final ImmutableList<String> agents = ImmutableList.copyOf(this.agentCodes);
            final ImmutableList<String> curr = ImmutableList.copyOf(this.currencies);

            final List<List<Object>> combinations = Lists.cartesianProduct(rateTypes, rateLayerTypes, sps, banks,
                    agents, curr);

            final List<AuthorizationSettingIdentity> identities = new ArrayList<>(combinations.size());
            for (final List<Object> combination : combinations) {
                String bank = null;
                if (RMType.BANK_WISE == (RMType) combination.get(0)) { // for NORMAL, bankCode will be null.
                    bank = (String) combination.get(3);
                }

                identities.add(AuthorizationSettingIdentity.of((RMType) combination.get(0),
                        (RateLayerType) combination.get(1), (String) combination.get(2), bank,
                        ((String) combination.get(4)), (Monetary.getCurrency((String)combination.get(5)))));
            }
            return this.basicIdentities = Collections.unmodifiableList(identities);
        }
        else {
            return this.basicIdentities;
        }
    }

    public int identityCount() {
        return basicIdentities().size();
    }

}
