package com.unimoni.pricingengine.adapter.rest.controller.agent;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addError;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.AGENT_RATE_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.AGENT_RATE_CREATION_FAILED;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.AGENT_RATE_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_BANK_WISE_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_BANK_WISE_META_DATA_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_BANK_WISE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_CALCULATE_CUSTOMER_LOW_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_CALCULATE_CUSTOMER_RATE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_CALCULATE_CUSTOMER_RATE_URI_NEW;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_CALCULATE_MARGIN_HIGH_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_CALCULATE_MARGIN_LOW_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_CALCULATE_MARGIN_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_CALCULATE_MARGIN_URI_NEW;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_CALCULATE_MAX_DISCOUNT_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_NORMAL_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_NORMAL_META_DATA_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_NORMAL_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.AGENT_RATE_RM_TYPE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.BANK_WISE_AGENT_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.constants.RestConstants.AgentLayer.NORMAL_AGENT_SERVER_SENT_EVENTS;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import javax.money.CurrencyUnit;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentMarginRateChangeDTO;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateCustomerRateChangeDTO;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateFormulaDTO;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateMetaData;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateRequest;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateResponse;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.CreateAgentRateRequest;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.SearchAgentRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.UpdateAgentRateRequest;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;
import com.unimoni.pricingengine.domain.service.agent.AgentRateService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "Agent", description = "Agent Branch Margin (Agent Rate Layer)", tags = "6th Layer")
@RestController
@RequestMapping(PRICING_API)
public class AgentRateController {

    @Autowired
    private AgentRateService agentRateService;

    @Autowired
    private PaginatedResourceAssembler<AgentRateResponse, String> agentPageAssembler;

    private final CopyOnWriteArrayList<SseEmitter> normalAgentEmitters = new CopyOnWriteArrayList<>();

    private final CopyOnWriteArrayList<SseEmitter> bankWiseAgentEmitters = new CopyOnWriteArrayList<>();

    @GetMapping(AGENT_RATE_NORMAL_META_DATA_URI)
    // @formatter:off
	@ApiOperation(nickname = "get-meta-data-to-create-normal-agent-rate", 
	    value = "Checks if Country rates exist, duplicate records exists "
			+ "and accordingly return the meta data to create new Agent Rate records", 
		notes = "", 
		response = AgentRateMetaData.class
	)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "agents", paramType = "query", required = true, dataType = "String", 
			        type = "array", dataTypeClass = AgentDetails.class, 
			        value = "Agent in the format: code,(BC_TO_FC|FC_TO_BC),(AGENT|BRANCH) example AGT0001,BC_TO_FC,AGENT", 
			        allowMultiple = true, example = "AGT0001,BC_TO_FC,AGENT"),
			@ApiImplicitParam(name = "baseCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Base Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR", required = true),
			@ApiImplicitParam(name = "foreignCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Foreign Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR", required = true) 
		}
	)
	@Valid
	public ResponseEntity<AgentRateMetaData> reviewNormalCountryRates(
			@RequestParam(value = "agents", required = true) @NotEmpty final List<@NotNull AgentDetails> agents,
			@ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", required = true, example = "UAE") 
			@RequestParam(value = "serviceProviders", required = true) @NotEmpty final List<@NotEmpty String> serviceProviders,
			@ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", required = true, example = "Remittance") 
			@RequestParam(value = "products", required = true) @NotEmpty final List<@NotEmpty String> products,
			@ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", required = true, example = "Account Credit") 
			@RequestParam(value = "subProducts", required = true) @NotEmpty final List<@NotEmpty String> subProducts,
			@ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", required = true, example = "Flash") 
			@RequestParam(value = "serviceTypes", required = true) @NotEmpty final List<@NotEmpty String> serviceTypes,
			@RequestParam(value = "baseCurrencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> baseCurrencies,
			@RequestParam(value = "foreignCurrencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> foreignCurrencies) {
		// @formatter:on
        return ResponseEntity.ok(agentRateService.createAgentRateMetaData(RMType.NORMAL,
                AgentRateRequest.ofNormal(serviceProviders, products, subProducts, serviceTypes, baseCurrencies,
                        foreignCurrencies, agents.stream().distinct().collect(Collectors.toList()))));
    }

    @GetMapping(AGENT_RATE_BANK_WISE_META_DATA_URI)
    // @formatter:off
	@ApiOperation(nickname = "get-meta-data-to-create-bankwise-agent-rate", 
	    value = "Checks if Country rates exist, duplicate records exists "
			+ "and accordingly return the meta data to create new Agent Rate records", 
		notes = "", 
		response = AgentRateMetaData.class
	)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "agents", paramType = "query", required = true, dataType = "String", type = "array", 
		        dataTypeClass = AgentDetails.class, value = "Agent in the format: code,(BC_TO_FC|FC_TO_BC),(AGENT|BRANCH) example AGT0001,BC_TO_FC,BRANCH", 
		        allowMultiple = true, example = "AGT0001,BC_TO_FC,BRANCH"),
			@ApiImplicitParam(name = "baseCurrencies", paramType = "query", dataType = "String", type = "array", 
		        value = "Base Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR", required = true),
			@ApiImplicitParam(name = "foreignCurrencies", paramType = "query", dataType = "String", type = "array", 
		        value = "Foreign Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR", required = true) 
		}
	)
	@Valid
	public ResponseEntity<AgentRateMetaData> reviewBankWiseCountryRates(
			@ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", required = true, example = "HDFC") 
			@RequestParam(value = "banks", required = true) @NotEmpty final List<@NotEmpty String> banks,
			@RequestParam(value = "agents", required = true) @NotEmpty final List<@NotNull AgentDetails> agents,
			@ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", required = true, example = "UAE") 
			@RequestParam(value = "serviceProviders", required = true) @NotEmpty final List<@NotEmpty String> serviceProviders,
			@ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.", required = true, example = "Remittance") 
			@RequestParam(value = "products", required = true) @NotEmpty final List<@NotEmpty String> products,
			@ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", required = true, example = "Account Credit") 
			@RequestParam(value = "subProducts", required = true) @NotEmpty final List<@NotEmpty String> subProducts,
			@ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.", required = true, example = "Flash") 
			@RequestParam(value = "serviceTypes", required = true) @NotEmpty final List<@NotEmpty String> serviceTypes,
			@RequestParam(value = "baseCurrencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> baseCurrencies,
			@RequestParam(value = "foreignCurrencies", required = true) @NotEmpty final List<@NotNull CurrencyUnit> foreignCurrencies) {
		// @formatter:on

        return ResponseEntity.ok(agentRateService.createAgentRateMetaData(RMType.BANK_WISE,
                AgentRateRequest.ofBankWise(serviceProviders, products, subProducts, serviceTypes, baseCurrencies,
                        foreignCurrencies, banks.stream().distinct().collect(Collectors.toList()),
                        agents.stream().distinct().collect(Collectors.toList()))));
    }

    @PostMapping(AGENT_RATE_RM_TYPE_URI)
    // @formatter:off
	@ApiOperation(nickname = "create-agent-rates", 
	    value = "Creates one or multiple new Agent rate records", 
	    notes = "", 
	    response = AgentRateResponse.class, 
	    responseContainer = "List"
	)
	@ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
	    value = "Rate management type: Normal or Bank wise", required = true, allowableValues = "NORMAL, BANK_WISE"
    )
	@ApiResponses(value = {
			@ApiResponse(response = AgentRateResponse.class, responseContainer = "List", code = 201, message = "One or more records created successfully"),
			@ApiResponse(code = 400, message = "Could not create records for supplied input") 
	    }
	)
    @Valid
	public ResponseEntity<List<AgentRateResponse>> createAgentRates(
	        final @PathVariable(name = "rmType", required = true) RMType rmType,
			@ApiParam(required = true, name = "createRequests", value = "A List of create Settlement rate requests") 
	        @RequestBody @Valid @NotEmpty final List<@Valid CreateAgentRateRequest> createRequests) {
		// @formatter:on

        createRequests.forEach((createRequest) -> {
            if (rmType.isBankWise() && !createRequest.getBank().isPresent()) {
                throw new RateException(RateExceptionExceptionType.BANK_REQUIRED_FOR_BANK_WISE_REQUEST,
                        Status.BAD_REQUEST);
            }
        });
        List<AgentRateResponse> agentRates = agentRateService.createAgentRates(rmType, createRequests);
        if (!agentRates.isEmpty()) { // All created
            return ResponseEntity.status(HttpStatus.CREATED)
                    .headers(addSuccess(getMessage(AGENT_RATE_CREATED_SUCCESSFULLY, agentRates.size())))
                    .body(agentRates);
        }
        else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .headers(addError(getMessage(AGENT_RATE_CREATION_FAILED))).build();
        }
    }

    @PatchMapping(AGENT_RATE_RM_TYPE_URI)
    // @formatter:off
	@ApiOperation(nickname = "update-agent-rates", 
	    value = "Updates one or multiple Agent rate records", 
	    notes = "Request should only contain the updated values "
			+ "If a value is not changed the respective value should not be there in request."
			+ "<b>You can only update the status of record and Margin/Agent sell and Margin buy value</b>", 
		consumes = APPLICATION_JSON_VALUE, 
		produces = APPLICATION_JSON_VALUE, 
		response = AgentRateResponse.class, 
		responseContainer = "List"
	)
	@ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
	    value = "Rate management type: Normal or Bank wise", required = true, allowableValues = "NORMAL, BANK_WISE"
	)
    @Valid
	public ResponseEntity<List<AgentRateResponse>> updateAgentRates(
	        final @PathVariable(name = "rmType", required = true) RMType rmType,
			@RequestBody @Valid @NotEmpty final Map<@NotEmpty String, @NotNull UpdateAgentRateRequest> updates) {
        // @formatter:on

        List<AgentRateResponse> results = agentRateService.updateAgentRates(rmType, updates);
        return ResponseEntity.ok().headers(addSuccess(getMessage(AGENT_RATE_UPDATED_SUCCESSFULLY, results.size())))
                .body(results);
    }

    @GetMapping(AGENT_RATE_NORMAL_URI)
    // @formatter:off
	@ApiOperation(nickname = "get-page-normal-agent-rates", 
	    consumes = APPLICATION_JSON_VALUE, 
	    produces = APPLICATION_JSON_VALUE, 
	    value = "Gets a page of Normal Country rate records matching the selection filters and sort criteria", 
	    notes = "", 
	    response = AgentRateResponse.class, 
	    responseContainer = "List"
    )
	@ApiImplicitParams({
			@ApiImplicitParam(name = "baseCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Base Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR"),
			@ApiImplicitParam(name = "foreignCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Foreign Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR") 
		}
	)
	@Paginated
	@Valid
	public ResponseEntity<PaginatedResource<Resource<AgentRateResponse>>> getAllNormalAgentRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
			@RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents,
			@ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.") 
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
			@ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.") 
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products,
			@ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit") 
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts,
			@ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.") 
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes,
			@RequestParam(value = "baseCurrencies", required = false) final List<@NotEmpty CurrencyUnit> baseCurrencies,
			@RequestParam(value = "foreignCurrencies", required = false) final List<@NotEmpty CurrencyUnit> foreignCurrencies,
			@ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false") 
            @RequestParam(value = "status", required = false) final Boolean status,
			@ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, sort = {
					"rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable,
			@ApiIgnore final PaginationData page, @RequestParam @ApiIgnore Map<String, Object> requestParams) {
		// @formatter:on
        List<AgentRateResponse> results = agentRateService
                .getAllAgentRates(SearchAgentRatesRequest.ofNormal(agents, serviceProviders, products, subProducts,
                        serviceTypes, baseCurrencies, foreignCurrencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(agentPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(AGENT_RATE_NORMAL_DOWNLOAD_URI)
    // @formatter:off
	@ApiOperation(nickname = "download-normal-agent-rates", 
	    consumes = APPLICATION_JSON_VALUE, 
	    produces = APPLICATION_JSON_VALUE, 
	    value = "Download all Normal Country rate records matching the selection filters and sort criteria", 
	    notes = "", 
	    response = Void.class
    )
	@ApiImplicitParams({
			@ApiImplicitParam(name = "baseCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Base Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR"),
			@ApiImplicitParam(name = "foreignCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Foreign Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR") 
		}
	)
	@Valid
	public void downloadNormalAgentRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
			@RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents,
			@ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.") 
			@RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
			@ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.") 
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products,
			@ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit") 
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts,
			@ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.") 
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes,
			@RequestParam(value = "baseCurrencies", required = false) final List<@NotEmpty CurrencyUnit> baseCurrencies,
			@RequestParam(value = "foreignCurrencies", required = false) final List<@NotEmpty CurrencyUnit> foreignCurrencies,
			@ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false") 
            @RequestParam(value = "status", required = false) final Boolean status,
			@ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken") 
            @RequestParam(value = "fileName", required = false) final String fileName,
			@ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true) 
            @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
			@ApiIgnore final HttpServletResponse response) {
		// @formatter:on

        FileDownloadHelper.downloadFile(
                SearchAgentRatesRequest.ofNormalDownload(agents, serviceProviders, products, subProducts, serviceTypes,
                        baseCurrencies, foreignCurrencies, status),
                agentRateService::getAllAgentRates, downloadFileType, fileName, DownloadContext.NORMAL_AGENT_RATE,
                response);
    }

    @GetMapping(AGENT_RATE_BANK_WISE_URI)
    // @formatter:off
	@ApiOperation(nickname = "get-page-bank-wise-agent-rates", 
	    consumes = APPLICATION_JSON_VALUE, 
	    produces = APPLICATION_JSON_VALUE, 
	    value = "Gets a page of Bank wise Agent rate records matching the selection filters and sort criteria", 
	    notes = "", 
	    response = AgentRateResponse.class, 
	    responseContainer = "PaginatedResource"
    )
	@ApiImplicitParams({
			@ApiImplicitParam(name = "baseCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Base Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR"),
			@ApiImplicitParam(name = "foreignCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Foreign Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR") 
		}
	)
	@Paginated
	@Valid
	public ResponseEntity<PaginatedResource<Resource<AgentRateResponse>>> getAllBankWiseAgentRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
			@RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents,
			@ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC") 
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks,
			@ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.") 
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
			@ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.") 
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products,
			@ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit") 
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts,
			@ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.") 
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes,
			@RequestParam(value = "baseCurrencies", required = false) final List<@NotEmpty CurrencyUnit> baseCurrencies,
			@RequestParam(value = "foreignCurrencies", required = false) final List<@NotEmpty CurrencyUnit> foreignCurrencies,
			@ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false") 
            @RequestParam(value = "status", required = false) final Boolean status,
			@ApiIgnore @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, sort = {
					"rate.ccy" }, direction = Sort.Direction.ASC) final Pageable pageable,
			@ApiIgnore final PaginationData page, @RequestParam @ApiIgnore Map<String, Object> requestParams) {
		// @formatter:on

        List<AgentRateResponse> results = agentRateService
                .getAllAgentRates(SearchAgentRatesRequest.ofBankWise(agents, banks, serviceProviders, products,
                        subProducts, serviceTypes, baseCurrencies, foreignCurrencies, status, page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(agentPageAssembler.assemble(results, page, requestParams));
        }
    }

    @GetMapping(AGENT_RATE_BANK_WISE_DOWNLOAD_URI)
    // @formatter:off
	@ApiOperation(nickname = "download-bank-wise-agent-rates", 
	    consumes = APPLICATION_JSON_VALUE, 
	    produces = APPLICATION_JSON_VALUE, 
	    value = "Gets a page of Bank wise Agent rate records matching the selection filters and sort criteria", 
	    notes = "", 
	    response = Void.class
    )
	@ApiImplicitParams({
			@ApiImplicitParam(name = "baseCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Base Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR"),
			@ApiImplicitParam(name = "foreignCurrencies", paramType = "query", dataType = "String", type = "array", 
			    value = "Foreign Currency Code in ISO format e.g. USD", allowMultiple = true, example = "INR") 
		}
	)
	@Valid
	public void downloadBankWiseAgentRates(
            @ApiParam(allowMultiple = true, type = "String", value = "Agents such as AGNT00X1 etc.", example = "AGNT00X1")
			@RequestParam(value = "agents", required = false) final List<@NotEmpty String> agents,
			@ApiParam(allowMultiple = true, type = "String", value = "Banks such as HDFC, ICICI etc.", example = "HDFC") 
            @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks,
			@ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.") 
            @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
			@ApiParam(allowMultiple = true, type = "String", value = "Products such as Remittance, Forex etc.") 
            @RequestParam(value = "products", required = false) final List<@NotEmpty String> products,
			@ApiParam(allowMultiple = true, type = "String", value = "Sub products such as Account Credit, Cash payout etc.", example = "Account Credit") 
            @RequestParam(value = "subProducts", required = false) final List<@NotEmpty String> subProducts,
			@ApiParam(allowMultiple = true, type = "String", value = "Service types such as Flash, Normal etc.") 
            @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes,
			@RequestParam(value = "baseCurrencies", required = false) final List<@NotEmpty CurrencyUnit> baseCurrencies,
			@RequestParam(value = "foreignCurrencies", required = false) final List<@NotEmpty CurrencyUnit> foreignCurrencies,
			@ApiParam(type = "Boolean", value = "Enabled or Disabled", allowableValues = "true,false") 
            @RequestParam(value = "status", required = false) final Boolean status,
			@ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken") 
            @RequestParam(value = "fileName", required = false) final String fileName,
			@ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true) @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
			@ApiIgnore final HttpServletResponse response) {
		// @formatter:on

        FileDownloadHelper.downloadFile(
                SearchAgentRatesRequest.ofBankWiseDownload(agents, banks, serviceProviders, products, subProducts,
                        serviceTypes, baseCurrencies, foreignCurrencies, status),
                agentRateService::getAllAgentRates, downloadFileType, fileName, DownloadContext.BANK_WISE_AGENT_RATE,
                response);
    }

    @GetMapping(AGENT_RATE_CALCULATE_CUSTOMER_RATE_URI)
    // @formatter:off
	@ApiOperation(nickname = "calculate-customerRate", 
	    value = "Calculates and returns the Customer Rate for Agent Rate of provided Value Date Wise as per following formulas:", 
	    notes = "<b>For scenario where From RateDisplay Mechanism  = BC_FC</b>"
			+ "        <ul><li> Agent Customer Rate Sell = Agent Cost Sell Rate – Agent Sell Margin</li>"
			+ "        <li> Agent Customer Rate Buy = Agent Cost Buy Rate + Agent Cash Buy Margin</li></ul>"
			+ "<b>For scenario where To currency = Foreign Currency To Base Currency</b>"
			+ "        <ul><li> Agent Customer Cash Sell Rate = Agent Cash Cost Sell Rate + Agent Cash Sell Margin</li>"
			+ "        <li> Agent Customer Cash Buy Rate = Agent Cash Cost Buy Rate - Agent Cash Buy Margin</li></ul>", 
		response = AgentRateFormulaDTO.class
	)
	@Valid
	public ResponseEntity<AgentRateFormulaDTO> calculateAgentCustomerRate(
			@ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String") 
			@RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
			@ApiParam(name = "agentCostSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCostSell", required = true) @NotNull final BigDecimal agentCostSell,
			@ApiParam(name = "agentCostBuy", value = "Agent cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCostBuy", required = true) @NotNull final BigDecimal agentCostBuy,
			@ApiParam(name = "agentMarginSell", value = "Agent margin sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginSell", required = true) @NotNull final BigDecimal agentMarginSell,
			@ApiParam(name = "agentMarginBuy", value = "Agent margin sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginBuy", required = true) @NotNull final BigDecimal agentMarginBuy) {
		// @formatter:on
        return ResponseEntity.ok(AgentRateFormulaDTO.byCustomerRateFormula(RDM, agentCostSell, agentCostBuy,
                agentMarginSell, agentMarginBuy));
    }

    @GetMapping(AGENT_RATE_CALCULATE_MARGIN_URI)
    // @formatter:off
	@ApiOperation(nickname = "calculate-margin", 
	    value = "Calculates and returns the Margin  for Agent Rate of provided Value Date Wise as per following formulas:", 
	    notes = "<b>For scenario where From RateDisplay Mechanism  = BC_FC</b>"
			+ "        <ul><li> Agent Sell Margin = Agent Cost Sell Rate – Agent Customer Rate Sell</li>"
			+ "        <li> Agent Buy Margin = Agent Customer Rate Buy – Agent Cost Buy Rate</li></ul>"
			+ "<b>For scenario where To currency = Foreign Currency To Base Currency</b>"
			+ "        <ul><li> Agent Cash Sell Margin = Agent Customer Cash Sell Rate - Agent Cash Cost Sell Rate</li>"
			+ "        <li> Agent Cash Buy Margin = Agent Cash Cost Buy Rate - Agent Customer Cash Buy Rate</li></ul>", 
		response = AgentRateFormulaDTO.class
	)
	@Valid
	public ResponseEntity<AgentRateFormulaDTO> calculateAgentMargin(
			@ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String") 
			@RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
			@ApiParam(name = "agentCostSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCostSell", required = true) @NotNull final BigDecimal agentCostSell,
			@ApiParam(name = "agentCostBuy", value = "Agent cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCostBuy", required = true) @NotNull final BigDecimal agentCostBuy,
			@ApiParam(name = "agentCustomerRateSell", value = "Agent customer rate sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateSell", required = true) @NotNull final BigDecimal agentCustomerRateSell,
			@ApiParam(name = "agentCustomerRateBuy", value = "Agent customer rate buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateBuy", required = true) @NotNull final BigDecimal agentCustomerRateBuy) {
		// @formatter:on
        return ResponseEntity.ok(AgentRateFormulaDTO.byMarginFormula(RDM, agentCostSell, agentCostBuy,
                agentCustomerRateSell, agentCustomerRateBuy));
    }

    @GetMapping(AGENT_RATE_CALCULATE_MAX_DISCOUNT_URI)
    // @formatter:off
	@ApiOperation(nickname = "calculate-max-discount", 
	    value = "Calculates and returns the Margin  for Agent Rate of provided Value Date Wise as per following formulas:", 
	    notes = "<b>For scenario where From RateDisplay Mechanism  = BC_FC</b>"
			+ "        <ul><li> Agent Customer Maximum Discounted Sell Rate = Customer Sell Rate + Agent Sell Margin Low</li>"
			+ "        <li> Agent Customer Maximum Discounted Buy Rate = Customer Buy Rate - Agent Buy Margin Low</li></ul>"
			+ "<b>For scenario where To currency = Foreign Currency To Base Currency</b>"
			+ "        <ul><li> Agent Customer Maximum Discounted Cash Sell Rate = Customer Cash Sell Rate – Agent Cash Sell Margin Low</li>"
			+ "        <li> Agent Customer Maximum Discounted Cash Buy Rate = Customer Cash Buy Rate + Agent Cash Buy Margin Low</li></ul>", 
		response = AgentRateFormulaDTO.class
	)
	@Valid
	public ResponseEntity<AgentRateFormulaDTO> calculateAgentMaximumDiscount(
			@ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String") 
			@RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
			@ApiParam(name = "agentCustomerRateSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateSell", required = true) @NotNull final BigDecimal agentCustomerRateSell,
			@ApiParam(name = "agentCustomerRateBuy", value = "Agent cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateBuy", required = true) @NotNull final BigDecimal agentCustomerRateBuy,
			@ApiParam(name = "agentMarginLowSell", value = "Agent margin sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginLowSell", required = true) @NotNull final BigDecimal agentMarginLowSell,
			@ApiParam(name = "agentMarginLowBuy", value = "Agent margin buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginLowBuy", required = true) @NotNull final BigDecimal agentMarginLowBuy) {
		// @formatter:on
        return ResponseEntity.ok(AgentRateFormulaDTO.byMaxDiscountFormula(RDM, agentCustomerRateSell,
                agentCustomerRateBuy, agentMarginLowSell, agentMarginLowBuy));
    }

    @GetMapping(AGENT_RATE_CALCULATE_MARGIN_LOW_URI)
    // @formatter:off
	@ApiOperation(nickname = "calculate-margin-low", 
	    value = "Calculates and returns the Margin  for Agent Rate of provided Value Date Wise as per following formulas:", 
	    notes = "<b>For scenario where From RateDisplay Mechanism  = BC_FC</b>"
			+ "        <ul><li> Agent Sell Margin Low = Agent Customer Maximum Discounted Sell Rate – Customer Sell Rate</li>"
			+ "        <li> Agent Buy Margin Low = Customer Buy Rate – Agent Customer Maximum Discounted Buy Rate</li></ul>"
			+ "<b>For scenario where To currency = Foreign Currency To Base Currency</b>"
			+ "        <ul><li> Agent Cash Sell Margin Low = Customer Cash Sell Rate – Agent Customer Maximum Discounted Cash Sell Rate</li>"
			+ "        <li> Agent Cash Buy Margin Low = Agent Customer Maximum Discounted Cash Buy Rate – Customer Cash Buy Rate</li></ul>", 
		response = AgentRateFormulaDTO.class
	)
	@Valid
	public ResponseEntity<AgentRateFormulaDTO> calculateAgentMarginLow(
			@ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String") 
			@RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
			@ApiParam(name = "agentCustomerRateSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateSell", required = true) @NotNull final BigDecimal agentCustomerRateSell,
			@ApiParam(name = "agentCustomerRateBuy", value = "Agent cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateBuy", required = true) @NotNull final BigDecimal agentCustomerRateBuy,
			@ApiParam(name = "agentMaxDiscountSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMaxDiscountSell", required = true) @NotNull final BigDecimal agentMaxDiscountSell,
			@ApiParam(name = "agentMaxDiscountBuy", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMaxDiscountBuy", required = true) @NotNull final BigDecimal agentMaxDiscountBuy) {
		// @formatter:on
        return ResponseEntity.ok(AgentRateFormulaDTO.byMarginLowFormula(RDM, agentCustomerRateSell,
                agentCustomerRateBuy, agentMaxDiscountSell, agentMaxDiscountBuy));
    }

    @GetMapping(AGENT_RATE_CALCULATE_MARGIN_HIGH_URI)
    // @formatter:off
	@ApiOperation(nickname = "calculate-margin-high", 
	    value = "Calculates and returns the Margin  for Agent Rate of provided Value Date Wise as per following formulas:", 
	    notes = "<b>For scenario where From RateDisplay Mechanism  = BC_FC</b>"
			+ "        <ul><li> Agent Sell Margin High = Customer Sell Rate – Agent Customer Lowest Sell Rate</li>"
			+ "        <li>   Agent Buy Margin High = Agent Customer Lowest Buy Rate – Customer Buy Rate</li></ul>"
			+ "<b>For scenario where To currency = Foreign Currency To Base Currency</b>"
			+ "        <ul><li>Agent Cash Sell Margin High = Agent Customer Lowest Cash Sell Rate – Customer Cash Sell Rate</li>"
			+ "        <li> Agent Cash Buy Margin High = Customer Cash Buy Rate – Agent Customer Lowest Cash Buy Rate</li></ul>", 
		response = AgentRateFormulaDTO.class
	)
	@Valid
	public ResponseEntity<AgentRateFormulaDTO> calculateAgentMarginHigh(
			@ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String") 
			@RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
			@ApiParam(name = "agentCustomerRateSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateSell", required = true) @NotNull final BigDecimal agentCustomerRateSell,
			@ApiParam(name = "agentCustomerRateBuy", value = "Agent cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateBuy", required = true) @NotNull final BigDecimal agentCustomerRateBuy,
			@ApiParam(name = "agentCustomerLowestSell", value = "Agent customer lowest sell sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerLowestSell", required = true) @NotNull final BigDecimal agentCustomerLowestSell,
			@ApiParam(name = "agentCustomerLowestBuy", value = "Agent customer lowest buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerLowestBuy", required = true) @NotNull final BigDecimal agentCustomerLowestBuy) {
		// @formatter:on
        return ResponseEntity.ok(AgentRateFormulaDTO.byMarginHighFormula(RDM, agentCustomerRateSell,
                agentCustomerRateBuy, agentCustomerLowestSell, agentCustomerLowestBuy));
    }

    @GetMapping(AGENT_RATE_CALCULATE_CUSTOMER_LOW_URI)
    // @formatter:off
	@ApiOperation(nickname = "calculate-customer-lowest", 
	    value = "Calculates and returns the Margin  for Agent Rate of provided Value Date Wise as per following formulas:", 
	    notes = "<b>For scenario where From RateDisplay Mechanism  = BC_TO_FC</b>"
			+ "        <ul><li> Agent Customer Lowest Sell Rate = Customer Sell Rate – Agent Sell Margin High</li>"
			+ "        <li> Agent Customer Lowest Buy Rate = Customer Buy Rate + Agent Buy Margin High</li></ul>"
			+ "<b>For scenario where To currency = Foreign Currency To Base Currency</b>"
			+ "        <ul><li>Agent Customer Lowest Cash Sell Rate = Customer Cash Sell Rate + Agent Cash Sell Margin High</li>"
			+ "        <li>  Agent Customer Lowest Cash Buy Rate = Customer Cash Buy Rate – Agent Cash Buy Margin High</li></ul>", 
		response = AgentRateFormulaDTO.class
	)
	@Valid
	public ResponseEntity<AgentRateFormulaDTO> calculateAgentCustomerLowest(
			@ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String") 
			@RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
			@ApiParam(name = "agentCustomerRateSell", value = "Country cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateSell", required = true) @NotNull final BigDecimal agentCustomerRateSell,
			@ApiParam(name = "agentCustomerRateBuy", value = "Country cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateBuy", required = true) @NotNull final BigDecimal agentCustomerRateBuy,
			@ApiParam(name = "agentMarginHighSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginHighSell", required = true) @NotNull final BigDecimal agentMarginHighSell,
			@ApiParam(name = "agentMarginHighBuy", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginHighBuy", required = true) @NotNull final BigDecimal agentMarginHighBuy) {
		// @formatter:on
        return ResponseEntity.ok(AgentRateFormulaDTO.byCustomerLowestFormula(RDM, agentCustomerRateSell,
                agentCustomerRateBuy, agentMarginHighSell, agentMarginHighBuy));
    }

    @GetMapping(AGENT_RATE_CALCULATE_CUSTOMER_RATE_URI_NEW)
    // @formatter:off
	@ApiOperation(nickname = "calculate-customerRate-new", 
	    value = "Calculates and returns the Customer Rate for Agent Rate of provided Value Date Wise as per following formulas:", 
	    notes = "<b>For scenario where From RateDisplay Mechanism  = BC_FC</b>"
			+ "        <ul><li> Agent Customer Rate Sell = Agent Cost Sell Rate – Agent Sell Margin</li>"
			+ "        <li> Agent Customer Rate Buy = Agent Cost Buy Rate + Agent Cash Buy Margin</li>"
			+ "        <li>Customer Lowest Sell Rate = Customer Sell Rate – Sell Margin High<li>"
			+ "        <li>Customer Lowest Buy Rate = Customer Buy Rate + Buy Margin High<li>"
			+ "        <li>Customer Maximum Discounted Sell Rate = Customer Sell Rate + Sell Margin Low<li>"
			+ "        <li>Customer Maximum Discounted Buy Rate = Customer Buy Rate - Buy Margin Low<li></ul>"
			+ "<b>For scenario where To currency = Foreign Currency To Base Currency</b>"
			+ "        <ul><li> Agent Customer Cash Sell Rate = Agent Cash Cost Sell Rate + Agent Cash Sell Margin</li>"
			+ "        <li> Agent Customer Cash Buy Rate = Agent Cash Cost Buy Rate - Agent Cash Buy Margin</li>"
			+ "        <li>Customer Maximum Discounted Sell Rate = Customer Sell Rate – Sell Margin Low<li>"
			+ "        <li>Customer Maximum Discounted Buy Rate = Customer Buy Rate + Buy Margin Low<li>"
			+ "        <li>Customer Lowest Sell Rate = Customer Sell Rate + Sell Margin High<li>"
			+ "        <li>Customer Lowest Buy Rate = Customer Buy Rate – Buy Margin High<li></ul>", 
		response = AgentRateCustomerRateChangeDTO.class
	)
	@Valid
	public ResponseEntity<AgentRateCustomerRateChangeDTO> calculateAgentCustomerRateNew(
			@ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String") 
			@RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
			@ApiParam(name = "agentCostSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCostSell", required = true) @NotNull final BigDecimal agentCostSell,
			@ApiParam(name = "agentCostBuy", value = "Agent cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCostBuy", required = true) @NotNull final BigDecimal agentCostBuy,
			@ApiParam(name = "agentMarginSell", value = "Agent margin sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginSell", required = true) @NotNull final BigDecimal agentMarginSell,
			@ApiParam(name = "agentMarginBuy", value = "Agent margin sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginBuy", required = true) @NotNull final BigDecimal agentMarginBuy,
			@ApiParam(name = "agentMarginHighSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginHighSell", required = true) @NotNull final BigDecimal agentMarginHighSell,
			@ApiParam(name = "agentMarginHighBuy", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginHighBuy", required = true) @NotNull final BigDecimal agentMarginHighBuy,
			@ApiParam(name = "agentMarginLowSell", value = "Agent margin sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginLowSell", required = true) @NotNull final BigDecimal agentMarginLowSell,
			@ApiParam(name = "agentMarginLowBuy", value = "Agent margin buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginLowBuy", required = true) @NotNull final BigDecimal agentMarginLowBuy) {
		// @formatter:on
        return ResponseEntity
                .ok(AgentRateCustomerRateChangeDTO.byCustomerRateFormula(CostDTO.of(agentCostSell, agentCostBuy),
                        CostDTO.of(agentMarginSell, agentMarginBuy), CostDTO.of(agentMarginLowSell, agentMarginLowBuy),
                        CostDTO.of(agentMarginHighSell, agentMarginHighBuy), RDM));
    }

    @GetMapping(AGENT_RATE_CALCULATE_MARGIN_URI_NEW)
    // @formatter:off
	@ApiOperation(nickname = "calculate-marginRate-new", 
	    value = "Calculates and returns the Customer Rate for Agent Rate of provided Value Date Wise as per following formulas:", 
	    notes = "<b>For scenario where From RateDisplay Mechanism  = BC_FC</b>"
			+ "        <ul><li> Sell Margin = Cost Sell Rate – Customer Rate Sell</li>"
			+ "        <li> Buy Margin = Customer Rate Buy – Cost Buy Rate</li>"
			+ "        <li>Customer Lowest Sell Rate = Customer Sell Rate – Sell Margin High<li>"
			+ "        <li>Customer Lowest Buy Rate = Customer Buy Rate + Buy Margin High<li>"
			+ "        <li>Customer Maximum Discounted Sell Rate = Customer Sell Rate + Sell Margin Low<li>"
			+ "        <li>Customer Maximum Discounted Buy Rate = Customer Buy Rate - Buy Margin Low<li></ul>"
			+ "<b>For scenario where To currency = Foreign Currency To Base Currency</b>"
			+ "        <ul><li> Agent  Sell Margin = Agent Customer  Sell Rate - Agent  Cost Sell Rate</li>"
			+ "        <li> Agent  Buy Margin = Agent  Cost Buy Rate - Agent Customer  Buy Rate</li>"
			+ "        <li>Customer Maximum Discounted Sell Rate = Customer Sell Rate – Sell Margin Low<li>"
			+ "        <li>Customer Maximum Discounted Buy Rate = Customer Buy Rate + Buy Margin Low<li>"
			+ "        <li>Customer Lowest Sell Rate = Customer Sell Rate + Sell Margin High<li>"
			+ "        <li>Customer Lowest Buy Rate = Customer Buy Rate – Buy Margin High<li></ul>", 
		response = AgentMarginRateChangeDTO.class
	)
	@Valid
	public ResponseEntity<AgentMarginRateChangeDTO> calculateMarginChangeNew(
			@ApiParam(name = "rateDisplayMachenism", value = "Agent's Rate Display Machenism", required = true, allowableValues = "BC_TO_FC, FC_TO_BC", example = "BC_TO_FC", type = "String") 
			@RequestParam(name = "rateDisplayMachenism", required = true) @NotNull RateDisplayMachenism RDM,
			@ApiParam(name = "agentCostSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCostSell", required = true) @NotNull final BigDecimal agentCostSell,
			@ApiParam(name = "agentCostBuy", value = "Agent cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCostBuy", required = true) @NotNull final BigDecimal agentCostBuy,
			@ApiParam(name = "agentCustomerRateSell", value = "Country cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateSell", required = true) @NotNull final BigDecimal agentCustomerRateSell,
			@ApiParam(name = "agentCustomerRateBuy", value = "Country cost buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentCustomerRateBuy", required = true) @NotNull final BigDecimal agentCustomerRateBuy,
			@ApiParam(name = "agentMarginHighSell", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginHighSell", required = true) @NotNull final BigDecimal agentMarginHighSell,
			@ApiParam(name = "agentMarginHighBuy", value = "Agent cost sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginHighBuy", required = true) @NotNull final BigDecimal agentMarginHighBuy,
			@ApiParam(name = "agentMarginLowSell", value = "Agent margin sell value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginLowSell", required = true) @NotNull final BigDecimal agentMarginLowSell,
			@ApiParam(name = "agentMarginLowBuy", value = "Agent margin buy value in BigDecimal with " + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000") 
			@RequestParam(value = "agentMarginLowBuy", required = true) @NotNull final BigDecimal agentMarginLowBuy) {
		// @formatter:on
        return ResponseEntity.ok(AgentMarginRateChangeDTO.byMarginRateFormula(CostDTO.of(agentCostSell, agentCostBuy),
                CostDTO.of(agentCustomerRateSell, agentCustomerRateBuy),
                CostDTO.of(agentMarginLowSell, agentMarginLowBuy), CostDTO.of(agentMarginHighSell, agentMarginHighBuy),
                RDM));
    }

    // --------------------- Server Sent Events Code Start --------------------------

    @GetMapping(NORMAL_AGENT_SERVER_SENT_EVENTS)
    public SseEmitter sendNormalVARSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.normalAgentEmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.normalAgentEmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.normalAgentEmitters.remove(emitter);
        });

        return emitter;
    }

    @GetMapping(BANK_WISE_AGENT_SERVER_SENT_EVENTS)
    public SseEmitter sendBankWiseVARSSEvents() {
        SseEmitter emitter = new SseEmitter();
        this.bankWiseAgentEmitters.add(emitter);

        emitter.onCompletion(() -> {
            this.bankWiseAgentEmitters.remove(emitter);
        });

        emitter.onTimeout(() -> {
            emitter.complete();
            this.bankWiseAgentEmitters.remove(emitter);
        });

        return emitter;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleServerSentEvents(AgentRateResponse agentRateResponse) {
        List<SseEmitter> normalDeadEmitters = new ArrayList<>();
        List<SseEmitter> bankDeadEmitters = new ArrayList<>();

        if (agentRateResponse.getBank() != null && !agentRateResponse.getBank().isEmpty()) {
            this.bankWiseAgentEmitters.forEach(emitter -> {
                try {
                    emitter.send(agentRateResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    bankDeadEmitters.add(emitter);
                }
            });

            this.bankWiseAgentEmitters.removeAll(bankDeadEmitters);
        }
        else {
            this.normalAgentEmitters.forEach(emitter -> {
                try {
                    emitter.send(agentRateResponse);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    normalDeadEmitters.add(emitter);
                }
            });

            this.normalAgentEmitters.removeAll(normalDeadEmitters);
        }
    }

    // --------------------- Server Sent Events Code Ends --------------------------
}
