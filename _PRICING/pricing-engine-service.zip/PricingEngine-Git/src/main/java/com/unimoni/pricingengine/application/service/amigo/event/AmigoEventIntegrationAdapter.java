package com.unimoni.pricingengine.application.service.amigo.event;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import com.unimoni.pricingengine.common.annotation.spring.JmsIntegration;

import lombok.extern.slf4j.Slf4j;

@JmsIntegration
@Slf4j
@Component
public class AmigoEventIntegrationAdapter {

    @Autowired
    private JmsTemplate jmsTopicTemplate;

    @Autowired
    private Topic paasRateChangedTopic;

    private static final String TOPIC_PAAS_RATE_CHANGED = "PAASRateChanged";

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public <T extends AmigoEvent> void handlePaasRateChangedAmigoEvent(final T amigoEvent) {
        log.info("Pushing IBR create/update event: {} to JMS topic : {} ", amigoEvent, TOPIC_PAAS_RATE_CHANGED);
        this.jmsTopicTemplate.convertAndSend(paasRateChangedTopic, amigoEvent);
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public <T extends VDWRateAmigoEvent> void handleVDWPaasRateChangedAmigoEvent(final T amigoEvent) {
        log.info("Pushing VDWRate create/update event: {} to JMS topic : {} ", amigoEvent, TOPIC_PAAS_RATE_CHANGED);
        this.jmsTopicTemplate.convertAndSend(paasRateChangedTopic, amigoEvent);
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, classes = { StandardChargeCreatedEvent.class })
    public <T extends AmigoStandardChargeEvent> void handleStandardChargeCreatedEvent(final T standardChargeEvent) {
        log.info("START: Pushing StandardChargeCreatedEvent: {} to JMS topic for " + standardChargeEvent.getType());
        this.jmsTopicTemplate.convertAndSend(paasRateChangedTopic, standardChargeEvent);
        log.info("END: Pushing StandardChargeCreatedEvent: {} to JMS topic for " + standardChargeEvent.getType());
    }

    @JmsListener(destination = TOPIC_PAAS_RATE_CHANGED, containerFactory = "topicListenerFactory")
    public void testConsumePaasRateChangedJMSEvent(final Message message) {
        log.info("Received Amigo event : {} from JMS topic : {} ", message, TOPIC_PAAS_RATE_CHANGED);
        try {
            String jsonTxt = ((TextMessage) message).getText();
            log.info("Received Amigo event event: {} from JMS topic : {} ", jsonTxt, TOPIC_PAAS_RATE_CHANGED);
            // System.out.println("Received VaR/Settlement rate create/update event >>> jsonMessage --->>" + jsonTxt);
        }
        catch (JMSException e) {
            e.printStackTrace();
        }
    }
}
