package com.unimoni.pricingengine.adapter.persistence.repository.rate.authorizationsetting;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationQueue;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationQueue_;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationSetting;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationSetting_;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationStatusType;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationQueueSearchRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationRateSettingRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingIdentity;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingSearchRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.ColumnNameType;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

public abstract class AuthorizationSettingPredicates {

    public static Predicate[] getSearchAuthorizationSettingPredicates(final Root<AuthorizationSetting> root,
            final CriteriaBuilder criteriaBuilder, final AuthorizationSettingSearchRequest searchRequest) {
        List<Predicate> predicates = new ArrayList<>();

        if (searchRequest.rateTypes() != null && !searchRequest.rateTypes().isEmpty()) {
            predicates.add(root.get(AuthorizationSetting_.rateType).in(searchRequest.rateTypes()));
        }

        if (searchRequest.rateLayerTypes() != null && !searchRequest.rateLayerTypes().isEmpty()) {
            predicates.add(root.get(AuthorizationSetting_.rateLayerType).in(searchRequest.rateLayerTypes()));
        }

        if (searchRequest.serviceProviders() != null && !searchRequest.serviceProviders().isEmpty()) {
            predicates.add(root.get(AuthorizationSetting_.serviceProvider).in(searchRequest.serviceProviders()));
        }

        if (searchRequest.bankCodes() != null && !searchRequest.bankCodes().isEmpty()) {
            predicates.add(root.get(AuthorizationSetting_.bankCode).in(searchRequest.bankCodes()));
        }

        if (searchRequest.agentCodes() != null && !searchRequest.agentCodes().isEmpty()) {
            predicates.add(root.get(AuthorizationSetting_.agentCode).in(searchRequest.agentCodes()));
        }

        if (searchRequest.currencies() != null && !searchRequest.currencies().isEmpty()) {
            predicates.add(criteriaBuilder.or(root.get("currency").in(searchRequest.currencies())));
        }

        if (searchRequest.status() != null) {
            predicates.add(
                    criteriaBuilder.equal(root.get(AuthorizationSetting_.enabled.getName()), searchRequest.status()));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getAuthorizationSettingPredicatesByIdendity(Root<AuthorizationSetting> root,
            CriteriaBuilder criteriaBuilder, AuthorizationSettingIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(AuthorizationSetting_.rateType), identity.getRateType()));

        predicates
                .add(criteriaBuilder.equal(root.get(AuthorizationSetting_.rateLayerType), identity.getRateLayerType()));

        predicates.add(
                criteriaBuilder.equal(root.get(AuthorizationSetting_.serviceProvider), identity.getServiceProvider()));

        if (identity.getBankCode() != null && !identity.getBankCode().isEmpty()) {
            predicates.add(criteriaBuilder.equal(root.get(AuthorizationSetting_.bankCode), identity.getBankCode()));
        }
        else {
            predicates.add(criteriaBuilder.isNull(root.get(AuthorizationSetting_.bankCode)));
        }

        predicates.add(criteriaBuilder.equal(root.get(AuthorizationSetting_.agentCode), identity.getAgentCode()));

        predicates.add(criteriaBuilder.equal(root.get("currency"), identity.getCurrency()));

        predicates.add(criteriaBuilder.equal(root.get(AuthorizationSetting_.enabled.getName()), true));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getAuthorizationSettingPredicatesForLayer(Root<AuthorizationSetting> root,
            CriteriaBuilder criteriaBuilder, AuthorizationRateSettingRequest request) {
        List<Predicate> predicates = new ArrayList<>();

        if (request.rateTypes() != null) {
            predicates.add(root.get(AuthorizationSetting_.rateType).in(request.rateTypes()));
        }

        if (request.rateLayerTypes() != null) {
            predicates.add(root.get(AuthorizationSetting_.rateLayerType).in(request.rateLayerTypes()));
        }

        if (request.serviceProvider() != null && !request.serviceProvider().isEmpty()) {
            predicates.add(root.get(AuthorizationSetting_.serviceProvider).in(request.serviceProvider()));
        }

        if (request.bankCode() != null && !request.bankCode().isEmpty()) {
            predicates.add(root.get(AuthorizationSetting_.bankCode).in(request.bankCode()));
        }

        if (request.agentCode() != null && !request.agentCode().isEmpty()) {
            predicates.add(root.get(AuthorizationSetting_.agentCode).in(request.agentCode()));
        }

        if (request.currencies() != null) {
            predicates.add(criteriaBuilder.or(root.get("currency").in(request.currencies())));
        }

        predicates.add(criteriaBuilder.equal(root.get(AuthorizationSetting_.enabled.getName()), request.status()));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getAuthQueuePredictaes(CriteriaBuilder criteriaBuilder, Root<AuthorizationQueue> root,
            String refId, VDWType vdwType, ColumnNameType columnName, AuthorizationStatusType status) {
        final List<Predicate> predicates = new ArrayList<>();

        if (refId != null) {
            predicates.add(criteriaBuilder.equal(root.get(AuthorizationQueue_.refID), refId));
        }

        if (vdwType != null) {
            predicates.add(criteriaBuilder.equal(root.get(AuthorizationQueue_.vdwType.getName()), vdwType));
        }

        if (columnName != null) {
            predicates.add(criteriaBuilder.equal(root.get(AuthorizationQueue_.columnChanged.getName()), columnName));
        }

        if (status != null) {
            predicates.add(criteriaBuilder.equal(root.get(AuthorizationQueue_.status.getName()), status));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getSearchAuthorizationQueuePredicates(Root<AuthorizationQueue> root,
            CriteriaBuilder criteriaBuilder, AuthorizationQueueSearchRequest searchRequest) {
        List<Predicate> predicates = new ArrayList<>();

        if (searchRequest.rateTypes() != null && !searchRequest.rateTypes().isEmpty()) {
            predicates.add(root.get(AuthorizationQueue_.rateType).in(searchRequest.rateTypes()));
        }

        if (searchRequest.rateLayerTypes() != null && !searchRequest.rateLayerTypes().isEmpty()) {
            predicates.add(root.get(AuthorizationQueue_.rateLayerType).in(searchRequest.rateLayerTypes()));
        }

        if (searchRequest.serviceProviders() != null && !searchRequest.serviceProviders().isEmpty()) {
            predicates.add(root.get(AuthorizationQueue_.serviceProvider).in(searchRequest.serviceProviders()));
        }

        if (searchRequest.bankCodes() != null && !searchRequest.bankCodes().isEmpty()) {
            predicates.add(root.get(AuthorizationQueue_.bankCode).in(searchRequest.bankCodes()));
        }

        if (searchRequest.agentCodes() != null && !searchRequest.agentCodes().isEmpty()) {
            predicates.add(root.get(AuthorizationQueue_.agentCode).in(searchRequest.agentCodes()));
        }

        if (searchRequest.currencies() != null && !searchRequest.currencies().isEmpty()) {
            predicates.add(criteriaBuilder.or(root.get("currency").in(searchRequest.currencies())));
        }

        if (searchRequest.statusType() != null && !searchRequest.statusType().isEmpty()) {
            predicates.add(root.get(AuthorizationQueue_.status).in(searchRequest.statusType()));
        }

        predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get(AuthorizationQueue_.createdDate.getName()),
                LocalDate.now()));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

}
