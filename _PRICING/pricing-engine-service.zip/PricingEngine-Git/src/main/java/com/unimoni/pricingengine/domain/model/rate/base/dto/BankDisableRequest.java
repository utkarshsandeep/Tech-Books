package com.unimoni.pricingengine.domain.model.rate.base.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BankDisableRequest {
	
	String bankCode;
	String serviceProviderCode;
	
	
	public BankDisableRequest(String bankCode, String serviceProviderCode){
		this.bankCode = bankCode;
		this.serviceProviderCode = serviceProviderCode;
	}

}
