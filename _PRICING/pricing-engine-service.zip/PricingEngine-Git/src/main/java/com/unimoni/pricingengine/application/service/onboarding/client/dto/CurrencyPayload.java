package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.application.service.onboarding.model.AbstractPairItem;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CurrencyPayload extends AbstractPairItem {

    private boolean status;

    public CurrencyPayload(final @JsonProperty("code") String code, final @JsonProperty("currencyName") String name,
            final @JsonProperty("status") String status) {
        super(code, name != null ? name : code);
        this.status = status != null && status.equalsIgnoreCase("ENABLED");
    }

    @Override
    public String toString() {
        return "Currency {code: " + this.getCode() + ", name: " + this.getName() + "}";
    }

    public boolean isEnabled() {
        return this.status;
    }
}
