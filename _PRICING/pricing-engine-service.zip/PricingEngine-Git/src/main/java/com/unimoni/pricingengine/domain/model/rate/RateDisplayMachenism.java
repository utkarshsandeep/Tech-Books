package com.unimoni.pricingengine.domain.model.rate;

import com.fasterxml.jackson.annotation.JsonCreator;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "rateDisplayMachenism", description = "Rate Display Mechanisms")
public enum RateDisplayMachenism {
    
    // @formatter:off
    BC_TO_FC("Base currency to Foriegn currency"),
    FC_TO_BC("Foriegn currency to Base currency");
    // @formatter:on

    private final String description;

    private RateDisplayMachenism(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }

    @JsonCreator
    public static RateDisplayMachenism of(final String typeName) {
        return RateDisplayMachenism.valueOf(typeName);
    }
    
    public boolean isBCtoFC() {
        return this == BC_TO_FC;
    }

    public boolean isFCtoBC() {
        return this == FC_TO_BC;
    }
}
