package com.unimoni.pricingengine.application.event.listner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.money.CurrencyUnit;
import javax.money.Monetary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.unimoni.pricingengine.adapter.rest.controller.events.AgentOnBoard;
import com.unimoni.pricingengine.application.events.AgentOnboardEvent;
import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;
import com.unimoni.pricingengine.common.annotation.spring.OnboardingIntegration;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentCurrencyCode;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentCurrencyResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardCurrencies;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardResponse;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CreateSettlementRateRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementMetaData;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementRateRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.CreateVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRMetaData;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRRequest;
import com.unimoni.pricingengine.domain.service.settlement.SettlementRateService;
import com.unimoni.pricingengine.domain.service.var.VaRService;

import lombok.extern.slf4j.Slf4j;

@Conditional(value = OnboardingIntegration.class)
@Component
@Slf4j
public class AgentOnBoardListner {

    @Autowired
    private VaRService varService;

    @Autowired
    private SettlementRateService settlementService;

    @Autowired
    private AgentOnBoard agentOnBoard;

    @Autowired
    private Gson gson;

    @Autowired
    private MasterData masterData;

    @JmsListener(destination = "ALLOWED_PRODUCTS_SEND_RULE_CREATED", containerFactory = "topicListenerFactory")
    public void onApplicationEvent(final Message jsonMessage) {

        Integer agentId = null;
        Integer agentBranchId = null;
        Integer allowedProductsSendRuleId = null;

        log.info("*****ALLOWED_PRODUCTS_SEND_RULE_CREATED EVENT******" + jsonMessage);
        TextMessage textMessage = (TextMessage) jsonMessage;
        String payload;
        try {
            payload = textMessage.getText();
        }
        catch (JMSException e1) {
            e1.printStackTrace();
            return;
        }
        log.info("****EVENT_PAYLOAD****", payload);

        AgentOnboardEvent agentOnboardEvent;

        agentOnboardEvent = gson.fromJson(payload, AgentOnboardEvent.class);

        agentId = (int) (long) agentOnboardEvent.getAgentId();

        agentBranchId = (int) (long) agentOnboardEvent.getAgentBranchId();

        allowedProductsSendRuleId = (int) (long) agentOnboardEvent.getAllowedProductsSendRuleId();

        log.info("*****Onboard AgentId*****" + agentId);

        log.info("*****Onboard AgentBranchId*****" + agentBranchId);

        log.info("*****Onboard allowedProductsSendRuleId*****" + allowedProductsSendRuleId);
        AgentOnboardCurrencies agentOnboardData = agentOnBoard.getAgentProductSendRule(agentId, agentBranchId,
                allowedProductsSendRuleId);
        log.info("*****AgentOnboardData*****" + agentOnboardData);
        String serviveProvider = agentOnboardData.getServiceProviderCode();
        String product = agentOnboardData.getProductType();
        List<Integer> listagentBranchId = new ArrayList<Integer>();
        listagentBranchId.add(agentBranchId);

        // get Agent display code
        String agentDisplayCode = getAgentDisplayCode(agentId, agentBranchId);
        log.info("******Onboard agentDisplayCode*******" + agentDisplayCode);
        List<String> listOfBaseCurrencies = getListOfAgentBaseCurrencies(agentId, listagentBranchId);
        log.info("*****List of BaseCurrencies*****" + listOfBaseCurrencies);
        List<String> serviceProviderList = new ArrayList<String>();
        serviceProviderList.add(serviveProvider);
        List<String> listOfForeginCurrency = masterData.getNormalForeignCurrencyPairs(serviceProviderList, false)
                .stream().map(item -> item.getCode()).distinct().collect(Collectors.toList());
        log.info("******List of ForeginCurrency*******" + listOfForeginCurrency);

        // Adding base currencies into foreign currencies
        Set<String> foreginAndBaseCurrencySet = new HashSet<>();
        foreginAndBaseCurrencySet.addAll(listOfForeginCurrency);
        foreginAndBaseCurrencySet.addAll(listOfBaseCurrencies);

        List<String> foreginAndBaseCurrencyList = new ArrayList<>();
        foreginAndBaseCurrencyList.addAll(foreginAndBaseCurrencySet);

        log.info("******List of ForeginCurrency and BaseCurrency*******" + foreginAndBaseCurrencyList);

        if (agentId != null && serviveProvider != null && product != null && foreginAndBaseCurrencyList.size() > 0) {

            log.info("*****Method call for creatingRecordInNormalVAR *****");
            creatingRecordInNormalVAR(agentId, foreginAndBaseCurrencyList, agentDisplayCode, agentOnboardData);
            log.info("******Method call for createRecordForNormalSettlement ******");
            createRecordForNormalSettlement(agentId, foreginAndBaseCurrencyList, agentDisplayCode, agentOnboardData);

        }
    }

    private String getAgentDisplayCode(Integer agentId, Integer agentBranchId) {
        AgentOnboardResponse agentCurrencyResponse = agentOnBoard.agentOnBoard(agentId);
        log.info("********Onboarding agent display code response*******" + agentCurrencyResponse);
        log.info("********Onboarding agent display code*******" + agentCurrencyResponse.getCode());
        return agentCurrencyResponse.getCode();
    }

    private void createRecordForNormalSettlement(Integer agentId, List<String> listOfCurrencies,
            String agentDisplayCode, AgentOnboardCurrencies agentOnboardData) {

        log.info("********create Record For Normal Settlement*********");

        SettlementRateRequest settlementRequest = createNormalSettlementMetaRequest(agentId, listOfCurrencies,
                agentDisplayCode, agentOnboardData);

        log.info("*****Created Normal Settlement MetaRequest*******" + settlementRequest);

        SettlementMetaData settlementMetaData = settlementService.createSettlementRateMetaData(RMType.NORMAL,
                settlementRequest);

        log.info("******Created Settlement RateMetaData********" + settlementMetaData);

        List<CreateSettlementRateRequest> createRequests = null;

        if (settlementMetaData.getNewSettlementsCount() > 0) {
            createRequests = new ArrayList<CreateSettlementRateRequest>();

            for (int i = 0; i < settlementMetaData.getNewSettlementsCount(); i++) {
                CreateSettlementRateRequest settlementRequestObj = new CreateSettlementRateRequest();

                settlementRequestObj.setCurrency(settlementMetaData.getNewSettlements().get(i).getCurrency());
                settlementRequestObj.setInstruments(settlementMetaData.getNewSettlements().get(i).getInstruments());
                settlementRequestObj.setVarId(settlementMetaData.getNewSettlements().get(i).getVarId());
                settlementRequestObj
                        .setValueDateWises(settlementMetaData.getNewSettlements().get(i).getValueDateWises());
                settlementRequestObj.setAgent(settlementMetaData.getNewSettlements().get(i).getAgent());

                createRequests.add(settlementRequestObj);
            }
        }

        if (createRequests != null && createRequests.size() > 0) {

            log.info("*****Create Settlement Rates******");
            settlementService.createSettlementRates(RMType.NORMAL, createRequests);
        }
    }

    private SettlementRateRequest createNormalSettlementMetaRequest(Integer agentId, List<String> listOfCurrencies,
            String agentDisplayCode, AgentOnboardCurrencies agentOnboardData) {
        SettlementRateRequest settlementRateRequest = new SettlementRateRequest();

        List<String> serviceProviders = new ArrayList<String>();
        List<String> products = new ArrayList<String>();
        List<String> subProducts = new ArrayList<String>();
        List<String> serviceTypes = new ArrayList<String>();

        serviceProviders.add(agentOnboardData.serviceProviderCode);
        products.add(agentOnboardData.getProductType());
        subProducts.add(ApplicationConstants.ALL_INSTRUMENTS);
        // serviceTypes.add(agentOnboardData.getServiceType());
        // Getting all service types from master data and adding to serviceTypes
        List<String> subProductListForMasterData = new ArrayList<>();
        subProductListForMasterData.add(agentOnboardData.getSubProductType());
        serviceTypes.addAll(masterData.getAllServiceTypes(products, subProductListForMasterData).stream()
                .map(item -> item.getCode()).distinct().collect(Collectors.toList()));

        if (serviceTypes.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            serviceTypes.remove(ApplicationConstants.ALL_INSTRUMENTS);
        }

        List<CurrencyUnit> currencies = new ArrayList<CurrencyUnit>();
        for (int i = 0; i < listOfCurrencies.size(); i++) {
            CurrencyUnit currency = Monetary.getCurrency(listOfCurrencies.get(i));
            currencies.add(currency);
        }

        List<String> listOfAgents = new ArrayList<String>();
        listOfAgents.add(agentDisplayCode);

        settlementRateRequest.setProducts(products);
        settlementRateRequest.setSubProducts(subProducts);
        settlementRateRequest.setServiceProviders(serviceProviders);
        settlementRateRequest.setServiceTypes(serviceTypes);
        settlementRateRequest.setCurrencies(currencies);
        settlementRateRequest.setAgents(listOfAgents);

        return settlementRateRequest;
    }

    private void creatingRecordInNormalVAR(Integer agentId, List<String> listOfCurrencies, String agentDisplayCode,
            AgentOnboardCurrencies agentOnboardData) {

        log.info("****** Creating Record InNormalVAR Method ******");

        VaRRequest varRequest = createNormalVarMetaRequest(agentId, listOfCurrencies, agentDisplayCode,
                agentOnboardData);
        log.info("***** CreateNormalVarMetaRequest VaRRequest *****" + varRequest);

        VaRMetaData normalMetadata = varService.createVaRMetaData(RMType.NORMAL, varRequest);
        log.info("******* Var Meta Data Request ********* " + normalMetadata);

        List<CreateVaRRequest> createRequests = null;
        if (normalMetadata.getNewVarsCount() > 0) {
            createRequests = (List<CreateVaRRequest>) new ArrayList<CreateVaRRequest>();
            for (int i = 0; i < normalMetadata.getNewVarsCount(); i++) {
                CreateVaRRequest createNormalVaRRequest = new CreateVaRRequest();
                createNormalVaRRequest.setAgent(normalMetadata.getNewVars().get(i).getAgent());
                createNormalVaRRequest.setExchange(normalMetadata.getNewVars().get(i).getExchange());
                createNormalVaRRequest.setIbrId(normalMetadata.getNewVars().get(i).getIbrId());
                createNormalVaRRequest.setInstruments(normalMetadata.getNewVars().get(i).getInstruments());
                createNormalVaRRequest.setValueDateWises(normalMetadata.getNewVars().get(i).getValueDateWises());

                createRequests.add(createNormalVaRRequest);
            }
        }
        if (createRequests != null && createRequests.size() > 0) {

            log.info("******Method call for CreateVars*******");
            varService.createVaRs(RMType.NORMAL, createRequests);
        }
    }

    private VaRRequest createNormalVarMetaRequest(Integer agentId, List<String> listOfCurrencies,
            String agentDisplayCode, AgentOnboardCurrencies agentOnboardData) {
        VaRRequest varRequest = new VaRRequest();
        List<String> serviceProviders = new ArrayList<String>();
        List<String> products = new ArrayList<String>();
        List<String> subProducts = new ArrayList<String>();
        List<String> serviceTypes = new ArrayList<String>();

        serviceProviders.add(agentOnboardData.getServiceProviderCode());
        products.add(agentOnboardData.getProductType());
        subProducts.add(ApplicationConstants.ALL_INSTRUMENTS);
        // serviceTypes.add(agentOnboardData.getServiceType());
        // Getting all service types from master data and adding to serviceTypes
        List<String> subProductListForMasterData = new ArrayList<>();
        subProductListForMasterData.add(agentOnboardData.getSubProductType());
        serviceTypes.addAll(masterData.getAllServiceTypes(products, subProductListForMasterData).stream()
                .map(item -> item.getCode()).distinct().collect(Collectors.toList()));

        if (serviceTypes.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            serviceTypes.remove(ApplicationConstants.ALL_INSTRUMENTS);
        }
        List<CurrencyUnit> currencies = new ArrayList<CurrencyUnit>();
        for (int i = 0; i < listOfCurrencies.size(); i++) {
            CurrencyUnit currency = Monetary.getCurrency(listOfCurrencies.get(i));
            currencies.add(currency);
        }

        List<String> listOfAgents = new ArrayList<String>();
        listOfAgents.add(agentDisplayCode);

        varRequest.setServiceTypes(serviceTypes);
        varRequest.setAgents(listOfAgents);
        varRequest.setCurrencies(currencies);
        varRequest.setProducts(products);
        varRequest.setServiceProviders(serviceProviders);
        varRequest.setSubProducts(subProducts);
        return varRequest;
    }

    private List<String> getListOfAgentBaseCurrencies(Integer agentId, List<Integer> listOfBranchesForAgent) {
        List<String> listOfBaseCurrencies = new ArrayList<String>();

        List<ArrayList<AgentOnboardCurrencies>> listOfAgentBaseCurrencies = new ArrayList<ArrayList<AgentOnboardCurrencies>>();
        List<AgentCurrencyResponse> listOfAgentBaseCurrencyResponse = new ArrayList<AgentCurrencyResponse>();
        List<AgentCurrencyCode> listOfCurrencyCodes = new ArrayList<AgentCurrencyCode>();
        AgentCurrencyResponse agentCurrencyResponse = new AgentCurrencyResponse();

        for (Integer branchId : listOfBranchesForAgent) {
            agentCurrencyResponse = agentOnBoard.getAgentBaseCurrencies(agentId, branchId);
            listOfAgentBaseCurrencyResponse.add(agentCurrencyResponse);
        }

        for (int i = 0; i < listOfAgentBaseCurrencyResponse.size(); i++) {
            listOfAgentBaseCurrencies
                    .add((ArrayList<AgentOnboardCurrencies>) listOfAgentBaseCurrencyResponse.get(i).getData());
        }

        for (int i = 0; i < listOfAgentBaseCurrencies.size(); i++) {
            List<AgentOnboardCurrencies> listOfAgentCurrencies = listOfAgentBaseCurrencies.get(i);

            for (int j = 0; j < listOfAgentCurrencies.size(); j++) {
                ArrayList<AgentCurrencyCode> tempList = (ArrayList<AgentCurrencyCode>) listOfAgentCurrencies.get(j)
                        .getCurrencyCodes();
                listOfCurrencyCodes.addAll(tempList);
                tempList.clear();
            }
        }

        for (AgentCurrencyCode currencyCodes : listOfCurrencyCodes) {
            if (!listOfBaseCurrencies.contains(currencyCodes.getCode())
                    && "string".equals(currencyCodes.getCode()) != true) {
                listOfBaseCurrencies.add(currencyCodes.getCode());
            }
        }

        return listOfBaseCurrencies;
    }
}
