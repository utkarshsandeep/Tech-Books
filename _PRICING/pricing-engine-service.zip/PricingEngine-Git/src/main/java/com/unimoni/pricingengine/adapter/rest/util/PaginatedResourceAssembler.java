package com.unimoni.pricingengine.adapter.rest.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.common.dto.ViewModel;

@Component("pageAssembler")
public class PaginatedResourceAssembler<T extends ViewModel<I>, I> implements PageAssembler<T, I> {

    @Override
    public <A extends ResourceAssembler<T, I>> PaginatedResource<Resource<T>> assemble(final Iterable<T> content,
            final PaginationData page, final Map<String, Object> paramsMap) {

        Assert.notNull(content, "Content must not be null!");

        page.add(paginationLinks(page, paramsMap, uriComponentBuilder(paramsMap)));
        PaginatedResource<Resource<T>> paginatedResource = PaginatedResource.wrap(content, page);
        paginatedResource.add(selfLink(paramsMap));
        return paginatedResource;
    }

    @Override
    public <A extends ResourceAssembler<T, I>> PaginatedResource<Resource<T>> assemble(final Iterable<T> content,
            final PaginationData page, final Map<String, Object> paramsMap, final A resourceAssembler,
            final Object... assemblerParameters) {

        Assert.notNull(content, "Content must not be null!");

        page.add(paginationLinks(page, paramsMap, uriComponentBuilder(paramsMap)));
        PaginatedResource<Resource<T>> paginatedResource = PaginatedResource.wrap(content, page, resourceAssembler,
                assemblerParameters);
        paginatedResource.add(selfLink(paramsMap));
        return paginatedResource;
    }

    @Override
    public Link selfLink(final Map<String, Object> paramsMap) {
        return new Link(uriComponentBuilder(paramsMap).expand(paramsMap).encode().toUriString(), Link.REL_SELF);
    }

    @Override
    public List<Link> paginationLinks(final PaginationData page, final Map<String, Object> paramsMap,
            final UriComponents uriComponents) {

        List<Link> links = new ArrayList<>(4);
        if (page.hasNext()) {
            paramsMap.put("page", page.getCurrentPage() + 1);
            links.add(new Link(uriComponents.expand(paramsMap).encode().toUriString(), Link.REL_NEXT));

            paramsMap.put("page", page.getTotalPages() - 1);
            links.add(new Link(uriComponents.expand(paramsMap).encode().toUriString(), Link.REL_LAST));
        }
        if (page.hasPrevious()) {
            paramsMap.put("page", 0);
            links.add(new Link(uriComponents.expand(paramsMap).encode().toUriString(), Link.REL_FIRST));

            paramsMap.put("page", page.getCurrentPage() - 1);
            links.add(new Link(uriComponents.expand(paramsMap).encode().toUriString(), Link.REL_PREVIOUS));
        }
        paramsMap.put("page", page.getCurrentPage());

        return links;
    }

    private UriComponents uriComponentBuilder(final Map<String, Object> paramsMap) {
        String queryParameters = paramsMap.entrySet().stream().map((x) -> x.getKey() + "={" + x.getKey() + "}")
                .collect(Collectors.joining("&"));
        String uri = ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString() + "?" + queryParameters;
        return UriComponentsBuilder.fromUriString(uri).build();

    }
}
