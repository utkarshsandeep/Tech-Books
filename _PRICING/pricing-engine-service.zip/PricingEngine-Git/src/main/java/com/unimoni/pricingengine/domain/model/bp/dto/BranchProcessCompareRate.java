package com.unimoni.pricingengine.domain.model.bp.dto;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "branchProcessCompare", description = "Request")
public class BranchProcessCompareRate {
	
	    @ApiModelProperty(name = "dealId", value = "dealId", required = true)
	    @NotNull
		private String dealId;
	 
	    @ApiModelProperty(name = "ibr", value = "ibr", required = true)
	    @NotNull
		private BigDecimal ibr;
	    
	    @ApiModelProperty(name = "countryCost", value = "countryCost", required = true)
	    @NotNull
		private BigDecimal countryCost;
	    
	    @ApiModelProperty(name = "agentCost", value = "agentCost", required = true)
	    @NotNull
		private BigDecimal agentCost;
	    
	    @ApiModelProperty(name = "ibr", value = "ibr", required = true)
	    @NotNull
		private BigDecimal offerRate;

}
