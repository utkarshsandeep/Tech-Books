package com.unimoni.pricingengine.adapter.persistence.repository.var;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.rate.var.VaR;

public interface VaRRepository extends JpaRepository<VaR, String>, VaRRepositoryJPA {

}
