package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import javax.validation.constraints.NotNull;

import org.joda.beans.gen.PropertyDefinition;

import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverride;
import com.unimoni.pricingengine.common.util.download.jodaBeans.DownloadOverrides;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "agentMarginRateChange", description = "Agent Sell and Buy values for Margin, CustomerLowest, MaxDiscount")
public class AgentMarginRateChangeDTO {

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Customer Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Customer Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "margin", required = true, notes = "Margin Rate cost Buy and Sell values")
    private CostDTO margin;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Maximum Discounted Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Maximum Discounted Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "maxDiscount", required = true, notes = "Max Discount cost Buy and Sell values")
    private CostDTO maxDiscount;

    @PropertyDefinition
    @DownloadOverrides({
            @DownloadOverride(fieldName = "sellValue", download = @Download(columnName = "Lowest Transaction Rate Sell")),
            @DownloadOverride(fieldName = "buyValue", download = @Download(columnName = "Lowest Transaction Rate Buy")) })
    @NotNull
    @ApiModelProperty(value = "customerLowest", required = true, notes = "Customer Lowest cost Buy and Sell values")
    private CostDTO customerLowest;

    public static AgentMarginRateChangeDTO byMarginRateFormula(final CostDTO cost, CostDTO customerRate,
            CostDTO marginLow, CostDTO marginHigh, final RateDisplayMachenism RDM) {
        AgentMarginRateChangeDTO agentValueDateWise = new AgentMarginRateChangeDTO();

        if (RDM.isBCtoFC()) {
            // Sell Margin = Cost Sell Rate – Customer Rate Sell
            // Buy Margin = Customer Rate Buy – Cost Buy Rate
            CostDTO newMargin = CostDTO.of(cost.getSellValue().subtract(customerRate.getSellValue()),
                    customerRate.getBuyValue().subtract(cost.getBuyValue()));
            validatePositive(newMargin.getBuyValue(), "Margin Buy");
            validatePositive(newMargin.getSellValue(), "Margin Sell");
            agentValueDateWise.margin = newMargin;

            // Customer Maximum Discounted Sell Rate = Customer Sell Rate + Sell Margin Low
            // Customer Maximum Discounted Buy Rate = Customer Buy Rate - Buy Margin Low
            CostDTO newMaxDiscount = CostDTO.of(customerRate.getSellValue().add(marginLow.getSellValue()),
                    customerRate.getBuyValue().subtract(marginLow.getBuyValue()));
            validatePositive(newMaxDiscount.getBuyValue(), "Max Discount Buy");
            validatePositive(newMaxDiscount.getSellValue(), "Max Discount Sell");
            agentValueDateWise.maxDiscount = newMaxDiscount;

            // Customer Lowest Sell Rate = Customer Sell Rate – Sell Margin High
            // Customer Lowest Buy Rate = Customer Buy Rate + Buy Margin High
            CostDTO newCustomerLowest = CostDTO.of(customerRate.getSellValue().subtract(marginHigh.getSellValue()),
                    customerRate.getBuyValue().add(marginHigh.getBuyValue()));
            validatePositive(newCustomerLowest.getBuyValue(), "Customer Lowest Buy");
            validatePositive(newCustomerLowest.getSellValue(), "Customer Lowest Sell");
            agentValueDateWise.customerLowest = newCustomerLowest;
        }
        else {
            // Agent Sell Margin = Agent Customer Sell Rate - Agent Cost Sell Rate
            // Agent Buy Margin = Agent Cost Buy Rate - Agent Customer Buy Rate
            CostDTO newMargin = CostDTO.of(customerRate.getSellValue().subtract(cost.getSellValue()),
                    cost.getBuyValue().subtract(customerRate.getBuyValue()));
            validatePositive(newMargin.getBuyValue(), "Margin Buy");
            validatePositive(newMargin.getSellValue(), "Margin Sell");
            agentValueDateWise.margin = newMargin;

            // Customer Maximum Discounted Sell Rate = Customer Sell Rate – Sell Margin Low
            // Customer Maximum Discounted Buy Rate = Customer Buy Rate + Buy Margin Low
            CostDTO newMaxDiscount = CostDTO.of(customerRate.getSellValue().subtract(marginLow.getSellValue()),
                    customerRate.getBuyValue().add(marginLow.getBuyValue()));
            validatePositive(newMaxDiscount.getBuyValue(), "Max Discount Buy");
            validatePositive(newMaxDiscount.getSellValue(), "Max Discount Sell");
            agentValueDateWise.maxDiscount = newMaxDiscount;

            // Customer Lowest Sell Rate = Customer Sell Rate + Sell Margin High
            // Customer Lowest Buy Rate = Customer Buy Rate – Buy Margin High
            CostDTO newCustomerLowest = CostDTO.of(customerRate.getSellValue().add(marginHigh.getSellValue()),
                    customerRate.getBuyValue().subtract(marginHigh.getBuyValue()));
            validatePositive(newCustomerLowest.getBuyValue(), "Customer Lowest Buy");
            validatePositive(newCustomerLowest.getSellValue(), "Customer Lowest Sell");
            agentValueDateWise.customerLowest = newCustomerLowest;

        }
        return agentValueDateWise;
    }

}
