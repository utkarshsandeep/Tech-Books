package com.unimoni.pricingengine.domain.model.bp.dto;

import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.bp.BranchProcessSourceType;
import com.unimoni.pricingengine.domain.model.bp.StatusType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@ApiModel(value = "branchProcessStatusChangeRequest", description = "Update BP deal status Request")
@ToString
public class BranchProcessStatusChangeFromAmigoRequest {

    @NotNull
    @ApiModelProperty(name = "deal", allowEmptyValue = false, dataType = "String", required = true)
    private String deal;

    @NotNull
    @ApiModelProperty(name = "status", allowEmptyValue = false, dataType = "Enum", required = true)
    private StatusType status;
    
    @ApiModelProperty(name = "sourceType", value = "AMIGOG", required = true)
    @NotNull
    private BranchProcessSourceType sourceType;
}
