package com.unimoni.pricingengine.domain.model.rate.ibr;

import static com.unimoni.pricingengine.adapter.persistence.PersistenceConstant.TableMetaData.TABLE_BANK_WISE_IBRS;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.AuditMappedBy;
import org.hibernate.envers.Audited;

import com.unimoni.pricingengine.application.event.listner.EntityChangeListener;
import com.unimoni.pricingengine.application.service.amigo.event.IBRCreatedEvent;
import com.unimoni.pricingengine.application.service.event.EventPublisher;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.BankWiseRate;
import com.unimoni.pricingengine.domain.model.rate.base.BankWiseBaseRate;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.domain.model.remittance.IBRRate;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString
@Slf4j
@Entity
@EntityListeners(EntityChangeListener.class)
@DiscriminatorValue("BANK_WISE_IBR")
// @formatter:off
@SecondaryTable(name = TABLE_BANK_WISE_IBRS, 
    indexes = {
        @Index(name = "IDX_BANK_WISE_IBRS_BANK_CODE", columnList = "BANK_CODE"),
        @Index(name = "IDX_BANK_WISE_IBRS_AGENT_CODE", columnList = "AGENT_CODE"),
        @Index(name = "IDX_BANK_WISE_IBRS_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
        @Index(name = "IDX_BANK_WISE_IBRS_PRODUCT_CODE", columnList = "PRODUCT_CODE")
    }, 
    pkJoinColumns = @PrimaryKeyJoinColumn(name = "ID"), 
    foreignKey = @ForeignKey(name = "FK_BANK_WISE_IBRS_MANAGED_RATES_ID")
)
// @formatter:on
@Audited
public class BankWiseIBR extends AbstractLayer implements InterBankRate, BankWiseRate {

    @NotNull
    @Column(table = TABLE_BANK_WISE_IBRS, name = "BANK_CODE", updatable = false, nullable = false, length = 100)
    private String bank;

    @NotNull
    @Column(table = TABLE_BANK_WISE_IBRS, name = "AGENT_CODE", updatable = false, nullable = false, length = 100)
    private String agent;

    @NotNull
    @Embedded
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "serviceProvider", 
            column = @Column(table = TABLE_BANK_WISE_IBRS, name = "SERVICE_PROVIDER_CODE", 
                 updatable = false, nullable = false, length = 100)),
        @AttributeOverride(name = "product", 
            column = @Column(table = TABLE_BANK_WISE_IBRS, name = "PRODUCT_CODE", 
                 updatable = false, nullable = false, length = 100)) 
    })
    // @formatter:on
    private RateInstruments instruments;

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Column(table = TABLE_BANK_WISE_IBRS, name = "PRIORITY", nullable = false, updatable = false)
    private BankWiseIBRPriority priority;

    @OneToMany(mappedBy = "ibr", fetch = FetchType.LAZY)
    @AuditMappedBy(mappedBy = "ibr")
    private Set<VaR> vars = new HashSet<>();

    public boolean updateRate(final BigDecimal askValue, final BigDecimal bidValue) {
        return updateRate(ExchangeRate.of(askValue, bidValue));
    }

    public boolean updateRate(final ExchangeRate rate) {
        return updateRate(rate, DateTimeHelper.nowZonedDateTimeUTC());
    }

    public boolean updateRate(final ExchangeRate rate, final ZonedDateTime updatedOn) {
        if (exchange().updateRate(rate)) {
            this.updatedOn = updatedOn;
            propagateRateChangeToVaR();
            
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateStatus(final boolean status) {
        if (this.enabled == status) {
            return false;
        }
        else {
            this.enabled = status;
            if (status == false) { // Propagate only when record is being disabled.
                propagateStatusChangeToVaR();
            }
            return true;
        }
    }

    private void propagateRateChangeToVaR() {
        if (this.vars != null && !this.vars.isEmpty()) {
            this.vars.forEach(var -> {
                if (var.isEnabled()) {
                    var.updateFromIBR(this.exchange.rate(), this.updatedOn);
                }
                else {
                    log.debug("Linked VaR record is disabled, So can not propagate rate changes");
                }
            });
        }
    }

    private void propagateStatusChangeToVaR() {
        if (this.vars != null && !this.vars.isEmpty()) {
            this.vars.forEach(var -> var.updateStatus(this.enabled));
        }
    }

    public IBRRate layerCharge() {
        return IBRRate.of(this.exchange().rate());
    }

    public static BankWiseIBR of(BankWiseBaseRate bankWiseBaseRate) {
        BankWiseIBR bankWiseIBR = new BankWiseIBR();
        bankWiseIBR.bank = bankWiseBaseRate.bank();
        bankWiseIBR.agent = bankWiseBaseRate.agent();
        bankWiseIBR.exchange = bankWiseBaseRate.exchange();
        bankWiseIBR.instruments = bankWiseBaseRate.instruments();
        bankWiseIBR.priority = BankWiseIBRPriority.of(bankWiseIBR.instruments(), bankWiseBaseRate.bank(),
                bankWiseBaseRate.agent());
        bankWiseIBR.enabled = bankWiseBaseRate.isEnabled();
        bankWiseIBR.updatedOn = bankWiseBaseRate.updatedOn();
        EventPublisher.publishAmigoEvent(IBRCreatedEvent.of(bankWiseIBR));
        return bankWiseIBR;
    }
}
