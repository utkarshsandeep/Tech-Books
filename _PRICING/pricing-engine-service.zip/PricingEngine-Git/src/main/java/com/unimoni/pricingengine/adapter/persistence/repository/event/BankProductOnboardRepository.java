package com.unimoni.pricingengine.adapter.persistence.repository.event;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.rate.BankProductOnboard;

public interface BankProductOnboardRepository extends JpaRepository<BankProductOnboard, Long>  {
	
	public BankProductOnboard findByid(String id);
}
