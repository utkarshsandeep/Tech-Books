package com.unimoni.pricingengine.application.service.amigo.event;

import java.io.Serializable;
import java.time.ZonedDateTime;

import javax.money.CurrencyUnit;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.unimoni.pricingengine.application.security.SecurityConstants;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;

import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;

@Getter
@ToString
public class AmigoEvent implements Serializable {

    private static final long serialVersionUID = 1L;

    @NonNull
    private Type type;

    private String source = "NPAAS";

    @NonNull
    private String serviceProviderCode;

    @NonNull
    private String productCode;

    @NonNull
    private CurrencyUnit sourceCcy;

    @NonNull
    private CurrencyUnit targetCcy;

    private boolean status;

    @NonNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ApplicationConstants.AMIGO_DATE_TIME_FORMAT)
    private ZonedDateTime updatedOn;

    @NonNull
    private String updatedBy;

    protected AmigoEvent(final Type type, final String serviceProviderCode, final String productCode,
            final CurrencyUnit sourceCcy, final CurrencyUnit targetCcy, final boolean status,
            final ZonedDateTime updatedOn) {
        this.type = type;
        this.serviceProviderCode = serviceProviderCode;
        this.productCode = productCode;
        this.sourceCcy = sourceCcy;
        this.targetCcy = targetCcy;
        this.status = status;
        this.updatedOn = updatedOn;
        this.updatedBy = SecurityConstants.SYSTEM_USER;
    }

    public static enum Type {
        IBR_NORMAL, IBR_BANK_WISE, VAR_NORMAL, VAR_BANK_WISE, SETTLEMENT_RATE_NORMAL, SETTLEMENT_RATE_BANK_WISE;
    }
}
