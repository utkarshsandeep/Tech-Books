package com.unimoni.pricingengine.domain.model.bp.dto;

import java.time.LocalDate;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
@ToString
public class BPOfferRateRequest {

    private AllInstruments instruments;

    private AgentDetails agent;

    private String bank;

    private CurrencyUnit payInCurrency;

    private CurrencyUnit payOutCurrency;

    private LocalDate initiationDate;

    private LocalDate transmissionDate;

    private VDWType valueDateWise;
}
