package com.unimoni.pricingengine.application.audit;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionEntity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "REVINFO", indexes = { @Index(name = "IDX_RI_UPDATED_ON", columnList = "UPDATED_ON")})
@RevisionEntity(RevisionEntityListener.class)
public class RevisionInfo extends DefaultRevisionEntity {

    private static final long serialVersionUID = 1L;

    public static final String LAST_MODIFIED_DATE = "updatedOn";

    public static final String MODIFIED_BY = "updatedBy";

    @NotNull
    @Column(name = "UPDATED_BY", updatable = false, nullable = false)
    private String updatedBy;

    @NotNull
    @Column(name = "UPDATED_ON", updatable = false, nullable = false, columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    private ZonedDateTime updatedOn;
}