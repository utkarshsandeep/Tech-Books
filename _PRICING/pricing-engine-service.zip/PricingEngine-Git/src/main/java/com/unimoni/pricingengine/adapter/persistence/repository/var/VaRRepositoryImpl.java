package com.unimoni.pricingengine.adapter.persistence.repository.var;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.persistence.NonUniqueResultException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementBasicIdentity;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.domain.model.rate.var.VaR_;
import com.unimoni.pricingengine.domain.model.rate.var.dto.SearchVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRIdentity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class VaRRepositoryImpl extends AbstractJPA implements VaRRepositoryJPA {

    @Override
    public Optional<VaR> findEnabledVaRByIdentity(final RMType rmType, final VaRIdentity varIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<VaR> query = criteriaQuery(VaR.class);
        Root<VaR> var = query.from(VaR.class);
        query.where(VaRPredicates.getVaRdentityPredicates(var, criteriaBuilder, rmType, varIdentity),
                criteriaBuilder.equal(var.get(VaR_.enabled.getName()), true));
        query.select(var);
        return getSingleResultSafely(query);
    }

    @Override
    public Optional<VaR> findLatestDisabledVaRByIdentity(final RMType rmType, final VaRIdentity varIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<VaR> query = criteriaQuery(VaR.class);
        Root<VaR> var = query.from(VaR.class);
        query.where(VaRPredicates.getVaRdentityPredicates(var, criteriaBuilder, rmType, varIdentity),
                criteriaBuilder.equal(var.get(VaR_.enabled.getName()), false));
        query.select(var);
        query.orderBy(criteriaBuilder.desc(var.get(VaR_.updatedOn.getName())));
        TypedQuery<VaR> typedQuery = typedQuery(query);
        typedQuery.setMaxResults(1);
        return getSingleResultSafely(typedQuery);
    }

    @Override
    public List<VaR> findAllVaRs(final SearchVaRRequest request) {
        long totalRecords = findVaRsCount(request);
        request.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            CriteriaQuery<VaR> query = criteriaQuery(VaR.class);
            Root<VaR> rate = query.from(VaR.class);

            query.where(VaRPredicates.getSearchVaRsPredicates(rate, criteriaBuilder, request));

            query.select(rate);
            query.distinct(true);
            query.orderBy(criteriaBuilder.asc(rate.get(VaR_.exchange.getName()).get("currency").get("source")));

            TypedQuery<VaR> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(request.page().queryFirstResult());
            typedQuery.setMaxResults(request.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findVaRsCount(final SearchVaRRequest request) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<VaR> rate = query.from(VaR.class);

        query.where(VaRPredicates.getSearchVaRsPredicates(rate, criteriaBuilder, request));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<VaR> findVaRsByIds(RMType rmType, List<String> ids, boolean eagerFetchSettlement) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<VaR> query = criteriaQuery(VaR.class);
        Root<VaR> var = query.from(VaR.class);
        query.where(criteriaBuilder.and(criteriaBuilder.equal(var.get(VaR_.rmType.getName()), rmType),
                var.get(VaR_.id.getName()).in(ids)));
        query.select(var);
        TypedQuery<VaR> typedQuery = typedQuery(query);
        // if (eagerFetchSettlement) {
        // typedQuery.setHint("javax.persistence.fetchgraph",
        // entityManager.getEntityGraph("bankWiseBaseRate"));
        // }
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public Optional<VaR> findHighestVaRsBySettlementBasicIdentity(RMType rmType,
            SettlementBasicIdentity settlementBasicIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<VaR> query = criteriaQuery(VaR.class);
        Root<VaR> rate = query.from(VaR.class);
        query.select(rate);
        Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
        Root<VaR> maxPriority = maxPriorityQuery.from(VaR.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(VaR_.priority.getName())));
        maxPriorityQuery.where(
                VaRPredicates.getBasicPredicatesForHighestPriorityFetch(maxPriority, criteriaBuilder, rmType,
                        settlementBasicIdentity.getServiceProvider(), settlementBasicIdentity.getProduct(),
                        settlementBasicIdentity.getSubProduct(), settlementBasicIdentity.getServiceType(),
                        settlementBasicIdentity.getAgent(), settlementBasicIdentity.getBank()),
                VaRPredicates.getCurrencyPredicateForHighestPriorityFetch(maxPriority, criteriaBuilder,
                        settlementBasicIdentity.getCurrency()));

        query.where(
                VaRPredicates.getBasicPredicatesForHighestPriorityFetch(rate, criteriaBuilder, rmType,
                        settlementBasicIdentity.getServiceProvider(), settlementBasicIdentity.getProduct(),
                        settlementBasicIdentity.getSubProduct(), settlementBasicIdentity.getServiceType(),
                        settlementBasicIdentity.getAgent(), settlementBasicIdentity.getBank()),
                VaRPredicates.getCurrencyPredicateForHighestPriorityFetch(rate, criteriaBuilder,
                        settlementBasicIdentity.getCurrency()),
                criteriaBuilder.equal(rate.get(VaR_.priority.getName()), maxPriorityQuery));

        try {
            return getSingleResultSafely(query);
        }
        catch (final NonUniqueResultException unre) {
            log.error("Duplicate highest priority VaR record for rmType: {} and SettlementIdentity: {}", rmType,
                    settlementBasicIdentity);
            throw unre;
        }
    }

    @Override
    public Optional<VaR> findHighestVaRsBySettlementIdentity(final RMType rmType,
            final SettlementIdentity settlementIdentity) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<VaR> query = criteriaQuery(VaR.class);
        Root<VaR> rate = query.from(VaR.class);
        query.select(rate);
        Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
        Root<VaR> maxPriority = maxPriorityQuery.from(VaR.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(VaR_.priority.getName())));
        maxPriorityQuery.where(VaRPredicates.getBasicPredicatesForHighestPriorityFetch(maxPriority, criteriaBuilder,
                rmType, settlementIdentity.getInstruments().getServiceProvider(),
                settlementIdentity.getInstruments().getProduct(), settlementIdentity.getInstruments().getSubProduct(),
                settlementIdentity.getInstruments().getServiceType(), settlementIdentity.getAgent(),
                settlementIdentity.getBank()),
                VaRPredicates.getCurrencyPairPredicateForHighestPriorityFetch(maxPriority, criteriaBuilder,
                        settlementIdentity.getCurrency().toModel()));

        query.where(VaRPredicates.getBasicPredicatesForHighestPriorityFetch(rate, criteriaBuilder, rmType,
                settlementIdentity.getInstruments().getServiceProvider(),
                settlementIdentity.getInstruments().getProduct(), settlementIdentity.getInstruments().getSubProduct(),
                settlementIdentity.getInstruments().getServiceType(), settlementIdentity.getAgent(),
                settlementIdentity.getBank()),
                VaRPredicates.getCurrencyPairPredicateForHighestPriorityFetch(rate, criteriaBuilder,
                        settlementIdentity.getCurrency().toModel()),
                criteriaBuilder.equal(rate.get(VaR_.priority.getName()), maxPriorityQuery));

        try {
            return getSingleResultSafely(query);
        }
        catch (final NonUniqueResultException unre) {
            log.error("Duplicate highest priority VaR record for rmType: {} and SettlementIdentity: {}", rmType,
                    settlementIdentity);
            throw unre;
        }
    }

    @Override
    public VaR getVaRReference(final String varId) {
        return getReference(VaR.class, varId);
    }
}
