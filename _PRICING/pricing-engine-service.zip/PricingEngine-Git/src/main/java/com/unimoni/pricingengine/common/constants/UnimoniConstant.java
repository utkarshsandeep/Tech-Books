package com.unimoni.pricingengine.common.constants;

public interface UnimoniConstant {
    public static final String UNIMONI_JOB_GROUPID = "UNIMONI_PRICING_GROUPID";

    public static final Long DEFAULT_SCHEDULER_TIME = 1000L;

    public static final String FROM_CURRENCY_KEY = "FROM_CURRENCY";

    public static final String TO_CURRENCY_KEY = "TO_CURRENCY";

    public static final String SERVICE_PROVIDER_KEY = "SERVICE_PROVIDER_ID";

    public static final String PRODUCT_KEY = "PRODUCT_ID";

    public static final String RIC_KEY = "RICID";

    public static final String THOMSON_URL = "http://192.168.91.243:8080/rates";

}
