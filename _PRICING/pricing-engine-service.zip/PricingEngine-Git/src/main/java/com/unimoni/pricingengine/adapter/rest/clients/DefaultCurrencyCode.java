package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DefaultCurrencyCode {

    private long id;

    private String code;

    public DefaultCurrencyCode(@JsonProperty("id") long id, @JsonProperty("code") String code) {
        super();
        this.id = id;
        this.code = code;
    }

}
