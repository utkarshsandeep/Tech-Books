package com.unimoni.pricingengine.domain.model.rate.var;

import java.math.BigDecimal;
import java.util.Optional;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import com.unimoni.pricingengine.domain.model.rate.composable.Exchange;
import com.unimoni.pricingengine.domain.model.rate.composable.Margin;
import com.unimoni.pricingengine.domain.model.rate.composable.Settlement;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode
@ToString(includeFieldNames = true)
@Embeddable
@Access(AccessType.FIELD)
@Audited
public class VaRValueDateWise {

    @NotNull
    @Embedded
    @Setter
    private Margin margin;

    @NotNull
    @Embedded
    @Setter
    private Settlement settlement;

    public static VaRValueDateWise of(final BigDecimal marginAsk, final BigDecimal marginBid,
            final BigDecimal settlementSell, final BigDecimal settlementBuy) {
        return VaRValueDateWise.of(Margin.of(marginAsk, marginBid), Settlement.of(settlementSell, settlementBuy));
    }

    public static VaRValueDateWise byDefault(final Exchange ibrExchange) {
        return VaRValueDateWise.of(Margin.ZERO, Settlement.byFormula(ibrExchange, Margin.ZERO));
    }

    public boolean updateFromIBR(final Exchange exchange) {
        Settlement newSettlement = Settlement.byFormula(exchange, this.margin);
        if (this.settlement.equals(newSettlement)) {
            return false;
        }
        else {
            this.settlement = newSettlement;
            return true;
        }
    }
    
    public boolean updateSettlement(final Settlement newSettlement) {
        if (this.settlement.equals(newSettlement)) {
            return false;
        }
        else {
            this.settlement = newSettlement;
            return true;
        }
    }

    public boolean updateSettlement(final Optional<BigDecimal> settlementSell,
            final Optional<BigDecimal> settlementBuy) {
        Settlement newSettlement = null;
        if (settlementSell.isPresent() && settlementBuy.isPresent()) {
            newSettlement = Settlement.of(settlementSell.get(), settlementBuy.get());
        }
        else if (settlementSell.isPresent()) {
            newSettlement = Settlement.of(settlementSell.get(), this.settlement.buyValue());
        }
        else if (settlementBuy.isPresent()) {
            newSettlement = Settlement.of(this.settlement.sellValue(), settlementBuy.get());
        }
        else {
            return false;
        }

        if (this.settlement.equals(newSettlement)) {
            return false;
        }
        else {
            this.settlement = newSettlement;
            return true;
        }
    }

    public boolean updateMargin(final Optional<BigDecimal> marginAsk, final Optional<BigDecimal> marginBid) {
        Margin newMargin = null;
        if (marginAsk.isPresent() && marginBid.isPresent()) {
            newMargin = Margin.of(marginAsk.get(), marginBid.get());
        }
        else if (marginAsk.isPresent()) {
            newMargin = Margin.of(marginAsk.get(), this.margin.bidValue());
        }
        else if (marginBid.isPresent()) {
            newMargin = Margin.of(this.margin.askValue(), marginBid.get());
        }
        else {
            return false;
        }

        if (this.margin.equals(newMargin)) {
            return false;
        }
        else {
            this.margin = newMargin;
            return true;
        }
    }
}
