package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Country {

    private String code;

    private String name;

    public Country(@JsonProperty("countryCode") String code, @JsonProperty("name") String name) {
        this.code = code;
        this.name = name;
    }

    public CodeLabelPair<String, String> countryItem() {
        return CodeLabelPair.of(this.name, this.code + "(" + this.name + ")");
    }

    @Override
    public String toString() {
        return "Country [code=" + code + ", name=" + name + "]";
    }
}