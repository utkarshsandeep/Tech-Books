package com.unimoni.pricingengine.common.enums;

public interface Describable {
    
    public String value();

    public String description();
}
