package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.application.service.onboarding.model.Product;
import com.unimoni.pricingengine.application.service.onboarding.model.SubProduct;

import lombok.ToString;

@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductPayload {

    private String code;

    private List<SubProductPayload> subProducts;

    public ProductPayload(@JsonProperty("product") String product,
            @JsonProperty("subProducts") List<SubProductPayload> subProducts) {
        this.code = product;
        this.subProducts = subProducts;
    }

    public List<SubProduct> subProducts() {
        return this.subProducts != null & !this.subProducts.isEmpty()
                ? this.subProducts.stream().distinct().sorted(Comparator.comparing(SubProductPayload::getName))
                        .map(SubProductPayload::subProduct).collect(Collectors.toList())
                : Collections.emptyList();
    }

    public Product product() {
        return Product.of(this.code, this.subProducts());
    }

    public String getName() {
        return this.code;
    }
}
