package com.unimoni.pricingengine.common.util;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public class MessageKey {

    private String messageCode;
    
    private String defaultMessage;
}
