package com.unimoni.pricingengine.application.service.amigo.event;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class SettlementRateCreatedEvent extends VDWRateAmigoEvent {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;

    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashSettlementSellMargin;

    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashSettlementBuyMargin;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashSettlementSellCost;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashSettlementBuyCost;

    private SettlementRateCreatedEvent(final SettlementRate settlementRate) {
        super(settlementRate.rmType().isNormal() ? Type.SETTLEMENT_RATE_NORMAL : Type.SETTLEMENT_RATE_BANK_WISE,
                settlementRate.agent(), settlementRate.rmType().isBankWise() ? settlementRate.bank().get() : null,
                settlementRate.instruments().serviceProvider(), settlementRate.instruments().product(),
                settlementRate.instruments().subProduct(), settlementRate.instruments().serviceType(),
                settlementRate.currency().source(), settlementRate.currency().target(), settlementRate.isEnabled(),
                settlementRate.updatedOn());
        this.cashSettlementSellMargin = settlementRate.cash().get().margin().sellValue();
        this.cashSettlementBuyMargin = settlementRate.cash().get().margin().buyValue();
        if (settlementRate.rmType().isBankWise()) {
            this.cashSettlementSellCost = settlementRate.cash().get().settlement().sellValue();
            this.cashSettlementBuyCost = settlementRate.cash().get().settlement().buyValue();
        }
    }

    public static SettlementRateCreatedEvent of(final SettlementRate settlementRate) {
        return new SettlementRateCreatedEvent(settlementRate);
    }
}
