package com.unimoni.pricingengine.domain.model.enquiry.settlement;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import javax.money.CurrencyUnit;

import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.enquiry.StreamResponse;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.ToString;

@Getter
@ApiModel(value = "settlementRateEnquiryResponse", description = "Settlement Rate enquiry response")
@ToString(callSuper = true)
public class SettlementRateEnquiryResponse extends StreamResponse {

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Service Provider such as UAE, UK etc.", required = true, example = "UAEEXNZ#####", position = 1)
    private String serviceProvider;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Product such as Remittance, Forex etc.", required = true, example = "Remittance", position = 2)
    private String product;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(name = "subProduct", dataType = "String", value = "Sub product such as Account Credit, Cash payout etc.", required = true, example = "Account Credit", position = 3)
    private String subProduct;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(name = "serviceType", dataType = "String", value = "Service type such as Flash, Normal etc.", required = true, example = "Flash", position = 4)
    private String serviceType;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Bank Code", required = true, example = "HDFCIN", position = 5)
    private String bank;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Agent Code", required = true, example = "TRVLX#######", position = 6)
    private String agent;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Currency Code in ISO format e.g. INR", required = true, example = "INR", position = 7)
    private CurrencyUnit currency;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Settlement rate", required = true, position = 9)
    private Map<VDWType, CostDTO> rate;

    private SettlementRateEnquiryResponse(final int identityIndex, final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final String bank, final String agent,
            final CurrencyUnit currency, final Map<VDWType, CostDTO> rate) {
        super(identityIndex);
        this.serviceProvider = serviceProvider;
        this.product = product;
        this.subProduct = subProduct;
        this.serviceType = serviceType;
        this.bank = bank;
        this.agent = agent;
        this.currency = currency;
        this.rate = rate;
    }

    public static Optional<SettlementRateEnquiryResponse> of(final int identityIndex,
            final List<SettlementRateEnquiryProjection> dbResults) {
        if (dbResults.isEmpty()) {
            return Optional.empty();
        }
        else {
            return Optional.of(new SettlementRateEnquiryResponse(identityIndex, dbResults.get(0).serviceProvider(),
                    dbResults.get(0).product(), dbResults.get(0).subProduct(), dbResults.get(0).serviceType(),
                    dbResults.get(0).bank(), dbResults.get(0).agent(), dbResults.get(0).currency(),
                    dbResults.stream()
                            .collect(Collectors.toMap(SettlementRateEnquiryProjection::valueDateWise,
                                    SettlementRateEnquiryProjection::rate, (e1, e2) -> e1,
                                    () -> new LinkedHashMap<VDWType, CostDTO>(dbResults.size())))));
        }
    }

    private SettlementRateEnquiryResponse(final int batchSize, final int recordCount, final int endIndex,
            final int lastIndex, final Supplier<String> linkSupplier) {
        super(batchSize, recordCount, endIndex, lastIndex, linkSupplier);
    }

    public static SettlementRateEnquiryResponse end(final RMType rmType,
            final SettlementRateEnquiryRequest enquiryRequest, final int recordCount, final int lastIndex,
            final String URI) {
        return new SettlementRateEnquiryResponse(enquiryRequest.batchSize(), recordCount, enquiryRequest.endIndex(),
                lastIndex, () -> moreLink(rmType, enquiryRequest, lastIndex, URI));
    }

    private static String moreLink(final RMType rmType, final SettlementRateEnquiryRequest enquiryRequest,
            final int lastIndex, final String URI) {
        final Map<String, Object> paramsMap = new LinkedHashMap<>(10);
        paramsMap.put("serviceProviders", enquiryRequest.serviceProviders().toArray());
        paramsMap.put("products", enquiryRequest.products().toArray());
        paramsMap.put("subProducts", enquiryRequest.subProducts().toArray());
        paramsMap.put("serviceTypes", enquiryRequest.serviceTypes().toArray());
        if (rmType.isBankWise()) {
            paramsMap.put("banks", enquiryRequest.banks().toArray());
        }
        paramsMap.put("agents", enquiryRequest.agents().toArray());
        paramsMap.put("currencies", enquiryRequest.currencies().stream().map(CurrencyUnit::getCurrencyCode).toArray());
        paramsMap.put("valueDateWises", enquiryRequest.valueDateWises().toArray());
        paramsMap.put("startingIndex", lastIndex);
        paramsMap.put("batchSize", enquiryRequest.batchSize());

        String queryParameters = paramsMap.entrySet().stream().map((x) -> x.getKey() + "={" + x.getKey() + "}")
                .collect(Collectors.joining("&"));
        String uri = URI + "?" + queryParameters;
        return UriComponentsBuilder.fromUriString(uri).build().expand(paramsMap).encode().toUriString();
    }
}
