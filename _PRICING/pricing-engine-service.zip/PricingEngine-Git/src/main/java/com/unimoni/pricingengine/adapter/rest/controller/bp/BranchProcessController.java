package com.unimoni.pricingengine.adapter.rest.controller.bp;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.BRANCH_PROCESS_DEAL_CREATED;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.BRANCH_PROCESS_DEAL_UPDATED;
import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS_COMPARE_RATES;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS_CREATE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS_DOWNLOAD_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS_RATES;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS_STATUS_UPDATE_FROM_AMIGO_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS_STATUS_UPDATE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS_UPDATE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.BranchProcess.BRANCH_PROCESS_URI;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.hateoas.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unimoni.pricingengine.adapter.rest.util.PaginatedResource;
import com.unimoni.pricingengine.adapter.rest.util.PaginatedResourceAssembler;
import com.unimoni.pricingengine.common.annotation.Paginated;
import com.unimoni.pricingengine.common.constants.ApplicationDefaults;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.DownloadFileType;
import com.unimoni.pricingengine.common.util.download.FileDownloadHelper;
import com.unimoni.pricingengine.domain.model.bp.dto.BPOfferRateResponse;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessCompareRate;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessCreateRequest;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessCreateResponse;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessDealResponse;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessSearchResponse;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessStatusChangeFromAmigoRequest;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessStatusChangeRequest;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessUpdateRequest;
import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessUpdateResponse;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BranchProcessDownloadRequest;
import com.unimoni.pricingengine.domain.service.bp.BranchProcessService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "BRANCH_PROCESS", description = "Branch Process APIs", tags = "Branch Process")
@RestController
@RequestMapping(PRICING_API)
public class BranchProcessController {

    @Autowired
    BranchProcessService branchProcessService;

    @Autowired
    private PaginatedResourceAssembler<BranchProcessSearchResponse, String> pageAssembler;

    @GetMapping(BRANCH_PROCESS)
    @Paginated
    public ResponseEntity<PaginatedResource<Resource<BranchProcessSearchResponse>>> getBranchProcess(@ApiIgnore
    @PageableDefault(page = 0, size = ApplicationDefaults.DEFAULT_PAGE_SIZE, sort = {
            "DEAL_ID" }, direction = Sort.Direction.ASC)
    final Pageable pageable, @ApiIgnore
    final PaginationData page, @ApiIgnore @RequestParam Map<String, Object> requestParams) {

        List<BranchProcessSearchResponse> results = branchProcessService
                .getAllRecords(BranchProcessDownloadRequest.of(page));
        if (results.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            return ResponseEntity.ok(pageAssembler.assemble(results, page, requestParams));
        }
    }

    @PostMapping(BRANCH_PROCESS_CREATE_URI)
    @ApiOperation(nickname = "createDeal", value = "Creates deal record", notes = "", response = BranchProcessCreateResponse.class)
    public ResponseEntity<BranchProcessCreateResponse> createBranchProcessRequest(@RequestBody
    @Valid
    @NotEmpty
    final BranchProcessCreateRequest branchProcessRequest) {

        BranchProcessCreateResponse deal = branchProcessService.createBranchProcessRecord(branchProcessRequest);

        return ResponseEntity.ok().headers(addSuccess(getMessage(BRANCH_PROCESS_DEAL_CREATED, 1))).body(deal);
    }

    @GetMapping(BRANCH_PROCESS_URI)
    @ApiOperation(nickname = "get-deal-data", value = "Gets deal data and returns current status and offered rate ", response = BranchProcessDealResponse.class)
    public ResponseEntity<BranchProcessDealResponse> getDealDetail(
            @ApiParam(allowMultiple = false, type = "String", value = "Deal id for any deal", required = true)
            @RequestParam(value = "dealId", required = true)
            @NotEmpty
            final @NotEmpty String deal) {

        return ResponseEntity.ok(branchProcessService.getDealDetail(deal));
    }

    /*
     * API would be consumed by Amigo system
     */
    @PatchMapping(BRANCH_PROCESS_UPDATE_URI)
    @ApiOperation(nickname = "Update deal record", value = "Update deal record", notes = "API consumed by Amigo system to update the status and amount consumed")
    public ResponseEntity<BranchProcessUpdateResponse> updateBranchProcessDeal(@RequestBody
    @Valid
    final BranchProcessUpdateRequest branchProcessUpdateRequest) {
        BranchProcessUpdateResponse deal = branchProcessService.updateBranchProcessRecord(branchProcessUpdateRequest);

        return ResponseEntity.ok().headers(addSuccess(getMessage(BRANCH_PROCESS_DEAL_UPDATED, 1))).body(deal);
    }

    @GetMapping(BRANCH_PROCESS_RATES)
    public BPOfferRateResponse getRates(@RequestParam String dealId) {
        return branchProcessService.getOfferRateForBranchProcess(dealId);
    }

    @PostMapping(BRANCH_PROCESS_COMPARE_RATES)
    @ApiOperation(nickname = "Update deal offered rate", value = "Update deal offered rate", notes = "API consumed by PAAS UI to update the offered rate or status")
    public ResponseEntity<BranchProcessCreateResponse> compareRateSetStatus(@RequestBody
    @Valid
    final BranchProcessCompareRate rates) {
        BranchProcessCreateResponse resp = branchProcessService.updateStatusCompareRate(rates);

        return ResponseEntity.ok().headers(addSuccess(getMessage(BRANCH_PROCESS_DEAL_UPDATED, 1))).body(resp);
    }

    @GetMapping(BRANCH_PROCESS_DOWNLOAD_URI)
    // @formatter:off
	@ApiOperation(nickname = "download-branch-process-data", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Download branch process data", response = Void.class, notes = "")
	@Valid
	public void downloadBranchProcessRates(

			@ApiParam(type = "fileName", value = "Download File name, if not provided default will be taken") @RequestParam(value = "fileName", required = false) final String fileName,
			@ApiParam(type = "downloadFileType", value = "Download File type as CSV or EXCEL", allowableValues = "CSV,EXCEL", required = true) @RequestParam(value = "downloadFileType", required = true) @NotNull final DownloadFileType downloadFileType,
			@ApiIgnore final HttpServletResponse response) {
		// @formatter:on
        FileDownloadHelper.downloadFile(BranchProcessDownloadRequest.of(PaginationData.of(0, 100000)),
                branchProcessService::getAllRecords, downloadFileType, fileName,
                DownloadContext.BRANCH_PROCESS_DOWNLOAD, response);
    }

    @PatchMapping(BRANCH_PROCESS_STATUS_UPDATE_URI)
    @ApiOperation(nickname = "Update deal record status", value = "Update deal record status-Call from PAAS UI", notes = "API consumed by PAAS UI to change the status in database", response = Void.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "bpId", dataType = "String", paramType = "path", value = "Branch Process Id", required = true) })
    public ResponseEntity<Void> updateBranchProcessDealStatus(@PathVariable String bpId, @RequestBody
    @Valid
    final BranchProcessStatusChangeRequest request) {

        String dealId = branchProcessService.updateBranchProcessStatus(bpId, request);

        return ResponseEntity.status(HttpStatus.OK)
                .headers(addSuccess(getMessage(BRANCH_PROCESS_DEAL_UPDATED, dealId))).build();
    }

    @PatchMapping(BRANCH_PROCESS_STATUS_UPDATE_FROM_AMIGO_URI)
    @ApiOperation(nickname = "Update deal record status", value = "Update deal record status-Request from Amigo", notes = "API consumed by Amigo or Qatar", response = Void.class)
    public ResponseEntity<Void> updateBranchProcessDealFromAmigoStatus(@RequestBody
    @Valid
    final BranchProcessStatusChangeFromAmigoRequest request) {

        String dealId = branchProcessService.updateStatusFromAmigo(request);

        return ResponseEntity.status(HttpStatus.OK)
                .headers(addSuccess(getMessage(BRANCH_PROCESS_DEAL_UPDATED, dealId))).build();
    }
}
