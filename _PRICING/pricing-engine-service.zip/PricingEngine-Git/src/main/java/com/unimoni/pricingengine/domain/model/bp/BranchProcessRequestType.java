package com.unimoni.pricingengine.domain.model.bp;

public enum BranchProcessRequestType {
    SINGLE,
    MULTIPLE;
}
