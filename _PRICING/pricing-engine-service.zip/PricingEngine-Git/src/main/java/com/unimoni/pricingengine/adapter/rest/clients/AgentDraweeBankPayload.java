package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgentDraweeBankPayload {

    private List<String> draweeBankProductProfileIds;

    private List<String> serviceProviderCodes;

}
