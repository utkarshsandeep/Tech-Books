package com.unimoni.pricingengine.application.service.onboarding.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.unimoni.pricingengine.application.service.onboarding.client.dto.BranchRateSettingPayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.ChargeRulePayload;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.NormalDataPayloadWrapper;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.NormalDataRequest;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.PayloadWrapper;
import com.unimoni.pricingengine.application.service.onboarding.client.dto.RateSkipSettingPayload;

@FeignClient(name = "agent-onboarding-client", url = "${onboarding.base-url.agent-onboarding}")
public interface AgentOnboardingClient {

    @PostMapping("${onboarding.api-path.get-all-normal-data}")
    NormalDataPayloadWrapper getAllNormalData(final NormalDataRequest normalDataRequest);

    @GetMapping("${onboarding.api-path.get-agent-branch-rate-setting}")
    BranchRateSettingPayload getAgentBranchRateSetting(final @PathVariable("agentId") long agentId,
            final @PathVariable("agentBranchId") long agentBranchId);

    @GetMapping("${onboarding.api-path.get-agent-branch-charge-rules}")
    PayloadWrapper<ChargeRulePayload> getAgentBranchChargeRules(final @PathVariable("agentId") long agentId,
            final @PathVariable("agentBranchId") long agentBranchId);

    @GetMapping("${onboarding.api-path.get-agent-rate-skip-setting}")
    RateSkipSettingPayload getRateSkipSettingPayload(final @PathVariable("agentId") long agentId);
}
