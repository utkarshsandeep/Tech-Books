package com.unimoni.pricingengine.common.exception;

import org.zalando.problem.Status;

import com.unimoni.pricingengine.common.enums.ErrorCodeType;

public class RemittanceTransactionException extends PricingEngineException {

    private static final long serialVersionUID = 1L;

    private ErrorCodeType exceptionType;

    public enum RemittanceTransactionExceptionType implements ErrorCodeType {

        //@formatter:off
        ILLEGAL_AMOUNT_WITH_TYPE_REQUEST_PARAMETER("illegal.amount.with.type.request.parameter", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        INVALID_TRANSACTION_UUID("invalid.transaction.uuid", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        TRANSMISSION_DATE_LESS_THAN_INITIATION_DATE("transmission.date.less.than.initiation.date", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        RATE_NOT_FOUND_FOR_CURRENCY("rate.not.found.for.currency", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        DUPLICATE_RATES_FOUND_FOR_CURRENCY("duplicate.rates.found.for.currency", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        INVALID_AGENT_BRANCH_ID("invalid.agent.branch.id", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        AGENT_BRANCH_RATE_SETTINGS_NOT_SET("agent.branch.rate.settings.not.set", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        AGENT_RATE_SKIP_SETTING_NOT_SET("agent.rate.skip.setting.not.set", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        AGENT_BRANCH_VALUE_DATE_WISE_CALCULATION_FAILED("agent.branch.value.date.wise.calculation.failed", REMITTANCE_TRANSACTION_EXCEPTION_TITLE),
        ONBOARDING_HOLIDAY_DATA_INCORRECT("onboarding.holiday.data.incorrect", REMITTANCE_TRANSACTION_EXCEPTION_TITLE);
        
        //@formatter:on

        private final String errorCode;

        private final String title;

        private RemittanceTransactionExceptionType(final String errorCode, final String title) {
            this.errorCode = errorCode;
            this.title = title;
        }

        private RemittanceTransactionExceptionType(final String errorCode) {
            this.errorCode = errorCode;
            this.title = REMITTANCE_TRANSACTION_EXCEPTION_TITLE;
        }

        @Override
        public String errorCode() {
            return this.errorCode;
        }

        @Override
        public String title() {
            return this.title;
        }
    }

    public RemittanceTransactionException(RemittanceTransactionExceptionType exceptionType, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), parameters);
        setExceptionType(exceptionType);
    }

    public RemittanceTransactionException(RemittanceTransactionExceptionType exceptionType, Status status,
            Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), status, parameters);
        setExceptionType(exceptionType);
    }

    private void setExceptionType(RemittanceTransactionExceptionType exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Override
    public ErrorCodeType exceptionType() {
        return this.exceptionType;
    }
}
