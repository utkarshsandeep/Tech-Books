package com.unimoni.pricingengine.domain.model.remittance;

import java.time.ZonedDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.standardcharges.types.TransactionStatus;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@ToString
@Entity
//@formatter:off
@Table(name = "REMITTANCE_TRANSACTION_CANCELLATION_REQUESTS", 
     indexes = { 
         @Index(name = "IDX_TXN_CANCEL_REQS_TRANSACTION_UUID", columnList = "TRANSACTION_UUID")  
     }
)
//@formatter:on
public class RemittanceTransactionCancellationRequest extends AbstractRemittanceTransaction {

    @ManyToOne
    // @formatter:off
    @JoinColumn(name = "TXN_INIT_REQ_ID", 
        referencedColumnName = "ID", 
        foreignKey = @ForeignKey(name = "FK_REMIT_CNCL_REQS_TXN_REQ_UUID"))
    // @formatter:on
    private RemittanceTransactionInitiationRequest txnInitRequest;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "TRANSACTION_STATUS", nullable = false, updatable = false, length = 30)
    private TransactionStatus transactionStatus;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "REASON_FOR_CANCELLATION", nullable = false, updatable = false, length = 20)
    private TxnCancellationReason reasonForCancellation;

    @OneToOne(mappedBy = "txnCancelRequest", cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = true)
    private RemittanceTransactionCancellationResponse txnCancelResponse;

    public void setResponse(final RemittanceTransactionCancellationResponse txnCancelResponse) {
        this.txnCancelResponse = txnCancelResponse;
    }

    public static RemittanceTransactionCancellationRequest of(
            final RemittanceTransactionInitiationRequest txnInitRequest, final TransactionStatus transactionStatus,
            final TxnCancellationReason reasonForCancellation, final ZonedDateTime txnTimestamp) {
        RemittanceTransactionCancellationRequest txnCancellationRequest = new RemittanceTransactionCancellationRequest();
        txnCancellationRequest.txnInitRequest = txnInitRequest;
        txnCancellationRequest.transactionUUID = txnInitRequest.transactionUUID();
        txnCancellationRequest.transactionStatus = transactionStatus;
        txnCancellationRequest.reasonForCancellation = reasonForCancellation;
        txnCancellationRequest.createdOn = txnTimestamp;
        return txnCancellationRequest;
    }
}
