package com.unimoni.pricingengine.domain.model.rate;

public enum RateType {

    // @formatter:off
    NORMAL_BASE("Normal or agent wise base rate"),
    BANK_WISE_BASE("Bank wise base rate"),
    NORMAL_IBR("Normal or agent wise IBT"),
    BANK_WISE_IBR("Bank wise IBR"),
    NORMAL_VAR("Normal or agent wise VaR"),
    BANK_WISE_VAR("Bank wise VaR"),
    NORMAL_SETTLEMENT_RATE("Normal or agent wise Settlement Rate"),
    BANK_WISE_SETTLEMENT_RATE("Bank wise Settlement Rate");
    // @formatter:on

    private final String description;

    private RateType(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }
}
