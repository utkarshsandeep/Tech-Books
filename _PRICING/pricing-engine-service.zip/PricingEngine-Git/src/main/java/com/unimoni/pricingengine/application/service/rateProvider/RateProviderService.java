package com.unimoni.pricingengine.application.service.rateProvider;

import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.domain.model.rate.RateProvider;

public interface RateProviderService {

    public RateProvider createRateProvider(final RateProvider rateProvider);

    public List<RateProvider> getAllRateProviders();

    public Optional<RateProvider> getManualRateProvider();

    public Optional<RateProvider> getThomsonReutersRateProvider();

    public Optional<RateProvider> getFutureSourceRateProvider();

    public RateProvider loadRateProvider(final int rateProviderId);

    public Optional<RateProvider> getRateProviderById(final int rateProviderId);
}
