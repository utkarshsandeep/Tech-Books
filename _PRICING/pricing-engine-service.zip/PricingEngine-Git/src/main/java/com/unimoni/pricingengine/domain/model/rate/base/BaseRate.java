package com.unimoni.pricingengine.domain.model.rate.base;

public interface BaseRate {

}
