package com.unimoni.pricingengine.application.service.amigo.event;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;
import java.time.ZonedDateTime;

import javax.money.CurrencyUnit;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class SettlementRateUpdatedEvent extends VDWRateAmigoEvent {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashSettlementSellMargin;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashSettlementBuyMargin;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashSettlementSellCost;

    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal cashSettlementBuyCost;

    private SettlementRateUpdatedEvent(final Type type, final RMType rmType, final String agentCode,
            final String bankCode, final String serviceProviderCode, final String productCode,
            final String subProductCode, final String serviceTypeCode, final CurrencyUnit sourceCcy,
            final CurrencyUnit targetCcy, final BigDecimal cashSettlementSellMargin,
            final BigDecimal cashSettlementBuyMargin, final BigDecimal cashSettlementSellCost,
            final BigDecimal cashSettlementBuyCost, final boolean status, final ZonedDateTime updatedOn) {
        super(type, agentCode, bankCode, serviceProviderCode, productCode, subProductCode, serviceTypeCode, sourceCcy,
                targetCcy, status, updatedOn);
        this.cashSettlementSellMargin = cashSettlementSellMargin;
        this.cashSettlementBuyMargin = cashSettlementBuyMargin;
        if (rmType.isBankWise()) {
            this.cashSettlementBuyCost = cashSettlementBuyCost;
            this.cashSettlementSellCost = cashSettlementSellCost;
        }
    }

    public static SettlementRateUpdatedEvent forStatusChange(final SettlementRate settlementRate) {
        return new SettlementRateUpdatedEvent(
                settlementRate.rmType().isNormal() ? Type.SETTLEMENT_RATE_NORMAL : Type.SETTLEMENT_RATE_BANK_WISE,
                settlementRate.rmType(), settlementRate.agent(),
                settlementRate.rmType().isBankWise() ? settlementRate.bank().get() : null,
                settlementRate.instruments().serviceProvider(), settlementRate.instruments().product(),
                settlementRate.instruments().subProduct(), settlementRate.instruments().serviceType(),
                settlementRate.currency().source(), settlementRate.currency().target(),
                settlementRate.cash().get().margin().sellValue(), settlementRate.cash().get().margin().buyValue(),
                settlementRate.cash().get().settlement().sellValue(),
                settlementRate.cash().get().settlement().buyValue(), settlementRate.isEnabled(),
                settlementRate.updatedOn());
    }

    public static SettlementRateUpdatedEvent forRateChange(final SettlementRate settlementRate) {
        return new SettlementRateUpdatedEvent(
                settlementRate.rmType().isNormal() ? Type.SETTLEMENT_RATE_NORMAL : Type.SETTLEMENT_RATE_BANK_WISE,
                settlementRate.rmType(), settlementRate.agent(),
                settlementRate.rmType().isBankWise() ? settlementRate.bank().get() : null,
                settlementRate.instruments().serviceProvider(), settlementRate.instruments().product(),
                settlementRate.instruments().subProduct(), settlementRate.instruments().serviceType(),
                settlementRate.currency().source(), settlementRate.currency().target(),
                settlementRate.cash().get().margin().sellValue(), settlementRate.cash().get().margin().buyValue(),
                settlementRate.cash().get().settlement().sellValue(),
                settlementRate.cash().get().settlement().buyValue(), settlementRate.isEnabled(),
                settlementRate.updatedOn());
    }
}
