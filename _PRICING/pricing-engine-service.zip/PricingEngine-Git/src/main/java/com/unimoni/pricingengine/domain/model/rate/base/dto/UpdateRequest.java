package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@ApiModel(value = "updateRequest", description = "Request to update multiple records")
public class UpdateRequest<T extends Serializable, S> {

    @NotEmpty
    @Valid
    @ApiModelProperty(allowEmptyValue = false, required = true, value = "Map with keys as record ids and values as updated values")
    private Map<@NotNull T, @NotNull S> updates;

    public List<T> ids() {
        return this.updates.keySet().stream().collect(Collectors.toList());
    }
    
    public Iterator<Entry<T, S>> iterator() {
        return this.updates.entrySet().iterator();
    }
    
    public S value(final T key) {
        return this.updates.get(key);
    }
    
	public int updateSize() {
		return this.updates.keySet().size();
	}
}
