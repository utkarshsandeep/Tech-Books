package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceProvider {

    private String name;

    private String code;

    public CodeLabelPair<String, String> serviceProviderItem() {
        return CodeLabelPair.of(this.code, this.name);
    }

    public ServiceProvider(@JsonProperty("serviceProvider") String name, @JsonProperty("code") String code) {

        this.name = name;
        this.code = code;
    }

    @Override
    public String toString() {
        return "ServiceProvider [name=" + name + ", code=" + code + "]";
    }

}
