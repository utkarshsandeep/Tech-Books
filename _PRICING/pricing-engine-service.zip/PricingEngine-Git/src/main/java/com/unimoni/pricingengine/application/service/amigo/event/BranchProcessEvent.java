package com.unimoni.pricingengine.application.service.amigo.event;

import java.io.Serializable;

import com.unimoni.pricingengine.domain.model.bp.dto.BranchProcessAmigoCreateRequest;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class BranchProcessEvent  implements Serializable {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;
  
    private BranchProcessAmigoCreateRequest req;
    private BranchProcessEvent(BranchProcessAmigoCreateRequest req) {
        this.req = req;
    }

    public static BranchProcessEvent of(final BranchProcessAmigoCreateRequest item) {
        return new BranchProcessEvent(item);
    }
    
}
