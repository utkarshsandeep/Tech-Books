package com.unimoni.pricingengine.domain.model.bp.dto;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.bp.BranchProcessSourceType;
import com.unimoni.pricingengine.domain.model.bp.StatusType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor(staticName = "of")
public class BranchProcessUpdateResponse {
	@NotNull
	private String deal;

	private StatusType status;

	private BigDecimal amountConsumed;
	
	private BigDecimal offeredRate;
	
    private BranchProcessSourceType sourceType;	
}
