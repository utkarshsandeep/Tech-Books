package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NormalDataPayloadWrapper {

    private PayloadWrapper<NormalDataPayload> innerWrapper;

    public NormalDataPayloadWrapper(
            @JsonProperty("allowedProductSendRules") PayloadWrapper<NormalDataPayload> allowedProductSendRules) {
        this.innerWrapper = allowedProductSendRules;
    }

    public List<NormalDataPayload> getPayload() {
        return this.innerWrapper.getPayload();
    }
}
