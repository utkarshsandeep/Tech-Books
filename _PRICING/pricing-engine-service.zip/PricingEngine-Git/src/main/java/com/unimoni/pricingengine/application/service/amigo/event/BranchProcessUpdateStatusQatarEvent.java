package com.unimoni.pricingengine.application.service.amigo.event;

import java.io.Serializable;

import com.unimoni.pricingengine.adapter.rest.clients.bp.BranchProcessAmigoQatarRequest;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class BranchProcessUpdateStatusQatarEvent  implements Serializable {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;
  
    private BranchProcessAmigoQatarRequest req;
    private BranchProcessUpdateStatusQatarEvent(BranchProcessAmigoQatarRequest req) {
        this.req = req;
    }

    public static BranchProcessUpdateStatusQatarEvent of(final BranchProcessAmigoQatarRequest item) {
        return new BranchProcessUpdateStatusQatarEvent(item);
    }
    
}
