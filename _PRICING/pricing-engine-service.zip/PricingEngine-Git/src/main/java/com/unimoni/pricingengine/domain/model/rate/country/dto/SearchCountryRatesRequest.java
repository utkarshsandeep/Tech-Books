package com.unimoni.pricingengine.domain.model.rate.country.dto;

import java.util.List;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.common.dto.AbstractSearchRequest;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import lombok.Getter;

@Getter
public class SearchCountryRatesRequest extends AbstractSearchRequest {

    private RMType rmType;

    private List<String> agents;

    private List<String> banks;

    private List<String> serviceProviders;

    private List<String> products;

    private List<String> subProducts;

    private List<String> serviceTypes;

    private List<CurrencyUnit> baseCurrencies;

    private List<CurrencyUnit> foreignCurrencies;

    private Boolean status;

    private SearchCountryRatesRequest(final RMType rmType, final List<String> agents, final List<String> banks,
            final List<String> serviceProviders, final List<String> products, final List<String> subProducts,
            final List<String> serviceTypes, final List<CurrencyUnit> baseCurrencies,
            final List<CurrencyUnit> foreignCurrencies, final Boolean status, final PaginationData page) {
        this.rmType = rmType;
        this.agents = agents;
        this.banks = banks;
        this.serviceProviders = serviceProviders;
        this.products = products;
        this.subProducts = subProducts;
        this.serviceTypes = serviceTypes;
        this.baseCurrencies = baseCurrencies;
        this.foreignCurrencies = foreignCurrencies;
        this.status = status;
        this.page = page;
    }

    public static SearchCountryRatesRequest ofNormal(final List<String> agents, final List<String> serviceProviders,
            final List<String> products, final List<String> subProducts, final List<String> serviceTypes,
            final List<CurrencyUnit> baseCurrencies, final List<CurrencyUnit> foreignCurrencies, final Boolean status,
            final PaginationData page) {
        return new SearchCountryRatesRequest(RMType.NORMAL, agents, null, serviceProviders, products, subProducts,
                serviceTypes, baseCurrencies, foreignCurrencies, status, page);
    }

    public static SearchCountryRatesRequest ofNormalDownload(final List<String> agents,
            final List<String> serviceProviders, final List<String> products, final List<String> subProducts,
            final List<String> serviceTypes, final List<CurrencyUnit> baseCurrencies,
            final List<CurrencyUnit> foreignCurrencies, final Boolean status) {
        return ofNormal(agents, serviceProviders, products, subProducts, serviceTypes, baseCurrencies,
                foreignCurrencies, status,
                PaginationData.ofFirstPage(BeanFactory.applicationProperties().getDownloadChunkSize()));
    }

    public static SearchCountryRatesRequest ofBankWise(final List<String> agents, final List<String> banks,
            final List<String> serviceProviders, final List<String> products, final List<String> subProducts,
            final List<String> serviceTypes, final List<CurrencyUnit> baseCurrencies,
            final List<CurrencyUnit> foreignCurrencies, final Boolean status, final PaginationData page) {
        return new SearchCountryRatesRequest(RMType.BANK_WISE, agents, banks, serviceProviders, products, subProducts,
                serviceTypes, baseCurrencies, foreignCurrencies, status, page);
    }

    public static SearchCountryRatesRequest ofBankWiseDownload(final List<String> agents, final List<String> banks,
            final List<String> serviceProviders, final List<String> products, final List<String> subProducts,
            final List<String> serviceTypes, final List<CurrencyUnit> baseCurrencies,
            final List<CurrencyUnit> foreignCurrencies, final Boolean status) {
        return ofBankWise(agents, banks, serviceProviders, products, subProducts, serviceTypes, baseCurrencies,
                foreignCurrencies, status,
                PaginationData.ofFirstPage(BeanFactory.applicationProperties().getDownloadChunkSize()));
    }
}
