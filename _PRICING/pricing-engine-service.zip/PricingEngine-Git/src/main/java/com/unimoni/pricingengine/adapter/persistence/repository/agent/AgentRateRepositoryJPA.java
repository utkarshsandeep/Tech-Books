package com.unimoni.pricingengine.adapter.persistence.repository.agent;

import java.util.List;
import java.util.Optional;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.bp.dto.BPOfferRateRequest;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.SearchAgentRatesRequest;
import com.unimoni.pricingengine.domain.model.remittance.TransactionCurrencies.TxnCurrencyType;
import com.unimoni.pricingengine.domain.model.remittance.dto.TxnLayerChargeRequest;

public interface AgentRateRepositoryJPA extends JPA {

    public Optional<AgentRate> findActiveAgentRatesByIdentity(final RMType rmType,
            final AgentRateIdentity countryIdentity);

    public List<AgentRate> findAllAgentRates(final SearchAgentRatesRequest searchRequest);

    public List<AgentRate> findAgentRatesByIds(final RMType rmType, final List<String> ids, boolean eagerFetchCountry);

    public Optional<AgentRate> findHighestPriorityAgentRateByRemmitanceTransaction(
            final TxnLayerChargeRequest layerChargeRequest, final CurrencyUnit payInCurrency,
            final TxnCurrencyType txnCurrencyType, final CurrencyUnit currency);

    public Optional<AgentRate> findAgentRateByBPOfferRequest(final BPOfferRateRequest bpOfferRateRequest);
}
