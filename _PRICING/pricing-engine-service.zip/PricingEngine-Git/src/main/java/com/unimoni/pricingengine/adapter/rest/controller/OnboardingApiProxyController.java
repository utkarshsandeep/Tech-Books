package com.unimoni.pricingengine.adapter.rest.controller;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addInfo;
import static com.unimoni.pricingengine.common.constants.CommonMessageConstants.NO_RECORDS_FOUND;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_AGENT_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_BANK_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_COUNTRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_CURRENCY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_DESTINATIONS_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_PRODUCT_SERVICE_TYPE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_PRODUCT_SUB_TYPE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_PRODUCT_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_SERVICE_PROVIDERS_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.MasterApi.MASTER_SOURCES_URI;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unimoni.pricingengine.adapter.rest.clients.Agent;
import com.unimoni.pricingengine.adapter.rest.clients.AgentDraweeBank;
import com.unimoni.pricingengine.adapter.rest.clients.AgentDraweeBank4RatesClient;
import com.unimoni.pricingengine.adapter.rest.clients.AgentDraweeBankPayload;
import com.unimoni.pricingengine.adapter.rest.clients.AgentDraweeBankResponse;
import com.unimoni.pricingengine.adapter.rest.clients.AgentRestClient;
import com.unimoni.pricingengine.adapter.rest.clients.AllowedProductsSendRules;
import com.unimoni.pricingengine.adapter.rest.clients.Bank;
import com.unimoni.pricingengine.adapter.rest.clients.BankRestClient;
import com.unimoni.pricingengine.adapter.rest.clients.CodeLabelPair;
import com.unimoni.pricingengine.adapter.rest.clients.Country;
import com.unimoni.pricingengine.adapter.rest.clients.CountryRestClient;
import com.unimoni.pricingengine.adapter.rest.clients.Currency;
import com.unimoni.pricingengine.adapter.rest.clients.CurrencyRestClient;
import com.unimoni.pricingengine.adapter.rest.clients.DrawBankPayload;
import com.unimoni.pricingengine.adapter.rest.clients.DrawBankProfileIdResponse;
import com.unimoni.pricingengine.adapter.rest.clients.DraweeBankProductProfileId;
import com.unimoni.pricingengine.adapter.rest.clients.DraweeBankProductProfileIdClient;
import com.unimoni.pricingengine.adapter.rest.clients.MappingDataHandler;
import com.unimoni.pricingengine.adapter.rest.clients.MappingMasterData;
import com.unimoni.pricingengine.adapter.rest.clients.Product;
import com.unimoni.pricingengine.adapter.rest.clients.ProductRestClient;
import com.unimoni.pricingengine.adapter.rest.clients.ServiceProviderDetails;
import com.unimoni.pricingengine.adapter.rest.clients.ServiceProviderPayload;
import com.unimoni.pricingengine.adapter.rest.clients.ServiceProviderResponse;
import com.unimoni.pricingengine.adapter.rest.clients.ServiceProviderRestClient;
import com.unimoni.pricingengine.application.event.listner.AgentOnBoardListner;
import com.unimoni.pricingengine.application.event.listner.RoundOfCutOffRateSettingCreatedListner;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(value = "MASTER_OLD", description = "Deprecated now - Would be removed soon", tags = "Master API - Old", hidden = true)
//@RestController
//@RequestMapping(MASTER_API)
@Deprecated
public class OnboardingApiProxyController {

    private ServiceProviderRestClient serviceProviderRestClient;

    private CurrencyRestClient currencyRestClient;

    private CountryRestClient countryRestClient;

    private ProductRestClient productRestClient;

    private AgentRestClient agentRestClient;

    private BankRestClient bankRestClient;

    private AllowedProductsSendRules allowedProductsSendRules;

    private DraweeBankProductProfileIdClient draweeBankProductProfileIdClient;

    private AgentDraweeBank4RatesClient agentDraweeBank4RatesClient;

    @Lazy
    @Autowired
    AgentOnBoardListner agentOnBoardEventListner;

    @Lazy
    @Autowired
    RoundOfCutOffRateSettingCreatedListner roundOfCutOffRateSettingCreatedListner;

    @Autowired
    public OnboardingApiProxyController(ServiceProviderRestClient serviceProviderRestClient,
            CurrencyRestClient currencyRestClient, CountryRestClient countryRestClient,
            ProductRestClient productRestClient, AgentRestClient agentRestClient, BankRestClient bankRestClient,
            AllowedProductsSendRules allowedProductsSendRules,
            DraweeBankProductProfileIdClient draweeBankProductProfileIdClient,
            AgentDraweeBank4RatesClient agentDraweeBank4RatesClient) {

        this.serviceProviderRestClient = serviceProviderRestClient;
        this.currencyRestClient = currencyRestClient;
        this.countryRestClient = countryRestClient;
        this.productRestClient = productRestClient;
        this.agentRestClient = agentRestClient;
        this.bankRestClient = bankRestClient;
        this.allowedProductsSendRules = allowedProductsSendRules;
        this.draweeBankProductProfileIdClient = draweeBankProductProfileIdClient;
        this.agentDraweeBank4RatesClient = agentDraweeBank4RatesClient;

    }

    @Deprecated
    @GetMapping(MASTER_SERVICE_PROVIDERS_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-service-providers", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Service providers", notes = "", response = CodeLabelPair.class, responseContainer = "List")
    public ResponseEntity<List<CodeLabelPair<String, String>>> getServiceProviders() {
        // @formatter:on

        return null;
    }

    @Deprecated
    @GetMapping(MASTER_COUNTRY_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-countries", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Countries", notes = "", response = CodeLabelPair.class, responseContainer = "List")
    public ResponseEntity<List<CodeLabelPair<String, String>>> getCountries() {
        // @formatter:on
        List<Country> countries = countryRestClient.allCountries();
        if (countries.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {
            List<CodeLabelPair<String, String>> results = new ArrayList<>();
            results.add(CodeLabelPair.ofAll());
            results.addAll(countries.stream().map(Country::countryItem).distinct()
                    .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
            return ResponseEntity.ok(results);
        }
    }

    @Deprecated
    @GetMapping(MASTER_BANK_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-banks", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Banks", notes = "", response = CodeLabelPair.class, responseContainer = "List")
    @Valid
    public ResponseEntity<List<CodeLabelPair<String, String>>> getBanks(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE") @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders) {
        // @formatter:on
        if (serviceProviders != null) {

            DrawBankPayload drawBankPayload = new DrawBankPayload();
            drawBankPayload.setServiceProviderCodes(serviceProviders);
            DrawBankProfileIdResponse drawBankProfileIdResponse = draweeBankProductProfileIdClient
                    .getDraweeBankProductProfileIdResponse(drawBankPayload);

            List<DraweeBankProductProfileId> draweeBankProductProfileIds = drawBankProfileIdResponse.getData();

            if (draweeBankProductProfileIds.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(draweeBankProductProfileIds.stream().filter(sp -> sp.notIn(serviceProviders))
                        .map(DraweeBankProductProfileId::draweeBankProductProfileIdItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }
        else {
            List<Bank> banks = bankRestClient.allBanks();
            if (banks.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(banks.stream().map(Bank::bankItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }

    }

    @Deprecated
    @GetMapping(MASTER_AGENT_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-agents", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Agents", notes = "", response = CodeLabelPair.class, responseContainer = "List")
    @Valid
    public ResponseEntity<List<CodeLabelPair<String, String>>> getAgents(
            @ApiParam(allowMultiple = true, value = "Service Providers such as UAE, UK etc.", example = "Western union") @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, value = "Banks such as HDFC, ICICI etc.", example = "ICICI") @RequestParam(value = "banks", required = false) final List<@NotEmpty String> banks) {
        // @formatter:on

        if (serviceProviders != null && banks != null) {

            AgentDraweeBankPayload agentDraweeBankPayload = new AgentDraweeBankPayload();
            agentDraweeBankPayload.setDraweeBankProductProfileIds(banks);
            agentDraweeBankPayload.setServiceProviderCodes(serviceProviders);

            AgentDraweeBankResponse agentDraweeBankResponse = agentDraweeBank4RatesClient
                    .getAgentDraweeBank4Rates(agentDraweeBankPayload);
            List<AgentDraweeBank> agentDraweeBank = agentDraweeBankResponse.getAgentDraweeBank();
            if (agentDraweeBank.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(agentDraweeBank.stream().map(AgentDraweeBank::agentDraweeBankItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }
        else if (serviceProviders != null && banks == null) {
            ServiceProviderPayload serviceProviderPayload = new ServiceProviderPayload();
            serviceProviderPayload.setServiceProviderCodes(serviceProviders);
            ServiceProviderResponse serviceProviderResponse = allowedProductsSendRules
                    .getServiceProviderDetailsResponse(serviceProviderPayload);
            List<ServiceProviderDetails> serviceProviderDetails = serviceProviderResponse.getAllowedProductSendRules()
                    .getServiceProviderDetails();
            if (serviceProviderDetails.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(serviceProviderDetails.stream().filter(sp -> sp.notIn(serviceProviders))
                        .map(ServiceProviderDetails::agentItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }
        else {
            List<Agent> agents = agentRestClient.allAgents();
            if (agents.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(agents.stream().map(Agent::agentItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }

        }

    }

    @Deprecated
    @GetMapping(MASTER_PRODUCT_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-products", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Products", notes = "", response = CodeLabelPair.class, responseContainer = "List")
    public ResponseEntity<List<CodeLabelPair<String, String>>> getProduct(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE") @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, value = "Banks such as HDFC, ICICI etc.", example = "ICICI") @RequestParam(value = "banks", required = false) final List<@NotEmpty Long> banks,
            @ApiParam(allowMultiple = true, value = "Agents such as Western union, SBIVI etc.", example = "Western union") @RequestParam(value = "agents", required = false) final List<@NotEmpty Long> agents) {
        // @formatter:on
        if (serviceProviders != null && agents == null && banks != null) {
            DrawBankPayload drawBankPayload = new DrawBankPayload();
            drawBankPayload.setServiceProviderCodes(serviceProviders);

            DrawBankProfileIdResponse drawBankProfileIdResponse = draweeBankProductProfileIdClient
                    .getDraweeBankProductProfileIdResponse(drawBankPayload);

            List<DraweeBankProductProfileId> draweeBankProductProfileIds = drawBankProfileIdResponse.getData();
            MappingDataHandler mappingDataHandler = new MappingDataHandler();
            List<MappingMasterData> mappingMasterData = mappingDataHandler.spBankMappingData(serviceProviders, banks);
            if (draweeBankProductProfileIds.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(draweeBankProductProfileIds.stream().filter(sp -> sp.notPresent(mappingMasterData))
                        .map(DraweeBankProductProfileId::productItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }
        else if (serviceProviders != null && agents != null && banks == null) {

            ServiceProviderPayload serviceProviderPayload = new ServiceProviderPayload();
            serviceProviderPayload.setServiceProviderCodes(serviceProviders);
            serviceProviderPayload.setAgentBranchIds(agents);
            ServiceProviderResponse serviceProviderResponse = allowedProductsSendRules
                    .getServiceProviderDetailsResponse(serviceProviderPayload);

            List<ServiceProviderDetails> serviceProviderDetails = serviceProviderResponse.getAllowedProductSendRules()
                    .getServiceProviderDetails();
            MappingDataHandler mappingDataHandler = new MappingDataHandler();
            List<MappingMasterData> mappingMasterData = mappingDataHandler.spAgentMappingData(serviceProviders, agents);

            if (serviceProviderDetails.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(serviceProviderDetails.stream().filter(sp -> sp.notPresent(mappingMasterData))
                        .map(ServiceProviderDetails::productItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }
        else {
            List<Product> products = productRestClient.allProducts();

            if (products.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(products.stream().map(Product::productItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }
    }

    @Deprecated
    @GetMapping(MASTER_PRODUCT_SUB_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-productSubTypes", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Sub Products", notes = "", response = CodeLabelPair.class, responseContainer = "List")
    public ResponseEntity<List<CodeLabelPair<String, String>>> getProductSubType(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE") @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, value = "Agents such as Western union, SBIVI etc.", example = "Western union") @RequestParam(value = "agents", required = false) final List<@NotEmpty Long> agents,
            @ApiParam(allowMultiple = true, value = "Banks such as HDFC, ICICI etc.", example = "ICICI") @RequestParam(value = "banks", required = false) final List<@NotEmpty Long> banks,
            @ApiParam(allowMultiple = true, value = "Product  such as Remittance, Lendingetc.", example = "Remittance") @RequestParam(value = "products", required = false) final List<@NotEmpty String> products) {
        // @formatter:on
        if (serviceProviders != null && agents == null && banks != null && products != null) {

            DrawBankPayload drawBankPayload = new DrawBankPayload();
            drawBankPayload.setServiceProviderCodes(serviceProviders);

            DrawBankProfileIdResponse drawBankProfileIdResponse = draweeBankProductProfileIdClient
                    .getDraweeBankProductProfileIdResponse(drawBankPayload);
            MappingDataHandler mappingDataHandler = new MappingDataHandler();
            List<MappingMasterData> mappingMasterData = mappingDataHandler.spBankProductMappingData(serviceProviders,
                    banks, products);
            List<DraweeBankProductProfileId> draweeBankProductProfileIds = drawBankProfileIdResponse.getData();
            if (draweeBankProductProfileIds.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(draweeBankProductProfileIds.stream().filter(sp -> sp.notAvaliable(mappingMasterData))
                        .map(DraweeBankProductProfileId::productSubTypeItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }

        }
        else if (serviceProviders != null && agents != null && banks == null && products != null) {
            ServiceProviderPayload serviceProviderPayload = new ServiceProviderPayload();
            serviceProviderPayload.setServiceProviderCodes(serviceProviders);
            serviceProviderPayload.setAgentBranchIds(agents);
            serviceProviderPayload.setProductTypes(products);

            ServiceProviderResponse serviceProviderResponse = allowedProductsSendRules
                    .getServiceProviderDetailsResponse(serviceProviderPayload);

            List<ServiceProviderDetails> serviceProviderDetails = serviceProviderResponse.getAllowedProductSendRules()
                    .getServiceProviderDetails();
            if (serviceProviderDetails.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }

            else {
                MappingDataHandler mappingDataHandler = new MappingDataHandler();
                List<MappingMasterData> mappingMasterData = mappingDataHandler
                        .spAgentProductMappingData(serviceProviders, agents, products);
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(serviceProviderDetails.stream().filter(sp -> sp.notAvaliable(mappingMasterData))
                        .map(ServiceProviderDetails::productSubTypesItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }
        else {
            // return null;

            // Rajveer: Don't know what following code does, just did a temporary fix to return some data instead of
            // null to fix blocker issue
            List<CodeLabelPair<String, String>> results = new ArrayList<>();
            results.add(CodeLabelPair.ofAll());

            if (serviceProviders != null) {
                DrawBankPayload drawBankPayload = new DrawBankPayload();
                drawBankPayload.setServiceProviderCodes(serviceProviders);

                DrawBankProfileIdResponse drawBankProfileIdResponse = draweeBankProductProfileIdClient
                        .getDraweeBankProductProfileIdResponse(drawBankPayload);

                List<DraweeBankProductProfileId> draweeBankProductProfileIds = drawBankProfileIdResponse.getData();
                results.addAll(draweeBankProductProfileIds.stream().map(DraweeBankProductProfileId::productSubTypeItem)
                        .distinct().sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
            }
            return ResponseEntity.ok(results);
        }

    }

    @Deprecated
    @GetMapping(MASTER_PRODUCT_SERVICE_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-products", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Product service types", notes = "", response = CodeLabelPair.class, responseContainer = "List")
    public ResponseEntity<List<CodeLabelPair<String, String>>> getProductServiceTypes(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE") @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, value = "Banks such as HDFC, ICICI etc.", example = "ICICI") @RequestParam(value = "banks", required = false) final List<@NotEmpty Long> banks,
            @ApiParam(allowMultiple = true, value = "Agents such as Western union, SBIVI etc.", example = "Western union") @RequestParam(value = "agents", required = false) final List<@NotEmpty Long> agents,
            @ApiParam(allowMultiple = true, value = "Product  such as Remittance, Lending etc.", example = "Remittance") @RequestParam(value = "products", required = false) final List<@NotEmpty String> products,
            @ApiParam(allowMultiple = true, value = "SubProduct such as Account Credit, Cash payout,Cash to Card etc.", example = "Account Credit") @RequestParam(value = "subProduct", required = false) final List<@NotEmpty String> subProducts) {
        // @formatter:on
        if (serviceProviders != null && banks != null && products != null && subProducts != null) {

            DrawBankPayload drawBankPayload = new DrawBankPayload();
            drawBankPayload.setServiceProviderCodes(serviceProviders);

            DrawBankProfileIdResponse drawBankProfileIdResponse = draweeBankProductProfileIdClient
                    .getDraweeBankProductProfileIdResponse(drawBankPayload);
            MappingDataHandler mappingDataHandler = new MappingDataHandler();
            List<MappingMasterData> mappingMasterData = mappingDataHandler
                    .spBankProductSubProductMappingData(serviceProviders, banks, products, subProducts);
            List<DraweeBankProductProfileId> draweeBankProductProfileIds = drawBankProfileIdResponse.getData();
            if (draweeBankProductProfileIds.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(draweeBankProductProfileIds.stream().filter(sp -> sp.notInMaster(mappingMasterData))
                        .map(DraweeBankProductProfileId::serviceTypeItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }

        }
        else if (serviceProviders != null && agents != null && banks == null && products != null
                && subProducts != null) {
            ServiceProviderPayload serviceProviderPayload = new ServiceProviderPayload();
            serviceProviderPayload.setServiceProviderCodes(serviceProviders);
            serviceProviderPayload.setAgentBranchIds(agents);
            serviceProviderPayload.setProductTypes(products);
            serviceProviderPayload.setSubProductTypes(subProducts);

            ServiceProviderResponse serviceProviderResponse = allowedProductsSendRules
                    .getServiceProviderDetailsResponse(serviceProviderPayload);

            List<ServiceProviderDetails> serviceProviderDetails = serviceProviderResponse.getAllowedProductSendRules()
                    .getServiceProviderDetails();
            if (serviceProviderDetails.isEmpty()) {
                return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
            }
            else {
                MappingDataHandler mappingDataHandler = new MappingDataHandler();
                List<MappingMasterData> mappingMasterData = mappingDataHandler
                        .spAgentProductSubProductMapping(serviceProviders, agents, products, subProducts);
                List<CodeLabelPair<String, String>> results = new ArrayList<>();
                results.add(CodeLabelPair.ofAll());
                results.addAll(serviceProviderDetails.stream().filter(sp -> sp.notInMasterData(mappingMasterData))
                        .map(ServiceProviderDetails::productServiceTypesItem).distinct()
                        .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
                return ResponseEntity.ok(results);
            }
        }
        else {
            // return null;

            // Rajveer: Don't know what following code does, just did a temporary fix to return some data instead of
            // null to fix blocker issue
            List<CodeLabelPair<String, String>> results = new ArrayList<>();
            results.add(CodeLabelPair.ofAll());

            if (serviceProviders != null) {
                DrawBankPayload drawBankPayload = new DrawBankPayload();
                drawBankPayload.setServiceProviderCodes(serviceProviders);

                DrawBankProfileIdResponse drawBankProfileIdResponse = draweeBankProductProfileIdClient
                        .getDraweeBankProductProfileIdResponse(drawBankPayload);
                List<DraweeBankProductProfileId> draweeBankProductProfileIds = drawBankProfileIdResponse.getData();
                if (draweeBankProductProfileIds.isEmpty()) {
                    return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
                }
                else {
                    results.addAll(draweeBankProductProfileIds.stream().map(DraweeBankProductProfileId::serviceTypeItem)
                            .collect(Collectors.toList()));
                    return ResponseEntity.ok(results);
                }
            }
            return ResponseEntity.ok(results);
        }

    }

    @Deprecated
    @GetMapping(MASTER_CURRENCY_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-currencies", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Currencies", notes = "", response = CodeLabelPair.class, responseContainer = "List")
    public ResponseEntity<List<CodeLabelPair<String, String>>> getCurrencies(
            @ApiParam(allowMultiple = true, type = "String", value = "Service Providers such as UAE, UK etc.", example = "UAE") @RequestParam(value = "serviceProviders", required = false) final List<@NotEmpty String> serviceProviders,
            @ApiParam(allowMultiple = true, value = "Agents such as Western union, SBIVI etc.", example = "Western union") @RequestParam(value = "agents", required = false) final List<@NotEmpty Long> agents,
            @ApiParam(allowMultiple = true, value = "Product  such as Remittance, Lending etc.", example = "Remittance") @RequestParam(value = "products", required = false) final List<@NotEmpty String> products,
            @ApiParam(allowMultiple = true, value = "SubProduct  such as Account Credit, Cash payout etc.", example = "Account Credit") @RequestParam(value = "subProduct", required = false) final List<@NotEmpty String> subProducts,
            @ApiParam(allowMultiple = true, value = "ServiceTypes such as Flash, Normal,Other( IMPS) etc.", example = "Flash") @RequestParam(value = "serviceTypes", required = false) final List<@NotEmpty String> serviceTypes) {
        // @formatter:on
        if (serviceProviders != null && agents != null && products != null && subProducts != null
                && serviceTypes != null) {
            List<Currency> currencies = currencyRestClient.allCurrencies();
            return ResponseEntity
                    .ok(currencies.stream().map(Currency::currencyItem).collect(ImmutableCollectors.toImmutableList()));

        }
        else if (serviceProviders != null && agents != null && products != null) {

            List<Currency> currencies = currencyRestClient.allCurrencies();
            return ResponseEntity
                    .ok(currencies.stream().map(Currency::currencyItem).collect(ImmutableCollectors.toImmutableList()));
        }
        else {
            List<Currency> currencies = currencyRestClient.allCurrencies();
            return ResponseEntity
                    .ok(currencies.stream().map(Currency::currencyItem).collect(ImmutableCollectors.toImmutableList()));

        }
    }

    @Deprecated
    @GetMapping(MASTER_SOURCES_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-sources", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Sources", response = List.class, notes = "")
    public ResponseEntity<?> getSources() {
        // @formatter:on
        List<CodeLabelPair<String, String>> results = new ArrayList<>();

        List<Country> countries = countryRestClient.allCountries();
        List<Agent> agents = agentRestClient.allAgents();

        if (countries.isEmpty() || agents.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {

            results.add(CodeLabelPair.ofAll());
            results.addAll(countries.stream().map(Country::countryItem).distinct()
                    .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
            results.add(CodeLabelPair.ofAll());
            results.addAll(agents.stream().map(Agent::agentItem).distinct()
                    .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));

            return ResponseEntity.ok(results);
        }

    }

    @Deprecated
    @GetMapping(MASTER_DESTINATIONS_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-destinations", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, value = "Gets all Destinations", response = List.class, notes = "")
    public ResponseEntity<?> getDestinations() {
        // @formatter:on
        List<CodeLabelPair<String, String>> results = new ArrayList<>();

        List<Country> countries = countryRestClient.allCountries();
        List<Agent> agents = agentRestClient.allAgents();
        List<Bank> banks = bankRestClient.allBanks();

        if (countries.isEmpty() || agents.isEmpty() || banks.isEmpty()) {
            return ResponseEntity.ok().headers(addInfo(getMessage(NO_RECORDS_FOUND))).build();
        }
        else {

            results.add(CodeLabelPair.ofAll());
            results.addAll(countries.stream().map(Country::countryItem).distinct()
                    .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
            results.add(CodeLabelPair.ofAll());
            results.addAll(agents.stream().map(Agent::agentItem).distinct()
                    .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));
            results.addAll(banks.stream().map(Bank::bankItem).distinct()
                    .sorted(Comparator.comparing(CodeLabelPair::getName)).collect(Collectors.toList()));

            return ResponseEntity.ok(results);
        }
    }
}
