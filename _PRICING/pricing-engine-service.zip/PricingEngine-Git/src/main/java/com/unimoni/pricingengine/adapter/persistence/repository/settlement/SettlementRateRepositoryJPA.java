package com.unimoni.pricingengine.adapter.persistence.repository.settlement;

import java.util.List;
import java.util.Optional;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementRateEnquiryIdentity;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementRateEnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementVDWRateType;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SearchSettlementRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementIdentity;

public interface SettlementRateRepositoryJPA extends JPA {

    public Optional<SettlementRate> findEnabledSettlementRateByIdentity(final RMType rmType,
            final SettlementIdentity settlementIdentity);

    public Optional<SettlementRate> findLatestDisabledSettlementRateByIdentity(final RMType rmType,
            final SettlementIdentity settlementIdentity);

    public List<SettlementRate> findAllSettlementRates(final SearchSettlementRatesRequest searchRequest);

    public List<SettlementRate> findSettlementRatesByIds(final RMType rmType, final List<String> ids,
            boolean eagerFetchCountry);

    public SettlementRate getSettlementReference(final RMType rmType, final String settlementId);

    public Optional<SettlementRate> findHighestPrioritySettlementRatesByCountryRateIdentity(final RMType rmType,
            final CountryRateIdentity identity, final CurrencyUnit currency);

    public List<CurrencyUnit> findDistinctSettlementRateCurrencies(final RMType rmType);

    public Optional<SettlementRateEnquiryResponse> findSettlementRateForEnquiry(final RMType rmType,
            final SettlementVDWRateType vdwRateType, final SettlementRateEnquiryIdentity enquiryIdentity);
}
