package com.unimoni.pricingengine.common.util.collection;

public enum InstrumentTreeLevel implements Level {
    
    SERVICE_PROVIDER(0), AGENT(1), PRODUCT(2);

    private final int level;

    private InstrumentTreeLevel(final int level) {
        this.level = level;
    }

    @Override
    public int level() {
        return this.level;
    }
}
