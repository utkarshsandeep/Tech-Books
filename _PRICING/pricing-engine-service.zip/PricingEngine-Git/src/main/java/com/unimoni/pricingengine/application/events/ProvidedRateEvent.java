package com.unimoni.pricingengine.application.events;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@ToString
public class ProvidedRateEvent {

    private String rateId;

    private String ricId;

    private BigDecimal askValue;

    private BigDecimal bidValue;

    @JsonCreator
    public static ProvidedRateEvent of(final @JsonProperty("rateId") String rateId,
            final @JsonProperty("ricId") String ricId, final @JsonProperty("askValue") BigDecimal askValue,
            final @JsonProperty("bidValue") BigDecimal bidValue) {
        ProvidedRateEvent providedRate = new ProvidedRateEvent();
        providedRate.rateId = rateId;
        providedRate.ricId = ricId;
        providedRate.askValue = askValue;
        providedRate.bidValue = bidValue;

        return providedRate;
    }
}
