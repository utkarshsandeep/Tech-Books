package com.unimoni.pricingengine.adapter.persistence.repository.rate.authorizationsetting;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationSetting;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationSetting_;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationRateSettingRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingIdentity;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingSearchRequest;

@Repository
public class AuthorizationSettingRepositoryImpl extends AbstractJPA implements AuthorizationSettingRepositoryJPA {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<AuthorizationSetting> findAllAuthorizationSettings(
            final AuthorizationSettingSearchRequest searchRequest) {
        final long totalRecords = findAuthorizationSettingsCount(searchRequest);
        searchRequest.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            final CriteriaBuilder criteriaBuilder = criteriaBuilder();
            final CriteriaQuery<AuthorizationSetting> query = criteriaQuery(AuthorizationSetting.class);
            final Root<AuthorizationSetting> root = query.from(AuthorizationSetting.class);

            query.where(AuthorizationSettingPredicates.getSearchAuthorizationSettingPredicates(root, criteriaBuilder,
                    searchRequest));
            query.select(root);
            final TypedQuery<AuthorizationSetting> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(searchRequest.page().queryFirstResult());
            typedQuery.setMaxResults(searchRequest.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findAuthorizationSettingsCount(final AuthorizationSettingSearchRequest searchRequest) {
        final CriteriaBuilder criteriaBuilder = criteriaBuilder();
        final CriteriaQuery<Long> query = criteriaQuery(Long.class);
        final Root<AuthorizationSetting> rate = query.from(AuthorizationSetting.class);

        query.where(AuthorizationSettingPredicates.getSearchAuthorizationSettingPredicates(rate, criteriaBuilder,
                searchRequest));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public Optional<AuthorizationSetting> findActiveAuthorizationByIdentity(
            final AuthorizationSettingIdentity identity) {
        final CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<AuthorizationSetting> query = criteriaBuilder.createQuery(AuthorizationSetting.class);
        final Root<AuthorizationSetting> root = query.from(AuthorizationSetting.class);

        query.where(AuthorizationSettingPredicates.getAuthorizationSettingPredicatesByIdendity(root, criteriaBuilder,
                identity));
        query.select(root);

        return getSingleResultSafely(entityManager.createQuery(query));
    }

    @Override
    public List<AuthorizationSetting> findAuthorizationSettingsByIds(final List<String> ids, final boolean status) {
        final CriteriaQuery<AuthorizationSetting> query = criteriaQuery(AuthorizationSetting.class);
        final Root<AuthorizationSetting> authorizationSetting = query.from(AuthorizationSetting.class);
        query.where(authorizationSetting.get(AuthorizationSetting_.id.getName()).in(ids));
        query.select(authorizationSetting);
        final TypedQuery<AuthorizationSetting> typedQuery = typedQuery(query);

        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public List<AuthorizationSetting> getRateSettingsForLayer(AuthorizationRateSettingRequest request) {

        final CriteriaBuilder criteriaBuilder = criteriaBuilder();
        final CriteriaQuery<AuthorizationSetting> query = criteriaQuery(AuthorizationSetting.class);
        final Root<AuthorizationSetting> root = query.from(AuthorizationSetting.class);

        query.where(AuthorizationSettingPredicates.getAuthorizationSettingPredicatesForLayer(root, criteriaBuilder,
                request));
        query.select(root);
        final TypedQuery<AuthorizationSetting> typedQuery = typedQuery(query);

        return getUnmodifiableResultList(typedQuery);

    }

}
