package com.unimoni.pricingengine.domain.model.remittance;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.adapter.persistence.jpa.converter.LayerChargesAttributeConverter;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@ToString
@Entity
//@formatter:off
@Table(name = "REMITTANCE_TRANSACTION_INITIATION_RESPONSES", 
   indexes = { 
       @Index(name = "IDX_TXN_INIT_RESPS_TRANSACTION_UUID", columnList = "TRANSACTION_UUID")  
   }
)
//@formatter:on
public class RemittanceTransactionInitiationResponse extends AbstractRemittanceTransaction {

    @OneToOne
    // @formatter:off
    @JoinColumn(name = "TXN_INIT_REQ_ID", 
        referencedColumnName = "ID", 
        foreignKey = @ForeignKey(name = "FK_REMIT_TXN_RESPONSE_REQUEST_TXN_UUID"))
    // @formatter:on
    private RemittanceTransactionInitiationRequest txnInitRequest;

    @NotNull
    private TxnSDCharge charge;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "VDW_TYPE", nullable = false, updatable = false, length = 20)
    private VDWType valueDateWise;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RATE_DISPLAY_MECHANISM", nullable = false, updatable = false, length = 20)
    private RateDisplayMachenism rateDisplayMechanism;
    
    @NotNull
    private RateSkipSetting rateSkipSetting;

    @NotNull
    @Convert(converter = LayerChargesAttributeConverter.class)
    @Column(name = "LAYER_CHARGES", columnDefinition = "CLOB")
    private LayerCharges layerCharges;

    public static RemittanceTransactionInitiationResponse of(
            final RemittanceTransactionInitiationRequest txnInitRequest, final TxnSDCharge charge,
            final VDWType valueDateWise, final RateDisplayMachenism rateDisplayMechanism,
            final RateSkipSetting rateSkipSetting,
            final LayerCharges layerCharges, final ZonedDateTime txnTimestamp) {
        RemittanceTransactionInitiationResponse txnInitiationResponse = new RemittanceTransactionInitiationResponse();
        txnInitiationResponse.txnInitRequest = txnInitRequest;
        txnInitiationResponse.transactionUUID = txnInitRequest.transactionUUID();
        txnInitiationResponse.charge = charge;
        txnInitiationResponse.valueDateWise = valueDateWise;
        txnInitiationResponse.rateDisplayMechanism = rateDisplayMechanism;
        txnInitiationResponse.rateSkipSetting = rateSkipSetting;
        txnInitiationResponse.layerCharges = layerCharges;
        txnInitiationResponse.createdOn = txnTimestamp;
        return txnInitiationResponse;
    }
}
