package com.unimoni.pricingengine.adapter.persistence.repository.rm;

import java.util.List;
import java.util.Optional;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.BankWiseIBREnquiryIdentity;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.BankWiseIBREnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.NormalIBREnquiryIdentity;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.NormalIBREnquiryResponse;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.base.BankWiseBaseRate;
import com.unimoni.pricingengine.domain.model.rate.base.NormalBaseRate;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseEventRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateIdentity;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchBankWiseBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchNormalBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRBasicIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRIdentity;

public interface RateManagementRepositoryJPA extends JPA {

    public List<NormalBaseRate> findAllNormalBaseRates(final SearchNormalBaseRateRequest request);

    public List<NormalBaseRate> findEnabledNonManualNormalBaseRates();

    public List<NormalBaseRate> findNormalBaseRatesByIds(final List<String> ids, boolean eagerFetchIbr);

    public Optional<NormalBaseRate> findActiveNormalBaseRatesByIdentity(final RateIdentity identity);

    public List<BankWiseBaseRate> findAllBankWiseBaseRates(final SearchBankWiseBaseRateRequest request);

    public Optional<BankWiseBaseRate> findActiveBankWiseBaseRatesByIdentity(final BankRateIdentity identity);

    public List<BankWiseBaseRate> findBankWiseBaseRatesByIds(final List<String> ids, final boolean eagerFetchIbrAndVar);

    public List<NormalIBR> findAllNormalIBRRates(final SearchNormalBaseRateRequest request);

    public List<NormalIBR> findNormalIBRRatesByIds(final List<String> ids, final boolean eagerLoadVar);

    public NormalIBR getNormalIBRReference(final String ibrId);

    public Optional<NormalIBR> findActiveNormalIBRByIdentity(final RateIdentity identity);

    public List<BankWiseIBR> findAllBankWiseIBRRates(final SearchBankWiseBaseRateRequest request);

    public List<BankWiseIBR> findBankWiseIBRRatesByIds(final List<String> ids, final boolean eagerLoadVar);

    public Optional<NormalBaseRate> findNormalBaseRateById(final String id, final boolean eagerFetchIbrAndVar);

    public BankWiseIBR getBankWiseIBRReference(final String ibrId);

    public Optional<BankWiseIBR> findActiveBankWiseIBRByIdentity(final BankRateIdentity identity);

    // Added for BankOnboard
    public List<NormalIBR> findByCurrencyInNormalIBR(BankWiseEventRateRequest createEventRateRequest);

    // Added for bankOnboard , to check if existing record is present in RM Bank or
    // not with product , serviceProvider , source , target , status(active)
    public long findCountByIdentity(String product, String serviceProvider, CurrencyUnit source, CurrencyUnit target,
            Boolean status, String agentDisplayCode, String bankDisplayCode);

    public Optional<? extends AbstractLayer> findHighestPriorityIBRByVaRBasicIdentity(final RMType rmType,
            final VaRBasicIdentity varBasicIdentity);

    public Optional<? extends AbstractLayer> findHighestPriorityIBRByVaRIdentity(final RMType rmType,
            final VaRIdentity varIdentity);

    public List<BankWiseBaseRate> findAllActiveBankWiseRateByRateIdentity(final RateIdentity rateIdentity);

    public List<CurrencyUnit> findDistinctNormalIBRCurrencies();

    public List<CurrencyUnit> findDistinctBankWiseIBRCurrencies();

    public Optional<NormalIBREnquiryResponse> findNormalIBRForEnquiry(final NormalIBREnquiryIdentity enquiryIdentity);

    public Optional<BankWiseIBREnquiryResponse> findBankWiseIBRForEnquiry(
            final BankWiseIBREnquiryIdentity enquiryIdentity);
}
