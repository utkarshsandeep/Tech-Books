package com.unimoni.pricingengine.domain.model.rate.country;

import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.money.CurrencyUnit;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode
@ToString(includeFieldNames = true)
@Embeddable
@Access(AccessType.FIELD)
public class CountryRateValueDateWise {

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "AGENT_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "AGENT_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost agent;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "MARGIN_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "MARGIN_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost margin;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "COST_RATE_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "COST_RATE_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost costRate;

    public static CountryRateValueDateWise of(CurrencyUnit sourceCurrency, CurrencyUnit targetCurrency,
            final Cost agent, final Cost margin, final Cost country) {

        validatePositive(agent.buyValue(), "Agent Buy");
        validatePositive(agent.sellValue(), "Agent Sell");
        validatePositive(margin.buyValue(), "Margin Buy");
        validatePositive(margin.sellValue(), "Margin Sell");
        validatePositive(country.buyValue(), "Country Buy");
        validatePositive(country.sellValue(), "Country Sell");

        CountryRateValueDateWise settlementValueDateWise = new CountryRateValueDateWise();
        settlementValueDateWise.agent = agent;
        settlementValueDateWise.margin = margin;
        settlementValueDateWise.costRate = country;
        return settlementValueDateWise;
    }

    public static CountryRateValueDateWise zero() {
        return CountryRateValueDateWise.of(Cost.ZERO, Cost.ZERO, Cost.ZERO);
    }

    public boolean updateCostMargin(Cost margin) {
        validatePositive(margin.buyValue(), "Margin Buy");
        validatePositive(margin.sellValue(), "Margin Sell");
        if (this.margin.equals(margin)) {
            return false;
        }
        else {
            this.margin = margin;
            return true;
        }
    }

    public boolean updateCostAgent(Cost agent) {
        validatePositive(agent.buyValue(), "Agent Buy");
        validatePositive(agent.sellValue(), "Agent Sell");
        if (this.agent.equals(agent)) {
            return false;
        }
        else {
            this.agent = agent;
            return true;
        }
    }

    public boolean updateCountryAndAgentCostFromSettlement(final Cost baseSettlementCountryCost,
            final Cost foreignSettlementCountryCost, final RateDisplayMachenism RDM) {
        BigDecimal countryCostRateSell;
        BigDecimal countryContRateBuy;
        if (RDM.isBCtoFC()) {
            countryCostRateSell = foreignSettlementCountryCost.sellValue().divide(baseSettlementCountryCost.buyValue(),
                    8, RoundingMode.CEILING);
            countryContRateBuy = foreignSettlementCountryCost.buyValue().divide(baseSettlementCountryCost.sellValue(),
                    8, RoundingMode.CEILING);
        }
        else {
            countryCostRateSell = baseSettlementCountryCost.buyValue().divide(foreignSettlementCountryCost.sellValue(),
                    8, RoundingMode.CEILING);
            countryContRateBuy = baseSettlementCountryCost.sellValue().divide(foreignSettlementCountryCost.buyValue(),
                    8, RoundingMode.CEILING);
        }
        Cost newCountryCost = Cost.of(countryCostRateSell, countryContRateBuy);
        validatePositive(newCountryCost.buyValue(), "Country Buy");
        validatePositive(newCountryCost.sellValue(), "Country Sell");
        this.costRate = newCountryCost;

        BigDecimal agentSell;
        BigDecimal agentBuy;
        if (RDM.isBCtoFC()) {
            // Agent Sell = Country Cost Rate Sell – Country Sell Margin
            // Agent Buy = Country Cost Rate Buy + Country Buy Margin

            agentSell = this.costRate.sellValue().subtract(this.margin.sellValue());
            agentBuy = this.costRate.buyValue().add(this.margin.buyValue());
        }
        else {
            // Agent Sell = Country Cost Rate Sell + Country Sell Margin
            // Agent Buy = Country Cost Rate Buy - Country Buy Margin

            agentSell = this.costRate.sellValue().add(this.margin.sellValue());
            agentBuy = this.costRate.buyValue().subtract(this.margin.buyValue());
        }
        Cost newAgentCost = Cost.of(agentSell, agentBuy);
        validatePositive(newAgentCost.buyValue(), "Agent Buy");
        validatePositive(newAgentCost.sellValue(), "Agent Sell");
        if (this.agent.equals(newAgentCost)) {
            return false;
        }
        else {
            this.agent = newAgentCost;
            return true;
        }
    }
}
