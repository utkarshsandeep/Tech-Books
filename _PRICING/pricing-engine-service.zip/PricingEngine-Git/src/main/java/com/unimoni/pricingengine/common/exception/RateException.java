package com.unimoni.pricingengine.common.exception;

import org.zalando.problem.Status;

import com.unimoni.pricingengine.common.enums.ErrorCodeType;

public class RateException extends PricingEngineException {

    private static final long serialVersionUID = 1L;

    private ErrorCodeType exceptionType;

    public enum RateExceptionExceptionType implements ErrorCodeType {

        //@formatter:off
		RATE_PROVIDER_NOT_FOUND("rate.provider.not.found", RATE_EXCEPTION_TITLE),
        FREQUENCY_REQUIRED_FOR_NON_MANUAL_RATE_PROVIDERS("frequency.required.for.non.manual.rate.providers", RATE_EXCEPTION_TITLE),
        FREQUENCY_OUTSIDE_RANGE_FOR_NON_MANUAL_RATE_PROVIDERS("frequency.outside.range.for.non.manual.rate.providers", RATE_EXCEPTION_TITLE),
        RIC_ID_REQUIRED_FOR_NON_MANUAL_RATE_PROVIDERS("ricId.required.for.non.manual.rate.providers", RATE_EXCEPTION_TITLE),
        SERVICE_PROVIDERS_NOT_FOUND("service.providers.not.found", RATE_EXCEPTION_TITLE),
        PRODUCTS_NOT_FOUND("products.not.found", RATE_EXCEPTION_TITLE),
        INVALID_IDS("invalid.ids", RATE_EXCEPTION_TITLE),
		INVALID_ASK_BID_VALUE("rate.invalid.ask.bid.value", RATE_EXCEPTION_TITLE),
		FILE_FORMAT_NOT_FOUND("file.format.not.found", DOWNLOAD_EXCEPTION_TITLE),
        NON_USD_CUURENCY_PAIR_INVALID("var.invalid.non.usd.currency.pair", RATE_EXCEPTION_TITLE),
        AT_LEAST_ONE_OF_MARGIN_ASK_OR_MARGIN_BID_REQUIRED("at.least.one.of.margin.ask.or.margin.bid.required", RATE_EXCEPTION_TITLE),
        AT_LEAST_ONE_OF_SETTLEMENT_SELL_OR_SETTLEMENT_BUY_REQUIRED("at.least.one.of.settlement.sell.or.settlement.buy.required", RATE_EXCEPTION_TITLE),
	    SAME_SOURCE_TARGET_CURRENCY("same.source.target.currency", RATE_EXCEPTION_TITLE),
	    MINIMUM_FREQUENCY_CHECK("frequency.minimum.value", RATE_EXCEPTION_TITLE),
        UNSATISFIED_SETTLEMENT_VAR_RATE_LAYER_LINK("unsatisfied.settlement.var.rate.layer.link", RATE_EXCEPTION_TITLE),
        UNSATISFIED_COUNTRY_SETTLEMENT_RATE_LAYER_LINK("unsatisfied.country.var.rate.layer.link", RATE_EXCEPTION_TITLE),
        BANK_REQUIRED_FOR_BANK_WISE_REQUEST("bank.required.for.bankWise.request", RATE_EXCEPTION_TITLE),
        AGENT_AND_BANK_REQUIRED_FOR_BANK_WISE_IBR_REQUEST("agent.and.bank.required.for.bank.wise.ibr.request", RATE_EXCEPTION_TITLE),
        ILLEGAL_AGENT_DETAILS_REQUEST_PARAMETER("illegal.agent.with.rate.display.machenism.request.parameter", RATE_EXCEPTION_TITLE),
        DOWNLOAD_FILE_INTERNAL_EXCEPTION("download.file.internal.exception", RATE_EXCEPTION_TITLE),
        DOWNLOAD_FILE_NO_RECORDS_FOUND_EXCEPTION("download.file.no.records.found.exception", RATE_EXCEPTION_TITLE),
        UNSATISFIED_VAR_IBR_LAYER_LINK("unsatisfied.var.ibr.layer.link", RATE_EXCEPTION_TITLE),
        VAR_NOT_FOUND_BY_IDENTITY("var.not.found.by.identity", RATE_EXCEPTION_TITLE),
        DUPLICATE_VAR_RECORD_EXISTS("duplicate.var.record.exists", RATE_EXCEPTION_TITLE),
        NOTHING_TO_UPDATE("nothing.to.update", RATE_EXCEPTION_TITLE),
        SETTLEMENT_RATE_NOT_FOUND_BY_IDENTITY("settlement.rate.not.found.by.identity", RATE_EXCEPTION_TITLE),
        DUPLICATE_SETTLEMENT_RATE_RECORD_EXISTS("duplicate.settlement.rate.record.exists", RATE_EXCEPTION_TITLE),
        DUPLICATE_BASE_RATE_RECORD_EXISTS("duplicate.base.rate.record.exists", RATE_EXCEPTION_TITLE),
        DUPLICATE_COUNTRY_RATE_RECORD_EXISTS("duplicate.base.country.rate.record.exists", RATE_EXCEPTION_TITLE),
        DUPLICATE_AGENT_RATE_RECORD_EXISTS("duplicate.base.agent.rate.record.exists", RATE_EXCEPTION_TITLE),
        PREVIOUS_LAYER_ENABLED_RECORD_DOES_NOT_EXISTS("previous.layer.enabled.record.does.not.exists", RATE_EXCEPTION_TITLE),
        IBR_NOT_FOUND_BY_IDENTITY("ibr.not.found.by.identity", RATE_EXCEPTION_TITLE),
        RATE_DISPLAY_MECHANISM_NOT_SET_FOR_AGENT_OR_BRANCH("rate.display.mechanism.not.set.for.agent.or.branch", RATE_EXCEPTION_TITLE),
        VALUE_CAN_NOT_BE_NEGATIVE("value.can.not.be.negative", RATE_EXCEPTION_TITLE),
        AS_UNIQUE("auth.setting.unique", RATE_EXCEPTION_TITLE),
        DB_ERROR("auth.setting.db.error", RATE_EXCEPTION_TITLE),
        NO_DATA_TO_SAVE("auth.setting.nodata.save", RATE_EXCEPTION_TITLE), 
        BANK_CODE_MANDAOTRY("auth.setting.bankcode.mandatory", RATE_EXCEPTION_TITLE),
        DUPLICATE_AUTHORIZATION_SETTING_RECORD_EXISTS("duplicate.authorization.setting.record.exists", RATE_EXCEPTION_TITLE), 
        NO_UPDATE_FOR_DISABLED_RECORD("disabled.no.update", RATE_EXCEPTION_TITLE);
		//@formatter:on

        private final String errorCode;

        private final String title;

        private RateExceptionExceptionType(final String errorCode, final String title) {
            this.errorCode = errorCode;
            this.title = title;
        }

        private RateExceptionExceptionType(final String errorCode) {
            this.errorCode = errorCode;
            this.title = RATE_EXCEPTION_TITLE;
        }

        @Override
        public String errorCode() {
            return this.errorCode;
        }

        @Override
        public String title() {
            return this.title;
        }
    }

    public RateException(RateExceptionExceptionType exceptionType, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), parameters);
        setExceptionType(exceptionType);
    }

    public RateException(RateExceptionExceptionType exceptionType, Status status, Object... parameters) {
        super(exceptionType.title(), exceptionType.errorCode(), status, parameters);
        setExceptionType(exceptionType);
    }

    private void setExceptionType(RateExceptionExceptionType exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Override
    public ErrorCodeType exceptionType() {
        return this.exceptionType;
    }
}
