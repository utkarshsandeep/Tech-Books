package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.fasterxml.jackson.annotation.JsonProperty;

@FeignClient(name = "agentClient", url = "http://agent-onboarding-service-snap.integration.apps.ocp.uaeexchange.com/onboarding/api/v1/agents")
public interface AgentRestClient {

	@GetMapping("/")
	GenericResponseData<Agent> getAgentResponse();

	default List<Agent> allAgents() {
		return getAgentResponse().data;
	}

	class GenericResponseData<T> {

		List<T> data;

		public GenericResponseData(@JsonProperty("data") List<T> data) {
			this.data = data;
		}
	}

}