package com.unimoni.pricingengine.application.service.amigo.dto;

import java.math.BigDecimal;
import java.util.Optional;

import com.unimoni.pricingengine.domain.model.rate.composable.Cost;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "amigoUpdateSettlementRateRequest", description = "Update Settlement Request by Amigo, Atleast one of cashSettlementSellMargin, cashSettlementBuyMargin or status is mandatory")
public class UpdateSettlementRateRequest extends VDWRateAmigoRequest {

    @ApiModelProperty(name = "cashSettlementSellMargin", dataType = "BigDecimal", value = "New CASH Settlement sell margin in BigDecimal with 8 decimal points precision (Optional)", required = false, example = "75.32560000", position = 9)
    private BigDecimal cashSettlementSellMargin;

    @ApiModelProperty(name = "cashSettlementBuyMargin", dataType = "BigDecimal", value = "New CASH Settlement buy margin in BigDecimal with 8 decimal points precision (Optional)", required = false, example = "75.32560000", position = 10)
    private BigDecimal cashSettlementBuyMargin;

    @ApiModelProperty(name = "status", dataType = "Boolean", value = "New Status (Optional)", required = false, example = "75.32560000", position = 11)
    private Boolean status;

    public Optional<Boolean> status() {
        return Optional.ofNullable(this.status);
    }

    public Optional<BigDecimal> cashSettlementSellMargin() {
        return Optional.ofNullable(this.cashSettlementSellMargin);
    }

    public Optional<BigDecimal> cashSettlementBuyMargin() {
        return Optional.ofNullable(this.cashSettlementBuyMargin);
    }

    public Optional<Cost> cashMarginCost() {
        return cashSettlementSellMargin().isPresent() && cashSettlementBuyMargin().isPresent()
                ? Optional.of(Cost.of(this.cashSettlementSellMargin, this.cashSettlementBuyMargin))
                : Optional.empty();
    }
}
