package com.unimoni.pricingengine.application.service.onboarding.model;

import java.util.List;
import java.util.stream.Collectors;

import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

public interface Partner extends PairItem<String, String> {

    String getCode();

    List<Product> getProducts();

    public default List<CodeNamePair<String, String>> productPairs() {
        return this.getProducts().stream().map(Product::pair).collect(Collectors.toList());
    }

    public default List<CodeNamePair<String, String>> subProductPairs(final List<String> products) {
        boolean filterProduct = products != null && !products.isEmpty();
        return this.getProducts().stream().filter(p -> {
            return filterProduct ? products.contains(p.getCode()) : true;
        }).map(Product::getSubProducts).flatMap(x -> x.stream()).map(SubProduct::pair).collect(Collectors.toList());
    }

    public default List<CodeNamePair<String, String>> serviceTypePairs(final List<String> products,
            final List<String> subProducts) {
        boolean filterProduct = products != null && !products.isEmpty();
        boolean filterSubProduct = subProducts != null && !subProducts.isEmpty();
        return this.getProducts().stream().filter(p -> {
            return filterProduct ? products.contains(p.getCode()) : true;
        }).map(Product::getSubProducts).flatMap(x -> x.stream()).filter(sp -> {
            return filterSubProduct ? subProducts.contains(sp.getCode()) : true;
        }).map(SubProduct::getServiceTypes).flatMap(x -> x.stream()).map(ServiceType::pair)
                .collect(Collectors.toList());
    }
}
