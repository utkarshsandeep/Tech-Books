package com.unimoni.pricingengine.common.constants;

public interface RestConstants {

    public static String CURIE_NAMESPACE = "pricing";

    public static final String SLASH = "/";

    public static final String DOCS_DIR = SLASH + "docs";

    public static final String API = SLASH + "api";

    public static final String VERSION_v1 = "v1";

    public static final String VERSION_v2 = "v2";

    public static final String CURRENT_VERSION = VERSION_v1;

    public static final String PRICING_API = API + SLASH + CURRENT_VERSION;

    public static final String PATH_VARIABLE_ID = "{id}";

    public interface Config {
        // ------------------------ URIs ------------------------------------
        static final String CONFIG_URI = PRICING_API + SLASH + "configs";

        static final String CONFIG_RATE_PROVIDERS_URI = SLASH + "rateProviders";

        static final String CONFIG_VAR_REASONS_URI = SLASH + "varReasons";

        // Added for standard charges
        static final String CONFIG_TRANSACTION_TYPES_URI = SLASH + "transactionType";

        static final String CONFIG_BENEFICIARY_TYPES_URI = SLASH + "beneficiaryType";

        static final String CONFIG_CUSTOMER_TYPES_URI = SLASH + "customerType";

        static final String CONFIG_CHARGE_TYPES_URI = SLASH + "chargeType";

        static final String CONFIG_CHARGE_TYPES_ALL_URI = SLASH + "allChargeType";

        static final String CONFIG_CHARGE_BASIS_TYPES_URI = SLASH + "chargeBasisType";

        static final String CONFIG_PAYMENT_MODES_URI = SLASH + "paymentMode";

        static final String CONFIG_STATUS_TYPES_URI = SLASH + "branchProcessStatusType";

        static final String CONFIG_MASTER_DATA_REFRESH_URI = SLASH + "msdataLockMode";

        static final String CONFIG_SWIFT_CHARGE_TYPES_URI = SLASH + "swiftChargeType";

        static final String CONFIG_RATE_LAYER_TYPES_URI = SLASH + "layerTypes";

        static final String CONFIG_AUTHORIZATION_STATUS_URI = SLASH + "authorizationStatusType";
    }

    public interface RateManagement {

        static final String NORMAL_BASE_RATE_URI = SLASH + "normalBaseRates";

        static final String NORMAL_BASE_RATE_UPDATE_STATUS_URI = NORMAL_BASE_RATE_URI + SLASH + PATH_VARIABLE_ID + SLASH
                + "status";

        static final String NORMAL_BASE_RATE_DOWNLOAD_URI = NORMAL_BASE_RATE_URI + SLASH + "download";

        static final String BANK_WISE_BASE_RATE_URI = SLASH + "bankWiseBaseRates";

        static final String BANK_WISE_BASE_RATE_UPDATE_STATUS_URI = BANK_WISE_BASE_RATE_URI + SLASH + PATH_VARIABLE_ID
                + SLASH + "status";

        static final String BANK_WISE_RATE_DOWNLOAD_URI = BANK_WISE_BASE_RATE_URI + SLASH + "download";

        static final String NORMAL_IBR_URI = SLASH + "normalIbrs";

        static final String NORMAL_IBR_UPDATE_STATUS_URI = NORMAL_IBR_URI + SLASH + PATH_VARIABLE_ID + SLASH + "status";

        static final String NORMAL_IBR_DOWNLOAD_URI = NORMAL_IBR_URI + SLASH + "download";

        static final String BANK_WISE_IBR_URI = SLASH + "bankWiseIbrs";

        static final String BANK_WISE_IBR_UPDATE_STATUS_URI = BANK_WISE_IBR_URI + SLASH + PATH_VARIABLE_ID + SLASH
                + "status";

        static final String BANK_WISE_IBR_DOWNLOAD_URI = BANK_WISE_IBR_URI + SLASH + "download";

        static final String NORMAL_BASE_RATE_SERVER_SENT_EVENTS = NORMAL_BASE_RATE_URI + SLASH + "serverSentEvents";

        static final String BANK_WISE_BASE_RATE_SERVER_SENT_EVENTS = BANK_WISE_BASE_RATE_URI + SLASH
                + "serverSentEvents";

        static final String NORMAL_IBR_SERVER_SENT_EVENTS = NORMAL_IBR_URI + SLASH + "serverSentEvents";

        static final String BANK_WISE_IBR_SERVER_SENT_EVENTS = BANK_WISE_IBR_URI + SLASH + "serverSentEvents";

        static final String NORMAL_BASE_RATE_IDENTITY_WISE = BANK_WISE_BASE_RATE_URI + SLASH + "identityWiseRate";
    }

    public interface Var {

        static final String VAR_URI = SLASH + "vars";

        static final String VAR_RM_TYPE_URI = VAR_URI + SLASH + "{rmType}";

        static final String VAR_NORMAL_URI = VAR_URI + SLASH + "normal";

        static final String VAR_NORMAL_META_DATA_URI = VAR_NORMAL_URI + SLASH + "metadata";

        static final String VAR_NORMAL_DOWNLOAD_URI = VAR_NORMAL_URI + SLASH + "download";

        static final String VAR_BANK_WISE_URI = VAR_URI + SLASH + "bankWise";

        static final String VAR_BANK_WISE_META_DATA_URI = VAR_BANK_WISE_URI + SLASH + "metadata";

        static final String VAR_BANK_WISE_DOWNLOAD_URI = VAR_BANK_WISE_URI + SLASH + "download";

        static final String VAR_CALCULATE_MARGIN_URI = VAR_URI + SLASH + "margin";

        static final String VAR_CALCULATE_SETTLEMENT_URI = VAR_URI + SLASH + "settlement";

        static final String NORMAL_VAR_SERVER_SENT_EVENTS = VAR_NORMAL_URI + SLASH + "serverSentEvents";

        static final String BANK_WISE_VAR_SERVER_SENT_EVENTS = VAR_BANK_WISE_URI + SLASH + "serverSentEvents";
    }

    public interface Settlement {

        static final String SETTLEMENT_RATE_URI = SLASH + "settlementRates";

        static final String SETTLEMENT_URI_DOWNLOAD = SLASH + "settlements" + SLASH + "{rmType}" + "/download";

        static final String SETTLEMENT_RATE_RM_TYPE_URI = SETTLEMENT_RATE_URI + SLASH + "{rmType}";

        static final String SETTLEMENT_RATE_NORMAL_URI = SETTLEMENT_RATE_URI + SLASH + "normal";

        static final String SETTLEMENT_RATE_NORMAL_META_DATA_URI = SETTLEMENT_RATE_NORMAL_URI + SLASH + "metadata";

        static final String SETTLEMENT_RATE_NORMAL_DOWNLOAD_URI = SETTLEMENT_RATE_NORMAL_URI + SLASH + "download";

        static final String SETTLEMENT_RATE_BANK_WISE_URI = SETTLEMENT_RATE_URI + SLASH + "bankWise";

        static final String SETTLEMENT_RATE_BANK_WISE_META_DATA_URI = SETTLEMENT_RATE_BANK_WISE_URI + SLASH
                + "metadata";

        static final String SETTLEMENT_RATE_BANK_WISE_DOWNLOAD_URI = SETTLEMENT_RATE_BANK_WISE_URI + SLASH + "download";

        static final String NORMAL_SETTLEMENT_SERVER_SENT_EVENTS = SETTLEMENT_RATE_NORMAL_URI + SLASH
                + "serverSentEvents";

        static final String BANK_WISE_SETTLEMENT_SERVER_SENT_EVENTS = SETTLEMENT_RATE_BANK_WISE_URI + SLASH
                + "serverSentEvents";
    }

    public interface Events {

        static final String EVENTS_URI = SLASH + "events";

        static final String EVENT_BANK_ONBOARD = SLASH + "bankOnboard";

        static final String EVENT_AGENT_ONBOARDED = SLASH + "agentOnboard";
    }

    public interface CountryMarkUpRate {

        static final String COUNTRY_RATE_URI = SLASH + "countryRates";

        static final String COUNTRY_RATE_RM_TYPE_URI = COUNTRY_RATE_URI + SLASH + "{rmType}";

        static final String COUNTRY_RATE_NORMAL_URI = COUNTRY_RATE_URI + SLASH + "normal";

        static final String COUNTRY_RATE_NORMAL_META_DATA_URI = COUNTRY_RATE_NORMAL_URI + SLASH + "metadata";

        static final String COUNTRY_RATE_NORMAL_DOWNLOAD_URI = COUNTRY_RATE_NORMAL_URI + SLASH + "download";

        static final String COUNTRY_RATE_BANK_WISE_URI = COUNTRY_RATE_URI + SLASH + "bankWise";

        static final String COUNTRY_RATE_BANK_WISE_META_DATA_URI = COUNTRY_RATE_BANK_WISE_URI + SLASH + "metadata";

        static final String COUNTRY_RATE_BANK_WISE_DOWNLOAD_URI = COUNTRY_RATE_BANK_WISE_URI + SLASH + "download";

        static final String COUNTRY_RATE_CALCULATE_MARGIN_URI = COUNTRY_RATE_URI + SLASH + "margin";

        static final String COUNTRY_RATE_CALCULATE_AGENT_URI = COUNTRY_RATE_URI + SLASH + "agent";

        static final String NORMAL_COUNTRY_SERVER_SENT_EVENTS = COUNTRY_RATE_NORMAL_URI + SLASH + "serverSentEvents";

        static final String BANK_WISE_COUNTRY_SERVER_SENT_EVENTS = COUNTRY_RATE_BANK_WISE_URI + SLASH
                + "serverSentEvents";
    }

    public interface StandardCharges {

        static final String SC_URI = SLASH + "standard-charges";

        static final String SC_DOWNLOAD_URI = SC_URI + SLASH + "download";

        static final String SC_VALIDATED_URI = SC_URI + SLASH + "validate";

        static final String SC_CREATED_URI = SC_URI;

        static final String SC_UPDATED_URI = SC_URI + SLASH + "amount-range" + SLASH + "status";

        static final String SC_ADD_AMOUNTRANGE_URI = SC_URI + SLASH + "{scId}" + SLASH + "amount-range";

        static final String SC_AMOUNT_RANGE_UPDATED_URI = SC_ADD_AMOUNTRANGE_URI + SLASH + "update";

        static final String SC_AMOUNT_RANGE_VALIDATE_URI = SC_ADD_AMOUNTRANGE_URI + SLASH + "validate";

        static final String SC_STANDARD_CHARGE_UPLOAD_URI = SC_URI + SLASH + "upload";

        static final String SC_CALCULATE_CHARGE_URI = SC_URI + SLASH + "initiation-charges";

        static final String SC_CANCEL_CHARGE_URI = SC_URI + SLASH + "cancellation-charges";

    }

    public interface Remittance {
        // ------------------------ URIs ------------------------------------
        static final String REMITTANCE_URI = SLASH + "remittance";

        static final String REMITTANCE_TRANSACTION_INITIATION_URI = REMITTANCE_URI + SLASH + "transactionCharges";

        static final String REMITTANCE_TRANSACTION_CANCELLATION_URI = REMITTANCE_URI + SLASH + "cancellationCharges";

        // ------------------------ RELs ------------------------------------
    }

    public interface AgentLayer {

        static final String AGENT_RATE_URI = SLASH + "agentRates";

        static final String AGENT_RATE_RM_TYPE_URI = AGENT_RATE_URI + SLASH + "{rmType}";

        static final String AGENT_RATE_NORMAL_URI = AGENT_RATE_URI + SLASH + "normal";

        static final String AGENT_RATE_NORMAL_META_DATA_URI = AGENT_RATE_NORMAL_URI + SLASH + "metadata";

        static final String AGENT_RATE_NORMAL_DOWNLOAD_URI = AGENT_RATE_NORMAL_URI + SLASH + "download";

        static final String AGENT_RATE_BANK_WISE_URI = AGENT_RATE_URI + SLASH + "bankWise";

        static final String AGENT_RATE_BANK_WISE_META_DATA_URI = AGENT_RATE_BANK_WISE_URI + SLASH + "metadata";

        static final String AGENT_RATE_BANK_WISE_DOWNLOAD_URI = AGENT_RATE_BANK_WISE_URI + SLASH + "download";

        static final String AGENT_RATE_CALCULATE_MARGIN_URI = AGENT_RATE_URI + SLASH + "margin";

        static final String AGENT_RATE_CALCULATE_CUSTOMER_RATE_URI = AGENT_RATE_URI + SLASH + "customerRate";

        static final String AGENT_RATE_CALCULATE_MAX_DISCOUNT_URI = AGENT_RATE_URI + SLASH + "maxDiscount";

        static final String AGENT_RATE_CALCULATE_MARGIN_LOW_URI = AGENT_RATE_URI + SLASH + "marginLow";

        static final String AGENT_RATE_CALCULATE_CUSTOMER_LOW_URI = AGENT_RATE_URI + SLASH + "customerLow";

        static final String AGENT_RATE_CALCULATE_MARGIN_HIGH_URI = AGENT_RATE_URI + SLASH + "marginHigh";

        static final String AGENT_RATE_CALCULATE_CUSTOMER_RATE_URI_NEW = AGENT_RATE_URI + SLASH + "customerRateNew";

        static final String AGENT_RATE_CALCULATE_MARGIN_URI_NEW = AGENT_RATE_URI + SLASH + "marginNew";

        static final String NORMAL_AGENT_SERVER_SENT_EVENTS = AGENT_RATE_NORMAL_URI + SLASH + "serverSentEvents";

        static final String BANK_WISE_AGENT_SERVER_SENT_EVENTS = AGENT_RATE_BANK_WISE_URI + SLASH + "serverSentEvents";

    }

    public interface BranchProcess {

        static final String BRANCH_PROCESS = SLASH + "branchProcess";

        static final String BRANCH_PROCESS_CREATE_URI = BRANCH_PROCESS + SLASH + "create";

        static final String BRANCH_PROCESS_URI = BRANCH_PROCESS + SLASH + "getDealDetail";

        static final String BRANCH_PROCESS_UPDATE_URI = BRANCH_PROCESS + SLASH + "update";

        static final String BRANCH_PROCESS_RATES = BRANCH_PROCESS + SLASH + "getRates";

        static final String BRANCH_PROCESS_COMPARE_RATES = BRANCH_PROCESS + SLASH + "compareRates";

        static final String BRANCH_PROCESS_DOWNLOAD_URI = BRANCH_PROCESS + "download";

        static final String BRANCH_PROCESS_STATUS_UPDATE_URI = BRANCH_PROCESS + SLASH + "{bpId}" + SLASH + "status";

        static final String BRANCH_PROCESS_STATUS_UPDATE_FROM_AMIGO_URI = BRANCH_PROCESS + SLASH + "update-status";

    }

    public interface MasterApi {

        static final String MASTER_API = PRICING_API + SLASH + "proxies/onboarding";

        static final String MASTER_SERVICE_PROVIDERS_URI = SLASH + "serviceProviders";

        static final String MASTER_PRODUCT_URI = SLASH + "products";

        static final String MASTER_COUNTRY_URI = SLASH + "countries";

        static final String MASTER_CURRENCY_URI = SLASH + "currencies";

        static final String MASTER_BANK_URI = SLASH + "banks";

        static final String MASTER_AGENT_URI = SLASH + "agents";

        static final String MASTER_PRODUCT_SUB_TYPE_URI = SLASH + "productSubTypes";

        static final String MASTER_PRODUCT_SERVICE_TYPE_URI = SLASH + "serviceTypes";

        static final String MASTER_DRAWEE_BANK_PRODUCT_PROFILEID_URI = SLASH + "draweeBankProductProfileId";

        static final String MASTER_SERVICE_PROVIDER_DETAILS = SLASH + "serviceProviderDetails";

        static final String MASTER_AGENT_DETAILS = SLASH + "agentDetails";

        static final String MASTER_SOURCES_URI = SLASH + "sources";

        static final String MASTER_DESTINATIONS_URI = SLASH + "destinations";

    }

    public interface MasterData {

        static final String MASTER_API_V2 = PRICING_API + SLASH + "proxies/onboarding/v2";

        static final String MASTER_DATA_ALL_SERVICE_PROVIDER_PAIRS = SLASH + "allServiceProviderPairs";

        static final String MASTER_DATA_ALL_CURRENCY_PAIRS = SLASH + "allCurrencyPairs";

        static final String MASTER_DATA_ALL_COUNTRY_PAIRS = SLASH + "allCountryPairs";

        static final String MASTER_DATA_ALL_PRODUCTS = SLASH + "allProducts";

        static final String MASTER_DATA_ALL_SUB_PRODUCTS = SLASH + "allSubProducts";

        static final String MASTER_DATA_ALL_SERVICE_TYPES = SLASH + "allServiceTypes";

        static final String MASTER_DATA_PARTNER_PRODUCTS = SLASH + "products";

        static final String MASTER_DATA_PARTNER_SUB_PRODUCTS = SLASH + "subProducts";

        static final String MASTER_DATA_PARTNER_SERVICE_TYPES = SLASH + "serviceTypes";

        static final String MASTER_DATA_BANK_WISE_PRODUCTS = SLASH + "bankWiseProducts";

        static final String MASTER_DATA_NORMAL_AGENT_DISPLAY_CODE_PAIRS = SLASH + "normalAgentDisplayCodePairs";

        static final String MASTER_DATA_BANK_WISE_AGENT_DISPLAY_CODE_PAIRS = SLASH + "bankWiseAgentDisplayCodePairs";

        static final String MASTER_DATA_BANK_DISPLAY_CODE_PAIRS = SLASH + "bankDisplayCodePairs";

        static final String MASTER_DATA_NORMAL_FOREIGN_CURRENCY_PAIRS = SLASH + "normalForeignCurrencyPairs";

        static final String MASTER_DATA_BANK_WISE_FOREIGN_CURRENCY_PAIRS = SLASH + "bankWiseForeignCurrencyPairs";

        static final String MASTER_DATA_NORMAL_FOREIGN_BASE_CURRENCY_PAIRS = SLASH + "foreignBaseCurrencyPairs";

        static final String MASTER_DATA_BASE_CURRENCY_PAIRS = SLASH + "baseCurrencyPairs";

        static final String MASTER_DATA_NORMAL_AGENTS_WITH_BRANCHES = SLASH + "normalAgentsWithBranches";

        static final String MASTER_DATA_BANK_WISE_AGENTS_WITH_BRANCHES = SLASH + "bankWiseAgentsWithBranches";

        static final String MASTER_DATA_SOURCES = SLASH + "sources";

        static final String MASTER_DATA_SOURCE_TRIPLETS = SLASH + "sourceTriplets";

        static final String MASTER_DATA_DESTINATIONS = SLASH + "destinations";

        static final String MASTER_DATA_DESTINATION_TRIPLETS = SLASH + "destinationTriplets";

        static final String MASTER_DATA_NORMAL_BANKWISE_AGENT_CODE = SLASH + "allAgentCodePairs";

    }

    public interface AmigoIntegration {

        static final String AMIGO_INT_URI = PRICING_API + SLASH + "amigo";

        static final String AMIGO_INT_IBR_URI = SLASH + "ibrs";

        static final String AMIGO_INT_IBR_RM_TYPE_URI = AMIGO_INT_IBR_URI + SLASH + "{rmType}";

        static final String AMIGO_INT_VAR_URI = SLASH + "vars";

        static final String AMIGO_INT_VAR_RM_TYPE_URI = AMIGO_INT_VAR_URI + SLASH + "{rmType}";

        static final String AMIGO_INT_SETTLEMENT_URI = SLASH + "settlementRates";

        static final String AMIGO_INT_SETTLEMENT_RM_TYPE_URI = AMIGO_INT_SETTLEMENT_URI + SLASH + "{rmType}";

        static final String AMIGO_INT_STANDARD_CHARGE_URI = SLASH + "standardCharges";
    }

    public interface AuthorizationSetting {

        static final String AUTH_SETTING_URI = SLASH + "authorizationSettings";

        static final String AUTH_SETTING_DOWNLOAD_URI = AUTH_SETTING_URI + SLASH + "download";

        static final String AUTH_QUEUE_URI = SLASH + "authorizationQueue";

        static final String AUTH_QUEUE_DOWNLOAD_URI = AUTH_QUEUE_URI + SLASH + "download";

    }

    public interface Enquiry {
        // ------------------------ URIs ------------------------------------

        static final String ENQUIRY_URI = SLASH + "prices";

        static final String IBR_NORMAL_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH + "normalIbrRates";

        static final String IBR_BANKWISE_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH + "bankWiseIbrRates";

        static final String SETTLEMENT_NORMAL_RATES_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH + "normalSettlementRates";

        static final String SETTLEMENT_BANKWISE_RATES_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH
                + "bankWiseSettlementRates";

        static final String SETTLEMENT_NORMAL_COST_RATES_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH
                + "normalSettlementCostRates";

        static final String SETTLEMENT_BANKWISE_COST_RATES_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH
                + "bankWiseSettlementCostRates";

        static final String COUNTRY_NORMAL_AGENT_COST_RATES_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH + "normalAgentCostRates";

        static final String COUNTRY_BANKWISE_AGENT_COST_RATES_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH + "bankWiseAgentCostRates";

        static final String COUNTRY_NORMAL_AGENT_BRANCH_COST_RATES_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH
                + "normalAgentBranchCostRates";

        static final String COUNTRY_BANKWISE_AGENT_BRANCH_COST_RATES_ENQUIRY_URI = SLASH + ENQUIRY_URI + SLASH
                + "bankWiseAgentBranchCostRates";

        // ------------------------ RELs ------------------------------------
    }
}
