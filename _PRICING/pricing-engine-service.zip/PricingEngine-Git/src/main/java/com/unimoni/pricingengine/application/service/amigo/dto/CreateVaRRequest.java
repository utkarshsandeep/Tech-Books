package com.unimoni.pricingengine.application.service.amigo.dto;

import java.math.BigDecimal;

import javax.validation.constraints.PositiveOrZero;

import com.unimoni.pricingengine.domain.model.rate.composable.Margin;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "amigoCreateVaRRequest", description = "The request to create new VaR by Amigo")
public class CreateVaRRequest extends VDWRateAmigoRequest {

    @ApiModelProperty(name = "cashAskMargin", dataType = "BigDecimal", value = "CASH Ask Margin in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 9)
    @PositiveOrZero
    private BigDecimal cashAskMargin;

    @ApiModelProperty(name = "cashBidMargin", dataType = "BigDecimal", value = "CASH Bid Margin in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 10)
    @PositiveOrZero
    private BigDecimal cashBidMargin;
    
    public Margin cashMagin() {
        return Margin.of(this.cashAskMargin, this.cashBidMargin);
    }
}
