package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.domain.model.common.dto.Frequency;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "normalRateRequest", description = "Request to create normal base rate")
public class NormalRateRequest {

    @Positive
    @ApiModelProperty(allowEmptyValue = false, required = true, value = "Rate provider ID: 1 for Manual, 2 for Thomson Reuters, 3 for Future Source", example = "1")
    private int rateProvider;

    @NotEmpty
    @ApiModelProperty(allowEmptyValue = true, required = true, value = "Service Providers such as UAE, UK etc.")
    private List<@NotEmpty String> serviceProviders;

    @NotEmpty
    @ApiModelProperty(allowEmptyValue = true, required = true, value = "Products such as Remittance, Forex etc.")
    private List<@NotEmpty String> products;

    @NotNull
    @Valid
    private ExchangeDTO exchange;

    @ApiModelProperty(allowEmptyValue = false, value = "Ric ID to get rates from Rate providers such as Thomson Reuters or Future Sorce", example = "INR=")
    private String ricId;

    private Frequency frequency;

    @ApiModelProperty(hidden = true)
    @Getter(value = AccessLevel.NONE)
    @Setter(value = AccessLevel.NONE)
    private List<RateIdentity> identities;

    @ApiModelProperty(hidden = true)
    @Getter(value = AccessLevel.NONE)
    @Setter(value = AccessLevel.NONE)
    private int identityCount;

    @SuppressWarnings("unchecked")
    public List<RateIdentity> identities() {
        if (this.identities == null) {
            ImmutableList<String> sps = ImmutableList.copyOf(this.serviceProviders);
            ImmutableList<String> prds = ImmutableList.copyOf(this.products);
            List<List<String>> combinations = Lists.cartesianProduct(sps, prds);
            List<RateIdentity> identities = new ArrayList<>(combinations.size());
            for (List<String> combination : combinations) {
                identities.add(RateIdentity.of(this.exchange.getCurrency().getSource(),
                        this.exchange.getCurrency().getTarget(), combination.get(0), combination.get(1)));
            }
            this.identityCount = identities.size();
            return this.identities = identities;
        } else {
            return this.identities;
        }
    }

    public int identityCount() {
        return this.identityCount;
    }

    public static NormalRateRequest of(final int rateProvider, final List<String> serviceProviders,
            final List<String> products, final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency,
            final BigDecimal askValue, final BigDecimal bidValue, final String ricId, final Frequency frequency) {
        NormalRateRequest normalRateRequest = new NormalRateRequest();
        normalRateRequest.rateProvider = rateProvider;
        normalRateRequest.serviceProviders = serviceProviders;
        normalRateRequest.products = products;
        normalRateRequest.exchange = ExchangeDTO.of(sourceCurrency, targetCurrency, askValue, bidValue);
        normalRateRequest.ricId = ricId;
        normalRateRequest.frequency = frequency;
        return normalRateRequest;
    }

    public static NormalRateRequest ofManualRateProvider(final int rateProvider, final List<String> serviceProviders,
            final List<String> products, final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency,
            final BigDecimal askValue, final BigDecimal bidValue) {
        NormalRateRequest normalRateRequest = new NormalRateRequest();
        normalRateRequest.rateProvider = rateProvider;
        normalRateRequest.serviceProviders = serviceProviders;
        normalRateRequest.products = products;
        normalRateRequest.exchange = ExchangeDTO.of(sourceCurrency, targetCurrency, askValue, bidValue);
        return normalRateRequest;
    }

}
