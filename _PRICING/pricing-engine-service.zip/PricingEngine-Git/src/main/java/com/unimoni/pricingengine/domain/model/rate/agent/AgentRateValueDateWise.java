package com.unimoni.pricingengine.domain.model.rate.agent;

import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import java.math.BigDecimal;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentValueDateWiseDTO;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode
@ToString(includeFieldNames = true)
@Embeddable
@Access(AccessType.FIELD)
public class AgentRateValueDateWise {

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "CUSTOMER_RATE_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "CUSTOMER_RATE_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost customerRate;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "MARGIN_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "MARGIN_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost margin;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "MARGIN_LOW_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "MARGIN_LOW_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost marginLow;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "MARGIN_HIGH_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "MARGIN_HIGH_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost marginHigh;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "COST_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "COST_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost cost;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "CUSTOMER_LOWEST_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "CUSTOMER_LOWEST_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost customerLowest;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "MAX_DISCOUNT_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "MAX_DISCOUNT_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost maxDiscount;

    public static AgentRateValueDateWise zero() {
        return AgentRateValueDateWise.of(Cost.ZERO, Cost.ZERO, Cost.ZERO, Cost.ZERO, Cost.ZERO, Cost.ZERO, Cost.ZERO);
    }

    public static AgentRateValueDateWise of(final AgentValueDateWiseDTO agentValueDateWise) {
        Cost customerRate = Cost.of(agentValueDateWise.getCustomerRate().getSellValue(),
                agentValueDateWise.getCustomerRate().getBuyValue());
        validatePositive(customerRate.buyValue(), "Customer Buy");
        validatePositive(customerRate.sellValue(), "Customer Sell");

        Cost margin = Cost.of(agentValueDateWise.getMargin().getSellValue(),
                agentValueDateWise.getMargin().getBuyValue());
        validatePositive(margin.buyValue(), "Margin Buy");
        validatePositive(margin.sellValue(), "Margin Sell");

        Cost marginLow = Cost.of(agentValueDateWise.getMarginLow().getSellValue(),
                agentValueDateWise.getMarginLow().getBuyValue());
        validatePositive(marginLow.buyValue(), "Margin Low Buy");
        validatePositive(marginLow.sellValue(), "Margin Low Sell");

        Cost marginHigh = Cost.of(agentValueDateWise.getMarginHigh().getSellValue(),
                agentValueDateWise.getMarginHigh().getBuyValue());
        validatePositive(marginHigh.buyValue(), "Margin High Buy");
        validatePositive(marginHigh.sellValue(), "Margin High Sell");

        Cost cost = Cost.of(agentValueDateWise.getCost().getSellValue(), agentValueDateWise.getCost().getBuyValue());
        validatePositive(cost.buyValue(), "Cost Buy");
        validatePositive(cost.sellValue(), "Cost Sell");

        Cost customerLowest = Cost.of(agentValueDateWise.getCustomerLowest().getSellValue(),
                agentValueDateWise.getCustomerLowest().getBuyValue());
        validatePositive(customerLowest.buyValue(), "Customer Lowest Buy");
        validatePositive(customerLowest.sellValue(), "Customer Lowest Sell");

        Cost maxDiscount = Cost.of(agentValueDateWise.getMaxDiscount().getSellValue(),
                agentValueDateWise.getMaxDiscount().getBuyValue());
        validatePositive(maxDiscount.buyValue(), "Max Discount Buy");
        validatePositive(maxDiscount.sellValue(), "Max Discount Sell");

        return of(customerRate, margin, marginLow, marginHigh, cost, customerLowest, maxDiscount);
    }

    public boolean updateCustomerRate(final Cost newCost, final Cost newMargin) {
        if (this.margin.equals(newMargin) && this.cost.equals(newCost)) {
            return false;
        }
        else {
            validatePositive(newMargin.buyValue(), "Margin Buy");
            validatePositive(newMargin.sellValue(), "Margin Sell");
            this.margin = newMargin;
            validatePositive(newCost.buyValue(), "Cost Buy");
            validatePositive(newCost.sellValue(), "Cost Sell");
            this.cost = newCost;
            this.customerRate = calculateCustomerCost(newCost, newMargin);
            return true;
        }
    }

    private Cost calculateCustomerCost(Cost newCost, Cost newMargin) {
        BigDecimal sellValue = newCost.sellValue().subtract(newMargin.sellValue());
        BigDecimal buyValue = newCost.buyValue().add(newMargin.buyValue());
        Cost customerRate = Cost.of(sellValue, buyValue);
        validatePositive(customerRate.buyValue(), "Customer Buy");
        validatePositive(customerRate.sellValue(), "Customer Sell");
        return customerRate;
    }

    public boolean updateMargin(final Cost newCost, final Cost customerRate) {
        if (this.customerRate.equals(customerRate) && this.cost.equals(newCost)) {
            return false;
        }
        else {
            validatePositive(customerRate.buyValue(), "Customer Buy");
            validatePositive(customerRate.sellValue(), "Customer Sell");
            this.customerRate = customerRate;
            validatePositive(newCost.buyValue(), "Cost Buy");
            validatePositive(newCost.sellValue(), "Cost Sell");
            this.cost = newCost;
            this.margin = calculateMarginCost(newCost, customerRate);
            return true;
        }
    }

    private Cost calculateMarginCost(Cost newCost, Cost customerRate) {
        BigDecimal sellValue = newCost.sellValue().subtract(customerRate.sellValue());
        BigDecimal buyValue = newCost.buyValue().subtract(customerRate.buyValue());
        Cost margin = Cost.of(sellValue, buyValue);
        validatePositive(margin.buyValue(), "Margin Buy");
        validatePositive(margin.sellValue(), "Margin Sell");
        return margin;
    }

    public boolean updateMaximumDiscountCost(final Cost newMarginLow, final Cost customerRate) {
        if (this.customerRate.equals(customerRate) && this.marginLow.equals(newMarginLow)) {
            return false;
        }
        else {
            validatePositive(customerRate.buyValue(), "Customer Buy");
            validatePositive(customerRate.sellValue(), "Customer Sell");
            this.customerRate = customerRate;
            validatePositive(newMarginLow.buyValue(), "Margin Low Buy");
            validatePositive(newMarginLow.sellValue(), "Margin Low Sell");
            this.marginLow = newMarginLow;
            this.maxDiscount = calculateMaximumDiscountCost(newMarginLow, customerRate);
            return true;
        }

    }

    private Cost calculateMaximumDiscountCost(Cost newMarginLow, Cost customerRate) {
        BigDecimal sellValue = newMarginLow.sellValue().add(customerRate.sellValue());
        BigDecimal buyValue = newMarginLow.buyValue().subtract(customerRate.buyValue());
        Cost maximumDiscount = Cost.of(sellValue, buyValue);
        validatePositive(maximumDiscount.buyValue(), "Max Discount Buy");
        validatePositive(maximumDiscount.sellValue(), "Max Discount Sell");
        return maximumDiscount;
    }

    public boolean updateCostMargin(Cost margin) {
        validatePositive(margin.buyValue(), "Margin Buy");
        validatePositive(margin.sellValue(), "Margin Sell");
        if (this.margin.equals(margin)) {
            return false;
        }
        else {
            this.margin = margin;
            return true;
        }
    }

    public boolean updateCostMaginLow(Cost marginLow) {
        validatePositive(marginLow.buyValue(), "Margin Low Buy");
        validatePositive(marginLow.sellValue(), "Margin Low Sell");
        if (this.marginLow.equals(marginLow)) {
            return false;
        }
        else {
            this.marginLow = marginLow;
            return true;
        }
    }

    public boolean updateCostMaginHigh(Cost marginHigh) {
        validatePositive(marginHigh.buyValue(), "Margin High Buy");
        validatePositive(marginHigh.sellValue(), "Margin High Sell");
        if (this.marginHigh.equals(marginHigh)) {
            return false;
        }
        else {
            this.marginHigh = marginHigh;
            return true;
        }
    }

    public boolean updateCostCustomerLowest(Cost customerLowest) {
        validatePositive(customerLowest.buyValue(), "Customer Lowest Buy");
        validatePositive(customerLowest.sellValue(), "Customer Lowest Sell");
        if (this.customerLowest.equals(customerLowest)) {
            return false;
        }
        else {
            this.customerLowest = customerLowest;
            return true;
        }
    }

    public boolean updateCostCustomerRate(Cost customerRate) {
        validatePositive(customerRate.buyValue(), "Customer Buy");
        validatePositive(customerRate.sellValue(), "Customer Sell");
        if (this.customerRate.equals(customerRate)) {
            return false;
        }
        else {
            this.customerRate = customerRate;
            return true;
        }
    }

    public boolean updateCostMaxDiscount(Cost maxDiscount) {
        validatePositive(maxDiscount.buyValue(), "Max Discount Buy");
        validatePositive(maxDiscount.sellValue(), "Max Discount Sell");
        if (this.maxDiscount.equals(maxDiscount)) {
            return false;
        }
        else {
            this.maxDiscount = maxDiscount;
            return true;
        }
    }

    public boolean updateFromCountryLayer(final Cost countryAgentCost, final RateDisplayMachenism RDM) {
        if (this.cost.equals(countryAgentCost)) {
            return false;
        }
        else {
            this.cost = countryAgentCost;

            if (RDM.isBCtoFC()) {
                // Customer Rate Sell = Cost Sell Rate – Sell Margin
                // Customer Rate Buy = Cost Buy Rate + Buy Margin
                Cost newCustomerRate = Cost.of(this.cost.sellValue().subtract(this.margin.sellValue()),
                        this.cost.buyValue().add(this.margin.buyValue()));
                validatePositive(newCustomerRate.buyValue(), "Customer Buy");
                validatePositive(newCustomerRate.sellValue(), "Customer Sell");
                this.customerRate = newCustomerRate;

                // Customer Maximum Discounted Sell Rate = Customer Sell Rate + Sell Margin Low
                // Customer Maximum Discounted Buy Rate = Customer Buy Rate - Buy Margin Low
                Cost newMaxDiscount = Cost.of(this.customerRate.sellValue().add(this.marginLow.sellValue()),
                        this.customerRate.buyValue().subtract(this.marginLow.buyValue()));
                validatePositive(newMaxDiscount.buyValue(), "Max Discount Buy");
                validatePositive(newMaxDiscount.sellValue(), "Max Discount Sell");
                this.maxDiscount = newMaxDiscount;

                // Customer Lowest Sell Rate = Customer Sell Rate – Sell Margin High
                // Customer Lowest Buy Rate = Customer Buy Rate + Buy Margin High
                Cost newCustomerLowest = Cost.of(this.customerRate.sellValue().subtract(this.marginHigh.sellValue()),
                        this.customerRate.buyValue().add(this.marginHigh.buyValue()));
                validatePositive(newCustomerLowest.buyValue(), "Customer Lowest Buy");
                validatePositive(newCustomerLowest.sellValue(), "Customer Lowest Sell");
                this.customerLowest = newCustomerLowest;
            }
            else {
                // Customer Rate Sell = Cost Sell Rate + Sell Margin
                // Customer Rate Buy = Cost Buy Rate - Buy Margin
                Cost newCustomerRate = Cost.of(this.cost.sellValue().add(this.margin.sellValue()),
                        this.cost.buyValue().subtract(this.margin.buyValue()));
                validatePositive(newCustomerRate.buyValue(), "Customer Buy");
                validatePositive(newCustomerRate.sellValue(), "Customer Sell");
                this.customerRate = newCustomerRate;

                // Customer Maximum Discounted Sell Rate = Customer Sell Rate – Sell Margin Low
                // Customer Maximum Discounted Buy Rate = Customer Buy Rate + Buy Margin Low
                Cost newMaxDiscount = Cost.of(this.customerRate.sellValue().subtract(this.marginLow.sellValue()),
                        this.customerRate.buyValue().add(this.marginLow.buyValue()));
                validatePositive(newMaxDiscount.buyValue(), "Max Discount Buy");
                validatePositive(newMaxDiscount.sellValue(), "Max Discount Sell");
                this.maxDiscount = newMaxDiscount;

                // Customer Lowest Sell Rate = Customer Sell Rate + Sell Margin High
                // Customer Lowest Buy Rate = Customer Buy Rate – Buy Margin High
                Cost newCustomerLowest = Cost.of(this.customerRate.sellValue().add(this.marginHigh.sellValue()),
                        this.customerRate.buyValue().subtract(this.marginHigh.buyValue()));
                validatePositive(newCustomerLowest.buyValue(), "Customer Lowest Buy");
                validatePositive(newCustomerLowest.sellValue(), "Customer Lowest Sell");
                this.customerLowest = newCustomerLowest;
            }
            return true;
        }
    }
}
