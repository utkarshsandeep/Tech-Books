package com.unimoni.pricingengine.domain.model.builder;

import java.util.List;

public interface MultiBuilder<T> {
    public List<T> buildAll();
}
