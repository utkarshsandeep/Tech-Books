package com.unimoni.pricingengine.application.events;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentDeleteOnboardEvent {

	private Integer agentId;
	private String agentDisplayCode;
	

	public AgentDeleteOnboardEvent(@JsonProperty Integer agentId, 
			@JsonProperty String agentDisplayCode) {
		this.agentId = agentId;
        this.agentDisplayCode= agentDisplayCode;
	}

}
