package com.unimoni.pricingengine.domain.model.rate;

import static com.unimoni.pricingengine.adapter.persistence.PersistenceConstant.Hibernate.GLOBAL_SEQ_ID_GENERATOR;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "AGENT_PRODUCT_ONBOARD")
@EqualsAndHashCode
public class AgentProductOnboard {
	
    @Id
    @GeneratedValue(generator = GLOBAL_SEQ_ID_GENERATOR)
    @Column(name = "ID", updatable = false, nullable = false)
    @Access(AccessType.FIELD)
    private long eventId;

    @Version
    @Access(AccessType.FIELD)
    @Column(name = "version", nullable = false)
    private long version;

    @Column(name = "AGENT_DRAWEE_BANK_FOR_RATES", updatable = false, nullable = false, length = 36)
    private Integer id;
	
	@Column(name = "AGENT_NAME", updatable = false, nullable = false, length = 36)
    private String agentName;
	
	@Column(name = "AGENT_BRANCH_NAME", updatable = false, nullable = false, length = 36)
    private String agentBranchName;
	
	@Column(name = "AGENT_ID", updatable = false, nullable = false, length = 36)
    private Integer agentId;
	
	@Column(name = "AGENT_BRANCH_ID", updatable = false, nullable = false, length = 36)
    private Integer agentBranchId;
	
	@Column(name = "STATUS", updatable = false, nullable = false, length = 36)
    private String status;
	
	@Column(name = "CREATED_DATE", updatable = false, nullable = false, length = 36)
	private String createdDate;
	
	@Column(name = "MODIFIED_DATE", updatable = false, nullable = false, length = 36)
	private String modifiedDate;
	
	@Column(name = "BANK_PRODUCT_PROFILE_ID", updatable = false, nullable = false, length = 36)
	private Integer draweeBankProductProfileId;
	
	@Column(name = "BANK_PRODUCT_PROFILE_NAME", updatable = false, nullable = false, length = 36)
	private String draweeBankProducProfileName;
	
	@Column(name = "DELETED", updatable = false, nullable = false, length = 36)
	private Boolean deleted;

}
