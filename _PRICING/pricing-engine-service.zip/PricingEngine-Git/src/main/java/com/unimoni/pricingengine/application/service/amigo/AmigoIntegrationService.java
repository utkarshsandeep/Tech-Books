package com.unimoni.pricingengine.application.service.amigo;

import com.unimoni.pricingengine.application.service.amigo.dto.CreateSettlementRateRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.CreateVaRRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateIBRRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateSettlementRateRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.AmigoStandardChargeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.AmigoStandardChargeResponse;

public interface AmigoIntegrationService {

    public void updateIBR(final RMType rmType, final UpdateIBRRequest updateRequest);
    
    public VaR createVaR(final RMType rmType, final CreateVaRRequest createRequest);

    public VaR updateVaR(final RMType rmType, final UpdateVaRRequest updateRequest);

    public SettlementRate createSettlementRate(final RMType rmType, final CreateSettlementRateRequest createRequest);

    public SettlementRate updateSettlementRate(final RMType rmType, final UpdateSettlementRateRequest updateRequest);

    public AmigoStandardChargeResponse createOrUpdateStandardCharge(final AmigoStandardChargeRequest createOrUpdateStandardCharge);

}
