package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.ToString;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString(includeFieldNames = true)
public class RateSkipSettingPayload {

    private boolean skipCustomerRate;

    private boolean skipCustomerFee;

    private boolean status;

    private boolean skipSwiftCharge;

    @JsonCreator
    public RateSkipSettingPayload(final @JsonProperty("customerRates") boolean skipCustomerRate,
            final @JsonProperty("customerFees") boolean skipCustomerFee, final @JsonProperty("status") String status,
            final @JsonProperty("swift") boolean skipSwiftCharge) {
        this.skipCustomerRate = skipCustomerRate;
        this.skipCustomerFee = skipCustomerFee;
        this.status = status != null && status.equalsIgnoreCase("ENABLED");
        this.skipSwiftCharge = skipSwiftCharge;
    }
}
