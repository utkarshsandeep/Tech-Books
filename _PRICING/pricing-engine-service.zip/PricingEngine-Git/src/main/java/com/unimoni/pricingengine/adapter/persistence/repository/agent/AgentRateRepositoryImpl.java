package com.unimoni.pricingengine.adapter.persistence.repository.agent;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.money.CurrencyUnit;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.stereotype.Repository;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.common.exception.RemittanceTransactionException;
import com.unimoni.pricingengine.common.exception.RemittanceTransactionException.RemittanceTransactionExceptionType;
import com.unimoni.pricingengine.domain.model.bp.dto.BPOfferRateRequest;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate_;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.SearchAgentRatesRequest;
import com.unimoni.pricingengine.domain.model.remittance.TransactionCurrencies.TxnCurrencyType;
import com.unimoni.pricingengine.domain.model.remittance.dto.TxnLayerChargeRequest;

@Repository
public class AgentRateRepositoryImpl extends AbstractJPA implements AgentRateRepositoryJPA {

    @Override
    public Optional<AgentRate> findActiveAgentRatesByIdentity(RMType rmType, AgentRateIdentity agentIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<AgentRate> query = criteriaQuery(AgentRate.class);
        Root<AgentRate> agent = query.from(AgentRate.class);
        query.where(
                AgentRatePredicates.getAgentRateByIdentityPredicates(agent, criteriaBuilder, rmType, agentIdentity));
        query.select(agent);
        return getSingleResultSafely(query);
    }

    @Override
    public List<AgentRate> findAllAgentRates(final SearchAgentRatesRequest searchRequest) {
        long totalRecords = findAgentRatesCount(searchRequest);
        searchRequest.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            CriteriaQuery<AgentRate> query = criteriaQuery(AgentRate.class);
            Root<AgentRate> rate = query.from(AgentRate.class);

            query.where(AgentRatePredicates.getSearchAgentRatesPredicates(rate, criteriaBuilder, searchRequest));

            query.select(rate);
            query.distinct(true);
            query.orderBy(criteriaBuilder.asc(rate.get(AgentRate_.currency.getName()).get("base")));

            TypedQuery<AgentRate> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(searchRequest.page().queryFirstResult());
            typedQuery.setMaxResults(searchRequest.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findAgentRatesCount(final SearchAgentRatesRequest searchRequest) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<AgentRate> rate = query.from(AgentRate.class);

        query.where(AgentRatePredicates.getSearchAgentRatesPredicates(rate, criteriaBuilder, searchRequest));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<AgentRate> findAgentRatesByIds(RMType rmType, List<String> ids, boolean eagerFetchCountry) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<AgentRate> query = criteriaQuery(AgentRate.class);
        Root<AgentRate> agentrate = query.from(AgentRate.class);
        query.where(criteriaBuilder.and(criteriaBuilder.equal(agentrate.get(AgentRate_.rmType.getName()), rmType),
                agentrate.get(AgentRate_.id.getName()).in(ids)));
        query.select(agentrate);
        TypedQuery<AgentRate> typedQuery = typedQuery(query);
        // if (eagerFetchCountry) {
        // typedQuery.setHint("javax.persistence.fetchgraph",
        // entityManager.getEntityGraph("bankWiseBaseRate"));
        // }
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public Optional<AgentRate> findHighestPriorityAgentRateByRemmitanceTransaction(
            final TxnLayerChargeRequest layerChargeRequest, final CurrencyUnit payInCurrency,
            final TxnCurrencyType txnCurrencyType, final CurrencyUnit currency) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<AgentRate> mainQuery = criteriaQuery(AgentRate.class);
        Root<AgentRate> rate = mainQuery.from(AgentRate.class);
        mainQuery.select(rate);

        Predicate basicPredicateMainQuery = AgentRatePredicates.getBasicPredicateForRemmitanceTransaction(rate,
                criteriaBuilder, layerChargeRequest.instruments(), layerChargeRequest.agentBranchCode(),
                layerChargeRequest.agentCode());

        Predicate bankWisePredicateMainQuery = criteriaBuilder.and(
                criteriaBuilder.equal(rate.get(AgentRate_.rmType.getName()), RMType.BANK_WISE),
                criteriaBuilder.or(
                        criteriaBuilder.equal(rate.get(AgentRate_.bank.getName()), layerChargeRequest.bank()),
                        criteriaBuilder.equal(rate.get(AgentRate_.bank.getName()), ALL_INSTRUMENTS)));

        Predicate normalPredicateMainQuery = criteriaBuilder.equal(rate.get(AgentRate_.rmType.getName()),
                RMType.NORMAL);

        Predicate currencyPredicateMainQuery = AgentRatePredicates.getCurrencyPredicateForRemmitanceTransaction(rate,
                criteriaBuilder, payInCurrency, txnCurrencyType, currency);

        Subquery<Integer> maxPriorityQuery = mainQuery.subquery(Integer.class);
        Root<AgentRate> maxPriority = maxPriorityQuery.from(AgentRate.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(AgentRate_.priority.getName())));

        Predicate basicPredicateMaxPriorityQuery = AgentRatePredicates.getBasicPredicateForRemmitanceTransaction(
                maxPriority, criteriaBuilder, layerChargeRequest.instruments(), layerChargeRequest.agentBranchCode(),
                layerChargeRequest.agentCode());

        Predicate bankWisePredicateMaxPriorityQuery = criteriaBuilder.and(
                criteriaBuilder.equal(maxPriority.get(AgentRate_.rmType.getName()), RMType.BANK_WISE),
                criteriaBuilder.or(
                        criteriaBuilder.equal(maxPriority.get(AgentRate_.bank.getName()), layerChargeRequest.bank()),
                        criteriaBuilder.equal(maxPriority.get(AgentRate_.bank.getName()), ALL_INSTRUMENTS)));

        Predicate normalPredicateMaxPriorityQuery = criteriaBuilder.equal(maxPriority.get(AgentRate_.rmType.getName()),
                RMType.NORMAL);

        Predicate currencyPredicateMaxPriorityQuery = AgentRatePredicates.getCurrencyPredicateForRemmitanceTransaction(
                maxPriority, criteriaBuilder, payInCurrency, txnCurrencyType, currency);

        Optional<AgentRate> bankWiseAgentRate = null;

        maxPriorityQuery.where(basicPredicateMaxPriorityQuery, bankWisePredicateMaxPriorityQuery,
                currencyPredicateMaxPriorityQuery);
        mainQuery.where(basicPredicateMainQuery, bankWisePredicateMainQuery, currencyPredicateMainQuery,
                criteriaBuilder.equal(rate.get(AgentRate_.priority.getName()), maxPriorityQuery));

        TypedQuery<AgentRate> typedQuery = typedQuery(mainQuery);
        typedQuery.setHint("javax.persistence.fetchgraph", entityManager().getEntityGraph("agentRate"));
        bankWiseAgentRate = getSingleResultSafely(typedQuery);

        if (!bankWiseAgentRate.isPresent()) {
            maxPriorityQuery.where(basicPredicateMaxPriorityQuery, normalPredicateMaxPriorityQuery,
                    currencyPredicateMaxPriorityQuery);
            mainQuery.where(basicPredicateMainQuery, normalPredicateMainQuery, currencyPredicateMainQuery,
                    criteriaBuilder.equal(rate.get(AgentRate_.priority.getName()), maxPriorityQuery));

            typedQuery = typedQuery(mainQuery);
            typedQuery.setHint("javax.persistence.fetchgraph", entityManager().getEntityGraph("agentRate"));

            List<AgentRate> normalAgentRates = getUnmodifiableResultList(typedQuery);

            if (normalAgentRates.isEmpty()) {
                return Optional.empty();
            }
            else if (normalAgentRates.size() == 1) {
                return Optional.of(normalAgentRates.get(0));
            }
            else if (normalAgentRates.size() == 2) {
                for (AgentRate ar : normalAgentRates) {
                    if (ar.agent().isBranch()) {
                        return Optional.of(ar);
                    }
                }
            }
            else {
                throw new RemittanceTransactionException(
                        RemittanceTransactionExceptionType.DUPLICATE_RATES_FOUND_FOR_CURRENCY,
                        Status.PRECONDITION_FAILED, txnCurrencyType.description(), currency,
                        layerChargeRequest.transactionUUID());
            }
        }
        
        return bankWiseAgentRate;
    }

    @Override
    public Optional<AgentRate> findAgentRateByBPOfferRequest(final BPOfferRateRequest bpOfferRateRequest) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<AgentRate> mainQuery = criteriaQuery(AgentRate.class);
        Root<AgentRate> rate = mainQuery.from(AgentRate.class);
        mainQuery.select(rate);

        Predicate basicPredicateMainQuery = AgentRatePredicates.getBasicPredicateForRemmitanceTransaction(rate,
                criteriaBuilder, bpOfferRateRequest.instruments(), null, bpOfferRateRequest.agent().getCode());

        Predicate bankWisePredicateMainQuery = criteriaBuilder.and(
                criteriaBuilder.equal(rate.get(AgentRate_.rmType.getName()), RMType.BANK_WISE),
                criteriaBuilder.equal(rate.get(AgentRate_.bank.getName()), bpOfferRateRequest.bank()));

        Predicate normalPredicateMainQuery = criteriaBuilder.equal(rate.get(AgentRate_.rmType.getName()),
                RMType.NORMAL);

        Predicate currencyPredicateMainQuery = criteriaBuilder.and(
                criteriaBuilder.equal(rate.get(AgentRate_.currency.getName()).get("base"),
                        bpOfferRateRequest.payInCurrency()),
                criteriaBuilder.equal(rate.get(AgentRate_.currency.getName()).get("foreign"),
                        bpOfferRateRequest.payOutCurrency()));

        Subquery<Integer> maxPriorityQuery = mainQuery.subquery(Integer.class);
        Root<AgentRate> maxPriority = maxPriorityQuery.from(AgentRate.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(AgentRate_.priority.getName())));

        Predicate basicPredicateMaxPriorityQuery = AgentRatePredicates.getBasicPredicateForRemmitanceTransaction(
                maxPriority, criteriaBuilder, bpOfferRateRequest.instruments(), null,
                bpOfferRateRequest.agent().getCode());
        Predicate bankWisePredicateMaxPriorityQuery = criteriaBuilder.and(
                criteriaBuilder.equal(maxPriority.get(AgentRate_.rmType.getName()), RMType.BANK_WISE),
                criteriaBuilder.equal(maxPriority.get(AgentRate_.bank.getName()), bpOfferRateRequest.bank()));
        Predicate normalPredicateMaxPriorityQuery = criteriaBuilder.equal(maxPriority.get(AgentRate_.rmType.getName()),
                RMType.NORMAL);
        Predicate currencyPredicateMaxPriorityQuery = criteriaBuilder.and(
                criteriaBuilder.equal(maxPriority.get(AgentRate_.currency.getName()).get("base"),
                        bpOfferRateRequest.payInCurrency()),
                criteriaBuilder.equal(maxPriority.get(AgentRate_.currency.getName()).get("foreign"),
                        bpOfferRateRequest.payOutCurrency()));

        Optional<AgentRate> agentRate = null;

        maxPriorityQuery.where(basicPredicateMaxPriorityQuery, bankWisePredicateMaxPriorityQuery,
                currencyPredicateMaxPriorityQuery);
        mainQuery.where(basicPredicateMainQuery, bankWisePredicateMainQuery, currencyPredicateMainQuery,
                criteriaBuilder.equal(rate.get(AgentRate_.priority.getName()), maxPriorityQuery));

        TypedQuery<AgentRate> typedQuery = typedQuery(mainQuery);
        typedQuery.setHint("javax.persistence.fetchgraph", entityManager().getEntityGraph("agentRate"));
        agentRate = getSingleResultSafely(typedQuery);

        if (agentRate.isPresent()) {
            return agentRate;
        }
        else {
            maxPriorityQuery.where(basicPredicateMaxPriorityQuery, normalPredicateMaxPriorityQuery,
                    currencyPredicateMaxPriorityQuery);
            mainQuery.where(basicPredicateMainQuery, normalPredicateMainQuery, currencyPredicateMainQuery,
                    criteriaBuilder.equal(rate.get(AgentRate_.priority.getName()), maxPriorityQuery));

            typedQuery = typedQuery(mainQuery);
            typedQuery.setHint("javax.persistence.fetchgraph", entityManager().getEntityGraph("agentRate"));
            agentRate = getSingleResultSafely(typedQuery);

            return agentRate;
        }
    }
}
