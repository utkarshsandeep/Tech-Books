package com.unimoni.pricingengine.common.util.collection;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public interface Tree<E> extends Iterable<E> {

    /**
     * Returns the position of the root of the tree (or null if empty).
     * 
     * @return
     */
    Position<E> root();

    Position<E> add(final Position<E> parent, final E child);

    List<Position<E>> add(final Position<E> parent, final List<E> children);

    void replace(final Position<E> position, final E element);
    
    public E remove(final Position<E> position);

    /**
     * Returns the position of the parent of position p (or null if p is the root).
     * 
     * @param position
     * @return
     */
    Optional<Position<E>> parent(final Position<E> position) throws IllegalStateException;

    /**
     * Returns an iterable collection containing the children of position p (if
     * any).
     * 
     * @param position
     * @return
     */
    Iterable<Position<E>> children(final Position<E> position) throws IllegalStateException;

    /**
     * Returns the number of children of position p.
     * 
     * @param position
     * @return
     */
    int numChildren(final Position<E> position) throws IllegalStateException;

    /**
     * Returns true if position p has at least one child.
     * 
     * @param position
     * @return
     */
    boolean isInternal(final Position<E> position) throws IllegalStateException;

    /**
     * Returns true if position p does not have any children.
     * 
     * @param position
     * @return
     */
    boolean isLeaf(final Position<E> position) throws IllegalStateException;

    /**
     * Returns true if position p is the root of the tree.
     * 
     * @param position
     * @return
     */
    boolean isRoot(final Position<E> position) throws IllegalStateException;

    int size();

    boolean isEmpty();

    /**
     * Returns an iterator for all elements in the tree (so that the tree itself is
     * Iterable).
     * 
     * @return
     */
    @Override
    Iterator<E> iterator();

    /**
     * Returns an iterable collection of all positions of the tree.
     * 
     * @return
     */
    Iterable<Position<E>> positions();
    
    Stream<Position<E>> stream();

    Iterable<Position<E>> positions(final int level);

    Stream<Position<E>> stream(final int level);

    Optional<Position<E>> position(final E element, final int level);
    
    Iterable<Position<E>> breathFirst();

    /**
     * Prints preorder representation of subtree of a tree rooted at a position
     * having a depth.
     *
     * @param          <E>
     * @param tree
     * @param position
     * @param depth
     */
    public static <E> void printPreOrderIndent(final Tree<E> tree, final Position<E> position, final int depth) {
        System.out.println(spaces(2 * depth) + position.element());

        for (Position<E> child : tree.children(position)) {
            printPreOrderIndent(tree, child, depth + 1); // child depth is d+1
        }
    }

    /**
     * Prints labeled representation of subtree of the tree rooted at a position
     * having a depth.
     * 
     * @param          <E>
     * @param tree
     * @param position
     * @param path
     */
    public static <E> void printPreOrderLabeled(final Tree<E> tree, final Position<E> position,
            final List<Integer> path) {
        int depth = path.size(); // depth equals the length of the path
        System.out.print(spaces(2 * depth));

        for (int j = 0; j < depth; j++) {
            System.out.print(path.get(j) + (j == depth - 1 ? " " : "."));
        }

        System.out.println(position.element());

        path.add(1); // add path entry for first child

        for (Position<E> child : tree.children(position)) {
            printPreOrderLabeled(tree, child, path);
            path.set(depth, 1 + path.get(depth)); // increment last entry of path
        }

        path.remove(depth);
    }

    /**
     * Prints parenthesized representation of subtree of the tree rooted at a
     * position
     * 
     * @param          <E>
     * @param tree
     * @param position
     */
    public static <E> void paranthesize(final Tree<E> tree, final Position<E> position) {
        System.out.println(position.element());

        if (tree.isInternal(position)) {
            boolean firstTime = true;

            for (Position<E> child : tree.children(position)) {
                System.out.println(firstTime ? "(" : ", ");
                firstTime = false;
                paranthesize(tree, child);
            }

            System.out.println(")");
        }
    }

    static String spaces(final int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append(" ");
        }
        return sb.toString();
    }
}
