package com.unimoni.pricingengine.domain.model.rate.var.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.*;

import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.base.dto.CurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.composable.CurrencyExchange;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode
@ToString
public class VaRIdentity {

    private AllInstrumentsDTO instruments;

    private String agent;

    @JsonInclude(NON_NULL)
    private String bank;

    private CurrencyDTO currency;

    public static VaRIdentity ofNormal(final String serviceProvider, final String product, final String subProduct,
            final String serviceType, final String agent, final CurrencyDTO currency) {
        VaRIdentity varIdentity = new VaRIdentity();
        varIdentity.instruments = AllInstrumentsDTO.of(serviceProvider, product, subProduct, serviceType);
        varIdentity.agent = agent;
        varIdentity.currency = currency;
        return varIdentity;
    }

    public static VaRIdentity ofBankWise(final String serviceProvider, final String product, final String subProduct,
            final String serviceType, final String agent, final String bank, final CurrencyDTO currency) {
        VaRIdentity varIdentity = ofNormal(serviceProvider, product, subProduct, serviceType, agent, currency);
        varIdentity.bank = bank;
        return varIdentity;
    }

    public static VaRIdentity of(final RMType rmType, final VaRBasicIdentity basicIdentity,
            final CurrencyExchange currency) {
        return rmType.isNormal()
                ? ofNormal(basicIdentity.getServiceProvider(), basicIdentity.getProduct(), basicIdentity.getSubProduct(),
                        basicIdentity.getServiceType(), basicIdentity.getAgent(), CurrencyDTO.of(currency))
                : ofBankWise(basicIdentity.getServiceProvider(), basicIdentity.getProduct(), basicIdentity.getSubProduct(),
                        basicIdentity.getServiceType(), basicIdentity.getAgent(), basicIdentity.getBank().get(),
                        CurrencyDTO.of(currency));
    }

    public Optional<String> getBank() {
        return Optional.ofNullable(this.bank);
    }
}
