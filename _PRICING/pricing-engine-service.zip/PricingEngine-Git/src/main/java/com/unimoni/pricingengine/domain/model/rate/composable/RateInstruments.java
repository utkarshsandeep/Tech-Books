package com.unimoni.pricingengine.domain.model.rate.composable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

import com.unimoni.pricingengine.domain.model.rate.Instruments;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@MappedSuperclass
@Embeddable
@org.hibernate.annotations.Immutable
public class RateInstruments implements Instruments {

    @NotNull
    @Column(name = "SERVICE_PROVIDER_CODE", updatable = false, nullable = false, length = 100)
    protected String serviceProvider;

    @NotNull
    @Column(name = "PRODUCT_CODE", updatable = false, nullable = false, length = 100)
    protected String product;

    protected RateInstruments(final String serviceProvider, final String product) {
        Assert.isTrue(StringUtils.isNotEmpty(serviceProvider), "serviceProvider must not be null or empty");
        Assert.isTrue(StringUtils.isNotEmpty(product), "product must not be null or empty");
        this.serviceProvider = serviceProvider;
        this.product = product;
    }

    public static RateInstruments of(final String serviceProvider, final String product) {
        return new RateInstruments(serviceProvider, product);
    }
}
