/*package com.unimoni.pricingengine.application.event.listner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.money.CurrencyUnit;
import javax.money.Monetary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.unimoni.pricingengine.adapter.rest.controller.events.AgentOnBoard;
import com.unimoni.pricingengine.adapter.rest.controller.events.BankOnBoard;
import com.unimoni.pricingengine.application.events.BankWiseEvent;
import com.unimoni.pricingengine.common.annotation.spring.OnboardingIntegration;
import com.unimoni.pricingengine.domain.model.rate.BankProductOnboard;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchDataForDraweeBankResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.UpdateRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.SearchVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.UpdateVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRResponse;
import com.unimoni.pricingengine.domain.service.var.VaRService;

import lombok.extern.slf4j.Slf4j;

@Conditional(value = OnboardingIntegration.class)
@Component
@Slf4j
public class BankWiseRecordDisabledListener {

    @Autowired
    private VaRService varService;

    @Autowired
    private BankOnBoard bankOnboard;

    @Autowired
    private AgentOnBoard agentOnBoard;


    @Autowired
    private Gson gson;

    private Integer draweeBankId = null;

    private Integer draweeBankProductId = null;

    private Integer agentDraweeBankForRateId = null;

    private BankProductOnboard response = null;

    private AgentBranchDataForDraweeBankResponse agentBranchRateResponse = null;

    private BankWiseEvent bankWiseEvent;

    RateDisplayMachenism rdm = null;

    @JmsListener(destination = "AGENT_RATE_FOR_DRAWEE_PRODUCT_DISABLED", containerFactory = "topicListenerFactory")
    public void onApplicationEvent(final Message jsonMessage) {

        log.debug("******AGENT_RATE_FOR_DRAWEE_PRODUCT_DISABLED******" + jsonMessage);
        TextMessage textMessage = (TextMessage) jsonMessage;
        String payload;
        try {
            payload = textMessage.getText();
        }
        catch (JMSException e1) {
            e1.printStackTrace();
            return;
        }
        bankWiseEvent = gson.fromJson(payload, BankWiseEvent.class);
        log.info("******EVENT_PAYLOAD*******", bankWiseEvent);
        draweeBankId = (int) (long) bankWiseEvent.getDraweeBankId();
        draweeBankProductId = (int) (long) bankWiseEvent.getDraweeBankProductProfileId();
        agentDraweeBankForRateId = (int) (long) bankWiseEvent.getDraweeBankForRateId();

        log.debug("*******DraweeBankId*********" + draweeBankId);
        log.debug("*******draweeBankProductProfileId********" + draweeBankProductId);
        log.debug("*******agentDraweeBankForRateId*" + agentDraweeBankForRateId);
        response = bankOnboard.bankOnBoard(draweeBankId, draweeBankProductId);
        log.debug("*******DraweeBank Response******" + response);
        agentBranchRateResponse = bankOnboard.agentInformationFromBankProfileIdAndAgentDraweeBank4RateId(
                draweeBankProductId, agentDraweeBankForRateId);
        log.debug("******AgentBranchRateResponse********" + agentBranchRateResponse);
        List<String> banks = new ArrayList<String>(java.util.Arrays.asList(response.getDisplayName()));
        List<String> agents = new ArrayList<String>(java.util.Arrays.asList(
                getAgentDisplayCode(agentBranchRateResponse.getAgentId(), agentBranchRateResponse.getAgentBranchId())));
        List<String> serviceProviders = new ArrayList<String>(
                java.util.Arrays.asList(response.getServiceProviderCode()));
        List<String> products = new ArrayList<String>(java.util.Arrays.asList(response.getProductType()));
        List<String> subProducts = new ArrayList<String>(java.util.Arrays.asList(response.getProductSubType()));
        List<String> serviceTypes = new ArrayList<String>(java.util.Arrays.asList(response.getServiceType()));
        List<CurrencyUnit> currencies = new ArrayList<CurrencyUnit>();
        currencies.add(Monetary.getCurrency(response.getCurrencyCode()));

        try {
            updateStatusForRecords(SearchVaRRequest.ofBankWiseDownload(agents, banks, serviceProviders, products,
                    subProducts, serviceTypes, currencies, true), varService::getAllVaRs);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getAgentDisplayCode(Integer agentId, Integer agentBranchId) {
        AgentOnboardResponse agentCurrencyResponse = agentOnBoard.agentOnBoard(agentId);
        log.debug("******Agent Display Response*****" + agentCurrencyResponse);
        log.debug("******Agent Display code******" + agentCurrencyResponse.getCode());
        return agentCurrencyResponse.getCode();
    }

    private void updateStatusForRecords(final SearchVaRRequest searchRequest,
            final Function<SearchVaRRequest, List<VaRResponse>> searchFunction) throws IOException {
        List<VaRResponse> firstDataSet = searchFunction.apply(searchRequest);
        if (firstDataSet.isEmpty()) {
            return;
        }
        updateStatus(firstDataSet);
        while (searchRequest.moveToNextPage()) {
            updateStatus(firstDataSet);
        }
    }

    private void updateStatus(List<VaRResponse> firstDataSet) {
        UpdateRequest<String, UpdateVaRRequest> updateRequest = new UpdateRequest<>();
        firstDataSet.forEach(response -> {
            Map<String, UpdateVaRRequest> map = new HashMap<>();
            UpdateVaRRequest updateVarRequest = new UpdateVaRRequest();
            updateVarRequest.setStatus(false);
            map.put(response.getVarId(), updateVarRequest);
            updateRequest.setUpdates(map);
        });
        varService.updateVaRs(RMType.BANK_WISE, updateRequest);
    }

}
*/