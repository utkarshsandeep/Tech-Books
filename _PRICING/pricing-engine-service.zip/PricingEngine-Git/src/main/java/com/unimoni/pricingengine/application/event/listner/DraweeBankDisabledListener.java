package com.unimoni.pricingengine.application.event.listner;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.money.CurrencyUnit;
import javax.money.Monetary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.unimoni.pricingengine.adapter.rest.controller.events.BankDisable;
import com.unimoni.pricingengine.adapter.rest.controller.events.BankOnBoard;
import com.unimoni.pricingengine.application.events.DraweeBankDisableEvent;
import com.unimoni.pricingengine.common.annotation.spring.OnboardingIntegration;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;
import com.unimoni.pricingengine.domain.model.rate.BankProductOnboard;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateResponse;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.SearchAgentRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankWiseRateResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.SearchBankWiseBaseRateRequest;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateResponse;
import com.unimoni.pricingengine.domain.model.rate.country.dto.SearchCountryRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SearchSettlementRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementRateResponse;
import com.unimoni.pricingengine.domain.model.rate.var.dto.SearchVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRResponse;
import com.unimoni.pricingengine.domain.service.agent.AgentRateService;
import com.unimoni.pricingengine.domain.service.country.CountryRateService;
import com.unimoni.pricingengine.domain.service.rm.RateManagementService;
import com.unimoni.pricingengine.domain.service.settlement.SettlementRateService;
import com.unimoni.pricingengine.domain.service.var.VaRService;

import lombok.extern.slf4j.Slf4j;

@Conditional(value = OnboardingIntegration.class)
@Component
@Slf4j
public class DraweeBankDisabledListener {

	@Autowired
	BankDisable bankDisableApi;

	@Autowired
	private BankOnBoard bankOnboard;

	@Autowired
	RateManagementService rateManagementService;

	@Autowired
	VaRService varService;

	@Autowired
	SettlementRateService settlementService;

	@Autowired
	CountryRateService countryRateService;

	@Autowired
	AgentRateService agentRateService;

	@Autowired
	Gson gson;

	@JmsListener(destination = "DRAWEE_BANK_PRODUCT_DISABLED", containerFactory = "topicListenerFactory")
	public void draweeBankProductDisabled(final Message draweeBankDisabled) {

		DraweeBankDisableEvent bankDisableOnboard = null;
		Integer draweeBankId = null;
		Integer draweeBankProductId = null;
		BankProductOnboard bankProductOnboard = null;
		String draweeBankProductDisabledPayload = null;
		log.info("**********DRAWEE_BANK_PRODUCT_DISABLED EVENT**********" + draweeBankDisabled);

		try {
			TextMessage draweeBankDisabledMessage = (TextMessage) draweeBankDisabled;
			draweeBankProductDisabledPayload = draweeBankDisabledMessage.getText();
			log.info("---drawee Bank Product DisabledPayload" + draweeBankProductDisabledPayload);
		} catch (JMSException jmsException) {
			log.error("---Jms Exception---" + jmsException.getStackTrace());
			return;
		}

		if (draweeBankProductDisabledPayload != null && !draweeBankProductDisabledPayload.isEmpty()) {
			bankDisableOnboard = gson.fromJson(draweeBankProductDisabledPayload, DraweeBankDisableEvent.class);
			log.info("---Drawee bank product disabled payload---" + bankDisableOnboard);
			log.info("---draweeBankId---" + bankDisableOnboard.getDraweeBankProductId());
			log.info("---draweeBankProductId---" + bankDisableOnboard.getDraweeBankId());
			if (bankDisableOnboard.getDraweeBankProductId() != null && bankDisableOnboard.getDraweeBankId() != null) {
				bankProductOnboard = bankOnboard.bankOnBoard(draweeBankId, draweeBankProductId);
				log.info("---Response for draweeBankId && draweeBankProductId---" + bankProductOnboard);
				if (bankProductOnboard != null) {
					List<String> banks = new ArrayList<String>();
					List<String> serviceProviders = new ArrayList<String>();
					List<String> products = new ArrayList<String>();
					List<String> productSubtypes = new ArrayList<String>();
					List<String> serviceTypes = new ArrayList<String>();
					List<CurrencyUnit> currencies = new ArrayList<CurrencyUnit>();
					serviceProviders.add(bankProductOnboard.getServiceProviderCode());
					banks.add(bankProductOnboard.getDisplayName());
					products.add(bankProductOnboard.getProductType());
					currencies.add(Monetary.getCurrency(bankProductOnboard.getCurrencyCode()));
					productSubtypes.add(bankProductOnboard.getProductSubType());
					serviceTypes.add(bankProductOnboard.getServiceType());

					disableRecords(banks, serviceProviders, products, currencies, productSubtypes, serviceTypes);

				}
			}

		}

	}

	@JmsListener(destination = "DRAWEE_BANK_PRODUCT_DELETED", containerFactory = "topicListenerFactory")
	public void draweeBankProductDeletedEvent(final Message draweeBankDeleted) {
		String draweeBankProductDeletedpayload = null;
		DraweeBankDisableEvent bankDisableOnboard = null;
		Integer draweeBankId = null;
		Integer draweeBankProductId = null;
		BankProductOnboard bankProductOnboard = null;
		log.info("***********DRAWEE_BANK_PRODUCT_DELETED EVENT************" + draweeBankDeleted);

		try {
			TextMessage draweeBankDeletedMessage = (TextMessage) draweeBankDeleted;
			draweeBankProductDeletedpayload = draweeBankDeletedMessage.getText();
			log.info("***draweeBankProductDeletedpayload***", draweeBankProductDeletedpayload);
		} catch (JMSException jmsException) {
			log.error("****jmsException exception****" + jmsException.getStackTrace());
			return;
		}
		if (draweeBankProductDeletedpayload != null && !draweeBankProductDeletedpayload.isEmpty()) {
			bankDisableOnboard = gson.fromJson(draweeBankProductDeletedpayload, DraweeBankDisableEvent.class);
			log.info("****Drawee bank product disabled payload****" + bankDisableOnboard);
			log.info("****draweeBankId****" + bankDisableOnboard.getDraweeBankProductId());
			log.info("****draweeBankProductId****" + bankDisableOnboard.getDraweeBankId());
			if (bankDisableOnboard.getDraweeBankProductId() != null && bankDisableOnboard.getDraweeBankId() != null) {
				bankProductOnboard = bankOnboard.bankOnBoard(draweeBankId, draweeBankProductId);
				log.info("****Response for draweeBankId && draweeBankProductId****" + bankProductOnboard);
				if (bankProductOnboard != null) {
					List<String> banks = new ArrayList<String>();
					List<String> serviceProviders = new ArrayList<String>();
					List<String> products = new ArrayList<String>();
					List<String> productSubtypes = new ArrayList<String>();
					List<String> serviceTypes = new ArrayList<String>();
					List<CurrencyUnit> currencies = new ArrayList<CurrencyUnit>();
					serviceProviders.add(bankProductOnboard.getServiceProviderCode());
					banks.add(bankProductOnboard.getDisplayName());

					disableRecords(banks, serviceProviders, products, currencies, productSubtypes, serviceTypes);
				}
			}

		}

	}

	public void disableRecords(List<String> bank, List<String> serviceProvider, List<String> product,
			List<CurrencyUnit> currency, List<String> productSubtype, List<String> serviceType) {

		log.info("****disableRecords method****");
		List<BankWiseRateResponse> results = rateManagementService.getAllBankWiseBaseRates(SearchBankWiseBaseRateRequest
				.of(bank, null, serviceProvider, product, currency, true, PaginationData.of(0, 10000, null)));

		log.info("***RATE MANAGEMENT BANK DISPLAY CODE TO BE DISABLED ***" + results);

		if (!results.isEmpty()) {
			List<String> listOfIds = results.stream().map(BankWiseRateResponse::getRateId).collect(Collectors.toList());
			log.info("***Disabling RM Layer Records***");
			rateManagementService.updateStatus(listOfIds);

		}

		List<VaRResponse> resultsVarIdToDisable = varService
				.getAllVaRs(SearchVaRRequest.ofBankWise(null, bank, serviceProvider, product, productSubtype,
						serviceType, currency, Boolean.TRUE, PaginationData.of(0, 10000, null)));
		log.info("***VAR BANK DISPLAY CODE TO BE DISABLED ***" + resultsVarIdToDisable);
		if (!resultsVarIdToDisable.isEmpty()) {
			List<String> listOfVarIds = resultsVarIdToDisable.stream().map(VaRResponse::getVarId)
					.collect(Collectors.toList());
			varService.updateBanktEvents(listOfVarIds);
		}

		List<SettlementRateResponse> resultsSettlementIdToDisable = settlementService
				.getAllSettlementRates(SearchSettlementRatesRequest.ofBankWise(null, bank, serviceProvider, product,
						productSubtype, serviceType, currency, true, PaginationData.of(0, 10000, null)));

		log.info("***SETTLEMENT BANK DISPLAY CODE TO BE DISABLED ***" + resultsSettlementIdToDisable);

		if (!resultsSettlementIdToDisable.isEmpty()) {
			List<String> listOfSettlementIds = resultsSettlementIdToDisable.stream()
					.map(SettlementRateResponse::getSettlementId).collect(Collectors.toList());
			settlementService.updateAgentBankEvents(listOfSettlementIds);

		}

		List<CountryRateResponse> resultCountryIdsToDisable = countryRateService
				.getAllCountryRates(SearchCountryRatesRequest.ofBankWise(null, bank, serviceProvider, product,
						productSubtype, serviceType, null, currency, Boolean.TRUE, PaginationData.of(0, 10000, null)));

		log.info("***Country result***" + resultCountryIdsToDisable);
		if (!resultCountryIdsToDisable.isEmpty()) {
			List<String> listOfCountryIds = resultCountryIdsToDisable.stream()
					.map(CountryRateResponse::getCountryRateId).collect(Collectors.toList());
			log.info("***Disabling Country Layer Records***");
			countryRateService.updateBankEvents(listOfCountryIds);
		}

		List<AgentRateResponse> resultAgentIdsToDisable = agentRateService
				.getAllAgentRates(SearchAgentRatesRequest.ofBankWise(null, bank, serviceProvider, product,
						productSubtype, serviceType, currency, null, true, PaginationData.of(0, 10000, null)));
		log.info("***Agent result***" + resultAgentIdsToDisable);
		if (!resultAgentIdsToDisable.isEmpty()) {
			List<String> listOfAgentIds = resultAgentIdsToDisable.stream().map(AgentRateResponse::getAgentRateId)
					.collect(Collectors.toList());
			log.info("***Disabling Agent Layer Records***");

			agentRateService.updateBankEvents(listOfAgentIds);

		}

	}
}
