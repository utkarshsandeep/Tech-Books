package com.unimoni.pricingengine.domain.model.event;

import java.time.Duration;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class ProvidedRateFrequencyChangedEvent {

    private Integer rateProviderId;
    
    private String rateId;
    
    private String ricId;
    
    private Duration frequency;
    
    @JsonCreator
	public static ProvidedRateFrequencyChangedEvent off(@JsonProperty("rateProviderId") Integer rateProviderId, @JsonProperty("rateId") String rateId,
			@JsonProperty("ricId") String ricId, @JsonProperty("frequency") String frequency) {
    	ProvidedRateFrequencyChangedEvent providedRateFrequencyChangeEvent = new ProvidedRateFrequencyChangedEvent();
    	providedRateFrequencyChangeEvent.rateProviderId = rateProviderId;
    	providedRateFrequencyChangeEvent.rateId = rateId;
    	providedRateFrequencyChangeEvent.ricId = ricId;
    	providedRateFrequencyChangeEvent.frequency = Duration.parse(frequency);
    	
		return providedRateFrequencyChangeEvent;
	}
    
    public static ProvidedRateFrequencyChangedEvent of(Integer rateProviderId, String rateId,
			String ricId, Duration frequency) {
    	ProvidedRateFrequencyChangedEvent providedRateFrequencyChangeEvent = new ProvidedRateFrequencyChangedEvent();
    	providedRateFrequencyChangeEvent.rateProviderId = rateProviderId;
    	providedRateFrequencyChangeEvent.rateId = rateId;
    	providedRateFrequencyChangeEvent.ricId = ricId;
    	providedRateFrequencyChangeEvent.frequency = frequency;
    	
		return providedRateFrequencyChangeEvent;
	}
}
