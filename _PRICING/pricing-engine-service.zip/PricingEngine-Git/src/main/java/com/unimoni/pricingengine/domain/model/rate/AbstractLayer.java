package com.unimoni.pricingengine.domain.model.rate;

import static com.unimoni.pricingengine.adapter.persistence.PersistenceConstant.Hibernate.*;

import java.time.ZonedDateTime;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import com.unimoni.pricingengine.domain.model.common.type.UUIDIdentifiable;
import com.unimoni.pricingengine.domain.model.common.type.Versionable;
import com.unimoni.pricingengine.domain.model.rate.composable.Exchange;
import com.unimoni.pricingengine.domain.model.rate.ibr.InterBankRate;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@Entity
//@formatter:off
@Table(name = "MANAGED_RATES", 
    indexes = {
        @Index(name = "IDX_MANAGED_RATES_SOURCE_CURRENCY", columnList = "SOURCE_CURRENCY"),
        @Index(name = "IDX_MANAGED_RATES_TARGET_CURRENCY", columnList = "TARGET_CURRENCY")
    }
)
//@formatter:on
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "RATE_TYPE", discriminatorType = DiscriminatorType.STRING)
@EqualsAndHashCode(of = "id")
@Audited
public abstract class AbstractLayer implements UUIDIdentifiable<String>, Versionable<Long>, InterBankRate {

    @Id
    @GeneratedValue(generator = UUID2_GENERATOR)
    @Column(name = "ID", updatable = false, nullable = false, length = 36)
    protected String id;

    @Version
    @Access(AccessType.FIELD)
    @Column(name = "VERSION", nullable = false)
    protected Long version;

    @NotNull
    protected Exchange exchange;

    @Getter(value = AccessLevel.NONE)
    @NotNull
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "ENABLED", length = 1)
    protected boolean enabled;

    public boolean isEnabled() {
        return this.enabled;
    }

    @NotNull
    // @formatter:off
    @Column(name = "UPDATED_ON", 
            columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    // @formatter:on
    protected ZonedDateTime updatedOn;

    @Enumerated(EnumType.STRING)
    @Column(name = "RATE_TYPE", nullable = false, insertable = false, updatable = false, length = 20)
    private RateType rateType;

}
