package com.unimoni.pricingengine.domain.model.rate.composable;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.CURRENCY_UNIT_USD;
import static com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType.NON_USD_CUURENCY_PAIR_INVALID;
import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import java.math.BigDecimal;
import java.util.Optional;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.base.dto.FormulaValue;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true)
@EqualsAndHashCode
@Embeddable
@Access(AccessType.FIELD)
public class Settlement implements RateValue {

    @NotNull
    @Column(name = "SETTLEMENT_SELL", columnDefinition = "NUMBER(*,10)")
    private BigDecimal sellValue;

    @NotNull
    @Column(name = "SETTLEMENT_BUY", columnDefinition = "NUMBER(*,10)")
    private BigDecimal buyValue;

    public static Settlement of(final BigDecimal sellValue, final BigDecimal buyValue) {
        Settlement settlement = new Settlement();
        settlement.sellValue = RateValue.preciseTo8Decimals(sellValue);
        settlement.buyValue = RateValue.preciseTo8Decimals(buyValue);
        return settlement;
    }

    public static final Settlement ZERO = Settlement.of(RateValue.ZERO, RateValue.ZERO);

    public static final Settlement ONE = Settlement.of(RateValue.ONE, RateValue.ONE);

    public static Settlement byFormula(final Exchange exchange, final Margin margin) {
        BigDecimal settlementSell;
        BigDecimal settlementBuy;
        if (exchange.currency().source() == CURRENCY_UNIT_USD) {
            settlementSell = exchange.rate().bidValue().subtract(margin.bidValue());
            settlementBuy = exchange.rate().askValue().add(margin.askValue());
        }
        else if (exchange.currency().target() == CURRENCY_UNIT_USD) {
            if (exchange.rate().askValue().add(margin.askValue()).compareTo(RateValue.ZERO) == 0) {
                settlementSell = RateValue.ZERO;
            }
            else {
                settlementSell = RateValue.ONE.divide(exchange.rate().askValue().add(margin.askValue()),
                        DECIMAL_POINTS_8, BigDecimal.ROUND_HALF_UP);
            }
            if (exchange.rate().bidValue().subtract(margin.bidValue()).compareTo(RateValue.ZERO) == 0) {
                settlementBuy = RateValue.ZERO;
            }
            else {
                settlementBuy = RateValue.ONE.divide(exchange.rate().bidValue().subtract(margin.bidValue()),
                        DECIMAL_POINTS_8, BigDecimal.ROUND_HALF_UP);
            }
        }
        else {
            throw new RateException(NON_USD_CUURENCY_PAIR_INVALID, exchange.currency().source(),
                    exchange.currency().target());
        }

        validatePositive(settlementSell, "Settlement Sell");
        validatePositive(settlementBuy, "Settlement Buy");

        return Settlement.of(settlementSell, settlementBuy);
    }

    public static FormulaValue byFormula(final Exchange exchange, final Optional<BigDecimal> marginAsk,
            final Optional<BigDecimal> marginBid) {
        if (exchange.currency().source() == CURRENCY_UNIT_USD) {
            return marginAsk.isPresent() ? FormulaValue.ofSettlementBuy(exchange.rate().askValue().add(marginAsk.get()))
                    : FormulaValue.ofSettlementSell(exchange.rate().bidValue().subtract(marginBid.get()));
        }
        else if (exchange.currency().target() == CURRENCY_UNIT_USD) {
            return marginAsk.isPresent()
                    ? FormulaValue
                            .ofSettlementSell(RateValue.ONE.divide(exchange.rate().askValue().add(marginAsk.get()),
                                    DECIMAL_POINTS_8, BigDecimal.ROUND_HALF_UP))
                    : FormulaValue
                            .ofSettlementBuy(RateValue.ONE.divide(exchange.rate().bidValue().subtract(marginBid.get()),
                                    DECIMAL_POINTS_8, BigDecimal.ROUND_HALF_UP));
        }
        else {
            throw new RateException(NON_USD_CUURENCY_PAIR_INVALID, exchange.currency().source(),
                    exchange.currency().target());
        }
    }
}
