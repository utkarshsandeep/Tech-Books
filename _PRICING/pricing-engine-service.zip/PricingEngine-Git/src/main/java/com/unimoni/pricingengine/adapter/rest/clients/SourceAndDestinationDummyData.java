package com.unimoni.pricingengine.adapter.rest.clients;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SourceAndDestinationDummyData {

	private String code;
	private String name;

}
