package com.unimoni.pricingengine.application.service.amigo.dto;

import javax.money.CurrencyUnit;
import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.rate.composable.CurrencyExchange;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AmigoRequest {

    @NotNull
    @ApiModelProperty(name = "serviceProviderCode", value = "Service Provider code such as UAE, UK etc.", required = true, example = "UAE", position = 3)
    protected String serviceProviderCode;

    @ApiModelProperty(name = "productCode", value = "Product code such as Remittance, Forex etc.", required = true, example = "Remittance", position = 4)
    @NotNull
    protected String productCode;

    @NotNull
    @ApiModelProperty(name = "sourceCcy", value = "Source ISO Currency Code e.g. USD", required = true, example = "USD", position = 7)
    protected CurrencyUnit sourceCcy;

    @NotNull
    @ApiModelProperty(name = "targetCcy", value = "Target ISO Currency Code e.g. INR", required = true, example = "INR", position = 8)
    protected CurrencyUnit targetCcy;

    public CurrencyExchange currencyExchange() {
        return CurrencyExchange.of(this.sourceCcy, this.targetCcy);
    }
}
