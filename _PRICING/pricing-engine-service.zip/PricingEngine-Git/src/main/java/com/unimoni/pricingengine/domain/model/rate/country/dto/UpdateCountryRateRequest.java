package com.unimoni.pricingengine.domain.model.rate.country.dto;

import java.util.Map;
import java.util.Optional;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "updateCountryRateRequest", description = "Update Country Rate request")
public class UpdateCountryRateRequest {

    @Getter(value = AccessLevel.NONE)
    @Size(min = 0, max = 4)
    private Map<@NotNull VDWType, @NotNull UpdateExchangeDTO> vdwExchange;

    @Getter(value = AccessLevel.NONE)
    @ApiModelProperty(name = "status", allowEmptyValue = false, dataType = "Boolean", value = "New status, either true or false", required = false, example = "false", allowableValues = "true,false")
    private Boolean status;

    @NotEmpty
    @ApiModelProperty(name = "reason", allowEmptyValue = false, dataType = "String", value = "The reson for update", required = false, example = "High volatility")
    private String reason;
    
    @ApiModelProperty(hidden = true)
    public Optional<Map<VDWType, UpdateExchangeDTO>> getValueDateWises() {
        return Optional.ofNullable(this.vdwExchange);
    }

    public Optional<Boolean> getStatus() {
        return Optional.ofNullable(this.status);
    }
}
