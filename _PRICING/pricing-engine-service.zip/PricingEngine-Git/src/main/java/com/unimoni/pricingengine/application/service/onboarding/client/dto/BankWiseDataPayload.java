package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Triple;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.application.service.onboarding.model.Bank;
import com.unimoni.pricingengine.application.service.onboarding.model.Product;
import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankWiseDataPayload {

    private long draweeBankProductProfileId;

    private long draweeBankId;

    private String bankDisplayCode;

    private boolean specificPricing;

    private String currencyCode;

    private String productType;

    private String subProductType;

    private String serviceType;

    private boolean status;

    private String serviceProviderCode;

    public BankWiseDataPayload(final @JsonProperty("draweeBankProductProfileId") long draweeBankProductProfileId,
            final @JsonProperty("draweeBankId") long draweeBankId,
            final @JsonProperty("displayName") String displayName,
            final @JsonProperty("uaexBankWiseExchangeCcy") boolean uaexBankWiseExchangeCcy,
            final @JsonProperty("currencyCode") String currencyCode,
            final @JsonProperty("productType") String productType,
            final @JsonProperty("subProductType") String subProductType,
            final @JsonProperty("serviceType") String serviceType,
            final @JsonProperty("serviceProviderCode") String serviceProviderCode,
            final @JsonProperty("status") String status) {

        this.draweeBankProductProfileId = draweeBankProductProfileId;
        this.draweeBankId = draweeBankId;
        this.bankDisplayCode = displayName;
        this.specificPricing = uaexBankWiseExchangeCcy;
        this.currencyCode = currencyCode;
        this.productType = productType;
        this.subProductType = subProductType;
        this.serviceType = serviceType;
        this.serviceProviderCode = serviceProviderCode;
        this.status = status != null && status.equalsIgnoreCase("ENABLED");
    }

    public Bank bank(final Map<String, String> allCurrenciesMap, final Map<String, List<String>> agentsWithBranches,
            final Set<Triple<String, String, String>> instrumentsData) {

        Map<String, Map<String, Set<String>>> productsData = instrumentsData.stream().collect(Collectors.groupingBy(
                Triple::getLeft,
                Collectors.groupingBy(Triple::getMiddle, Collectors.mapping(Triple::getRight, Collectors.toSet()))));

        return Bank.of(this.draweeBankProductProfileId, this.bankDisplayCode, this.specificPricing,
                CodeNamePair.of(this.currencyCode, allCurrenciesMap.get(this.currencyCode)), agentsWithBranches,
                Product.of(productsData));
    }

    public CodeNamePair<String, String> bankPair() {
        return CodeNamePair.of(this.bankDisplayCode, this.bankDisplayCode);
    }

    public Triple<String, String, String> instruments() {
        return Triple.of(this.productType, this.subProductType, this.serviceType);
    }

    public CodeNamePair<String, String> productPair() {
        return CodeNamePair.of(this.bankDisplayCode, this.bankDisplayCode);
    }

    public CodeNamePair<String, String> subProductPair() {
        return CodeNamePair.of(this.bankDisplayCode, this.bankDisplayCode);
    }

    public CodeNamePair<String, String> serviceTypePair() {
        return CodeNamePair.of(this.bankDisplayCode, this.bankDisplayCode);
    }

    public boolean isEnabled() {
        return this.status;
    }
}
