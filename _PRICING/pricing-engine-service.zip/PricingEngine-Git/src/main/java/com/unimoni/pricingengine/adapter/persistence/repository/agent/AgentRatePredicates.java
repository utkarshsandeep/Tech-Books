package com.unimoni.pricingengine.adapter.persistence.repository.agent;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;

import java.util.ArrayList;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate_;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.SearchAgentRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments_;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments_;
import com.unimoni.pricingengine.domain.model.rate.country.AgentItem_;
import com.unimoni.pricingengine.domain.model.remittance.TransactionCurrencies.TxnCurrencyType;

public abstract class AgentRatePredicates {

    public static Predicate[] getAgentRateByIdentityPredicates(Root<AgentRate> root, CriteriaBuilder criteriaBuilder,
            RMType rmType, AgentRateIdentity identity) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(
                criteriaBuilder.equal(root.get(AgentRate_.instruments.getName()), identity.getInstruments().toModel()));
        predicates.add(criteriaBuilder.equal(root.get(AgentRate_.agent.getName()).get(AgentItem_.code.getName()),
                identity.getAgent().getCode()));
        if (rmType.isBankWise()) {
            predicates.add(criteriaBuilder.equal(root.get(AgentRate_.bank.getName()), identity.getBank().get()));
        }
        predicates
                .add(criteriaBuilder.equal(root.get(AgentRate_.currency.getName()), identity.getCurrency().toModel()));
        predicates.add(criteriaBuilder.equal(root.get(AgentRate_.rmType.getName()), rmType));
        predicates.add(criteriaBuilder.equal(root.get(AgentRate_.enabled.getName()), true));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate[] getSearchAgentRatesPredicates(final Root<AgentRate> root,
            final CriteriaBuilder criteriaBuilder, final SearchAgentRatesRequest searchRequest) {
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(root.get(AgentRate_.rmType.getName()), searchRequest.getRmType()));
        if (searchRequest.getAgents() != null && !searchRequest.getAgents().isEmpty()) {
            predicates.add(
                    root.get(AgentRate_.agent.getName()).get(AgentItem_.code.getName()).in(searchRequest.getAgents()));
        }
        if (searchRequest.getRmType().isBankWise() && searchRequest.getBanks() != null
                && !searchRequest.getBanks().isEmpty()) {
            predicates.add(root.get(AgentRate_.bank.getName()).in(searchRequest.getBanks()));
        }
        if (searchRequest.getServiceProviders() != null && !searchRequest.getServiceProviders().isEmpty()) {
            predicates.add(root.get(AgentRate_.instruments.getName()).get(AllInstruments_.serviceProvider.getName())
                    .in(searchRequest.getServiceProviders()));
        }
        if (searchRequest.getProducts() != null && !searchRequest.getProducts().isEmpty()) {
            predicates.add(root.get(AgentRate_.instruments.getName()).get(AllInstruments_.product.getName())
                    .in(searchRequest.getProducts()));
        }
        if (searchRequest.getSubProducts() != null && !searchRequest.getSubProducts().isEmpty()) {
            predicates.add(root.get(AgentRate_.instruments.getName()).get(AllInstruments_.subProduct.getName())
                    .in(searchRequest.getSubProducts()));
        }
        if (searchRequest.getServiceTypes() != null && !searchRequest.getServiceTypes().isEmpty()) {
            predicates.add(root.get(AgentRate_.instruments.getName()).get(AllInstruments_.serviceType.getName())
                    .in(searchRequest.getServiceTypes()));
        }
        if (searchRequest.getBaseCurrencies() != null && !searchRequest.getBaseCurrencies().isEmpty()) {
            predicates.add(root.get(AgentRate_.currency.getName()).get("base").in(searchRequest.getBaseCurrencies()));
        }
        if (searchRequest.getForeignCurrencies() != null && !searchRequest.getForeignCurrencies().isEmpty()) {
            predicates.add(
                    root.get(AgentRate_.currency.getName()).get("foreign").in(searchRequest.getForeignCurrencies()));
        }
        if (searchRequest.getStatus() != null) {
            predicates.add(criteriaBuilder.equal(root.get(AgentRate_.enabled.getName()), searchRequest.getStatus()));
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public static Predicate getBasicPredicateForRemmitanceTransaction(final Root<AgentRate> root,
            final CriteriaBuilder criteriaBuilder, final AllInstruments allInstruments, final String agentBranchCode,
            final String agentCode) {
        // @formatter:off
        return criteriaBuilder.and(
                criteriaBuilder.or(
                        criteriaBuilder.equal(root.get(AgentRate_.agent.getName()).get(AgentItem_.code.getName()), agentCode),
                        criteriaBuilder.equal(root.get(AgentRate_.agent.getName()).get(AgentItem_.code.getName()),
                                agentBranchCode)), 
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(AgentRate_.instruments.getName()).get(AllInstruments_.serviceProvider.getName()),
                                allInstruments.serviceProvider()),
                        criteriaBuilder.equal(
                                root.get(AgentRate_.instruments.getName()).get(RateInstruments_.serviceProvider.getName()),
                                ALL_INSTRUMENTS)), 
                criteriaBuilder.or(
                        criteriaBuilder.equal(root.get(AgentRate_.instruments.getName()).get(AllInstruments_.product.getName()),
                                allInstruments.product()),
                        criteriaBuilder.equal(root.get(AgentRate_.instruments.getName()).get(AllInstruments_.product.getName()),
                                ALL_INSTRUMENTS)), 
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(AgentRate_.instruments.getName()).get(AllInstruments_.subProduct.getName()),
                                allInstruments.subProduct()),
                        criteriaBuilder.equal(
                                root.get(AgentRate_.instruments.getName()).get(AllInstruments_.subProduct.getName()),
                                ALL_INSTRUMENTS)), 
                criteriaBuilder.or(
                        criteriaBuilder.equal(
                                root.get(AgentRate_.instruments.getName()).get(AllInstruments_.serviceType.getName()),
                                allInstruments.serviceType()),
                        criteriaBuilder.equal(
                                root.get(AgentRate_.instruments.getName()).get(AllInstruments_.serviceType.getName()),
                                ALL_INSTRUMENTS)), 
                criteriaBuilder.equal(root.get(AgentRate_.enabled.getName()), true) 
            );
     // @formatter:on
    }

    public static Predicate getCurrencyPredicateForRemmitanceTransaction(final Root<AgentRate> root,
            final CriteriaBuilder criteriaBuilder, final CurrencyUnit payInCurrency,
            final TxnCurrencyType txnCurrencyType, final CurrencyUnit currency) {

        switch (txnCurrencyType) {
        case PAY_IN:
            return criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("base"), payInCurrency),
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("foreign"), payInCurrency));
        case PAY_OUT:
            return criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("base"), payInCurrency),
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("foreign"), currency));
        case SETTLEMENT:
            return criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("base"), payInCurrency),
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("foreign"), currency));
        case SERVICE_PROVIDER:
            return criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("base"), payInCurrency),
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("foreign"), currency));
        case PASS_SETTLEMENT:
            return criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("base"), payInCurrency),
                    criteriaBuilder.equal(root.get(AgentRate_.currency.getName()).get("foreign"), currency));

        default:
            throw new IllegalArgumentException("Invalid txnCurrencyType: " + txnCurrencyType);
        }
    }
}
