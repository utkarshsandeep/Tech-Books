package com.unimoni.pricingengine.adapter.rest.clients.bp;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor(staticName="of")
public class BranchProcessAmigoQatarRequest {
	private String dealId ;
	
	private BigDecimal offeredRate;

    private BigDecimal consumedAmount;
	
    private String status;
	
}
