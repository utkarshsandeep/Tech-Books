package com.unimoni.pricingengine.domain.model.rate.var.dto;

import java.util.List;

import com.unimoni.pricingengine.domain.model.rate.base.dto.RateIdentity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public class VaRMetaData {

    private int missingIbrsCount;

    private List<VaRBasicIdentity> missingIbrs;

    private int nonUSDIbrsCount;

    private List<RateIdentity> nonUSDIbrs;

    private int duplicateVarsCount;

    private List<VaRIdentity> duplicateVars;

    private int newVarsCount;

    private List<VaRResponse> newVars;

    public static VaRMetaData of(final List<VaRBasicIdentity> missingIbrs, final List<RateIdentity> nonUSDIbrs,
            final List<VaRIdentity> duplicateVars, final List<VaRResponse> newVars) {
        VaRMetaData varMetaData = new VaRMetaData();
        varMetaData.missingIbrs = missingIbrs;
        varMetaData.missingIbrsCount = missingIbrs != null ? missingIbrs.size() : 0;
        varMetaData.nonUSDIbrs = nonUSDIbrs;
        varMetaData.nonUSDIbrsCount = nonUSDIbrs != null ? nonUSDIbrs.size() : 0;
        varMetaData.duplicateVars = duplicateVars;
        varMetaData.duplicateVarsCount = duplicateVars != null ? duplicateVars.size() : 0;
        varMetaData.newVars = newVars;
        varMetaData.newVarsCount = newVars != null ? newVars.size() : 0;
        return varMetaData;
    }
}
