package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Triple;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.unimoni.pricingengine.application.service.onboarding.client.AgentOnboardingClient;
import com.unimoni.pricingengine.application.service.onboarding.model.Agent;
import com.unimoni.pricingengine.application.service.onboarding.model.AgentBranch;
import com.unimoni.pricingengine.application.service.onboarding.model.Product;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;
import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;

import feign.FeignException;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class NormalDataPayload {

    private long id;

    private String serviceProviderCode;

    private String serviceProviderName;

    private String productType;

    private String subProductType;

    private String serviceType;

    @Getter(value = AccessLevel.NONE)
    private List<CurrencyPayload> currencyCodes;

    private long agentId;

    private String agentDisplayCode;

    private String agentDisplayName;

    private String agentName;

    private String countryCode;

    private long agentBranchId;

    private String branchDisplayCode;

    private boolean status;

    public NormalDataPayload(final @JsonProperty("id") long id,
            final @JsonProperty("serviceProviderCode") String serviceProviderCode,
            final @JsonProperty("serviceProviderName") String serviceProviderName,
            final @JsonProperty("productType") String productType,
            final @JsonProperty("subProductType") String subProductType,
            final @JsonProperty("serviceType") String serviceType,
            final @JsonProperty("currencyCodes") List<CurrencyPayload> currencyCodes,
            final @JsonProperty("agentId") long agentId,
            final @JsonProperty("agentDisplayCode") String agentDisplayCode,
            final @JsonProperty("agentDisplayName") String agentDisplayName,
            final @JsonProperty("agentName") String agentName, final @JsonProperty("countryCode") String countryCode,
            final @JsonProperty("agentBranchId") long agentBranchId,
            final @JsonProperty("agentBranchCode") String agentBranchCode,
            final @JsonProperty("status") String status) {

        this.id = id;
        this.serviceProviderCode = serviceProviderCode;
        this.serviceProviderName = serviceProviderName;
        this.productType = productType;
        this.subProductType = subProductType;
        this.serviceType = serviceType;
        this.currencyCodes = currencyCodes;
        this.status = status != null && status.equalsIgnoreCase("ENABLED");
        this.agentId = agentId;
        this.agentName = agentName;
        this.countryCode = countryCode;
        this.agentDisplayCode = agentDisplayCode;
        this.agentName = agentName;
        this.agentBranchId = agentBranchId;
        this.branchDisplayCode = agentBranchCode;
    }

    public Agent agent(final Map<String, String> allCountriesMap, final List<AgentBranch> branches,
            final Set<Triple<String, String, String>> instrumentsData) {
        RateDisplayMachenism rateDisplayMachenism = null;
        boolean firstElement = true;
        for (AgentBranch ab : branches) {
            if (ab.getBranchRateSetting().isPresent()) {
                if (firstElement) {
                    rateDisplayMachenism = ab.getBranchRateSetting().get().getRateDisplayMachenism();
                    firstElement = false;
                }
                else if (rateDisplayMachenism != ab.getBranchRateSetting().get().getRateDisplayMachenism()) {
                    rateDisplayMachenism = null;
                    break;
                }
            }
            else {
                break;
            }
        }

        Map<String, Map<String, Set<String>>> productsData = instrumentsData.stream().collect(Collectors.groupingBy(
                Triple::getLeft,
                Collectors.groupingBy(Triple::getMiddle, Collectors.mapping(Triple::getRight, Collectors.toSet()))));

        // TODO: Temporary fix - remove ternary switch later
        // if (allCountriesMap.get(this.countryCode) == null) {
        // log.debug("????Missing countryCode: " + this.countryCode + " from master country list");
        // }
        return Agent.of(this.agentId, this.agentDisplayCode,
                allCountriesMap.get(this.countryCode) == null ? CodeNamePair.of(this.countryCode, this.countryCode)
                        : CodeNamePair.of(this.countryCode, allCountriesMap.get(this.countryCode)),
                rateDisplayMachenism, branches, Product.of(productsData));
    }

    public AgentBranch agentBranch(final AgentOnboardingClient agentOnboardingClient,
            final Map<String, String> allCurrenciesMap) {
        BranchRateSettingPayload branchRateSettingPayload = null;
        try {
            branchRateSettingPayload = agentOnboardingClient.getAgentBranchRateSetting(this.agentId,
                    this.agentBranchId);
        }
        catch (final FeignException fe) { // Ignore and set Branch Rate Setting as null
            // fe.printStackTrace();
            log.error(fe.getMessage());
        }
        return AgentBranch.of(this.agentId, this.agentBranchId, this.branchDisplayCode,
                baseCurrencies(allCurrenciesMap),
                branchRateSettingPayload != null && branchRateSettingPayload.isEnabled()
                        ? branchRateSettingPayload.branchRateSetting()
                        : null);
    }

    public CodeNamePair<String, String> agentPair() {
        return CodeNamePair.of(this.agentDisplayCode, this.agentDisplayCode);
    }

    public Triple<String, String, String> instruments() {
        return Triple.of(this.productType, this.subProductType, this.serviceType);
    }

    public CodeNamePair<String, String> productPair() {
        return CodeNamePair.of(this.productType, this.productType);
    }

    public CodeNamePair<String, String> subProductPair() {
        return CodeNamePair.of(this.subProductType, this.subProductType);
    }

    public CodeNamePair<String, String> serviceTypePair() {
        return CodeNamePair.of(this.serviceType, this.serviceType);
    }

    public List<CodeNamePair<String, String>> baseCurrencies(final Map<String, String> allCurrenciesMap) {
        return this.currencyCodes != null && !this.currencyCodes.isEmpty() ? this.currencyCodes.stream().map(curr -> {
            if (allCurrenciesMap.get(curr.getCode()) == null) {
                // log.debug("Base Currency -->>" + curr.getCode() + " missing in currency master data");
                return CodeNamePair.of(curr.getCode(), curr.getCode());
            }
            else {
                return CodeNamePair.of(curr.getCode(), allCurrenciesMap.get(curr.getCode()));
            }
        }).collect(ImmutableCollectors.toImmutableList()) : Collections.emptyList();
    }

    public boolean isEnabled() {
        return this.status;
    }
}
