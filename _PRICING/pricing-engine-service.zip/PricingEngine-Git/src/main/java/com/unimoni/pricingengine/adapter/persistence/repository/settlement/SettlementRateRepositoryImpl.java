package com.unimoni.pricingengine.adapter.persistence.repository.settlement;

import static com.unimoni.pricingengine.adapter.persistence.repository.settlement.SettlementRateSelectExpressions.currencySelectExpression;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.money.CurrencyUnit;
import javax.persistence.NonUniqueResultException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.MapJoin;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementRateEnquiryIdentity;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementRateEnquiryProjection;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementRateEnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementVDWRateType;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate_;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementValueDateWise;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementValueDateWise_;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SearchSettlementRatesRequest;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class SettlementRateRepositoryImpl extends AbstractJPA implements SettlementRateRepositoryJPA {

    @Override
    public Optional<SettlementRate> findEnabledSettlementRateByIdentity(final RMType rmType,
            final SettlementIdentity settlementIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<SettlementRate> query = criteriaQuery(SettlementRate.class);
        Root<SettlementRate> settlementRate = query.from(SettlementRate.class);
        query.where(
                SettlementRatePredicates.getSettlementRateByIdentityPredicates(settlementRate, criteriaBuilder, rmType,
                        settlementIdentity),
                criteriaBuilder.equal(settlementRate.get(SettlementRate_.enabled.getName()), true));
        query.select(settlementRate);
        return getSingleResultSafely(query);
    }

    @Override
    public Optional<SettlementRate> findLatestDisabledSettlementRateByIdentity(final RMType rmType,
            final SettlementIdentity settlementIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<SettlementRate> query = criteriaQuery(SettlementRate.class);
        Root<SettlementRate> settlementRate = query.from(SettlementRate.class);
        query.where(
                SettlementRatePredicates.getSettlementRateByIdentityPredicates(settlementRate, criteriaBuilder, rmType,
                        settlementIdentity),
                criteriaBuilder.equal(settlementRate.get(SettlementRate_.enabled.getName()), false));
        query.select(settlementRate);
        query.orderBy(criteriaBuilder.desc(settlementRate.get(SettlementRate_.updatedOn.getName())));
        TypedQuery<SettlementRate> typedQuery = typedQuery(query);
        typedQuery.setMaxResults(1);
        return getSingleResultSafely(typedQuery);
    }

    @Override
    public List<SettlementRate> findAllSettlementRates(final SearchSettlementRatesRequest searchRequest) {
        long totalRecords = findSettlementRatesCount(searchRequest);
        searchRequest.page().totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = criteriaBuilder();
            CriteriaQuery<SettlementRate> query = criteriaQuery(SettlementRate.class);
            Root<SettlementRate> rate = query.from(SettlementRate.class);

            query.where(
                    SettlementRatePredicates.getSearchSettlementRatesPredicates(rate, criteriaBuilder, searchRequest));

            query.select(rate);
            query.distinct(true);
            query.orderBy(criteriaBuilder.asc(rate.get(SettlementRate_.currency.getName()).get("source")));

            TypedQuery<SettlementRate> typedQuery = typedQuery(query);
            typedQuery.setFirstResult(searchRequest.page().queryFirstResult());
            typedQuery.setMaxResults(searchRequest.page().queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findSettlementRatesCount(final SearchSettlementRatesRequest searchRequest) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<SettlementRate> rate = query.from(SettlementRate.class);

        query.where(SettlementRatePredicates.getSearchSettlementRatesPredicates(rate, criteriaBuilder, searchRequest));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public List<SettlementRate> findSettlementRatesByIds(final RMType rmType, final List<String> ids,
            final boolean eagerFetchCountry) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<SettlementRate> query = criteriaQuery(SettlementRate.class);
        Root<SettlementRate> settlement = query.from(SettlementRate.class);
        query.where(criteriaBuilder.and(criteriaBuilder.equal(settlement.get(SettlementRate_.rmType.getName()), rmType),
                settlement.get(SettlementRate_.id.getName()).in(ids)));
        query.select(settlement);
        TypedQuery<SettlementRate> typedQuery = typedQuery(query);
        // if (eagerFetchCountry) {
        // typedQuery.setHint("javax.persistence.fetchgraph",
        // entityManager.getEntityGraph("bankWiseBaseRate"));
        // }
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public SettlementRate getSettlementReference(RMType rmType, String settlementId) {

        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<SettlementRate> query = criteriaQuery(SettlementRate.class);
        Root<SettlementRate> settlement = query.from(SettlementRate.class);
        query.where(SettlementRatePredicates.getSettlementRateByRmTypeAndId(settlement, criteriaBuilder, rmType,
                settlementId));
        query.select(settlement);
        return getSingleResultSafely(query).get();
    }

    @Override
    public Optional<SettlementRate> findHighestPrioritySettlementRatesByCountryRateIdentity(final RMType rmType,
            final CountryRateIdentity identity, final CurrencyUnit currency) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<SettlementRate> query = criteriaQuery(SettlementRate.class);
        Root<SettlementRate> rate = query.from(SettlementRate.class);
        query.select(rate);
        Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
        Root<SettlementRate> maxPriority = maxPriorityQuery.from(SettlementRate.class);

        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(SettlementRate_.priority.getName())));

        maxPriorityQuery.where(SettlementRatePredicates.getSettlementRatePredicatesForHighestPriorityFetch(maxPriority,
                criteriaBuilder, rmType, identity.getInstruments().getServiceProvider(),
                identity.getInstruments().getProduct(), identity.getInstruments().getSubProduct(),
                identity.getInstruments().getServiceType(), identity.getBank().orElse(null),
                identity.getAgent().getCode(), currency));

        query.where(
                SettlementRatePredicates.getSettlementRatePredicatesForHighestPriorityFetch(rate, criteriaBuilder,
                        rmType, identity.getInstruments().getServiceProvider(), identity.getInstruments().getProduct(),
                        identity.getInstruments().getSubProduct(), identity.getInstruments().getServiceType(),
                        identity.getBank().orElse(null), identity.getAgent().getCode(), currency),
                criteriaBuilder.equal(rate.get(SettlementRate_.priority.getName()), maxPriorityQuery));

        try {
            return getSingleResultSafely(query);
        }
        catch (final NonUniqueResultException unre) {
            log.error(
                    "Duplicate highest priority Settlement rate record for rmType: {}, Currency: {} and CountryRateIdentity: {}",
                    rmType, currency, identity);
            throw unre;
        }
    }

    @Override
    public List<CurrencyUnit> findDistinctSettlementRateCurrencies(final RMType rmType) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<CurrencyUnit> query = criteriaQuery(CurrencyUnit.class);
        Root<SettlementRate> rate = query.from(SettlementRate.class);
        query.select(currencySelectExpression(rate, criteriaBuilder)).distinct(true);
        query.where(criteriaBuilder.and(criteriaBuilder.equal(rate.get(SettlementRate_.rmType.getName()), rmType),
                criteriaBuilder.equal(rate.get(SettlementRate_.enabled.getName()), true)));
        return getUnmodifiableResultList(query);
    }

    @Override
    public Optional<SettlementRateEnquiryResponse> findSettlementRateForEnquiry(final RMType rmType,
            final SettlementVDWRateType vdwRateType, final SettlementRateEnquiryIdentity enquiryIdentity) {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<SettlementRateEnquiryProjection> query = criteriaQuery(SettlementRateEnquiryProjection.class);
        Root<SettlementRate> rate = query.from(SettlementRate.class);
        MapJoin<SettlementRate, VDWType, SettlementValueDateWise> valueDateWises = rate
                .join(SettlementRate_.valueDateWises);

        Predicate mainQueryPredicate = criteriaBuilder.and(
                SettlementRatePredicates.getSettlementRatePredicatesForHighestPriorityFetch(rate, criteriaBuilder,
                        rmType, enquiryIdentity.serviceProvider(), enquiryIdentity.product(),
                        enquiryIdentity.subProduct(), enquiryIdentity.serviceType(),
                        enquiryIdentity.bank().orElse(null), enquiryIdentity.agent(), enquiryIdentity.currency()),
                valueDateWises.key().in(enquiryIdentity.valueDateWises()));

        if (rmType.isNormal()) {
            query.select(criteriaBuilder.construct(SettlementRateEnquiryProjection.class,
                    criteriaBuilder.literal(enquiryIdentity.serviceProvider()),
                    criteriaBuilder.literal(enquiryIdentity.product()),
                    criteriaBuilder.literal(enquiryIdentity.subProduct()),
                    criteriaBuilder.literal(enquiryIdentity.serviceType()),
                    criteriaBuilder.literal(enquiryIdentity.agent()), currencySelectExpression(rate, criteriaBuilder),
                    valueDateWises.key(),
                    vdwRateType.isSettlement()
                            ? valueDateWises.value().get(SettlementValueDateWise_.settlement.getName())
                            : valueDateWises.value().get(SettlementValueDateWise_.country.getName())));
        }
        else {
            query.select(criteriaBuilder.construct(SettlementRateEnquiryProjection.class,
                    criteriaBuilder.literal(enquiryIdentity.serviceProvider()),
                    criteriaBuilder.literal(enquiryIdentity.product()),
                    criteriaBuilder.literal(enquiryIdentity.subProduct()),
                    criteriaBuilder.literal(enquiryIdentity.serviceType()),
                    criteriaBuilder.literal(enquiryIdentity.bank().orElse(null)),
                    criteriaBuilder.literal(enquiryIdentity.agent()), currencySelectExpression(rate, criteriaBuilder),
                    valueDateWises.key(),
                    vdwRateType.isSettlement()
                            ? valueDateWises.value().get(SettlementValueDateWise_.settlement.getName())
                            : valueDateWises.value().get(SettlementValueDateWise_.country.getName())));
        }

        Subquery<Integer> maxPriorityQuery = query.subquery(Integer.class);
        Root<SettlementRate> maxPriority = maxPriorityQuery.from(SettlementRate.class);
        maxPriorityQuery.select(criteriaBuilder.max(maxPriority.get(SettlementRate_.priority.getName())));

        maxPriorityQuery.where(SettlementRatePredicates.getSettlementRatePredicatesForHighestPriorityFetch(maxPriority,
                criteriaBuilder, rmType, enquiryIdentity.serviceProvider(), enquiryIdentity.product(),
                enquiryIdentity.subProduct(), enquiryIdentity.serviceType(), enquiryIdentity.bank().orElse(null),
                enquiryIdentity.agent(), enquiryIdentity.currency()));

        query.where(mainQueryPredicate,
                criteriaBuilder.equal(rate.get(SettlementRate_.priority.getName()), maxPriorityQuery));

        return SettlementRateEnquiryResponse.of(enquiryIdentity.index(), getUnmodifiableResultList(query));
    }
}
