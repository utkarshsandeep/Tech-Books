package com.unimoni.pricingengine.domain.model.rate.base.dto;

import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;

@Getter
@ApiModel(value = "formulaValue", description = "Rate value caculated by formula")
public class FormulaValue {

    @ApiModelProperty(name = "calculatedValue", dataType = "BigDecimal", value = "Formula Calculated value in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal calculatedValue;

    @ApiModelProperty(name = "valueType", dataType = "String", value = "Value Type", required = true, example = "SETTLEMENT_SELL_VALUE", allowableValues = "SETTLEMENT_SELL_VALUE,SETTLEMENT_BUY_VALUE,MARGIN_ASK_VALUE,MARGIN_BID_VALUE")
    private Type valueType;

    enum Type {
        SETTLEMENT_SELL_VALUE, SETTLEMENT_BUY_VALUE, MARGIN_ASK_VALUE, MARGIN_BID_VALUE;
    }

    private FormulaValue(final BigDecimal calculatedValue, final Type valueType) {
        this.calculatedValue = calculatedValue;
        this.valueType = valueType;
    }

    public static FormulaValue ofSettlementSell(final BigDecimal calculatedValue) {
        validatePositive(calculatedValue, "Settlement Sell");
        return new FormulaValue(calculatedValue, Type.SETTLEMENT_SELL_VALUE);
    }

    public static FormulaValue ofSettlementBuy(final BigDecimal calculatedValue) {
        validatePositive(calculatedValue, "Settlement Buy");
        return new FormulaValue(calculatedValue, Type.SETTLEMENT_BUY_VALUE);
    }

    public static FormulaValue ofMarginAsk(final BigDecimal calculatedValue) {
        return new FormulaValue(calculatedValue, Type.MARGIN_ASK_VALUE);
    }

    public static FormulaValue ofMarginBid(final BigDecimal calculatedValue) {
        return new FormulaValue(calculatedValue, Type.MARGIN_BID_VALUE);
    }
}
