package com.unimoni.pricingengine.adapter.rest.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "draweeBankProductProfileIdClient", url = "http://bank-onboarding-service-snap.integration.apps.ocp.uaeexchange.com/api/v1/onboarding/draweeBanks/draweeBankProductProfiles")

public interface DraweeBankProductProfileIdClient {

    @RequestMapping(path = "/", method = RequestMethod.POST, consumes = "application/json")
    DrawBankProfileIdResponse getDraweeBankProductProfileIdResponse(@RequestBody DrawBankPayload payload);

}
