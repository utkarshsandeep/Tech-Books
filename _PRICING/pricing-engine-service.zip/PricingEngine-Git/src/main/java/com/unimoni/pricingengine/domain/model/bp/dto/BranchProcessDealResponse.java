package com.unimoni.pricingengine.domain.model.bp.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.bp.BranchProcess;
import com.unimoni.pricingengine.domain.model.bp.BranchProcessSourceType;
import com.unimoni.pricingengine.domain.model.bp.StatusType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
public class BranchProcessDealResponse {
	@JsonInclude(NON_EMPTY)
	private String dealId;
	
	@JsonInclude(NON_EMPTY)
	private BigDecimal offeredRate;
	
	@JsonInclude(NON_EMPTY)
	private StatusType status;
	
	@JsonInclude(NON_EMPTY)
    private BranchProcessSourceType sourceType;
	
	public static BranchProcessDealResponse of(BranchProcess branchProcess) {
	    return BranchProcessDealResponse.of(branchProcess.getDeal(), 
	            branchProcess.getOfferedRate(), 
	            branchProcess.getStatus(),
	            branchProcess.getSourceType());
	    
	}
}
