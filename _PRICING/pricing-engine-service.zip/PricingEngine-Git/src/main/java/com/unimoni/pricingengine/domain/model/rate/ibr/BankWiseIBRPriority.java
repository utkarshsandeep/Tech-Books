package com.unimoni.pricingengine.domain.model.rate.ibr;

import static com.unimoni.pricingengine.domain.model.rate.RatePriority.isAll;
import static com.unimoni.pricingengine.domain.model.rate.RatePriority.isSpecific;

import com.unimoni.pricingengine.domain.model.rate.RatePriority;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments;

public enum BankWiseIBRPriority implements RatePriority {

    // @formatter:off
    // ZERO is lowest priority and SEVEN is highest
    /**
     * "If SP = “All” and Product = “All” and Bank = “All” and Agent="All""
     */
    ZERO,
    
    /**
     * "If SP = “Specific” and Product = “All” and Bank = “All” and Agent="All""
     */
    ONE,
    
    /**
     * "If SP = “All” and Product = “Specific” and Bank = “All” and Agent="All""
     */
    TWO,
    
    /**
     * "If SP = “Specific” and Product = “Specific” and Bank = “All” and Agent="All""
     */
    THREE,
    
    /**
     * "If SP = “All” and Product = “All” and Bank = “All” and Agent = "Specific""
     */
    FOUR,
    
    /**
     * "If SP = “Specific” and Product = “All” and Bank = “All” and Agent = "Specific""
     */
    FIVE,
    
    /**
     * "If SP = “All” and Product = “Specific” and Bank = “All” and Agent ="Specific""
     */
    SIX,
    
    /**
     * "If SP = “Specific” and Product = “Specific” and Bank = “All” and Agent ="Specific""
     */
    SEVEN,
	
	/**
     * "If SP = “All” and Product = “All” and Bank = “Specific” and Agent ="All""
     */
    EIGHT,
	
	/**
     * "If SP = “Specific” and Product = “All” and Bank = “Specific” and Agent ="All""
     */
    NINE,
	
	/**
     * "If SP = “All” and Product = “Specific” and Bank = “Specific” and Agent ="All""
     */
    TEN,
    
    /**
     * "If SP = “Specific” and Product = “Specific” and Bank = “Specific” and Agent ="All""
     */
    ELEVEEN,
    
    /**
     * "If SP = “All” and Product = “All” and Bank = “Specific” and Agent ="Specific""
     */
    TWELVE,
    
    /**
     * "If SP = “Specific” and Product = “All” and Bank = “Specific” and Agent ="Specific""
     */
    THIRTEEN,
    
    /**
     * "If SP = “All” and Product = “Specific” and Bank = “Specific” and Agent ="Specific""
     */
    FOURTEEN,
    
    /**
     * "If SP = “Specific” and Product = “Specific” and Bank = “Specific” and Agent ="Specific""
     */
    FIFTEEN;
	
	// @formatter:on

    public static BankWiseIBRPriority of(final RateInstruments rateInstruments, final String bank, final String agent) {
        String serviceProvider = rateInstruments.serviceProvider();
        String product = rateInstruments.product();
        
        if (isAll(serviceProvider) && isAll(product) && isAll(bank) && isAll(agent)) {
            return ZERO;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(bank) && isAll(agent)) {
            return ONE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(bank) && isAll(agent)) {
            return TWO;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(bank) && isAll(agent)) {
            return THREE;
        }
        else if (isAll(serviceProvider) && isAll(product) && isAll(bank) && isSpecific(agent)) {
            return FOUR;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isAll(bank) && isSpecific(agent)) {
            return FIVE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isAll(bank) && isSpecific(agent)) {
            return SIX;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isAll(bank) && isSpecific(agent)) {
            return SEVEN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(bank) && isAll(agent)) {
            return EIGHT;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(bank) && isAll(agent)) {
            return NINE;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(bank) && isAll(agent)) {
            return TEN;
        }
        else if (isSpecific(serviceProvider) && isSpecific(product) && isSpecific(bank) && isAll(agent)) {
            return ELEVEEN;
        }
        else if (isAll(serviceProvider) && isAll(product) && isSpecific(bank) && isSpecific(agent)) {
            return TWELVE;
        }
        else if (isSpecific(serviceProvider) && isAll(product) && isSpecific(bank) && isSpecific(agent)) {
            return THIRTEEN;
        }
        else if (isAll(serviceProvider) && isSpecific(product) && isSpecific(bank) && isSpecific(agent)) {
            return FOURTEEN;
        }
        else {
            return FIFTEEN;
        }
    }
}
