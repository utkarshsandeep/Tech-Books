package com.unimoni.pricingengine.common.constants;

public class DownloadFileConstants {

    public static String IBR_NORMAL_EXCEL_FILE_NAME = "IbrNormal.xlsx";

    public static String IBR_NORMAL_BANK_EXCEL_FILE_NAME = "IbrBankNormal.xlsx";

    public static String VAR_BANK_EXCEL_FILE_NAME = "VarBank.xlsx";

    public static String VAR_NORMAL_EXCEL_FILE_NAME = "VarNormal.xlsx";

    public static String SETTLEMENT_NORMAL_EXCEL_FILENAME = "SettlementNormal.xlsx";

    public static String SETTLEMENT_BANK_EXCEL_FILENAME = "SettlementBank.xlsx";

    public static String COUNTRY_NORMAL_EXCEL_FILE_NAME = "CountryNormal.xlsx";

    public static String COUNTRY_BANK_EXCEL_FILE_NAME = "CountryBank.xlsx";

    public static String IBR_CSV_FILE_NAME = "Ibr.csv";

    public static String IBR_BANK_CSV_FILE_NAME = "Ibr_bank.csv";

    public static String VAR_NORMAL_CSV_FILE_NAME = "VarNormal.csv";

    public static String VAR_BANK_CSV_FILE_NAME = "VarBank.csv";

    public static String SETTLEMENT_NORMAL_CSV_FILENAME = "SettlementNormal.csv";

    public static String SETTLEMENT_BANK_CSV_FILENAME = "SettlementBank.csv";

    public static String COUNTRY_NORMAL_CSV_FILE_NAME = "CountryNormal.csv";

    public static String COUNTRY_BANK_CSV_FILE_NAME = "CountryBank.csv";

    // Header Name
    public static String[] IBR_BANK_HEADER_NAME = { "CCY", "Currency Name", "Bid value", "Ask value",
            "Service provider", "Bank Code", "Product", "Last Update" };

    public static String[] IBR_NORMAL_HEADER_NAME = { "CCY", "Currency Name", "Bid value", "Ask value",
            "Service provider", "Product", "Last Update"  };

    public static String[] VAR_BANK_NORMAL_HEADER_NAME = { "CCY", "IBR Bid", "IBR Ask", "Service provider", "Bank Code",
            "Product", "Product Sub type", "Service Type", "CASH BidMargin", "CASH AskMargin", "CASH SettlementSell",
            "CASH SettlementBuy", "Tom Bid Margin", "Tom Ask Margin", "Tom Settlement Sell", "Tom Settlement Buy",
            "Spot Bid Margin", "Spot Ask Margin", "Spot Settlement Sell", "Spot Settlement Buy", "Future Bid Margin",
            "Future Ask Margin", "Future Settlement Sell", "Future Settlement Buy", "Reason for Change", "Status" };

    public static String[] VAR_NORMAL_HEADER_NAME = { "CCY", "IBR Bid", "IBR Ask", "Service provider", "Agent Id",
            "Product", "Product Sub type", "Service Type", "CASH Bid Margin", "CASH Ask Margin", "CASH Settlement Sell",
            "CASH Settlement Buy", "Tom Bid Margin", "Tom Ask Margin", "Tom Settlement Sell", "Tom Settlement Buy",
            "Spot Bid Margin", "Spot Ask Margin", "Spot Settlement Sell", "Spot Settlement Buy", "Future Bid Margin",
            "Future Ask Margin", "Future Settlement Sell", "Future Settlement Buy", "Reason for change", "Status" };

    public static String[] NORMAL_SETTLEMENT_HEADER_NAME = { "CCD", "Service provider", "Agent Id", "Product",
            "Product Sub type", "Product Service Type", "SettleMent Cash cost rate sell", "SettleMent Cash sell margin",
            "SettleMent Tom cost rate sell", "SettleMent Tom sell margin", "SettleMent Spot cost rate sell",
            "SettleMent Spot sell margin", "SettleMent Future cost rate sell", "SettleMent Future sell margin",
            "SettleMent Cash cost rate Buy", "SettleMent Cash Buy margin", "SettleMent Tom cost rate Buy",
            "SettleMent Tom Buy margin", "SettleMent Spot cost rate Buy", "SettleMent Spot Buy margin",
            "SettleMent Future cost rate Buy", "SettleMent Future Buy margin", "Reason for change", "Status" };

    public static String[] BANK_SETTLEMENT_HEADER_NAME = { "CCD", "Service provider", "Agent Id", "Bank code",
            "Product", "Product Sub type", "Product Service Type", "SettleMent Cash cost rate sell",
            "SettleMent Cash sell margin", "SettleMent Tom cost rate sell", "SettleMent Tom sell margin",
            "SettleMent Spot cost rate sell", "SettleMent Spot sell margin", "SettleMent Future cost rate sell",
            "SettleMent Future sell margin", "SettleMent Cash cost rate Buy", "SettleMent Cash Buy margin",
            "SettleMent Tom cost rate Buy", "SettleMent Tom Buy margin", "SettleMent Spot cost rate Buy",
            "SettleMent Spot Buy margin", "SettleMent Future cost rate Buy", "SettleMent Future Buy margin",
            "Reason for change", "Status" };

    public static String[] COUNTRY_NORMAL_HEADER_NAME = { "Base CCY", "Foreign CCY", "Service provider", "Agent Id",
            "Product", "Product Sub type", "Product Service Type", "Currency", "Country Cash cost rate sell",
            "Country Cash sell margin", "Agent cash sell", "Country Tom cost rate sell", "Country Tom sell margin",
            "Agent Tom sell", "Country Spot cost rate sell", "Country Spot sell margin", "Agent Spot sell",
            "Country Future cost rate sell", "Country Future sell margin", "Agent Future sell",
            "Country Cash cost rate Buy", "Country Cash Buy margin", "Agent cash buy", "Country Tom cost rate Buy",
            "Country Tom Buy margin", "Agent Tom buy", "Country Spot cost rate Buy", "Country Spot Buy margin",
            "Agent Spot buy", "Country Future cost rate Buy", "Country Future Buy margin", "Agent Future buy",
            "Status" };

    public static String[] COUNTRY_BANK_HEADER_NAME = { "Base CCY", "Foreign CCY", "Service provider", "Agent Id",
            "BankCode", "Product", "Product Sub type", "Product Service Type", "Currency",
            "Country Cash cost rate sell", "Country Cash sell margin", "Agent cash sell", "Country Tom cost rate sell",
            "Country Tom sell margin", "Agent Tom sell", "Country Spot cost rate sell", "Country Spot sell margin",
            "Agent Spot sell", "Country Future cost rate sell", "Country Future sell margin", "Agent Future sell",
            "Country Cash cost rate Buy", "Country Cash Buy margin", "Agent cash buy", "Country Tom cost rate Buy",
            "Country Tom Buy margin", "Agent Tom buy", "Country Spot cost rate Buy", "Country Spot Buy margin",
            "Agent Spot buy", "Country Future cost rate Buy", "Country Future Buy margin", "Agent Future buy",
            "Status" };

    public static String IBR_LAYER = "NormalIbr";

    public static String IBR_BANK_LAYER = "NormalBankIbr";

    public static String VAR_BANK_LAYER = "VarBankLayer";

    public static String VAR_NORMAL_LAYER = "VarIbrLayer";

    public static String SETTLEMENT_NORMAL_LAYER = "SettlementNormalLayer";

    public static String SETTLEMENT_BANK_LAYER = "SettlementBankLayer";

    public static String COUNTRY_NORMAL_LAYER = "CountryNormalLayer";

    public static String COUNTRY_BANK_LAYER = "CountryBankLayer";

    // field mapping for csv
    public static String[] FIELD_MAPPING_NAME_IBR_NORMAL = { "exchange.currency.ccy", "exchange.rate.bidValue",
            "exchange.rate.askValue", "serviceProvider", "product", "updatedOn", "status" };

    public static String[] FIELD_MAPPING_NAME_IBR_BANK = { "rateId", "serviceProvider", "product", "ccy", "askValue",
            "bidValue", "bank", "updatedOn", "status" };
}
