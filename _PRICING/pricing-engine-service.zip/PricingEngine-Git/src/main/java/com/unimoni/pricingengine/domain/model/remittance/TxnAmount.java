package com.unimoni.pricingengine.domain.model.remittance;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import org.zalando.problem.Status;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.common.exception.RemittanceTransactionException;
import com.unimoni.pricingengine.common.exception.RemittanceTransactionException.RemittanceTransactionExceptionType;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode
@ToString
@ApiModel(value = "amount", description = "Transaction amount with type such as PAYIN or PAYOUT")
@Embeddable
public class TxnAmount {

    @JsonProperty
    @ApiModelProperty(name = "value", dataType = "BigDecimal", value = "Transaction amount in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @NotNull
    // @formatter:off
    @Column(name = "AMOUNT_VALUE",  
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE")
    //@formatter:on
    private BigDecimal value;

    @JsonProperty
    @ApiModelProperty(name = "type", dataType = "String", value = "Amount Type", required = true, example = "PAYIN", allowableValues = "PAYIN, PAYOUT")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "AMOUNT_TYPE", nullable = false, updatable = false, length = 20)
    private AmountType type;

    public TxnAmount payin(final BigDecimal value) {
        return of(value, AmountType.PAYIN);
    }

    public TxnAmount payout(final BigDecimal value) {
        return of(value, AmountType.PAYOUT);
    }

    private static final String SEPERATOR = ",";

    public static TxnAmount fromString(final String stringValue) {
        String[] params = stringValue.split(SEPERATOR);
        if (params == null || params.length != 2
                || !(params[1].trim().equals(AmountType.PAYIN.name()) || params[1].trim().equals(AmountType.PAYOUT.name()))) {
            throw new RemittanceTransactionException(
                    RemittanceTransactionExceptionType.ILLEGAL_AMOUNT_WITH_TYPE_REQUEST_PARAMETER, Status.BAD_REQUEST,
                    stringValue);
        } else {
            return of(new BigDecimal(params[0].trim()), AmountType.of(params[1].trim()));
        }
    }
    
    @ApiModel(value = "amountType", description = "Amount Type either PAYIN or PAYOUT")
    public static enum AmountType {

        // @formatter:off
        PAYIN("Payin"),
        PAYOUT("Payout");
        // @formatter:on

        private final String description;

        private AmountType(final String description) {
            this.description = description;
        }

        public String description() {
            return this.description;
        }

        @JsonCreator
        public static AmountType of(final String typeName) {
            return AmountType.valueOf(typeName);
        }
        
        public boolean isPayIn() {
        	return this == AmountType.PAYIN;
        }

        public boolean isPayOut() {
        	return this == AmountType.PAYOUT;
        }
    }
}
