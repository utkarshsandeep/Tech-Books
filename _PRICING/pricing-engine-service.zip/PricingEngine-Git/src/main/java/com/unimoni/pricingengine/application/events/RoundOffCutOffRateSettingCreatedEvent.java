package com.unimoni.pricingengine.application.events;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RoundOffCutOffRateSettingCreatedEvent {

    private long agentId;

    private long agentBranchId;

    private long roundOffCutOffRateSettingId;

    public RoundOffCutOffRateSettingCreatedEvent(long agentId, long agentBranchId, long roundOffCutOffRateSettingId) {
        super();
        this.agentId = agentId;
        this.agentBranchId = agentBranchId;
        this.roundOffCutOffRateSettingId = roundOffCutOffRateSettingId;
    }

}
