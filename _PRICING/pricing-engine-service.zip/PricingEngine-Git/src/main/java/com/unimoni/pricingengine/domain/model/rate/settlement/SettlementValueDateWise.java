package com.unimoni.pricingengine.domain.model.rate.settlement;

import static com.unimoni.pricingengine.common.constants.ApplicationConstants.CURRENCY_UNIT_USD;
import static com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType.NON_USD_CUURENCY_PAIR_INVALID;
import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import java.math.BigDecimal;

import javax.money.CurrencyUnit;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.composable.Settlement;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode
@ToString(includeFieldNames = true)
@Embeddable
@Access(AccessType.FIELD)
@Audited
public class SettlementValueDateWise {

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "SETTLEMENT_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "SETTLEMENT_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost settlement;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "MARGIN_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "MARGIN_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    @Setter
    private Cost margin;

    @NotNull
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "sellValue", 
            column = @Column(name = "COUNTRY_SELL", 
                columnDefinition = "NUMBER(*,10)")),
        @AttributeOverride(name = "buyValue", 
            column = @Column(name = "COUNTRY_BUY", 
                columnDefinition = "NUMBER(*,10)")) 
    })
    // @formatter:on
    @Embedded
    private Cost country;

    public static SettlementValueDateWise of(final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency,
            final Cost settlement, final Cost margin) {
        SettlementValueDateWise settlementValueDateWise = new SettlementValueDateWise();
        settlementValueDateWise.settlement = settlement;
        settlementValueDateWise.margin = margin;
        settlementValueDateWise.country = calculateCountryCost(sourceCurrency, targetCurrency, settlement, margin);
        return settlementValueDateWise;
    }

    public static SettlementValueDateWise zero() {
        return SettlementValueDateWise.of(Cost.ZERO, Cost.ZERO, Cost.ZERO);
    }

    public static SettlementValueDateWise byDefault(final CurrencyUnit sourceCurrency,
            final CurrencyUnit targetCurrency, final Settlement varSettlement) {
        SettlementValueDateWise settlementValueDateWise = new SettlementValueDateWise();
        settlementValueDateWise.settlement = Cost.of(varSettlement.sellValue(), varSettlement.buyValue());
        settlementValueDateWise.margin = Cost.ZERO;
        settlementValueDateWise.country = calculateCountryCost(sourceCurrency, targetCurrency,
                settlementValueDateWise.settlement, settlementValueDateWise.margin);
        return settlementValueDateWise;
    }

    public boolean updateSettlementCostFromVaR(final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency,
            final Settlement varSettlement) {
        Cost newSettlement = Cost.of(varSettlement.sellValue(), varSettlement.buyValue());
        if (this.settlement.equals(newSettlement)) {
            return false;
        }
        else {
            this.settlement = newSettlement;
            this.country = calculateCountryCost(sourceCurrency, targetCurrency, newSettlement, this.margin);
            return true;
        }
    }

    public boolean updateMarginCost(final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency,
            final Cost newMargin) {
        if (this.margin.equals(newMargin)) {
            return false;
        }
        else {
            this.margin = newMargin;
            this.country = calculateCountryCost(sourceCurrency, targetCurrency, this.settlement, newMargin);
            return true;
        }
    }

    private static Cost calculateCountryCost(final CurrencyUnit sourceCurrency, final CurrencyUnit targetCurrency,
            final Cost settlement, final Cost margin) {
        Cost country = null;
        if (sourceCurrency == CURRENCY_UNIT_USD) {
            // for scenario where From Currency = USD
            // Country Sell in USD = Settlement Sell – Settlement Buy margin
            // Country Buy in USD = Settlement Buy + Settlement Sell margin
            BigDecimal countrySell = settlement.sellValue().subtract(margin.buyValue());
            BigDecimal countryBuy = settlement.buyValue().add(margin.sellValue());
            country = Cost.of(countrySell, countryBuy);
        }
        else if (targetCurrency == CURRENCY_UNIT_USD) {
            // for scenario To Currency = USD
            // Country Sell in USD = Settlement Sell - Settlement Buy Margin
            // Country Buy in USD = Settlement Buy + Settlement Sell margin
            BigDecimal countrySell = settlement.sellValue().subtract(margin.buyValue());
            BigDecimal countryBuy = settlement.buyValue().add(margin.sellValue());
            country = Cost.of(countrySell, countryBuy);
        }
        else {
            throw new RateException(NON_USD_CUURENCY_PAIR_INVALID, sourceCurrency, targetCurrency);
        }

        validatePositive(country.buyValue(), "Country Buy");
        validatePositive(country.sellValue(), "Country Sell");

        return country;
    }
}
