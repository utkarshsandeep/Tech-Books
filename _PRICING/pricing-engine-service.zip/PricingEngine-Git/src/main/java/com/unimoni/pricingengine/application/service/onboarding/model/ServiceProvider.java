package com.unimoni.pricingengine.application.service.onboarding.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;

@Getter
public class ServiceProvider extends AbstractPairItem {

    private List<Bank> banks;

    private List<Agent> agents;

    private ServiceProvider(final String code, final String name) {
        super(code, name);
        this.banks = new ArrayList<>();
        this.agents = new ArrayList<>();
    }

    public static ServiceProvider of(final String code, final String name, final List<Bank> banks,
            final List<Agent> agents) {
        ServiceProvider serviceProvider = new ServiceProvider(code, name);
        if (banks != null && !banks.isEmpty()) {
            serviceProvider.banks.addAll(banks);
        }
        if (agents != null && !agents.isEmpty()) {
            serviceProvider.agents.addAll(agents);
        }
        return serviceProvider;
    }

    public void refreshAgents(final List<Agent> agents) {
        this.agents = agents;
    }

    public void refreshBanks(final List<Bank> banks) {
        this.banks = banks;
    }
}
