package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceProviderResponse {

    private List<String> uniqueTypes;

    private AllowedProductSendRules allowedProductSendRules;

    public ServiceProviderResponse(@JsonProperty("uniqueTypes") List<String> uniqueTypes,
            @JsonProperty("allowedProductSendRules") AllowedProductSendRules allowedProductSendRules) {
        super();
        this.uniqueTypes = uniqueTypes;
        this.allowedProductSendRules = allowedProductSendRules;
    }

}
