package com.unimoni.pricingengine.domain.model.rate.authorizationsetting;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.common.type.BaseUUIDIdentifiableVersionableEntity;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateLayerType;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingIdentity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
//@formatter:off
@Table(name = "AUTHORIZATION_SETTING",   
    indexes = {
            @Index(name = "IDX_AUTHORIZATION_SETTING_RATE_TYPE", columnList = "RATE_TYPE"),
            @Index(name = "IDX_AUTHORIZATION_SETTING_RATE_LAYER_TYPE", columnList = "RATE_LAYER_TYPE"),
            @Index(name = "IDX_AUTHORIZATION_SETTING_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
            @Index(name = "IDX_AUTHORIZATION_SETTING_BANK_CODE", columnList = "BANK_CODE"),
            @Index(name = "IDX_AUTHORIZATION_SETTING_AGENT_CODE", columnList = "AGENT_CODE"),
            @Index(name = "IDX_AUTHORIZATION_SETTING_CURRENCY", columnList = "CURRENCY"),
            @Index(name = "IDX_AUTHORIZATION_SETTING_ENABLED", columnList = "ENABLED")        
    }
)
//@formatter:on
@Audited
public class AuthorizationSetting extends BaseUUIDIdentifiableVersionableEntity<String, Long> {

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RATE_TYPE", nullable = false, updatable = false, length = 20)
    private RMType rateType;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "RATE_LAYER_TYPE", nullable = false, updatable = false, length = 50)
    private RateLayerType rateLayerType;

    @NotNull
    @Column(name = "SERVICE_PROVIDER_CODE", updatable = false, nullable = false, length = 100)
    protected String serviceProvider;

    @Column(name = "BANK_CODE", updatable = false, nullable = true, length = 100)
    private String bankCode;

    @NotNull
    @Column(name = "AGENT_CODE", updatable = false, nullable = false, length = 100)
    private String agentCode;

    @NotNull
    @Column(name = "CURRENCY", updatable = false, nullable = false, length = 100)
    private CurrencyUnit currency;

    @Getter(value = AccessLevel.NONE)
    @NotNull
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "ENABLED", length = 1)
    private boolean enabled;

    public boolean isEnabled() {
        return this.enabled;
    }

    @NotNull
    // @formatter:off
    @Column(name = "UPDATED_ON", 
            columnDefinition = "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP")
    // @formatter:on
    private ZonedDateTime updatedOn;

    public void updateStatus(final boolean status) {
        this.enabled = status;
    }

    public void updatedNow() {
        this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
    }

    public void updatedOn(final ZonedDateTime zonedDateTime) {
        this.updatedOn = zonedDateTime;
    }

    public AuthorizationSettingIdentity identity() {
        return AuthorizationSettingIdentity.of(this.rateType, this.rateLayerType, this.serviceProvider, this.bankCode,
                this.agentCode, this.currency);

    }

    /**
     * @desc to create new enabled object from identity
     * @param identities
     * @param zd
     * @return
     */
    public static List<AuthorizationSetting> of(List<AuthorizationSettingIdentity> identities, ZonedDateTime zd) {
        final List<AuthorizationSetting> instances = new ArrayList<>(identities.size());

        for (final AuthorizationSettingIdentity identity : identities) {
            if (RMType.BANK_WISE == identity.getRateType()
                    && (identity.getBankCode() == null || identity.getBankCode().isEmpty())) {
                throw new RateException(RateExceptionExceptionType.BANK_CODE_MANDAOTRY, Status.PRECONDITION_FAILED);
            }
            instances.add(AuthorizationSetting.of(identity.getRateType(), identity.getRateLayerType(),
                    identity.getServiceProvider(), identity.getBankCode(), identity.getAgentCode(),
                    identity.getCurrency(), true, zd)); // create enabled record with current timestamp
        }

        return instances;
    }

}
