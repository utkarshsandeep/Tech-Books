package com.unimoni.pricingengine.domain.model.enquiry.settlement;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.money.CurrencyUnit;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;
import com.unimoni.pricingengine.common.util.Counter;
import com.unimoni.pricingengine.domain.model.enquiry.StreamRequest;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

@Slf4j
@Getter
@Accessors(chain = true, fluent = true)
@ToString(callSuper = true)
public class SettlementRateEnquiryRequest extends StreamRequest {

    private List<String> serviceProviders;

    private List<String> products;

    private List<String> subProducts;

    private List<String> serviceTypes;

    private List<String> banks;

    private List<String> agents;

    private List<CurrencyUnit> currencies;

    private EnumSet<VDWType> valueDateWises;

    private int endIndex;

    private SettlementRateEnquiryRequest(final int nextIndex, final int batchSize, final List<String> serviceProviders,
            final List<String> products, final List<String> subProducts, final List<String> serviceTypes,
            final List<String> banks, final List<String> agents, final List<CurrencyUnit> currencies,
            final EnumSet<VDWType> valueDateWises) {
        super(nextIndex, batchSize);
        this.serviceProviders = serviceProviders;
        this.products = products;
        this.subProducts = subProducts;
        this.serviceTypes = serviceTypes;
        this.banks = banks;
        this.agents = agents;
        this.currencies = currencies;
        this.valueDateWises = valueDateWises;
    }

    public static SettlementRateEnquiryRequest ofNormal(final Integer startingIndex, final Integer batchSize,
            final Set<String> serviceProviders, final Set<String> products, final Set<String> subProducts,
            final Set<String> serviceTypes, final Set<String> agents, final Set<String> valueDateWises,
            final Set<CurrencyUnit> currencies, final Set<CurrencyUnit> settlementCurrencies) {
        MasterData masterData = BeanFactory.masterData();
        return new SettlementRateEnquiryRequest(startingIndex == null ? 0 : startingIndex,
                batchSize == null ? DEFAULT_BATCH_SIZE : batchSize,
                masterData.validateServiceProviders(serviceProviders), masterData.validateProducts(products),
                masterData.validateSubProducts(subProducts), masterData.validateServiceTypes(serviceTypes), null,
                masterData.validateNormalAgent(agents), masterData.validateCurrencies(currencies, settlementCurrencies),
                VDWType.validate(valueDateWises));
    }

    public static SettlementRateEnquiryRequest ofBankWise(final Integer startingIndex, final Integer batchSize,
            final Set<String> serviceProviders, final Set<String> products, final Set<String> subProducts,
            final Set<String> serviceTypes, final Set<String> banks, final Set<String> agents,
            final Set<String> valueDateWises, final Set<CurrencyUnit> currencies,
            final Set<CurrencyUnit> settlementCurrencies) {
        MasterData masterData = BeanFactory.masterData();
        return new SettlementRateEnquiryRequest(startingIndex == null ? 0 : startingIndex,
                batchSize == null ? DEFAULT_BATCH_SIZE : batchSize,
                masterData.validateServiceProviders(serviceProviders), masterData.validateProducts(products),
                masterData.validateSubProducts(subProducts), masterData.validateServiceTypes(serviceTypes),
                masterData.validateBanks(banks), masterData.validateBankWiseAgent(agents),
                masterData.validateCurrencies(currencies, settlementCurrencies), VDWType.validate(valueDateWises));
    }

    @SuppressWarnings("unchecked")
    public Flux<SettlementRateEnquiryIdentity> identities(final RMType rmType) {
        ImmutableList<String> sps = ImmutableList.copyOf(this.serviceProviders);
        ImmutableList<String> prds = ImmutableList.copyOf(this.products);
        ImmutableList<String> sbprds = ImmutableList.copyOf(this.subProducts);
        ImmutableList<String> srvctps = ImmutableList.copyOf(this.serviceTypes);
        ImmutableList<String> agnts = ImmutableList.copyOf(this.agents);
        ImmutableList<CurrencyUnit> currs = ImmutableList.copyOf(this.currencies);

        List<List<Object>> combinations = Collections.emptyList();
        if (rmType.isNormal()) {
            combinations = Lists.cartesianProduct(sps, prds, sbprds, srvctps, agnts, currs);
        }
        else {
            ImmutableList<String> bnks = ImmutableList.copyOf(this.banks);
            combinations = Lists.cartesianProduct(sps, prds, sbprds, srvctps, bnks, agnts, currs);
        }

        this.endIndex = combinations.size() - 1;
        log.debug("SettlementRateEnquiryRequest --> {} \n total combinations --> {}", this, this.endIndex + 1);

        Counter indexCounter = Counter.initialize("index-counter");
        Iterator<List<Object>> itr = combinations.iterator();
        while (itr.hasNext() && indexCounter.get() < this.nextIndex()) {
            itr.next();
            indexCounter.increment();
        }

        return Flux.generate(() -> itr, (state, sink) -> {
            if (state.hasNext()) {
                List<Object> combination = state.next();
                if (rmType.isNormal()) {
                    sink.next(SettlementRateEnquiryIdentity.ofNormal(indexCounter.get(), (String) combination.get(0),
                            (String) combination.get(1), (String) combination.get(2), (String) combination.get(3),
                            (String) combination.get(4), (CurrencyUnit) combination.get(5), this.valueDateWises));
                }
                else {
                    sink.next(SettlementRateEnquiryIdentity.ofBankWise(indexCounter.get(), (String) combination.get(0),
                            (String) combination.get(1), (String) combination.get(2), (String) combination.get(3),
                            (String) combination.get(4), (String) combination.get(5), (CurrencyUnit) combination.get(6),
                            this.valueDateWises));
                }
                indexCounter.increment();
            }
            else {
                sink.complete();
            }
            return state;
        });
    }
}
