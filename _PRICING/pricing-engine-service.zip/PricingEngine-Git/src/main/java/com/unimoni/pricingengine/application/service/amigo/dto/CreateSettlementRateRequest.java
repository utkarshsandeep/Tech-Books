package com.unimoni.pricingengine.application.service.amigo.dto;

import java.math.BigDecimal;

import javax.validation.constraints.PositiveOrZero;

import com.unimoni.pricingengine.domain.model.rate.composable.Cost;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(value = "amigoCreateSettlementRateRequest", description = "The request to create new Settlement rate by Amigo")
public class CreateSettlementRateRequest extends VDWRateAmigoRequest {

    @ApiModelProperty(name = "cashSettlementSellMargin", dataType = "BigDecimal", value = "CASH Settlement sell margin in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 9)
    @PositiveOrZero
    private BigDecimal cashSettlementSellMargin;

    @ApiModelProperty(name = "cashSettlementBuyMargin", dataType = "BigDecimal", value = "CASH Settlement buy margin in BigDecimal with 8 decimal points precision", required = true, example = "75.32560000", position = 10)
    @PositiveOrZero
    private BigDecimal cashSettlementBuyMargin;

    public Cost cashMarginCost() {
        return Cost.of(this.cashSettlementSellMargin, this.cashSettlementBuyMargin);
    }
}
