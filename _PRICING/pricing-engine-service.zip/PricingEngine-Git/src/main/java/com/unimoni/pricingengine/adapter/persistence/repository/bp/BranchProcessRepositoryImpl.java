package com.unimoni.pricingengine.adapter.persistence.repository.bp;

import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.unimoni.pricingengine.adapter.persistence.AbstractJPA;
import com.unimoni.pricingengine.domain.model.bp.BranchProcess;
import com.unimoni.pricingengine.domain.model.bp.BranchProcess_;
import com.unimoni.pricingengine.domain.model.bp.StatusType;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;

@Repository
public class BranchProcessRepositoryImpl extends AbstractJPA implements BranchProcessJPA {

    @Autowired
    EntityManager entityManager;

    @Override
    public List<BranchProcess> findBranchProcessByDealId(String deal) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

        CriteriaQuery<BranchProcess> query = criteriaQuery(BranchProcess.class);
        Root<BranchProcess> bP = query.from(BranchProcess.class);
        query.where(BPPredicates.getBPDealPredictaes(criteriaBuilder, bP, deal, null));
        query.select(bP);

        TypedQuery<BranchProcess> typedQuery = typedQuery(query);
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public List<BranchProcess> findAll(PaginationData page) {

        long totalRecords = findBranchProcessRatesCount();
        page.totalRecords(totalRecords);
        if (totalRecords == 0) {
            return Collections.emptyList();
        }
        else {
            CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

            CriteriaQuery<BranchProcess> query = criteriaQuery(BranchProcess.class);
            Root<BranchProcess> rate = query.from(BranchProcess.class);

            query.where(BPPredicates.getBPDealPredictaesWithCreationDate(criteriaBuilder, rate));
            query.orderBy(criteriaBuilder.asc(rate.get(BranchProcess_.status)));
            query.select(rate);

            TypedQuery<BranchProcess> typedQuery = typedQuery(query);

            typedQuery.setFirstResult(page.queryFirstResult());
            typedQuery.setMaxResults(page.queryMaxResults());
            return getUnmodifiableResultList(typedQuery);
        }
    }

    private long findBranchProcessRatesCount() {
        CriteriaBuilder criteriaBuilder = criteriaBuilder();
        CriteriaQuery<Long> query = criteriaQuery(Long.class);
        Root<BranchProcess> rate = query.from(BranchProcess.class);
        query.where(BPPredicates.getBPDealPredictaesWithCreationDate(criteriaBuilder, rate));

        query.select(criteriaBuilder.countDistinct(rate));
        return typedQuery(query).getSingleResult().longValue();
    }

    @Override
    public BranchProcess findByDealIdAndStatus(String dealId, StatusType status) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

        CriteriaQuery<BranchProcess> query = criteriaQuery(BranchProcess.class);
        Root<BranchProcess> bP = query.from(BranchProcess.class);
        query.where(BPPredicates.getBPDealPredictaes(criteriaBuilder, bP, dealId, status));
        query.select(bP);

        TypedQuery<BranchProcess> typedQuery = typedQuery(query);
        List<BranchProcess> bpList = getUnmodifiableResultList(typedQuery);
        if (bpList != null && bpList.size() == 1) {
            return bpList.get(0);
        }
        else
            return null;
    }

    @Override
    public List<BranchProcess> findByStatus(StatusType status) {

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

        CriteriaQuery<BranchProcess> query = criteriaQuery(BranchProcess.class);
        Root<BranchProcess> bP = query.from(BranchProcess.class);
        query.where(BPPredicates.getBPDealPredictaes(criteriaBuilder, bP, null, status));
        query.select(bP);

        TypedQuery<BranchProcess> typedQuery = typedQuery(query);
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public List<BranchProcess> findByStatusEnumSet(EnumSet<StatusType> status) {

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

        CriteriaQuery<BranchProcess> query = criteriaQuery(BranchProcess.class);
        Root<BranchProcess> bP = query.from(BranchProcess.class);
        query.where(BPPredicates.getBPPredictaesForRequestedOrAccepted(criteriaBuilder, bP, status));
        query.select(bP);

        TypedQuery<BranchProcess> typedQuery = typedQuery(query);
        return getUnmodifiableResultList(typedQuery);
    }

    @Override
    public Optional<BranchProcess> findBranchProcessByBranchProcessId(String bpId) {
        BranchProcess bp = entityManager.find(BranchProcess.class, bpId);
        return bp == null ? Optional.empty() : Optional.of(bp);
    }
}
