package com.unimoni.pricingengine.domain.model.rate.settlement.dto;

import java.math.BigDecimal;
import java.util.Optional;

import com.unimoni.pricingengine.domain.model.rate.RateValue;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "updateMargin", description = "Margin update for Settlement Rate")
public class UpdateMarginDTO {

    @ApiModelProperty(name = "marginSell", dataType = "BigDecimal", value = "Margin Sell Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private BigDecimal marginSell;

    @ApiModelProperty(name = "marginBuy", dataType = "BigDecimal", value = "Margin Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private BigDecimal marginBuy;

    public Optional<BigDecimal> marginSell() {
        return Optional.ofNullable(this.marginSell);
    }

    public Optional<BigDecimal> marginBuy() {
        return Optional.ofNullable(this.marginBuy);
    }
}
