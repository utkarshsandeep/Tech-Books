package com.unimoni.pricingengine.domain.model.rate.country;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@ApiModel(value = "agentItem", description = "Agent or Agent Branch code with type: AGENT|BRANCH")
@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor
@Embeddable
public class AgentItem {

    @NotEmpty
    @ApiModelProperty(name = "code", dataType = "String", value = "The agent code", required = true, allowEmptyValue = false, example = "SMITH")
    @Column(name = "AGENT_CODE", updatable = false, length = 100)
    private String code;

    @ApiModelProperty(name = "type", dataType = "String", value = "Whether its an agent or branch", example = "AGENT", allowableValues = "AGENT,BRANCH", position = 4)
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "AGENT_TYPE", updatable = false, length = 20)
    private Type type;

    public static AgentItem ofAgent(final String code) {
        return of(code, Type.AGENT);
    }

    public static AgentItem ofBranch(final String code) {
        return of(code, Type.BRANCH);
    }

    public AgentDetails details() {
        return AgentDetails.of(this.code, rateDisplayMechanism(), this.type);
    }

    public RateDisplayMachenism rateDisplayMechanism() {
        return BeanFactory.masterData().getAgentOrBranchRateDisplayMechanism(this.code);
    }
    
    @JsonIgnore
    public boolean isBranch() {
        return this.type.isBranch();
    }

    public enum Type {

        AGENT, BRANCH;

        public boolean isAgent() {
            return this == AGENT;
        }

        public boolean isBranch() {
            return this == BRANCH;
        }
    }
}
