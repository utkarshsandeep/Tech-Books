package com.unimoni.pricingengine.application.events;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
// @JsonIgnoreProperties(ignoreUnknown = true)
public class AgentOnboardEvent {

    private long agentId;

    private long agentBranchId;

    private long allowedProductsSendRuleId;

    public AgentOnboardEvent(long agentId, long agentBranchId, long allowedProductsSendRuleId) {
        super();
        this.agentId = agentId;
        this.agentBranchId = agentBranchId;
        this.allowedProductsSendRuleId = allowedProductsSendRuleId;
    }

    // public AgentOnboardEvent() {
    // }
    //
    // @JsonCreator
    // public AgentOnboardEvent(final long agentId, final long agentBranchId) {
    // this.agentId = agentId;
    // this.agentBranchId = agentBranchId;
    // }

}
