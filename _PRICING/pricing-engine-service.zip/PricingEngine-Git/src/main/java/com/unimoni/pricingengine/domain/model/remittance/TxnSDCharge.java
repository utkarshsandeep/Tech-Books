package com.unimoni.pricingengine.domain.model.remittance;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal3PointsSerializer;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@ToString
@ApiModel(value = "transactionCharges", description = "Remittance Transaction Charges")
@Embeddable
@org.hibernate.annotations.Immutable
public class TxnSDCharge {

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "additionalCharges", dataType = "BigDecimal", value = "Additional charges in BigDecimal with "
            + RateValue.DECIMAL_POINTS_3
            + " decimal points precision", required = true, example = "12.325", position = 1)
    @JsonSerialize(using = BigDecimal3PointsSerializer.class)
    @Column(name = "ADDITIONAL_CHARGES", columnDefinition = "NUMBER(*,10)", updatable = false)
    private BigDecimal additionalCharges;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "cardCharges", dataType = "BigDecimal", value = "Card charges in BigDecimal with "
            + RateValue.DECIMAL_POINTS_3
            + " decimal points precision", required = true, example = "12.325", position = 3)
    @JsonSerialize(using = BigDecimal3PointsSerializer.class)
    // @formatter:off
    @Column(name = "CARD_CHARGES",  
            columnDefinition = "NUMBER(*,10)", updatable = false)
    //@formatter:on
    private BigDecimal cardCharges;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "commission", dataType = "BigDecimal", value = "Commission in BigDecimal with "
            + RateValue.DECIMAL_POINTS_3
            + " decimal points precision", required = true, example = "12.325", position = 4)
    @JsonSerialize(using = BigDecimal3PointsSerializer.class)
    // @formatter:off
    @Column(name = "COMMISSION",  
            columnDefinition = "NUMBER(*,10)", updatable = false)
    //@formatter:on
    private BigDecimal commission;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "otherCharges", dataType = "BigDecimal", value = "Other charges in BigDecimal with "
            + RateValue.DECIMAL_POINTS_3
            + " decimal points precision", required = true, example = "12.325", position = 5)
    @JsonSerialize(using = BigDecimal3PointsSerializer.class)
    // @formatter:off
    @Column(name = "OTHER_CHARGES",  
            columnDefinition = "NUMBER(*,10)", updatable = false)
    //@formatter:on
    private BigDecimal otherCharges;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "tax", dataType = "BigDecimal", value = "Tax charges in BigDecimal with "
            + RateValue.DECIMAL_POINTS_3
            + " decimal points precision", required = true, example = "12.325", position = 6)
    @JsonSerialize(using = BigDecimal3PointsSerializer.class)
    // @formatter:off
    @Column(name = "TAX",  
            columnDefinition = "NUMBER(*,10)", updatable = false)
    //@formatter:on
    private BigDecimal tax;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "rate", dataType = "BigDecimal", value = "Rate calculated from Pricing Layers in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8
            + " decimal points precision", required = true, example = "12.32560000", position = 7)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    // @formatter:off
    @Column(name = "RATE",  
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE", updatable = false)
    //@formatter:on
    private BigDecimal rate;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "swiftCharges", dataType = "BigDecimal", value = "Rate calculated from Pricing Layers in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8
            + " decimal points precision", required = true, example = "12.32560000", position = 7)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    // @formatter:off
    @Column(name = "SWIFT_CHARGES",  
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE", updatable = false)
    //@formatter:on   
    private BigDecimal swiftCharges;
    
    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "swiftChargesInSettlementCurrency", dataType = "BigDecimal", value = "Rate calculated from Pricing Layers in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8
            + " decimal points precision", required = true, example = "12.32560000", position = 7)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    // @formatter:off
    @Column(name = "SWIFT_CHARGES_IN_SETTLEMENT",  
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE", updatable = false)
    //@formatter:on   
    private BigDecimal swiftChargesInSettlementCurrency;
    
    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "swiftChargesInPassSettlementCurrency", dataType = "BigDecimal", value = "Rate calculated from Pricing Layers in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8
            + " decimal points precision", required = true, example = "12.32560000", position = 7)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    // @formatter:off
    @Column(name = "SWIFT_CHARGES_IN_PASS_SETTLEMENT",  
            columnDefinition = "NUMBER(*,10) NOT NULL ENABLE", updatable = false)
    //@formatter:on   
    private BigDecimal swiftChargesInPassSettlementCurrency;

    public static TxnSDCharge of(final BigDecimal additionalCharges, final BigDecimal cardCharges,
            final BigDecimal commission, final BigDecimal otherCharges, final BigDecimal tax,
            final BigDecimal agentPayoutRate, final BigDecimal swiftCharges,
            final BigDecimal swiftChargesInSettlementCurrency, final BigDecimal swiftChargesInPassSettlementCurrency) {
        TxnSDCharge txnSDCharge = new TxnSDCharge();
        txnSDCharge.additionalCharges = additionalCharges == null ? RateValue.ZERO : additionalCharges;
        txnSDCharge.cardCharges = cardCharges == null ? RateValue.ZERO : cardCharges;
        txnSDCharge.commission = commission;
        txnSDCharge.otherCharges = otherCharges == null ? RateValue.ZERO : otherCharges;
        txnSDCharge.tax = tax == null ? RateValue.ZERO : tax;
        txnSDCharge.rate = agentPayoutRate == null ? RateValue.ZERO : agentPayoutRate;
        txnSDCharge.swiftCharges = swiftCharges == null ? RateValue.ZERO : swiftCharges;
        txnSDCharge.swiftChargesInSettlementCurrency = swiftChargesInSettlementCurrency == null ? RateValue.ZERO
                : swiftChargesInSettlementCurrency;
        txnSDCharge.swiftChargesInPassSettlementCurrency = swiftChargesInPassSettlementCurrency == null ? RateValue.ZERO
                : swiftChargesInPassSettlementCurrency;

        return txnSDCharge;
    }

    public TxnSDCharge skip(final RateSkipSetting rateSkipSetting) {
        TxnSDCharge txnSDCharge = new TxnSDCharge();
        if (!rateSkipSetting.skipCustomerFeeOnly()) {
            txnSDCharge.additionalCharges = this.additionalCharges;
            txnSDCharge.cardCharges = this.cardCharges;
            txnSDCharge.commission = this.commission;
            txnSDCharge.otherCharges = this.otherCharges;
            txnSDCharge.tax = this.tax;
        }
        txnSDCharge.rate = rateSkipSetting.skipRatesOnly() ? null : this.rate;
        txnSDCharge.swiftCharges = rateSkipSetting.skipSwiftCharge() ? null : this.swiftCharges;
        txnSDCharge.rate = rateSkipSetting.skipRatesOnly() ? null : this.rate;
        
        txnSDCharge.swiftChargesInSettlementCurrency = rateSkipSetting.skipSwiftCharge() ? null : this.swiftChargesInSettlementCurrency;
        txnSDCharge.swiftChargesInPassSettlementCurrency = rateSkipSetting.skipSwiftCharge() ? null : this.swiftChargesInPassSettlementCurrency;

        return txnSDCharge;
    }
}
