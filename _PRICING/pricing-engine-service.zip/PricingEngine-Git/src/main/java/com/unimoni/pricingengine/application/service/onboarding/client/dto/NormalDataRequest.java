package com.unimoni.pricingengine.application.service.onboarding.client.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public class NormalDataRequest {

    private List<String> serviceProviderCodes;
}
