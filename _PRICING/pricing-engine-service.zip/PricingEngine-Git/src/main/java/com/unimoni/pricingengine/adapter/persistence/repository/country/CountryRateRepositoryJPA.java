package com.unimoni.pricingengine.adapter.persistence.repository.country;

import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryRateEnquiryIdentity;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryRateEnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryVDWRateType;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.country.dto.SearchCountryRatesRequest;

public interface CountryRateRepositoryJPA extends JPA {

    public Optional<CountryRate> findActiveCountryRateByIdentity(final RMType rmType,
            final CountryRateIdentity countryIdentity);

    public List<CountryRate> findAllCountryRates(final SearchCountryRatesRequest searchRequest);

    public List<CountryRate> findCountryRatesByIds(final RMType rmType, final List<String> ids,
            boolean eagerFetchCountry);

    public Optional<CountryRate> findHighestPriorityCountryRateByAgentBasicIdentity(final RMType rmType,
            final AgentRateIdentity identity);

    public CountryRate getCountryRateReference(final RMType rmType, final String countrytRateId);

    public Optional<CountryRateEnquiryResponse> findCountryRateForEnquiry(final RMType rmType,
            final CountryVDWRateType vdwRateType, final CountryRateEnquiryIdentity enquiryIdentity);
}
