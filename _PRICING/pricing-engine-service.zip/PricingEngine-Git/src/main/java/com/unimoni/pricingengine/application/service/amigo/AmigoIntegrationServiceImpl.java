package com.unimoni.pricingengine.application.service.amigo;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.adapter.persistence.repository.settlement.SettlementRateRepository;
import com.unimoni.pricingengine.adapter.persistence.repository.standardcharges.StandardChargesRepository;
import com.unimoni.pricingengine.adapter.persistence.repository.var.VaRRepository;
import com.unimoni.pricingengine.application.service.amigo.dto.CreateSettlementRateRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.CreateVaRRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateIBRRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateSettlementRateRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateVaRRequest;
import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.exception.StandardChargeException;
import com.unimoni.pricingengine.common.exception.StandardChargeException.StandardChargeExceptionType;
import com.unimoni.pricingengine.common.util.Counter;
import com.unimoni.pricingengine.domain.model.common.dto.Triplet;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.composable.Exchange;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;
import com.unimoni.pricingengine.domain.model.rate.composable.Margin;
import com.unimoni.pricingengine.domain.model.rate.composable.Settlement;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementValueDateWise;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.domain.model.rate.var.VaRValueDateWise;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRIdentity;
import com.unimoni.pricingengine.domain.model.standardcharges.OriginDestination.ODType;
import com.unimoni.pricingengine.domain.model.standardcharges.SCAmountRanges;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardCharge;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardChargeAmountRangeDateWise;
import com.unimoni.pricingengine.domain.model.standardcharges.StandardChargeAmountRangeWise;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.AmigoStandardChargeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.AmigoStandardChargeResponse;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargeAmountRangeDateWiseDTO;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargeAmountRangeWiseDTO;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.StandardChargesIdentity;
import com.unimoni.pricingengine.domain.model.validation.RatesValidationHelper;
import com.unimoni.pricingengine.domain.service.rm.RateManagementService;

@Service
public class AmigoIntegrationServiceImpl implements AmigoIntegrationService {

    @Autowired
    private RateManagementService rateManagementService;

    @Autowired
    private VaRRepository varRepository;

    @Autowired
    private SettlementRateRepository settlementRateRepository;

    @Autowired
    private StandardChargesRepository scRepository;

    @Autowired
    private MasterData masterData;

    @Transactional
    @Override
    public void updateIBR(final RMType rmType, final UpdateIBRRequest updateRequest) {
        if (!updateRequest.askValue().isPresent() && !updateRequest.bidValue().isPresent()) {
            throw new RateException(RateExceptionExceptionType.NOTHING_TO_UPDATE, Status.BAD_REQUEST);
        }
        if (rmType.isNormal()) {
            Optional<NormalIBR> normalIBR = this.rateManagementService
                    .getActiveNormalIBRByIdentity(updateRequest.normalIdentity());
            if (!normalIBR.isPresent()) {
                throw new RateException(RateExceptionExceptionType.IBR_NOT_FOUND_BY_IDENTITY, Status.BAD_REQUEST);
            }
            else {
                if (normalIBR.get().isEnabled()) {
                    Optional<ExchangeRate> exchangeRate = updateRequest.exchangeRate();
                    if (exchangeRate.isPresent()) {
                        RatesValidationHelper.validateAskAndBidValueForNormal(updateRequest.getSourceCcy(),
                                updateRequest.getTargetCcy(), exchangeRate.get().askValue(),
                                exchangeRate.get().bidValue());
                        normalIBR.get().updateRate(exchangeRate.get());
                    }
                    else if (updateRequest.askValue().isPresent()) {
                        ExchangeRate exgRate = ExchangeRate.of(updateRequest.askValue().get(),
                                normalIBR.get().exchange().rate().bidValue());
                        RatesValidationHelper.validateAskAndBidValueForNormal(updateRequest.getSourceCcy(),
                                updateRequest.getTargetCcy(), exgRate.askValue(), exgRate.bidValue());
                        normalIBR.get().updateRate(exgRate);
                    }
                    else if (updateRequest.bidValue().isPresent()) {
                        ExchangeRate exgRate = ExchangeRate.of(updateRequest.bidValue().get(),
                                normalIBR.get().exchange().rate().askValue());
                        RatesValidationHelper.validateAskAndBidValueForNormal(updateRequest.getSourceCcy(),
                                updateRequest.getTargetCcy(), exgRate.askValue(), exgRate.bidValue());
                        normalIBR.get().updateRate(exgRate);
                    }
                }
            }
        }
        else {
            Optional<BankWiseIBR> bankWiseIBR = this.rateManagementService
                    .getActiveBankWiseIBRByIdentity(updateRequest.bankWsieidentity());
            if (!bankWiseIBR.isPresent()) {
                throw new RateException(RateExceptionExceptionType.IBR_NOT_FOUND_BY_IDENTITY, Status.BAD_REQUEST);
            }
            else {
                if (bankWiseIBR.get().isEnabled()) {
                    Optional<ExchangeRate> exchangeRate = updateRequest.exchangeRate();
                    if (exchangeRate.isPresent()) {
                        RatesValidationHelper.validateAskAndBidValueForBankWise(updateRequest.getSourceCcy(),
                                updateRequest.getTargetCcy(), exchangeRate.get().askValue(),
                                exchangeRate.get().bidValue());
                        bankWiseIBR.get().updateRate(exchangeRate.get());
                    }
                    else if (updateRequest.askValue().isPresent()) {
                        ExchangeRate exgRate = ExchangeRate.of(updateRequest.askValue().get(),
                                bankWiseIBR.get().exchange().rate().bidValue());
                        RatesValidationHelper.validateAskAndBidValueForBankWise(updateRequest.getSourceCcy(),
                                updateRequest.getTargetCcy(), exgRate.askValue(), exgRate.bidValue());
                        bankWiseIBR.get().updateRate(exgRate);
                    }
                    else if (updateRequest.bidValue().isPresent()) {
                        ExchangeRate exgRate = ExchangeRate.of(updateRequest.bidValue().get(),
                                bankWiseIBR.get().exchange().rate().askValue());
                        RatesValidationHelper.validateAskAndBidValueForBankWise(updateRequest.getSourceCcy(),
                                updateRequest.getTargetCcy(), exgRate.askValue(), exgRate.bidValue());
                        bankWiseIBR.get().updateRate(exgRate);
                    }
                }
            }
        }
    }

    @Transactional
    @Override
    public VaR createVaR(final RMType rmType, final CreateVaRRequest createRequest) {
        final VaRIdentity varIdentity = createRequest.varIdentity(rmType);
        final Optional<VaR> existingVaR = this.varRepository.findEnabledVaRByIdentity(rmType, varIdentity);
        if (existingVaR.isPresent()) {
            throw new RateException(RateExceptionExceptionType.DUPLICATE_VAR_RECORD_EXISTS, Status.CONFLICT);
        }
        final Optional<? extends AbstractLayer> ibr = this.rateManagementService
                .getHighestPriorityIBRByVaRIdentity(rmType, varIdentity);
        if (!ibr.isPresent()) {
            throw new RateException(RateExceptionExceptionType.UNSATISFIED_VAR_IBR_LAYER_LINK,
                    Status.PRECONDITION_FAILED);
        }
        final VaRValueDateWise defaultVDW = VaRValueDateWise.byDefault(ibr.get().exchange());
        final Exchange ibrExchange = ibr.get().exchange();
        final Margin cashMargin = createRequest.cashMagin();
        final VaRValueDateWise cash = VaRValueDateWise.of(cashMargin, Settlement.byFormula(ibrExchange, cashMargin));

        if (rmType.isNormal()) {
            return this.varRepository.save(VaR.normal(createRequest.getAgentCode()).ibr(ibr.get()).exchange(ibrExchange)
                    .instruments(createRequest.instruments()).cash(cash).tom(defaultVDW).spot(defaultVDW)
                    .future(defaultVDW).build());
        }
        else {
            return this.varRepository.save(VaR.bankWise(createRequest.bank().get(), createRequest.getAgentCode())
                    .ibr(ibr.get()).exchange(ibrExchange).instruments(createRequest.instruments()).cash(cash)
                    .tom(defaultVDW).spot(defaultVDW).future(defaultVDW).build());
        }
    }

    @Transactional
    @Override
    public VaR updateVaR(final RMType rmType, final UpdateVaRRequest updateRequest) {

        if (!updateRequest.status().isPresent() && !updateRequest.cashAskMargin().isPresent()
                && !updateRequest.cashBidMargin().isPresent()) {
            throw new RateException(RateExceptionExceptionType.NOTHING_TO_UPDATE, Status.BAD_REQUEST);
        }

        Optional<VaR> existingVaR = null;

        if (!updateRequest.status().isPresent()
                || (updateRequest.status().isPresent() && updateRequest.status().get() == Boolean.FALSE)) {
            existingVaR = this.varRepository.findEnabledVaRByIdentity(rmType, updateRequest.varIdentity(rmType));
        }
        else if (updateRequest.status().isPresent() && updateRequest.status().get() == Boolean.TRUE) {
            existingVaR = this.varRepository.findLatestDisabledVaRByIdentity(rmType, updateRequest.varIdentity(rmType));
        }
        if (!existingVaR.isPresent()) {
            throw new RateException(RateExceptionExceptionType.VAR_NOT_FOUND_BY_IDENTITY, Status.BAD_REQUEST);
        }
        final VaR var = existingVaR.get();
        if (updateRequest.status().isPresent() && var.isEnabled() != updateRequest.status().get().booleanValue()) {
            if (updateRequest.status().get() == Boolean.TRUE) {
                Optional<VaR> duplicateVaR = this.varRepository.findEnabledVaRByIdentity(rmType,
                        updateRequest.varIdentity(rmType));
                if (duplicateVaR.isPresent()) {
                    throw new RateException(RateExceptionExceptionType.DUPLICATE_VAR_RECORD_EXISTS, Status.CONFLICT);
                }
                if (!((AbstractLayer) var.ibr()).isEnabled()) {
                    throw new RateException(RateExceptionExceptionType.PREVIOUS_LAYER_ENABLED_RECORD_DOES_NOT_EXISTS,
                            Status.PRECONDITION_FAILED);
                }
            }
            var.updateStatus(updateRequest.status().get());
        }
        if (var.isEnabled()
                && var.cash().get().updateMargin(updateRequest.cashAskMargin(), updateRequest.cashBidMargin())) {
            var.cash().get().updateSettlement(Settlement.byFormula(var.exchange(), var.cash().get().margin()));
        }

        return var;
    }

    @Transactional
    @Override
    public SettlementRate createSettlementRate(final RMType rmType, final CreateSettlementRateRequest createRequest) {
        final SettlementIdentity settlementIdentity = createRequest.settlementIdentity(rmType);
        final Optional<SettlementRate> existingSettlementRate = this.settlementRateRepository
                .findEnabledSettlementRateByIdentity(rmType, settlementIdentity);
        if (existingSettlementRate.isPresent()) {
            throw new RateException(RateExceptionExceptionType.DUPLICATE_SETTLEMENT_RATE_RECORD_EXISTS,
                    Status.CONFLICT);
        }

        final Optional<VaR> var = this.varRepository.findHighestVaRsBySettlementIdentity(rmType, settlementIdentity);
        if (!var.isPresent()) {
            throw new RateException(RateExceptionExceptionType.UNSATISFIED_SETTLEMENT_VAR_RATE_LAYER_LINK,
                    Status.PRECONDITION_FAILED);
        }

        final Cost cashMarginCost = createRequest.cashMarginCost();
        final Cost cashVarSettlement = Cost.of(var.get().cash().get().settlement().sellValue(),
                var.get().cash().get().settlement().buyValue());
        final SettlementValueDateWise cash = SettlementValueDateWise.of(createRequest.getSourceCcy(),
                createRequest.getTargetCcy(), cashVarSettlement, cashMarginCost);

        if (rmType.isNormal()) {
            return this.settlementRateRepository.save(SettlementRate.normal(createRequest.getAgentCode()).var(var.get())
                    .currency(createRequest.currencyExchange()).instruments(createRequest.instruments()).cash(cash)
                    .tom(SettlementValueDateWise.byDefault(createRequest.getSourceCcy(), createRequest.getTargetCcy(),
                            var.get().tom().get().settlement()))
                    .spot(SettlementValueDateWise.byDefault(createRequest.getSourceCcy(), createRequest.getTargetCcy(),
                            var.get().spot().get().settlement()))
                    .future(SettlementValueDateWise.byDefault(createRequest.getSourceCcy(),
                            createRequest.getTargetCcy(), var.get().future().get().settlement()))
                    .build());
        }
        else {
            return this.settlementRateRepository.save(SettlementRate
                    .bankWise(createRequest.getBankCode(), createRequest.getAgentCode()).var(var.get())
                    .currency(createRequest.currencyExchange()).instruments(createRequest.instruments()).cash(cash)
                    .tom(SettlementValueDateWise.byDefault(createRequest.getSourceCcy(), createRequest.getTargetCcy(),
                            var.get().tom().get().settlement()))
                    .spot(SettlementValueDateWise.byDefault(createRequest.getSourceCcy(), createRequest.getTargetCcy(),
                            var.get().spot().get().settlement()))
                    .future(SettlementValueDateWise.byDefault(createRequest.getSourceCcy(),
                            createRequest.getTargetCcy(), var.get().future().get().settlement()))
                    .build());
        }
    }

    @Transactional
    @Override
    public SettlementRate updateSettlementRate(final RMType rmType, final UpdateSettlementRateRequest updateRequest) {

        if (!updateRequest.status().isPresent() && !updateRequest.cashSettlementSellMargin().isPresent()
                && !updateRequest.cashSettlementBuyMargin().isPresent()) {
            throw new RateException(RateExceptionExceptionType.NOTHING_TO_UPDATE, Status.BAD_REQUEST);
        }

        Optional<SettlementRate> existingSettlementRate = null;
        if (!updateRequest.status().isPresent()
                || (updateRequest.status().isPresent() && updateRequest.status().get() == Boolean.FALSE)) {
            existingSettlementRate = this.settlementRateRepository.findEnabledSettlementRateByIdentity(rmType,
                    updateRequest.settlementIdentity(rmType));
        }
        else if (updateRequest.status().isPresent() && updateRequest.status().get() == Boolean.TRUE) {
            existingSettlementRate = this.settlementRateRepository.findLatestDisabledSettlementRateByIdentity(rmType,
                    updateRequest.settlementIdentity(rmType));
        }

        if (!existingSettlementRate.isPresent()) {
            throw new RateException(RateExceptionExceptionType.SETTLEMENT_RATE_NOT_FOUND_BY_IDENTITY,
                    Status.BAD_REQUEST);
        }
        final SettlementRate settlementRate = existingSettlementRate.get();
        if (updateRequest.status().isPresent()
                && settlementRate.isEnabled() != updateRequest.status().get().booleanValue()) {
            if (updateRequest.status().get() == Boolean.TRUE) {
                Optional<SettlementRate> duplicateSettlementRate = this.settlementRateRepository
                        .findEnabledSettlementRateByIdentity(rmType, updateRequest.settlementIdentity(rmType));
                if (duplicateSettlementRate.isPresent()) {
                    throw new RateException(RateExceptionExceptionType.DUPLICATE_SETTLEMENT_RATE_RECORD_EXISTS,
                            Status.CONFLICT);
                }
                if (!settlementRate.var().isEnabled()) {
                    throw new RateException(RateExceptionExceptionType.PREVIOUS_LAYER_ENABLED_RECORD_DOES_NOT_EXISTS,
                            Status.PRECONDITION_FAILED);
                }
            }
            settlementRate.updateStatus(updateRequest.status().get());
        }
        if (settlementRate.isEnabled()) {
            Optional<Cost> cashMarginCost = updateRequest.cashMarginCost();
            if (cashMarginCost.isPresent()) {
                settlementRate.cash().get().updateMarginCost(updateRequest.getSourceCcy(), updateRequest.getTargetCcy(),
                        cashMarginCost.get());
            }
            else if (updateRequest.cashSettlementSellMargin().isPresent()) {
                settlementRate.cash().get().updateMarginCost(updateRequest.getSourceCcy(), updateRequest.getTargetCcy(),
                        Cost.of(updateRequest.cashSettlementSellMargin().get(),
                                settlementRate.cash().get().margin().buyValue()));
            }
            else if (updateRequest.cashSettlementBuyMargin().isPresent()) {
                settlementRate.cash().get().updateMarginCost(updateRequest.getSourceCcy(), updateRequest.getTargetCcy(),
                        Cost.of(settlementRate.cash().get().margin().sellValue(),
                                updateRequest.cashSettlementBuyMargin().get()));
            }
        }

        return settlementRate;
    }

    /*
     * Amigo Integration for Standard Charge-Single API implementation
     * 
     */

    @Transactional
    @Override
    public AmigoStandardChargeResponse createOrUpdateStandardCharge(
            final AmigoStandardChargeRequest createOrUpdateStandardCharge) {

        final StandardChargeAmountRangeWiseDTO updatedAmtRangeDTO = AmigoStandardChargeRequest.amigoToPaas(
                createOrUpdateStandardCharge.getAmountRange(), createOrUpdateStandardCharge.getAmountRangeDateWise(),
                createOrUpdateStandardCharge.getEnabled());

        if (updatedAmtRangeDTO == null || updatedAmtRangeDTO.getAmountFrom() == null
                || updatedAmtRangeDTO.getAmountTo() == null) {
            throw new StandardChargeException(StandardChargeExceptionType.AMOUNT_RANGE_MISSING, Status.BAD_REQUEST);
        }

        final StandardChargesIdentity identity = createOrUpdateStandardCharge.basicIdentities();
        final Optional<StandardCharge> existingSC = scRepository.findActiveStandardChargesByIdentity(identity);

        if (!existingSC.isPresent()) {
            return createStandardCharge(identity, createOrUpdateStandardCharge, updatedAmtRangeDTO);
        }
        else {
            return updateStandardCharge(existingSC.get(), identity, createOrUpdateStandardCharge, updatedAmtRangeDTO);
        }
    }

    private String getSourceTypeFromMasterData(String code) {
        List<Triplet<String, String, ODType>> sourceTriplets = masterData.getSourceTriplets();
        if (sourceTriplets != null && sourceTriplets.size() > 0) {
            Triplet<String, String, ODType> triplet = sourceTriplets.stream()
                    .filter(item -> item.getCode() != null && item.getCode().equals(code)).findFirst().orElse(null);
            if (triplet != null) {
                return triplet.getType().name();
            }
        }
        return null;
    }

    private String getDestinationTypeFromMasterData(String code) {
        List<Triplet<String, String, ODType>> destinationTriplets = masterData.getDestinationTriplets();
        if (destinationTriplets != null && destinationTriplets.size() > 0) {
            Triplet<String, String, ODType> triplet = destinationTriplets.stream()
                    .filter(item -> item.getCode() != null && item.getCode().equals(code)).findFirst().orElse(null);
            if (triplet != null) {
                return triplet.getType().name();
            }
        }
        return null;
    }

    private AmigoStandardChargeResponse createStandardCharge(final StandardChargesIdentity identity,
            final AmigoStandardChargeRequest createOrUpdateStandardCharge,
            final StandardChargeAmountRangeWiseDTO updatedAmtRangeDTO) {
        String sourceType = getSourceTypeFromMasterData(identity.getSourceCode());
        String destinationType = getDestinationTypeFromMasterData(identity.getDestinationCode());
        if (sourceType == null || destinationType == null) {
            throw new StandardChargeException(StandardChargeExceptionType.MISSING_DATA_IN_ONBOARDING,
                    Status.BAD_REQUEST);
        }
        identity.setSourceType(sourceType);
        identity.setDestinationType(destinationType);

        final List<StandardChargesIdentity> scIdentityList = new ArrayList<>();
        scIdentityList.add(identity);

        final List<StandardCharge> scList = buildToCreateNew(updatedAmtRangeDTO, scIdentityList,
                createOrUpdateStandardCharge.getTaxIncluded(), createOrUpdateStandardCharge.getUpdatedOn()); // it will
                                                                                                             // only one
                                                                                                             // object
                                                                                                             // in list

        scRepository.saveAll(scList);
        scRepository.flush();

        return AmigoStandardChargeResponse.of(true);
    }

    private AmigoStandardChargeResponse updateStandardCharge(final StandardCharge originalSC,
            final StandardChargesIdentity identity, final AmigoStandardChargeRequest createOrUpdateStandardCharge,
            final StandardChargeAmountRangeWiseDTO updatedAmtRange) {

        final List<StandardChargeAmountRangeWise> amountRangeList = originalSC.amountRange();

        if (amountRangeList != null && amountRangeList.size() == 0) { // add amount range
            // log.debug("Add first amount range");
            final StandardChargeAmountRangeWise newAmtRangeobj = addNewAomuntRange(originalSC, updatedAmtRange);
            amountRangeList.add(newAmtRangeobj);
        }
        else {
            // get only CASH type amount range
            final List<StandardChargeAmountRangeWise> cashOrigAmtList = amountRangeList.stream()
                    .filter(item -> VDWType.CASH == item.vdwType()).collect(Collectors.toList());

            final Optional<StandardChargeAmountRangeWise> existingAmtRangeForCashList = cashOrigAmtList.stream()
                    .filter(item -> isMatchedAmountRange(item, updatedAmtRange)).findFirst();
            if (existingAmtRangeForCashList.isPresent()) { // already present for given amountFrom-AmountTo, no need to
                                                           // validate.
                // update existing
                // log.debug("Updating existing amount range");
                updateExistingAomuntRange(originalSC, existingAmtRangeForCashList.get(), updatedAmtRange);
            }
            else {
                // log.debug("Adding new amount range in existing list");
                final StandardChargeAmountRangeWise newAmtRangeobj = addNewAomuntRange(originalSC, updatedAmtRange);
                amountRangeList.add(newAmtRangeobj);
            }
        }

        // Check if all children are disabled or not
        if (!createOrUpdateStandardCharge.getEnabled()) { // if to disable
            List<StandardChargeAmountRangeWise> enabledList = originalSC.amountRange().stream()
                    .filter(item -> item.isEnabled()).collect(Collectors.toList());
            if (enabledList == null || enabledList.size() == 0) {
                originalSC.updateStatus(createOrUpdateStandardCharge.getEnabled());
            }
        }
        else if (!originalSC.isEnabled()) { // if request is from disable to enable, validate it against existing
                                            // standard charges.
            final Optional<StandardCharge> existingSC = scRepository
                    .findActiveStandardChargesByStandardCharge(originalSC);
            if (existingSC.isPresent()) {
                throw new StandardChargeException(StandardChargeExceptionType.DUPLICATE_RECORDS, Status.BAD_REQUEST);
            }
            else {
                originalSC.updateStatus(createOrUpdateStandardCharge.getEnabled()); // set status as enable
            }
        }

        ZonedDateTime zd = ZonedDateTime.parse(createOrUpdateStandardCharge.getUpdatedOn(),
                DateTimeFormatter.ofPattern(ApplicationConstants.AMIGO_DATE_TIME_FORMAT_STANDARD_CHARGE));

        originalSC.updatedOn(zd);
        scRepository.flush();

        return AmigoStandardChargeResponse.of(false);
    }

    private static boolean isMatchedAmountRange(final StandardChargeAmountRangeWise item,
            final StandardChargeAmountRangeWiseDTO dto) {

        // log.debug("Matched Amount Range found : "
        // + (item.amountFrom() != null && item.amountFrom().compareTo(dto.getAmountFrom()) == 0
        // && item.amountTo() != null && item.amountTo().compareTo(dto.getAmountTo()) == 0));

        return item.amountFrom() != null && item.amountFrom().compareTo(dto.getAmountFrom()) == 0
                && item.amountTo() != null && item.amountTo().compareTo(dto.getAmountTo()) == 0;
    }

    private StandardChargeAmountRangeWise addNewAomuntRange(final StandardCharge originalSC,
            final StandardChargeAmountRangeWiseDTO updatedAmtRangeDTO) {
        // log.debug("addNewAomuntRange()");
        final StandardChargeAmountRangeWise newAmtRangeObject = new StandardChargeAmountRangeWise();

        return buildAmountRangeObject(originalSC, newAmtRangeObject, updatedAmtRangeDTO);
    }

    private StandardChargeAmountRangeWise updateExistingAomuntRange(final StandardCharge originalSC,
            final StandardChargeAmountRangeWise existingAmtRange,
            final StandardChargeAmountRangeWiseDTO updatedAmtRangeDTO) {

        return buildAmountRangeObject(originalSC, existingAmtRange, updatedAmtRangeDTO);
    }

    private StandardChargeAmountRangeWise buildAmountRangeObject(final StandardCharge originalSC,
            final StandardChargeAmountRangeWise scAmtRange, final StandardChargeAmountRangeWiseDTO updatedAmtRangeDTO) {

        final List<StandardChargeAmountRangeDateWise> newUpdatedList = new ArrayList<>();

        final List<StandardChargeAmountRangeDateWise> oldDateList = scAmtRange.amountRangeWise();

        // if (oldDateList.size() > 0) { // disabling existing date data, if any.
        // log.debug("buildAmountRangeObject() :: disabling datewise");
        // oldDateList.stream().forEach(item -> item.enabled(false));
        // }

        if (updatedAmtRangeDTO.getAmountRangeDateWise() != null
                && updatedAmtRangeDTO.getAmountRangeDateWise().size() > 0) {
            // log.debug("buildAmountRangeObject() :: fromDate from Amigo : "
            // + updatedAmtRangeDTO.getAmountRangeDateWise().get(0).getFromDate());
            // Only one or zero Date object from Amigo
            final StandardChargeAmountRangeDateWiseDTO dto = updatedAmtRangeDTO.getAmountRangeDateWise().get(0);
            if (dto.getFromDate() == null || dto.getToDate() == null) {
                throw new StandardChargeException(StandardChargeExceptionType.DATERANGE_MISSING, Status.BAD_REQUEST);
            }

            final StandardChargeAmountRangeDateWise newDateObj = StandardChargeAmountRangeDateWise.of(
                    dto.getAmountEnable(), dto.getPercentageEnable(), dto.getFromDate(), dto.getToDate(),
                    SCAmountRanges.of(dto.getAmountRanges().getAmount(), dto.getAmountRanges().getAmountLow(),
                            dto.getAmountRanges().getAmountHigh(), dto.getAmountRanges().getPercentage(),
                            dto.getAmountRanges().getPercentageLow(), dto.getAmountRanges().getPercentageHigh(),
                            dto.getAmountRanges().getMaxSwiftAmount(), dto.getAmountRanges().getMinSwiftAmount()),
                    null, dto.isEnabled());

            Counter counter = Counter.initialize("date-range", 0);
            if (oldDateList != null && oldDateList.size() > 0) {
                oldDateList.stream().forEach(item -> {
                    if (item.fromDate().equals(newDateObj.fromDate()) && item.toDate().equals(newDateObj.toDate())
                            && item.isEnabled()) { // found matched enabled date range
                        item.amountEnable(dto.getAmountEnable());
                        item.percentageEnable(dto.getPercentageEnable());
                        item.amountRanges(SCAmountRanges.of(dto.getAmountRanges().getAmount(),
                                dto.getAmountRanges().getAmountLow(), dto.getAmountRanges().getAmountHigh(),
                                dto.getAmountRanges().getPercentage(), dto.getAmountRanges().getPercentageLow(),
                                dto.getAmountRanges().getPercentageHigh(), dto.getAmountRanges().getMaxSwiftAmount(),
                                dto.getAmountRanges().getMinSwiftAmount()));
                        item.enabled(dto.isEnabled());
                        counter.increment();
                    }
                    else {
                        item.enabled(false); // disable existing date ranges.
                    }
                });
            }

            if (counter.get() <= 0) {
                newDateObj.standardAmountRange(scAmtRange);
                newUpdatedList.add(newDateObj);
            }
        }

        if (newUpdatedList.size() > 0)
            oldDateList.addAll(newUpdatedList);

        // log.debug("buildAmountRangeObject() :: updating amount range");

        final SCAmountRanges ranges = updatedAmtRangeDTO.getAmountRanges().toModel();

        scAmtRange.amountEnable(updatedAmtRangeDTO.getAmountEnable());
        scAmtRange.percentageEnable(updatedAmtRangeDTO.getPercentageEnable());
        scAmtRange.amountFrom(updatedAmtRangeDTO.getAmountFrom());
        scAmtRange.amountTo(updatedAmtRangeDTO.getAmountTo());
        scAmtRange.vdwType(updatedAmtRangeDTO.getVdwType());
        scAmtRange.enabled(updatedAmtRangeDTO.isEnabled());
        scAmtRange.amountRanges(ranges);
        scAmtRange.standardCharge(originalSC);

        return scAmtRange;
    }

    private List<StandardCharge> buildToCreateNew(final StandardChargeAmountRangeWiseDTO dto,
            final List<StandardChargesIdentity> identities, final Boolean taxIncluded, String updatedOn) {

        final List<StandardChargeAmountRangeWiseDTO> list = new ArrayList<>();
        list.add(dto);

        ZonedDateTime zd = ZonedDateTime.parse(updatedOn,
                DateTimeFormatter.ofPattern(ApplicationConstants.AMIGO_DATE_TIME_FORMAT_STANDARD_CHARGE));

        return StandardCharge.of(identities, list, taxIncluded, zd);
    }
}
