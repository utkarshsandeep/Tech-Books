package com.unimoni.pricingengine.adapter.rest.controller.enquiry;

import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.COUNTRY_BANKWISE_AGENT_BRANCH_COST_RATES_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.COUNTRY_BANKWISE_AGENT_COST_RATES_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.COUNTRY_NORMAL_AGENT_BRANCH_COST_RATES_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.COUNTRY_NORMAL_AGENT_COST_RATES_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.IBR_BANKWISE_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.IBR_NORMAL_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.SETTLEMENT_BANKWISE_COST_RATES_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.SETTLEMENT_BANKWISE_RATES_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.SETTLEMENT_NORMAL_COST_RATES_ENQUIRY_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Enquiry.SETTLEMENT_NORMAL_RATES_ENQUIRY_URI;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.TEXT_EVENT_STREAM_VALUE;

import java.util.Set;

import javax.money.CurrencyUnit;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.unimoni.pricingengine.common.enums.standard.CurrencyCode;
import com.unimoni.pricingengine.common.exception.MasterDataValidationException;
import com.unimoni.pricingengine.common.exception.MasterDataValidationException.MasterDataValidationExceptionType;
import com.unimoni.pricingengine.domain.model.common.dto.ProblemResponse;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryRateEnquiryRequest;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryRateEnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.country.CountryVDWRateType;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.BankWiseIBREnquiryRequest;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.BankWiseIBREnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.NormalIBREnquiryRequest;
import com.unimoni.pricingengine.domain.model.enquiry.ibr.NormalIBREnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementRateEnquiryRequest;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementRateEnquiryResponse;
import com.unimoni.pricingengine.domain.model.enquiry.settlement.SettlementVDWRateType;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.service.enquiry.EnquiryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import reactor.core.publisher.Flux;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "rate-enquiry-apis", description = "<h1>Rate Enquiry APIs</h1>\n"
        + "<p>The parameters may accept \"<b>All</b>\" or specific values if it is marked as <b>(All/Specific)</b> or"
        + " just specific values if it is marked as <b>(Specific)</b>. "
        + "\"<b>All</b>\" or no value (both would have same effect) for a parameter would in effect return rates for all of the values for respective parameter in the system. "
        + "For example if \"<b>serviceProvider</b>\" is given with \"<b>All</b>\" or no value, "
        + "then the system would return records for all of the Service Providers available in the system. "
        + "If a parameter is required to have specific values only but supplied with \"<b>All</b>\" or no value, then it would result in a validation error. "
        + "<br>It is recommended to request with specific values of parameters and keep "
        + "the batch size  small <b>(The default batch size is 200 and maximum allowed is 1000)</b>, to get the results quickly. "
        + "Large data set matching a given request, may take time to respond with all the records matching given parameters. "
        + "<br><b>The API is reactive, so Consumers need to receive the data in same fashion</b>, "
        + "records are returned one by one till the requested batch is completed. "
        + "Once the current batch is completed the last packet contains the details of whether or not more batches are available. "
        + "If more batches are available for given request then the next batche's link is provided, "
        + "so that the consumer can iterate through the result set till all records are served. "
        + "<br>If all available records are returned and you have reached to the end of last batch, "
        + "then the last packet would contain a message that \"<b>No more records available</b>\". "
        + "Similarly if no record is found matching given parameters, the message would be \"<b>No records available</b>\".<br>"
        + "<b>Note:</b> To test the APIs, hit an API's URL (along with any request parameters) directly from browser, "
        + "executing the APIs from Swagger UI would return traditional blocking response, not reactive response.</p>", tags = "Rate Enquiry")
@Validated
@RestController
@RequestMapping(PRICING_API)
public class EnquiryController {

    @Autowired
    private EnquiryService enquiryService;

    @GetMapping(path = IBR_NORMAL_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-normal-ibr-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Normal IBR rates", 
        response = NormalIBREnquiryResponse.class, 
        responseContainer = "List",
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = NormalIBREnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<NormalIBREnquiryResponse> streamNormalIBRRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @RequestParam(value = "currencies", required = false) final Set<@NotNull CurrencyUnit> currencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        return this.enquiryService.streamNormalBRsForEnquiry(
                NormalIBREnquiryRequest.of(startingIndex, batchSize, serviceProviders, products, currencies,
                        this.enquiryService.getDistinctNormalIBRCurrencies()),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = IBR_BANKWISE_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-bankwise-ibr-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Bankwise IBR rates", 
        response = BankWiseIBREnquiryResponse.class, 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = BankWiseIBREnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<BankWiseIBREnquiryResponse> streamBankWiseIBRRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Bank Code such as HDFCIN (All/Specific)", required = false, example = "HDFCIN", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "banks", required = false) final Set<@NotEmpty String> banks, 
            @ApiParam(value = "Agent Code such as TRVLX####### (All/Specific)", required = false, example = "TRVLX#######", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @RequestParam(value = "currencies", required = false) final Set<@NotNull CurrencyUnit> currencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        return this.enquiryService.streamBankWiseIBRsForEnquiry(
                BankWiseIBREnquiryRequest.of(startingIndex, batchSize, serviceProviders, products, banks, agents,
                        currencies, this.enquiryService.getDistinctBankWiseIBRCurrencies()),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = SETTLEMENT_NORMAL_RATES_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-normal-settlement-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Normal Settlement rates", 
        response = SettlementRateEnquiryResponse.class, 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = SettlementRateEnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<SettlementRateEnquiryResponse> streamNormalSettlementRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc. (All/Specific)", required = false, example = "Account Credit", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "subProducts", required = false) final Set<@NotEmpty String> subProducts, 
            @ApiParam(value = "Service type such as Flash, Normal etc. (All/Specific)", required = false, example = "Flash", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceTypes", required = false) final Set<@NotEmpty String> serviceTypes, 
            @ApiParam(value = "Agent Code (All/Specific)", required = false, example = "AGENT-001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @ApiParam(value = "Value date wise such as CASH, TOM etc. (All/Specific)", required = false, example = "CASH", allowEmptyValue = false, allowMultiple = true, allowableValues = "All,CASH,TOM,SPOT,FUTURE")
            @RequestParam(value = "valueDateWises", required = false) final Set<@NotEmpty String> valueDateWises, 
            @RequestParam(value = "currencies", required = false) final Set<@NotNull CurrencyUnit> currencies,
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        return this.enquiryService.streamSettlementRates(RMType.NORMAL, SettlementVDWRateType.SETTLEMENT,
                SettlementRateEnquiryRequest.ofNormal(startingIndex, batchSize, serviceProviders, products, subProducts,
                        serviceTypes, agents, valueDateWises, currencies,
                        this.enquiryService.getDistinctSettlementRateCurrencies(RMType.NORMAL)),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = SETTLEMENT_BANKWISE_RATES_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-bankwise-settlement-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Bankwise Settlement rates", 
        response = SettlementRateEnquiryResponse.class, 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = SettlementRateEnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<SettlementRateEnquiryResponse> streamBankWiseSettlementRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc. (All/Specific)", required = false, example = "Account Credit", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "subProducts", required = false) final Set<@NotEmpty String> subProducts, 
            @ApiParam(value = "Service type such as Flash, Normal etc. (All/Specific)", required = false, example = "Flash", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceTypes", required = false) final Set<@NotEmpty String> serviceTypes,
            @ApiParam(value = "Bank Code (All/Specific)", required = false, example = "BANK001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "banks", required = false) final Set<@NotEmpty String> banks,  
            @ApiParam(value = "Agent Code (All/Specific)", required = false, example = "AGENT-001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @ApiParam(value = "Value date wise such as CASH, TOM etc. (All/Specific)", required = false, example = "CASH", allowEmptyValue = false, allowMultiple = true, allowableValues = "All,CASH,TOM,SPOT,FUTURE")
            @RequestParam(value = "valueDateWises", required = false) final Set<@NotEmpty String> valueDateWises, 
            @RequestParam(value = "currencies", required = false) final Set<@NotNull CurrencyUnit> currencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        return this.enquiryService.streamSettlementRates(RMType.BANK_WISE, SettlementVDWRateType.SETTLEMENT,
                SettlementRateEnquiryRequest.ofBankWise(startingIndex, batchSize, serviceProviders, products,
                        subProducts, serviceTypes, banks, agents, valueDateWises, currencies,
                        this.enquiryService.getDistinctSettlementRateCurrencies(RMType.BANK_WISE)),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = SETTLEMENT_NORMAL_COST_RATES_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-normal-settlement-cost-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Normal Settlement Cost rates", 
        response = SettlementRateEnquiryResponse.class, 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = SettlementRateEnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<SettlementRateEnquiryResponse> streamNormalSettlementCostRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc. (All/Specific)", required = false, example = "Account Credit", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "subProducts", required = false) final Set<@NotEmpty String> subProducts, 
            @ApiParam(value = "Service type such as Flash, Normal etc. (All/Specific)", required = false, example = "Flash", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceTypes", required = false) final Set<@NotEmpty String> serviceTypes, 
            @ApiParam(value = "Agent Code (All/Specific)", required = false, example = "AGENT-001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @ApiParam(value = "Value date wise such as CASH, TOM etc. (All/Specific)", required = false, example = "CASH", allowEmptyValue = false, allowMultiple = true, allowableValues = "All,CASH,TOM,SPOT,FUTURE")
            @RequestParam(value = "valueDateWises", required = false) final Set<@NotEmpty String> valueDateWises, 
            @RequestParam(value = "currencies", required = false) final Set<@NotNull CurrencyUnit> currencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        return this.enquiryService.streamSettlementRates(RMType.NORMAL, SettlementVDWRateType.COUNTRY,
                SettlementRateEnquiryRequest.ofNormal(startingIndex, batchSize, serviceProviders, products, subProducts,
                        serviceTypes, agents, valueDateWises, currencies,
                        this.enquiryService.getDistinctSettlementRateCurrencies(RMType.NORMAL)),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = SETTLEMENT_BANKWISE_COST_RATES_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-bankwise-settlement-cost-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Bankwise Settlement Cost rates", 
        response = SettlementRateEnquiryResponse.class, 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "currencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = SettlementRateEnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<SettlementRateEnquiryResponse> streamBankWiseSettlementCostRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc. (All/Specific)", required = false, example = "Account Credit", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "subProducts", required = false) final Set<@NotEmpty String> subProducts, 
            @ApiParam(value = "Service type such as Flash, Normal etc. (All/Specific)", required = false, example = "Flash", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceTypes", required = false) final Set<@NotEmpty String> serviceTypes, 
            @ApiParam(value = "Agent Code (All/Specific)", required = false, example = "AGENT-001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @ApiParam(value = "Bank Code (All/Specific)", required = false, example = "BANK001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "banks", required = false) final Set<@NotEmpty String> banks, 
            @ApiParam(value = "Value date wise such as CASH, TOM etc. (All/Specific)", required = false, example = "CASH", allowEmptyValue = false, allowMultiple = true, allowableValues = "All,CASH,TOM,SPOT,FUTURE")
            @RequestParam(value = "valueDateWises", required = false) final Set<@NotEmpty String> valueDateWises, 
            @RequestParam(value = "currencies", required = false) final Set<@NotNull CurrencyUnit> currencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        return this.enquiryService.streamSettlementRates(RMType.BANK_WISE, SettlementVDWRateType.COUNTRY,
                SettlementRateEnquiryRequest.ofBankWise(startingIndex, batchSize, serviceProviders, products,
                        subProducts, serviceTypes, banks, agents, valueDateWises, currencies,
                        this.enquiryService.getDistinctSettlementRateCurrencies(RMType.BANK_WISE)),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = COUNTRY_NORMAL_AGENT_COST_RATES_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-normal-agent-cost-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Normal Agent cost rates", 
        response = CountryRateEnquiryResponse.class, 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (Specific)", 
            example = "INR", required = true
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false 
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = CountryRateEnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<CountryRateEnquiryResponse> streamNormalCountryCostRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc. (All/Specific)", required = false, example = "Account Credit", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "subProducts", required = false) final Set<@NotEmpty String> subProducts, 
            @ApiParam(value = "Service type such as Flash, Normal etc. (All/Specific)", required = false, example = "Flash", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceTypes", required = false) final Set<@NotEmpty String> serviceTypes, 
            @ApiParam(value = "Agent Code (All/Specific)", required = false, example = "AGENT-001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @ApiParam(value = "Rate Display Machenism (Specific)", required = true, example = "BC_TO_FC", allowEmptyValue = false, allowMultiple = false, allowableValues = "BC_TO_FC,FC_TO_BC")
            @RequestParam(value = "rateDisplayMachenism", required = true) @NotNull final RateDisplayMachenism rateDisplayMachenism,
            @ApiParam(value = "Value date wise such as CASH, TOM etc. (All/Specific)", required = false, example = "CASH", allowEmptyValue = false, allowMultiple = true, allowableValues = "All,CASH,TOM,SPOT,FUTURE")
            @RequestParam(value = "valueDateWises", required = false) final Set<@NotEmpty String> valueDateWises, 
            @RequestParam(value = "baseCurrencies", required = true) @NotEmpty final Set<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = false) final Set<@NotNull CurrencyUnit> foreignCurrencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        if (baseCurrencies != null && baseCurrencies.contains(CurrencyCode.getAllCurrencyUnit())) {
            throw new MasterDataValidationException(MasterDataValidationExceptionType.SPECIFIC_CURRENCIES_REQUIRED,
                    "baseCurrencies");
        }
        return this.enquiryService.streamCountryCostRates(RMType.NORMAL, CountryVDWRateType.COST_RATE,
                CountryRateEnquiryRequest.ofNormal(startingIndex, batchSize, serviceProviders, products, subProducts,
                        serviceTypes, agents, baseCurrencies, foreignCurrencies, valueDateWises, rateDisplayMachenism),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = COUNTRY_BANKWISE_AGENT_COST_RATES_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-bankwise-agent-cost-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Bankwise Agent cost rates", 
        response = CountryRateEnquiryResponse.class, 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (Specific)", 
            example = "INR", required =  true
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = CountryRateEnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<CountryRateEnquiryResponse> streamBankWiseCountryCostRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc. (All/Specific)", required = false, example = "Account Credit", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "subProducts", required = false) final Set<@NotEmpty String> subProducts, 
            @ApiParam(value = "Service type such as Flash, Normal etc. (All/Specific)", required = false, example = "Flash", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceTypes", required = false) final Set<@NotEmpty String> serviceTypes,
            @ApiParam(value = "Bank Code (All/Specific)", required = false, example = "BANK001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "banks", required = false) final Set<@NotEmpty String> banks,  
            @ApiParam(value = "Agent Code or Agent Branch code (All/Specific)", required = false, example = "AGENT-001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @ApiParam(value = "Rate Display Machenism (Specific)", required = true, example = "BC_TO_FC", allowEmptyValue = false, allowMultiple = false, allowableValues = "BC_TO_FC,FC_TO_BC")
            @RequestParam(value = "rateDisplayMachenism", required = true) @NotNull final RateDisplayMachenism rateDisplayMachenism,
            @ApiParam(value = "Value date wise such as CASH, TOM etc. (All/Specific)", required = false, example = "CASH", allowEmptyValue = false, allowMultiple = true, allowableValues = "All,CASH,TOM,SPOT,FUTURE")
            @RequestParam(value = "valueDateWises", required = false) final Set<@NotEmpty String> valueDateWises, 
            @RequestParam(value = "baseCurrencies", required = true) @NotEmpty final Set<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = false) final Set<@NotNull CurrencyUnit> foreignCurrencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        if (baseCurrencies != null && baseCurrencies.contains(CurrencyCode.getAllCurrencyUnit())) {
            throw new MasterDataValidationException(MasterDataValidationExceptionType.SPECIFIC_CURRENCIES_REQUIRED,
                    "baseCurrencies");
        }
        return this.enquiryService.streamCountryCostRates(RMType.BANK_WISE, CountryVDWRateType.COST_RATE,
                CountryRateEnquiryRequest.ofBankWise(startingIndex, batchSize, serviceProviders, products, subProducts,
                        serviceTypes, banks, agents, baseCurrencies, foreignCurrencies, valueDateWises,
                        rateDisplayMachenism),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = COUNTRY_NORMAL_AGENT_BRANCH_COST_RATES_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-normal-agent-branch-cost-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Normal Agent Branch cost rates", 
        response = CountryRateEnquiryResponse.class, 
        notes = "",
        hidden = true
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (Specific)", 
            example = "INR", required = true
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false 
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = CountryRateEnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<CountryRateEnquiryResponse> streamNormalCountryAgentCostRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc. (All/Specific)", required = false, example = "Account Credit", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "subProducts", required = false) final Set<@NotEmpty String> subProducts, 
            @ApiParam(value = "Service type such as Flash, Normal etc. (All/Specific)", required = false, example = "Flash", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceTypes", required = false) final Set<@NotEmpty String> serviceTypes, 
            @ApiParam(value = "Agent Code (All/Specific)", required = false, example = "AGENT-001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @ApiParam(value = "Rate Display Machenism (Specific)", required = true, example = "BC_TO_FC", allowEmptyValue = false, allowMultiple = false, allowableValues = "BC_TO_FC,FC_TO_BC")
            @RequestParam(value = "rateDisplayMachenism", required = true) @NotNull final RateDisplayMachenism rateDisplayMachenism,
            @ApiParam(value = "Value date wise such as CASH, TOM etc. (All/Specific)", required = false, example = "CASH", allowEmptyValue = false, allowMultiple = true, allowableValues = "All,CASH,TOM,SPOT,FUTURE")
            @RequestParam(value = "valueDateWises", required = false) final Set<@NotEmpty String> valueDateWises, 
            @RequestParam(value = "baseCurrencies", required = true) @NotEmpty final Set<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = false) final Set<@NotNull CurrencyUnit> foreignCurrencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        if (baseCurrencies != null && baseCurrencies.contains(CurrencyCode.getAllCurrencyUnit())) {
            throw new MasterDataValidationException(MasterDataValidationExceptionType.SPECIFIC_CURRENCIES_REQUIRED,
                    "baseCurrencies");
        }
        return this.enquiryService.streamCountryCostRates(RMType.NORMAL, CountryVDWRateType.AGENT,
                CountryRateEnquiryRequest.ofNormal(startingIndex, batchSize, serviceProviders, products, subProducts,
                        serviceTypes, agents, baseCurrencies, foreignCurrencies, valueDateWises, rateDisplayMachenism),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }

    @GetMapping(path = COUNTRY_BANKWISE_AGENT_BRANCH_COST_RATES_ENQUIRY_URI, produces = TEXT_EVENT_STREAM_VALUE)
    // @formatter:off
    @ApiOperation(nickname = "enquire-bankwise-agent-branch-cost-rates", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = TEXT_EVENT_STREAM_VALUE,
        value = "Stream Bankwise Agent Branch cost rates", 
        response = CountryRateEnquiryResponse.class, 
        notes = "",
        hidden = true
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "baseCurrencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (Specific)", 
            example = "INR", required =  true
        ),
        @ApiImplicitParam(name = "foreignCurrencies", paramType = "query", 
            dataType = "String", allowMultiple = true, allowEmptyValue = false,
            value = "Currency Code in ISO format e.g. INR (All/Specific)", 
            example = "INR", required = false
        ),
        @ApiImplicitParam(name = "batchSize", paramType = "query", 
            dataType = "int", allowMultiple = false, allowEmptyValue = false,
            value = "The upper limit of batch size, default: 200, maximum allowed 1000", 
            example = "1000", required = false, defaultValue = "200"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = CountryRateEnquiryResponse.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = ProblemResponse.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters")
        }
    )
    @Valid
    public Flux<CountryRateEnquiryResponse> streamBankWiseCountryAgentCostRates(
            @ApiParam(value = "Service Provider such as UAE, UK etc. (All/Specific)", required = false, example = "UAE", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceProviders", required = false) final Set<@NotEmpty String> serviceProviders, 
            @ApiParam(value = "Product such as Remittance, Forex etc. (All/Specific)", required = false, example = "Remittance", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "products", required = false) final Set<@NotEmpty String> products, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc. (All/Specific)", required = false, example = "Account Credit", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "subProducts", required = false) final Set<@NotEmpty String> subProducts, 
            @ApiParam(value = "Service type such as Flash, Normal etc. (All/Specific)", required = false, example = "Flash", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "serviceTypes", required = false) final Set<@NotEmpty String> serviceTypes,
            @ApiParam(value = "Bank Code (All/Specific)", required = false, example = "BANK001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "banks", required = false) final Set<@NotEmpty String> banks,  
            @ApiParam(value = "Agent Code or Agent Branch code (All/Specific)", required = false, example = "AGENT-001", allowEmptyValue = false, allowMultiple = true)
            @RequestParam(value = "agents", required = false) final Set<@NotEmpty String> agents, 
            @ApiParam(value = "Rate Display Machenism (Specific)", required = true, example = "BC_TO_FC", allowEmptyValue = false, allowMultiple = false, allowableValues = "BC_TO_FC,FC_TO_BC")
            @RequestParam(value = "rateDisplayMachenism", required = true) @NotNull final RateDisplayMachenism rateDisplayMachenism,
            @ApiParam(value = "Value date wise such as CASH, TOM etc. (All/Specific)", required = false, example = "CASH", allowEmptyValue = false, allowMultiple = true, allowableValues = "All,CASH,TOM,SPOT,FUTURE")
            @RequestParam(value = "valueDateWises", required = false) final Set<@NotEmpty String> valueDateWises, 
            @RequestParam(value = "baseCurrencies", required = true) @NotEmpty final Set<@NotNull CurrencyUnit> baseCurrencies, 
            @RequestParam(value = "foreignCurrencies", required = false) final Set<@NotNull CurrencyUnit> foreignCurrencies, 
            @ApiIgnore @RequestParam(value = "startingIndex", required = false) @PositiveOrZero final Integer startingIndex, 
            @RequestParam(value = "batchSize", required = false) @Min(1) @Max(1000) final Integer batchSize) {
    // @formatter:on

        if (baseCurrencies != null && baseCurrencies.contains(CurrencyCode.getAllCurrencyUnit())) {
            throw new MasterDataValidationException(MasterDataValidationExceptionType.SPECIFIC_CURRENCIES_REQUIRED,
                    "baseCurrencies");
        }
        return this.enquiryService.streamCountryCostRates(RMType.BANK_WISE, CountryVDWRateType.AGENT,
                CountryRateEnquiryRequest.ofBankWise(startingIndex, batchSize, serviceProviders, products, subProducts,
                        serviceTypes, banks, agents, baseCurrencies, foreignCurrencies, valueDateWises,
                        rateDisplayMachenism),
                ServletUriComponentsBuilder.fromCurrentRequestUri().build().toUriString());
    }
}
