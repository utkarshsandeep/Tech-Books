package com.unimoni.pricingengine.adapter.rest.controller.amigo;

import static com.unimoni.pricingengine.adapter.rest.util.HeaderUtil.addSuccess;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.IBR_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.VAR_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.VAR_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.SETTLEMENT_RATE_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RateMessageConstants.SETTLEMENT_RATE_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.RestConstants.AmigoIntegration.AMIGO_INT_IBR_RM_TYPE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AmigoIntegration.AMIGO_INT_SETTLEMENT_RM_TYPE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AmigoIntegration.AMIGO_INT_STANDARD_CHARGE_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AmigoIntegration.AMIGO_INT_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.AmigoIntegration.AMIGO_INT_VAR_RM_TYPE_URI;
import static com.unimoni.pricingengine.common.constants.StandardChargeMessageConstants.STANDARD_CHARGES_CREATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.constants.StandardChargeMessageConstants.STANDARD_CHARGES_UPDATED_SUCCESSFULLY;
import static com.unimoni.pricingengine.common.util.MessageProvider.getMessage;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Problem;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.application.service.amigo.AmigoIntegrationService;
import com.unimoni.pricingengine.application.service.amigo.dto.CreateSettlementRateRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.CreateVaRRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateIBRRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateSettlementRateRequest;
import com.unimoni.pricingengine.application.service.amigo.dto.UpdateVaRRequest;
import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.AmigoStandardChargeRequest;
import com.unimoni.pricingengine.domain.model.standardcharges.dto.AmigoStandardChargeResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "AMIGO", description = "Amigo Integration APIs for rate synching between Amigo and Pricing Engine", tags = "Amigo Integration")
@RestController
@RequestMapping(AMIGO_INT_URI)
public class AmigoIntegrationController {

    @Autowired
    private AmigoIntegrationService amigoIntegrationService;

    @PatchMapping(AMIGO_INT_IBR_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "amigo-update-ibr", 
        value = "Updates an IBR record", 
        notes = "Agent and  bank are mandatory if rmType is BANK_WISE. Service provider and product are always mandatory.\n"
                + "You can update only <b>askValue</b> and <b>bidValue</b>.\n"
                + "Supply only the attributes in request which you want to update.\n"
                + "For example, if you want to update just askValue than don't supply bidValue.\n"
                + "And if you want to update both , supply both askValue and bidValue in input request", 
        response = Void.class
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = Problem.class, message = "Success: Settlement rate record updated successfully"),
            @ApiResponse(code = 400, response = Problem.class, message = "Bad Request: Input request validation failed"),
            @ApiResponse(code = 412, response = Problem.class, message = "Precondition failed: Upper layer link (VaR record) not enabled")
        }
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<Void> updateIBR(@PathVariable RMType rmType,
            @RequestBody @Valid final UpdateIBRRequest updateRequest) {
    // @formatter:on 

        if (rmType.isBankWise()) {
            if (!updateRequest.agent().isPresent() || !updateRequest.bank().isPresent()) {
                throw new RateException(RateExceptionExceptionType.AGENT_AND_BANK_REQUIRED_FOR_BANK_WISE_IBR_REQUEST,
                        Status.BAD_REQUEST, updateRequest.getAgentCode(), updateRequest.getBankCode());
            }
        }

        this.amigoIntegrationService.updateIBR(rmType, updateRequest);
        return ResponseEntity.status(HttpStatus.OK)
                .headers(addSuccess(getMessage(IBR_UPDATED_SUCCESSFULLY))).build();
    }

    @PostMapping(AMIGO_INT_STANDARD_CHARGE_URI)
    // @formatter:off
    @ApiOperation(nickname = "create-or-update-standard-charge", 
        value = "Creates or Update Standard charge record", 
        notes = "If any duplicate standard charge exists, it will be updated.",
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        response = Void.class
    )
    public ResponseEntity<Void> createOrUpdateStandardCharge(
            @ApiParam(required = true, name = "createOrUpdateStandardCharge", value = "Create or Update Standard Charge request")
            @RequestBody @Valid final AmigoStandardChargeRequest createOrUpdateStandardCharge) {
   
        AmigoStandardChargeResponse results = amigoIntegrationService.createOrUpdateStandardCharge(createOrUpdateStandardCharge);
        if(results.isCreated()) { 
            return ResponseEntity.status(HttpStatus.CREATED)
                .headers(addSuccess(getMessage(STANDARD_CHARGES_CREATED_SUCCESSFULLY))).build();
        }
        else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .headers(addSuccess(getMessage(STANDARD_CHARGES_UPDATED_SUCCESSFULLY))).build();
        }
    }
    
    @PostMapping(AMIGO_INT_VAR_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "amigo-create-var", 
        value = "Creates new VaR record", 
        notes = "", 
        response = Void.class
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 201, response = Problem.class, message = "Succes: New VaR record created successfully"),
            @ApiResponse(code = 400, response = Problem.class, message = "Bad Request: Input request validation failed"),
            @ApiResponse(code = 412, response = Problem.class, message = "Precondition failed: Upper layer link (IBR) does not exist"),
            @ApiResponse(code = 409, response = Problem.class, message = "Conflict: A record for requested Identity already exists") 
        }
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<Void> createVaR(@PathVariable RMType rmType,
            @RequestBody @Valid final CreateVaRRequest createRequest) {
    // @formatter:on 

        if (rmType.isBankWise()) {
            if (!createRequest.bank().isPresent()) {
                throw new RateException(RateExceptionExceptionType.BANK_REQUIRED_FOR_BANK_WISE_REQUEST,
                        Status.BAD_REQUEST);
            }
        }

        this.amigoIntegrationService.createVaR(rmType, createRequest);
        return ResponseEntity.status(HttpStatus.CREATED).headers(addSuccess(getMessage(VAR_CREATED_SUCCESSFULLY, 1)))
                .build();
    }

    @PatchMapping(AMIGO_INT_VAR_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "amigo-update-var", 
        value = "Updates a VaR record", 
        notes = "All identity attributes such as agent, bank (if rmType is BANK_WISE), service provider, product, sub product and service type are mandatory.\n"
                + "You can update only <b>cashAskMargin</b>, <b>cashBidMargin</b> or <b>status</b>.\n"
                + "Supply only the attributes in request which you want to update.\n"
                + "For example, if you just want to update status then supply just status not ask and bid CASH margin.\n"
                + "Similarly if you want to update just ask margin than don't supply bid margin and status.\n"
                + "And if you want to update all three, supply all ask, bid magin and status in input request", 
        response = Void.class
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = Problem.class, message = "Success: VaR record updated successfully"),
            @ApiResponse(code = 400, response = Problem.class, message = "Bad Request: Input request validation failed"),
            @ApiResponse(code = 412, response = Problem.class, message = "Precondition failed: Upper layer link (IBR record) not enabled")
        }
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<Void> updateVaR(@PathVariable RMType rmType,
            @RequestBody @Valid final UpdateVaRRequest updateRequest) {
    // @formatter:on 

        if (rmType.isBankWise()) {
            if (!updateRequest.bank().isPresent()) {
                throw new RateException(RateExceptionExceptionType.BANK_REQUIRED_FOR_BANK_WISE_REQUEST,
                        Status.BAD_REQUEST);
            }
        }

        this.amigoIntegrationService.updateVaR(rmType, updateRequest);
        return ResponseEntity.status(HttpStatus.OK).headers(addSuccess(getMessage(VAR_UPDATED_SUCCESSFULLY)))
                .build();
    }

    @PostMapping(AMIGO_INT_SETTLEMENT_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "amigo-create-settlement-rate", 
        value = "Creates new Settlement rate record", 
        notes = "", 
        response = Void.class
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 201, response = Problem.class, message = "Succes: New Settlement rate record created successfully"),
            @ApiResponse(code = 400, response = Problem.class, message = "Bad Request: Input request validation failed"),
            @ApiResponse(code = 412, response = Problem.class, message = "Precondition failed: Upper layer link (VaR) does not exist"),
            @ApiResponse(code = 409, response = Problem.class, message = "Conflict: A record for requested Identity already exists") 
        }
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<Void> createSettlementRate(@PathVariable RMType rmType,
            @RequestBody @Valid final CreateSettlementRateRequest createRequest) {
    // @formatter:on 

        if (rmType.isBankWise()) {
            if (!createRequest.bank().isPresent()) {
                throw new RateException(RateExceptionExceptionType.BANK_REQUIRED_FOR_BANK_WISE_REQUEST,
                        Status.BAD_REQUEST);
            }
        }

        this.amigoIntegrationService.createSettlementRate(rmType, createRequest);
        return ResponseEntity.status(HttpStatus.CREATED)
                .headers(addSuccess(getMessage(SETTLEMENT_RATE_CREATED_SUCCESSFULLY, 1))).build();
    }

    @PatchMapping(AMIGO_INT_SETTLEMENT_RM_TYPE_URI)
    // @formatter:off
    @ApiOperation(nickname = "amigo-update-settlement-rate", 
        value = "Updates a Settlement rate record", 
        notes = "All identity attributes such as agent, bank (if rmType is BANK_WISE), service provider, product, sub product and service type are mandatory.\n"
                + "You can update only <b>cashSettlementSellMargin</b>, <b>cashSettlementBuyMargin</b> or <b>status</b>.\n"
                + "Supply only the attributes in request which you want to update.\n"
                + "For example, if you just want to update status then supply just status not cashSettlementSellMargin and cashSettlementBuyMargin.\n"
                + "Similarly if you want to update just cashSettlementSellMargin than don't supply cashSettlementBuyMargin and status.\n"
                + "And if you want to update all three, supply all cashSettlementSellMargin, cashSettlementBuyMargin and status in input request", 
        response = Void.class
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = Problem.class, message = "Success: Settlement rate record updated successfully"),
            @ApiResponse(code = 400, response = Problem.class, message = "Bad Request: Input request validation failed"),
            @ApiResponse(code = 412, response = Problem.class, message = "Precondition failed: Upper layer link (VaR record) not enabled")
        }
    )
    @ApiImplicitParam(name = "rmType", dataType = "String", paramType = "path", dataTypeClass = RMType.class,
        value = "Rate management type: Normal or Bank wise", required = true,
        allowableValues = "NORMAL, BANK_WISE" 
    )
    public ResponseEntity<Void> updateSettlementRate(@PathVariable RMType rmType,
            @RequestBody @Valid final UpdateSettlementRateRequest updateRequest) {
    // @formatter:on 

        if (rmType.isBankWise()) {
            if (!updateRequest.bank().isPresent()) {
                throw new RateException(RateExceptionExceptionType.BANK_REQUIRED_FOR_BANK_WISE_REQUEST,
                        Status.BAD_REQUEST);
            }
        }

        this.amigoIntegrationService.updateSettlementRate(rmType, updateRequest);
        return ResponseEntity.status(HttpStatus.OK)
                .headers(addSuccess(getMessage(SETTLEMENT_RATE_UPDATED_SUCCESSFULLY))).build();
    }
}
