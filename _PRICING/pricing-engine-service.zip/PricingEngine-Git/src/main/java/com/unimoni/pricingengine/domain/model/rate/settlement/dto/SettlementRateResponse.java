package com.unimoni.pricingengine.domain.model.rate.settlement.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.joda.beans.Bean;
import org.joda.beans.ImmutableBean;
import org.joda.beans.JodaBeanUtils;
import org.joda.beans.MetaBean;
import org.joda.beans.MetaProperty;
import org.joda.beans.gen.BeanDefinition;
import org.joda.beans.gen.PropertyDefinition;
import org.joda.beans.impl.direct.DirectFieldsBeanBuilder;
import org.joda.beans.impl.direct.DirectMetaBean;
import org.joda.beans.impl.direct.DirectMetaProperty;
import org.joda.beans.impl.direct.DirectMetaPropertyMap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.ImmutableMap;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.domain.model.common.dto.ViewModel;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.base.dto.CurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.rate.var.ValueAtRisk;
import com.unimoni.pricingengine.domain.model.rate.var.dto.AllInstrumentsDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@BeanDefinition
@ApiModel(value = "settlementRate", description = "Settlement Rate")
public class SettlementRateResponse implements ViewModel<String>, ImmutableBean {

    @Getter
    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "settlementId", notes = "Settlement Rate ID")
    private String settlementId;

    @Getter
    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "varId", notes = "ID of VaR linked with this Settlement Rate")
    private String varId;

    @PropertyDefinition
    @Download(columnName = "Agent")
    @ApiModelProperty(value = "agent", notes = "Agent")
    private final String agent;

    @PropertyDefinition
    @Download(columnName = "Bank", contexts = DownloadContext.BANK_WISE_SETTLEMENT_RATE)
    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "bank", notes = "Bank")
    private final String bank;

    @Getter
    private RMType rmType;

    @PropertyDefinition
    private final CurrencyDTO currency;

    @PropertyDefinition
    private final AllInstrumentsDTO instruments;

    @PropertyDefinition
    @JsonInclude(NON_EMPTY)
    private final Map<VDWType, SettlementValueDateWiseDTO> valueDateWises;

    @PropertyDefinition
    @Download(columnName = "Updated On")
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "updatedOn", value = "Rate Last updated timestamp with timezone", example = "12-03-2019 09:07:50 (GMT)")
    private final String updatedOn;

    @PropertyDefinition
    @Download(columnName = "Status")
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "status", value = "Enabled or Disabled", example = "true")
    private final Boolean status;

    @PropertyDefinition
    @Download(columnName = "Reason for change")
    @ApiModelProperty(value = "reason", notes = "Reason for last rates update", example = "High volatility")
    private final String reason;

    @JsonInclude
    @PropertyDefinition
    private final Map<VDWType, SettlementValueDateWiseDTO> valueDateWisesForTip;
    
    //@JsonInclude
    //private List<String> oldValuesForTip;
    
    public static SettlementRateResponse of(final SettlementRate settlementRate) {
        SettlementRateResponse resp =  new SettlementRateResponse(settlementRate.id(), null, settlementRate.agent(),
                settlementRate.rmType().isBankWise() ? settlementRate.bank().get() : null, settlementRate.rmType(),
                CurrencyDTO.of(settlementRate.currency()), AllInstrumentsDTO.of(settlementRate.instruments()),
                settlementRate.valueDateWises() == null ? null
                        : settlementRate.valueDateWises().entrySet().stream().collect(Collectors.toMap(e -> e.getKey(),
                                e -> SettlementValueDateWiseDTO.of(e.getValue()), (e1, e2) -> e1, LinkedHashMap::new)),
                DateTimeHelper.convertAndFormatZonedDateTime(settlementRate.updatedOn()), settlementRate.isEnabled(),
                settlementRate.reason(),
                settlementRate.valueDateWisesTemp() == null ? null
                        : settlementRate.valueDateWisesTemp().entrySet().stream().collect(Collectors.toMap(e -> e.getKey(),
                                e -> SettlementValueDateWiseDTO.of(e.getValue()), (e1, e2) -> e1, LinkedHashMap::new)));
        
        //return updated value (temp) in main objects, and old values in tooltip.
        if(settlementRate.valueDateWisesTemp() != null && !settlementRate.valueDateWisesTemp().isEmpty()) {
            updateForTip(resp);
            return resp;
        }
        
        return resp;  
    }

    /*auth-api*/
    /**
     * Switch old to new values for valueDateWises, just to display at UI.
     * */
    private static void updateForTip(SettlementRateResponse resp) {
        
        resp.valueDateWisesForTip.entrySet().stream().forEach(item -> {
            if(resp.valueDateWises.containsKey(item.getKey())) {
                final BigDecimal buyMargin = resp.valueDateWises.get(item.getKey()).getMargin().getBuyValue();
                final BigDecimal sellMargin = resp.valueDateWises.get(item.getKey()).getMargin().getSellValue();
                
                //Set new change values in main object, only when there is any change..i.e.NotNull
                if(item.getValue().getMargin().getBuyValue() != null) {
                    resp.valueDateWises.get(item.getKey()).getMargin().setBuyValue(item.getValue().getMargin().getBuyValue());
                }
                if(item.getValue().getMargin().getSellValue() != null) {
                    resp.valueDateWises.get(item.getKey()).getMargin().setSellValue(item.getValue().getMargin().getSellValue());
                }
                
                item.getValue().setSettlement(null);            //nullify others
                item.getValue().setMargin(CostDTO.of(sellMargin, buyMargin));                
            }
        });        
    }

    public static SettlementRateResponse ofMetaData(final RMType rmType, final SettlementIdentity settlementAllIdentity,
            final ValueAtRisk var) {
        return new SettlementRateResponse(null, var.id(), settlementAllIdentity.getAgent(),
                rmType.isBankWise() ? settlementAllIdentity.getBank().get() : null, rmType,
                settlementAllIdentity.getCurrency(), settlementAllIdentity.getInstruments(),
                var.valueDateWises().entrySet().stream()
                        .collect(Collectors.toMap(e -> e.getKey(),
                                e -> SettlementValueDateWiseDTO.byDefault(e.getValue().settlement()), (e1, e2) -> e1,
                                LinkedHashMap::new)),
                null, null, null, null);
    }

    @Override
    public String id() {
        return this.settlementId;
    }

  //------------------------- AUTOGENERATED START -------------------------
  /**
   * The meta-bean for {@code SettlementRateResponse}.
   * @return the meta-bean, not null
   */
  public static SettlementRateResponse.Meta meta() {
    return SettlementRateResponse.Meta.INSTANCE;
  }

  static {
    MetaBean.register(SettlementRateResponse.Meta.INSTANCE);
  }

  /**
   * Returns a builder used to create an instance of the bean.
   * @return the builder, not null
   */
  public static SettlementRateResponse.Builder builder() {
    return new SettlementRateResponse.Builder();
  }

  /**
   * Restricted constructor.
   * @param builder  the builder to copy from, not null
   */
  protected SettlementRateResponse(SettlementRateResponse.Builder builder) {
    this.agent = builder.agent;
    this.bank = builder.bank;
    this.currency = builder.currency;
    this.instruments = builder.instruments;
    this.valueDateWises = (builder.valueDateWises != null ? ImmutableMap.copyOf(builder.valueDateWises) : null);
    this.updatedOn = builder.updatedOn;
    this.status = builder.status;
    this.reason = builder.reason;
    this.valueDateWisesForTip = (builder.valueDateWisesForTip != null ? ImmutableMap.copyOf(builder.valueDateWisesForTip) : null);
  }

  @Override
  public SettlementRateResponse.Meta metaBean() {
    return SettlementRateResponse.Meta.INSTANCE;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the agent.
   * @return the value of the property
   */
  public String getAgent() {
    return agent;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the bank.
   * @return the value of the property
   */
  public String getBank() {
    return bank;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the currency.
   * @return the value of the property
   */
  public CurrencyDTO getCurrency() {
    return currency;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the instruments.
   * @return the value of the property
   */
  public AllInstrumentsDTO getInstruments() {
    return instruments;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the valueDateWises.
   * @return the value of the property
   */
  public Map<VDWType, SettlementValueDateWiseDTO> getValueDateWises() {
    return valueDateWises;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the updatedOn.
   * @return the value of the property
   */
  public String getUpdatedOn() {
    return updatedOn;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the status.
   * @return the value of the property
   */
  public Boolean getStatus() {
    return status;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the reason.
   * @return the value of the property
   */
  public String getReason() {
    return reason;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the valueDateWisesForTip.
   * @return the value of the property
   */
  public Map<VDWType, SettlementValueDateWiseDTO> getValueDateWisesForTip() {
    return valueDateWisesForTip;
  }

  //-----------------------------------------------------------------------
  /**
   * Returns a builder that allows this bean to be mutated.
   * @return the mutable builder, not null
   */
  public Builder toBuilder() {
    return new Builder(this);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj != null && obj.getClass() == this.getClass()) {
      SettlementRateResponse other = (SettlementRateResponse) obj;
      return JodaBeanUtils.equal(agent, other.agent) &&
          JodaBeanUtils.equal(bank, other.bank) &&
          JodaBeanUtils.equal(currency, other.currency) &&
          JodaBeanUtils.equal(instruments, other.instruments) &&
          JodaBeanUtils.equal(valueDateWises, other.valueDateWises) &&
          JodaBeanUtils.equal(updatedOn, other.updatedOn) &&
          JodaBeanUtils.equal(status, other.status) &&
          JodaBeanUtils.equal(reason, other.reason) &&
          JodaBeanUtils.equal(valueDateWisesForTip, other.valueDateWisesForTip);
    }
    return false;
  }

  @Override
  public int hashCode() {
    int hash = getClass().hashCode();
    hash = hash * 31 + JodaBeanUtils.hashCode(agent);
    hash = hash * 31 + JodaBeanUtils.hashCode(bank);
    hash = hash * 31 + JodaBeanUtils.hashCode(currency);
    hash = hash * 31 + JodaBeanUtils.hashCode(instruments);
    hash = hash * 31 + JodaBeanUtils.hashCode(valueDateWises);
    hash = hash * 31 + JodaBeanUtils.hashCode(updatedOn);
    hash = hash * 31 + JodaBeanUtils.hashCode(status);
    hash = hash * 31 + JodaBeanUtils.hashCode(reason);
    hash = hash * 31 + JodaBeanUtils.hashCode(valueDateWisesForTip);
    return hash;
  }

  @Override
  public String toString() {
    StringBuilder buf = new StringBuilder(320);
    buf.append("SettlementRateResponse{");
    int len = buf.length();
    toString(buf);
    if (buf.length() > len) {
      buf.setLength(buf.length() - 2);
    }
    buf.append('}');
    return buf.toString();
  }

  protected void toString(StringBuilder buf) {
    buf.append("agent").append('=').append(JodaBeanUtils.toString(agent)).append(',').append(' ');
    buf.append("bank").append('=').append(JodaBeanUtils.toString(bank)).append(',').append(' ');
    buf.append("currency").append('=').append(JodaBeanUtils.toString(currency)).append(',').append(' ');
    buf.append("instruments").append('=').append(JodaBeanUtils.toString(instruments)).append(',').append(' ');
    buf.append("valueDateWises").append('=').append(JodaBeanUtils.toString(valueDateWises)).append(',').append(' ');
    buf.append("updatedOn").append('=').append(JodaBeanUtils.toString(updatedOn)).append(',').append(' ');
    buf.append("status").append('=').append(JodaBeanUtils.toString(status)).append(',').append(' ');
    buf.append("reason").append('=').append(JodaBeanUtils.toString(reason)).append(',').append(' ');
    buf.append("valueDateWisesForTip").append('=').append(JodaBeanUtils.toString(valueDateWisesForTip)).append(',').append(' ');
  }

  //-----------------------------------------------------------------------
  /**
   * The meta-bean for {@code SettlementRateResponse}.
   */
  public static class Meta extends DirectMetaBean {
    /**
     * The singleton instance of the meta-bean.
     */
    static final Meta INSTANCE = new Meta();

    /**
     * The meta-property for the {@code agent} property.
     */
    private final MetaProperty<String> _agent = DirectMetaProperty.ofImmutable(
        this, "agent", SettlementRateResponse.class, String.class);
    /**
     * The meta-property for the {@code bank} property.
     */
    private final MetaProperty<String> _bank = DirectMetaProperty.ofImmutable(
        this, "bank", SettlementRateResponse.class, String.class);
    /**
     * The meta-property for the {@code currency} property.
     */
    private final MetaProperty<CurrencyDTO> _currency = DirectMetaProperty.ofImmutable(
        this, "currency", SettlementRateResponse.class, CurrencyDTO.class);
    /**
     * The meta-property for the {@code instruments} property.
     */
    private final MetaProperty<AllInstrumentsDTO> _instruments = DirectMetaProperty.ofImmutable(
        this, "instruments", SettlementRateResponse.class, AllInstrumentsDTO.class);
    /**
     * The meta-property for the {@code valueDateWises} property.
     */
    @SuppressWarnings({"unchecked", "rawtypes" })
    private final MetaProperty<Map<VDWType, SettlementValueDateWiseDTO>> _valueDateWises = DirectMetaProperty.ofImmutable(
        this, "valueDateWises", SettlementRateResponse.class, (Class) Map.class);
    /**
     * The meta-property for the {@code updatedOn} property.
     */
    private final MetaProperty<String> _updatedOn = DirectMetaProperty.ofImmutable(
        this, "updatedOn", SettlementRateResponse.class, String.class);
    /**
     * The meta-property for the {@code status} property.
     */
    private final MetaProperty<Boolean> _status = DirectMetaProperty.ofImmutable(
        this, "status", SettlementRateResponse.class, Boolean.class);
    /**
     * The meta-property for the {@code reason} property.
     */
    private final MetaProperty<String> _reason = DirectMetaProperty.ofImmutable(
        this, "reason", SettlementRateResponse.class, String.class);
    /**
     * The meta-property for the {@code valueDateWisesForTip} property.
     */
    @SuppressWarnings({"unchecked", "rawtypes" })
    private final MetaProperty<Map<VDWType, SettlementValueDateWiseDTO>> _valueDateWisesForTip = DirectMetaProperty.ofImmutable(
        this, "valueDateWisesForTip", SettlementRateResponse.class, (Class) Map.class);
    /**
     * The meta-properties.
     */
    private final Map<String, MetaProperty<?>> _metaPropertyMap$ = new DirectMetaPropertyMap(
        this, null,
        "agent",
        "bank",
        "currency",
        "instruments",
        "valueDateWises",
        "updatedOn",
        "status",
        "reason",
        "valueDateWisesForTip");

    /**
     * Restricted constructor.
     */
    protected Meta() {
    }

    @Override
    protected MetaProperty<?> metaPropertyGet(String propertyName) {
      switch (propertyName.hashCode()) {
        case 92750597:  // agent
          return _agent;
        case 3016252:  // bank
          return _bank;
        case 575402001:  // currency
          return _currency;
        case 310319468:  // instruments
          return _instruments;
        case -1871135024:  // valueDateWises
          return _valueDateWises;
        case -1949194246:  // updatedOn
          return _updatedOn;
        case -892481550:  // status
          return _status;
        case -934964668:  // reason
          return _reason;
        case -1354307070:  // valueDateWisesForTip
          return _valueDateWisesForTip;
      }
      return super.metaPropertyGet(propertyName);
    }

    @Override
    public SettlementRateResponse.Builder builder() {
      return new SettlementRateResponse.Builder();
    }

    @Override
    public Class<? extends SettlementRateResponse> beanType() {
      return SettlementRateResponse.class;
    }

    @Override
    public Map<String, MetaProperty<?>> metaPropertyMap() {
      return _metaPropertyMap$;
    }

    //-----------------------------------------------------------------------
    /**
     * The meta-property for the {@code agent} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> agent() {
      return _agent;
    }

    /**
     * The meta-property for the {@code bank} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> bank() {
      return _bank;
    }

    /**
     * The meta-property for the {@code currency} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CurrencyDTO> currency() {
      return _currency;
    }

    /**
     * The meta-property for the {@code instruments} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<AllInstrumentsDTO> instruments() {
      return _instruments;
    }

    /**
     * The meta-property for the {@code valueDateWises} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<Map<VDWType, SettlementValueDateWiseDTO>> valueDateWises() {
      return _valueDateWises;
    }

    /**
     * The meta-property for the {@code updatedOn} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> updatedOn() {
      return _updatedOn;
    }

    /**
     * The meta-property for the {@code status} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<Boolean> status() {
      return _status;
    }

    /**
     * The meta-property for the {@code reason} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> reason() {
      return _reason;
    }

    /**
     * The meta-property for the {@code valueDateWisesForTip} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<Map<VDWType, SettlementValueDateWiseDTO>> valueDateWisesForTip() {
      return _valueDateWisesForTip;
    }

    //-----------------------------------------------------------------------
    @Override
    protected Object propertyGet(Bean bean, String propertyName, boolean quiet) {
      switch (propertyName.hashCode()) {
        case 92750597:  // agent
          return ((SettlementRateResponse) bean).getAgent();
        case 3016252:  // bank
          return ((SettlementRateResponse) bean).getBank();
        case 575402001:  // currency
          return ((SettlementRateResponse) bean).getCurrency();
        case 310319468:  // instruments
          return ((SettlementRateResponse) bean).getInstruments();
        case -1871135024:  // valueDateWises
          return ((SettlementRateResponse) bean).getValueDateWises();
        case -1949194246:  // updatedOn
          return ((SettlementRateResponse) bean).getUpdatedOn();
        case -892481550:  // status
          return ((SettlementRateResponse) bean).getStatus();
        case -934964668:  // reason
          return ((SettlementRateResponse) bean).getReason();
        case -1354307070:  // valueDateWisesForTip
          return ((SettlementRateResponse) bean).getValueDateWisesForTip();
      }
      return super.propertyGet(bean, propertyName, quiet);
    }

    @Override
    protected void propertySet(Bean bean, String propertyName, Object newValue, boolean quiet) {
      metaProperty(propertyName);
      if (quiet) {
        return;
      }
      throw new UnsupportedOperationException("Property cannot be written: " + propertyName);
    }

  }

  //-----------------------------------------------------------------------
  /**
   * The bean-builder for {@code SettlementRateResponse}.
   */
  public static class Builder extends DirectFieldsBeanBuilder<SettlementRateResponse> {

    private String agent;
    private String bank;
    private CurrencyDTO currency;
    private AllInstrumentsDTO instruments;
    private Map<VDWType, SettlementValueDateWiseDTO> valueDateWises;
    private String updatedOn;
    private Boolean status;
    private String reason;
    private Map<VDWType, SettlementValueDateWiseDTO> valueDateWisesForTip;

    /**
     * Restricted constructor.
     */
    protected Builder() {
    }

    /**
     * Restricted copy constructor.
     * @param beanToCopy  the bean to copy from, not null
     */
    protected Builder(SettlementRateResponse beanToCopy) {
      this.agent = beanToCopy.getAgent();
      this.bank = beanToCopy.getBank();
      this.currency = beanToCopy.getCurrency();
      this.instruments = beanToCopy.getInstruments();
      this.valueDateWises = (beanToCopy.getValueDateWises() != null ? ImmutableMap.copyOf(beanToCopy.getValueDateWises()) : null);
      this.updatedOn = beanToCopy.getUpdatedOn();
      this.status = beanToCopy.getStatus();
      this.reason = beanToCopy.getReason();
      this.valueDateWisesForTip = (beanToCopy.getValueDateWisesForTip() != null ? ImmutableMap.copyOf(beanToCopy.getValueDateWisesForTip()) : null);
    }

    //-----------------------------------------------------------------------
    @Override
    public Object get(String propertyName) {
      switch (propertyName.hashCode()) {
        case 92750597:  // agent
          return agent;
        case 3016252:  // bank
          return bank;
        case 575402001:  // currency
          return currency;
        case 310319468:  // instruments
          return instruments;
        case -1871135024:  // valueDateWises
          return valueDateWises;
        case -1949194246:  // updatedOn
          return updatedOn;
        case -892481550:  // status
          return status;
        case -934964668:  // reason
          return reason;
        case -1354307070:  // valueDateWisesForTip
          return valueDateWisesForTip;
        default:
          throw new NoSuchElementException("Unknown property: " + propertyName);
      }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Builder set(String propertyName, Object newValue) {
      switch (propertyName.hashCode()) {
        case 92750597:  // agent
          this.agent = (String) newValue;
          break;
        case 3016252:  // bank
          this.bank = (String) newValue;
          break;
        case 575402001:  // currency
          this.currency = (CurrencyDTO) newValue;
          break;
        case 310319468:  // instruments
          this.instruments = (AllInstrumentsDTO) newValue;
          break;
        case -1871135024:  // valueDateWises
          this.valueDateWises = (Map<VDWType, SettlementValueDateWiseDTO>) newValue;
          break;
        case -1949194246:  // updatedOn
          this.updatedOn = (String) newValue;
          break;
        case -892481550:  // status
          this.status = (Boolean) newValue;
          break;
        case -934964668:  // reason
          this.reason = (String) newValue;
          break;
        case -1354307070:  // valueDateWisesForTip
          this.valueDateWisesForTip = (Map<VDWType, SettlementValueDateWiseDTO>) newValue;
          break;
        default:
          throw new NoSuchElementException("Unknown property: " + propertyName);
      }
      return this;
    }

    @Override
    public Builder set(MetaProperty<?> property, Object value) {
      super.set(property, value);
      return this;
    }

    @Override
    public SettlementRateResponse build() {
      return new SettlementRateResponse(this);
    }

    //-----------------------------------------------------------------------
    /**
     * Sets the agent.
     * @param agent  the new value
     * @return this, for chaining, not null
     */
    public Builder agent(String agent) {
      this.agent = agent;
      return this;
    }

    /**
     * Sets the bank.
     * @param bank  the new value
     * @return this, for chaining, not null
     */
    public Builder bank(String bank) {
      this.bank = bank;
      return this;
    }

    /**
     * Sets the currency.
     * @param currency  the new value
     * @return this, for chaining, not null
     */
    public Builder currency(CurrencyDTO currency) {
      this.currency = currency;
      return this;
    }

    /**
     * Sets the instruments.
     * @param instruments  the new value
     * @return this, for chaining, not null
     */
    public Builder instruments(AllInstrumentsDTO instruments) {
      this.instruments = instruments;
      return this;
    }

    /**
     * Sets the valueDateWises.
     * @param valueDateWises  the new value
     * @return this, for chaining, not null
     */
    public Builder valueDateWises(Map<VDWType, SettlementValueDateWiseDTO> valueDateWises) {
      this.valueDateWises = valueDateWises;
      return this;
    }

    /**
     * Sets the updatedOn.
     * @param updatedOn  the new value
     * @return this, for chaining, not null
     */
    public Builder updatedOn(String updatedOn) {
      this.updatedOn = updatedOn;
      return this;
    }

    /**
     * Sets the status.
     * @param status  the new value
     * @return this, for chaining, not null
     */
    public Builder status(Boolean status) {
      this.status = status;
      return this;
    }

    /**
     * Sets the reason.
     * @param reason  the new value
     * @return this, for chaining, not null
     */
    public Builder reason(String reason) {
      this.reason = reason;
      return this;
    }

    /**
     * Sets the valueDateWisesForTip.
     * @param valueDateWisesForTip  the new value
     * @return this, for chaining, not null
     */
    public Builder valueDateWisesForTip(Map<VDWType, SettlementValueDateWiseDTO> valueDateWisesForTip) {
      this.valueDateWisesForTip = valueDateWisesForTip;
      return this;
    }

    //-----------------------------------------------------------------------
    @Override
    public String toString() {
      StringBuilder buf = new StringBuilder(320);
      buf.append("SettlementRateResponse.Builder{");
      int len = buf.length();
      toString(buf);
      if (buf.length() > len) {
        buf.setLength(buf.length() - 2);
      }
      buf.append('}');
      return buf.toString();
    }

    protected void toString(StringBuilder buf) {
      buf.append("agent").append('=').append(JodaBeanUtils.toString(agent)).append(',').append(' ');
      buf.append("bank").append('=').append(JodaBeanUtils.toString(bank)).append(',').append(' ');
      buf.append("currency").append('=').append(JodaBeanUtils.toString(currency)).append(',').append(' ');
      buf.append("instruments").append('=').append(JodaBeanUtils.toString(instruments)).append(',').append(' ');
      buf.append("valueDateWises").append('=').append(JodaBeanUtils.toString(valueDateWises)).append(',').append(' ');
      buf.append("updatedOn").append('=').append(JodaBeanUtils.toString(updatedOn)).append(',').append(' ');
      buf.append("status").append('=').append(JodaBeanUtils.toString(status)).append(',').append(' ');
      buf.append("reason").append('=').append(JodaBeanUtils.toString(reason)).append(',').append(' ');
      buf.append("valueDateWisesForTip").append('=').append(JodaBeanUtils.toString(valueDateWisesForTip)).append(',').append(' ');
    }

  }

  //-------------------------- AUTOGENERATED END --------------------------
}
