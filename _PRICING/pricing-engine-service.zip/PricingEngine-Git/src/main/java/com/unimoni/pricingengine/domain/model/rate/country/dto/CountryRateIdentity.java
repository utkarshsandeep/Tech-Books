package com.unimoni.pricingengine.domain.model.rate.country.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.var.dto.AllInstrumentsDTO;
import com.unimoni.pricingengine.infra.config.BeanFactory;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode
@ToString
public class CountryRateIdentity {

    private AllInstrumentsDTO instruments;

    private AgentDetails agent;

    @JsonInclude(NON_NULL)
    private String bank;

    private CountryCurrencyDTO currency;

    public static CountryRateIdentity ofNormal(final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final AgentDetails agent,
            final CountryCurrencyDTO currency) {
        CountryRateIdentity countryAllIdentity = new CountryRateIdentity();
        countryAllIdentity.instruments = AllInstrumentsDTO.of(serviceProvider, product, subProduct, serviceType);
        countryAllIdentity.agent = agent;
        countryAllIdentity.currency = currency;
        return countryAllIdentity;
    }

    public static CountryRateIdentity ofBankWise(final String serviceProvider, final String product,
            final String subProduct, final String serviceType, final AgentDetails agent, final String bank,
            final CountryCurrencyDTO currency) {
        CountryRateIdentity countryAllIdentity = ofNormal(serviceProvider, product, subProduct, serviceType, agent,
                currency);
        countryAllIdentity.bank = bank;
        return countryAllIdentity;
    }

    public Optional<String> getBank() {
        return Optional.ofNullable(this.bank);
    }

    @JsonIgnore
    public Optional<String> agentCodeIfBranch() {
        return agent.getType().isBranch()
                ? Optional.of(BeanFactory.masterData().getAgentCodeByBranchCode(this.agent.getCode()))
                : Optional.empty();
    }

    @JsonIgnore
    public boolean isAgent() {
        return this.getAgent().getType().isAgent();
    }

    @JsonIgnore
    public boolean areCurrenciesSame() {
        return this.currency.getBase() == this.currency.getForiegn();
    }
}
