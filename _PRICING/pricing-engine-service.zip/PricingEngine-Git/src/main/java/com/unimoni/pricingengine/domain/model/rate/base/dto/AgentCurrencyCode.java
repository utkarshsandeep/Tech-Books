package com.unimoni.pricingengine.domain.model.rate.base.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AgentCurrencyCode{
	private Integer id;
	private String code;
	
	public AgentCurrencyCode (@JsonProperty Integer id, @JsonProperty  String code) {
		this.id = id;
		this.code = code;
	}
}

