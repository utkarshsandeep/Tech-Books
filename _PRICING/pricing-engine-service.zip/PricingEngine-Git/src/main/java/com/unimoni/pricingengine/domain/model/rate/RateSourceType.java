package com.unimoni.pricingengine.domain.model.rate;

import java.util.EnumSet;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.unimoni.pricingengine.common.util.ImmutableCollectors;
import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "rateSourceType", description = "Rate Source Type")
public enum RateSourceType {

    MANUAL("Manual"), IBR_NORMAL("IBR Normal");

    private final String description;

    private static final EnumSet<RateSourceType> ALL_VALUES = EnumSet.allOf(RateSourceType.class);

    private RateSourceType(final String description) {
        this.description = description;
    }

    public String description() {
        return this.description;
    }

    @JsonCreator
    public static RateSourceType of(final String name) {
        for (RateSourceType e : values())
            if (e.name().equals(name))
                return e;
        throw new IllegalArgumentException();
    }

    @JsonValue
    public CodeNamePair<String, String> toPair() {
        return CodeNamePair.of(this.name(), this.description());
    }

    // @JsonValue
    public Pair<String, String> toPairType() {
        return Pair.of(this.name(), this.description());
    }

    public static EnumSet<RateSourceType> all() {
        return ALL_VALUES;
    }

    public static List<CodeNamePair<String, String>> listItems() {
        return ALL_VALUES.stream().map(RateSourceType::toPair).collect(ImmutableCollectors.toImmutableList());
    }
}
