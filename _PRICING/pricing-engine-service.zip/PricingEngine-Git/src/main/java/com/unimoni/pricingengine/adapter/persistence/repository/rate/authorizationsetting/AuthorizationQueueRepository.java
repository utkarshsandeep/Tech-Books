package com.unimoni.pricingengine.adapter.persistence.repository.rate.authorizationsetting;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationQueue;

public interface AuthorizationQueueRepository extends JpaRepository<AuthorizationQueue, String>, AuthorizationQueueRepositoryJPA {

}
