package com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationStatusType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@ToString
@ApiModel(value = "authorizationRequest", description = "Authorization queue authorize request")
public class AuthorizationQueueAuthorizeRequest {

    @ApiModelProperty(name = "queueIdsList", dataType = "String", value = "Ids of queue data", required = true)
    List<@NotEmpty String> queueIdsList;

    @ApiModelProperty(name = "status", allowEmptyValue = false, dataType = "AuthorizationStatusType", value = "APPROVED or REJECTED", required = true, example = "APPROVED", allowableValues = "APPROVED,REJECTED")
    private AuthorizationStatusType status;

}
