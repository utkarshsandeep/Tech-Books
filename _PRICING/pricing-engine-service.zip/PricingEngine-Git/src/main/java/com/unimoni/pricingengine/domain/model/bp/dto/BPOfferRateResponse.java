package com.unimoni.pricingengine.domain.model.bp.dto;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BPOfferRateResponse {
	private String dealId;
	private BigDecimal IBRRate;
	private BigDecimal CountryCost;
	private BigDecimal AgentCost;

}
