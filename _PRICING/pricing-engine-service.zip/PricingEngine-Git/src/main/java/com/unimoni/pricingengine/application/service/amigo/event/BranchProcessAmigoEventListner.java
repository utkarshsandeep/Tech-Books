package com.unimoni.pricingengine.application.service.amigo.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import com.unimoni.pricingengine.adapter.rest.clients.bp.BranchProcessAmigoClient;
import com.unimoni.pricingengine.adapter.rest.clients.bp.BranchProcessAmigoResponse;
import com.unimoni.pricingengine.adapter.rest.clients.bp.BranchProcessQatarAmigoClient;
import com.unimoni.pricingengine.common.annotation.spring.JmsIntegration;

import lombok.extern.slf4j.Slf4j;

@JmsIntegration
@Slf4j
@Component
public class BranchProcessAmigoEventListner {

    @Autowired
    private BranchProcessAmigoClient amigoClient;
    
    @Autowired
    private BranchProcessQatarAmigoClient qatarAmigoClient;
    
    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, classes = { BranchProcessEvent.class})
    public <T extends BranchProcessEvent> void handleBranchProcessCreatedEvent(final BranchProcessEvent bpEvent) {
        log.info("BranchProcessEvent: START: Pushing BranchProcessCreate Request: {} to Amigo API " + bpEvent.getReq());
        BranchProcessAmigoResponse resp = amigoClient.pushDealToAmigo(bpEvent.getReq());
        
        log.info("BranchProcessEvent: END: Pushing BranchProcessCreate Request: Response " + resp);
    }
    
    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, classes = { BranchProcessUpdateAmigoEvent.class})
    public <T extends BranchProcessUpdateAmigoEvent> void handleBranchProcessUpdateForAmigoEvent(final BranchProcessUpdateAmigoEvent bpEvent) {
        log.info("BranchProcessUpdateAmigoEvent: START: Pushing BranchProcessUpdate: {} to Amigo : " + bpEvent.getReq());
        BranchProcessAmigoResponse resp = amigoClient.updateOfferedRateAmigo(bpEvent.getReq());
        
        log.info("BranchProcessUpdateAmigoEvent: END: Pushing BranchProcessUpdate: Response : " + resp);
    }
    
    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, classes = { BranchProcessUpdateAmigoQatarEvent.class})
    public <T extends BranchProcessUpdateAmigoQatarEvent> void handleBranchProcessUpdateForAmigoEvent(final BranchProcessUpdateAmigoQatarEvent bpEvent) {
        log.info("BranchProcessUpdateAmigoQatarEvent: START: Pushing BranchProcessUpdate: {} to Amigo Qatar : " + bpEvent.getReq());
        BranchProcessAmigoResponse resp = qatarAmigoClient.updateOfferedRateQatarAmigo(bpEvent.getReq());
        
        log.info("BranchProcessUpdateAmigoQatarEvent: END: Pushing BranchProcessUpdate: Response : " + resp);
    }
    
    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, classes = { BranchProcessUpdateStatusAmigoEvent.class})
    public <T extends BranchProcessUpdateStatusAmigoEvent> void handleBranchProcessUpdateForAmigoEvent(final BranchProcessUpdateStatusAmigoEvent bpEvent) {
        log.info("BranchProcessUpdateStatusAmigoEvent: START: Pushing BranchProcessUpdate: {} to Amigo : " + bpEvent.getReq());
        BranchProcessAmigoResponse resp = amigoClient.updateDealStatusAmigo(bpEvent.getReq());
        
        log.info("BranchProcessUpdateStatusAmigoEvent: END: Pushing BranchProcessUpdate: Response : " + resp);
    }
    
    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, classes = { BranchProcessUpdateStatusQatarEvent.class})
    public <T extends BranchProcessUpdateStatusQatarEvent> void handleBranchProcessUpdateForAmigoEvent(final BranchProcessUpdateStatusQatarEvent bpEvent) {
        log.info("BranchProcessUpdateStatusQatarEvent: START: Pushing BranchProcessUpdate: {} to Amigo Qatar : " + bpEvent.getReq());
        BranchProcessAmigoResponse resp = qatarAmigoClient.updateDealStatusQatarAmigo(bpEvent.getReq());
        
        log.info("BranchProcessUpdateStatusQatarEvent: END: Pushing BranchProcessUpdate: Response : " + resp);
    }
}
