package com.unimoni.pricingengine.domain.model.enquiry.settlement;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@ToString
public class SettlementRateEnquiryProjection {

    private String serviceProvider;

    private String product;

    private String subProduct;

    private String serviceType;

    private String bank;

    private String agent;

    private CurrencyUnit currency;

    private VDWType valueDateWise;

    private CostDTO rate;

    // Normal
    public SettlementRateEnquiryProjection(final String serviceProvider, final String product, final String subProduct,
            final String serviceType, final String agent, final CurrencyUnit currency, final VDWType valueDateWise,
            final Cost rate) {
        this.serviceProvider = serviceProvider;
        this.product = product;
        this.subProduct = subProduct;
        this.serviceType = serviceType;
        this.agent = agent;
        this.currency = currency;
        this.valueDateWise = valueDateWise;
        this.rate = CostDTO.of(rate);
    }

    // Bankwise
    public SettlementRateEnquiryProjection(final String serviceProvider, final String product, final String subProduct,
            final String serviceType, final String bank, final String agent, final CurrencyUnit currency,
            final VDWType valueDateWise, final Cost rate) {
        this.serviceProvider = serviceProvider;
        this.product = product;
        this.subProduct = subProduct;
        this.serviceType = serviceType;
        this.bank = bank;
        this.agent = agent;
        this.currency = currency;
        this.valueDateWise = valueDateWise;
        this.rate = CostDTO.of(rate);
    }
}
