package com.unimoni.pricingengine.domain.model.rate.composable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString(includeFieldNames = true, callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Embeddable
@org.hibernate.annotations.Immutable
public class AllInstruments extends RateInstruments {

    @NotNull
    @Column(name = "SUB_PRODUCT_CODE", updatable = false, nullable = false, length = 100)
    private String subProduct;

    @NotNull
    @Column(name = "SERVICE_TYPE_CODE", updatable = false, nullable = false, length = 100)
    private String serviceType;

    protected AllInstruments(final String serviceProvider, final String product,
            final String subProduct, final String serviceType) {
        super(serviceProvider, product);
        Assert.isTrue(StringUtils.isNotEmpty(subProduct), "subProduct must not be null or empty");
        Assert.isTrue(StringUtils.isNotEmpty(serviceType), "serviceType must not be null or empty");
        this.subProduct = subProduct;
        this.serviceType = serviceType;
    }

    public static AllInstruments of(final String serviceProvider, final String product,
            final String subProduct, final String serviceType) {
        return new AllInstruments(serviceProvider, product, subProduct, serviceType);
    }
}
