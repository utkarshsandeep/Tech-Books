package com.unimoni.pricingengine.adapter.persistence.repository.var;

import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementBasicIdentity;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.SettlementIdentity;
import com.unimoni.pricingengine.domain.model.rate.var.VaR;
import com.unimoni.pricingengine.domain.model.rate.var.dto.SearchVaRRequest;
import com.unimoni.pricingengine.domain.model.rate.var.dto.VaRIdentity;

public interface VaRRepositoryJPA extends JPA {

    public Optional<VaR> findEnabledVaRByIdentity(final RMType rmType, final VaRIdentity varIdentity);

    public Optional<VaR> findLatestDisabledVaRByIdentity(final RMType rmType, final VaRIdentity varIdentity);

    public List<VaR> findAllVaRs(final SearchVaRRequest request);

    public List<VaR> findVaRsByIds(final RMType rmType, final List<String> ids, boolean eagerFetchSettlement);

    public Optional<VaR> findHighestVaRsBySettlementBasicIdentity(final RMType rmType,
            final SettlementBasicIdentity settlementBasicIdentity);

    public Optional<VaR> findHighestVaRsBySettlementIdentity(final RMType rmType,
            final SettlementIdentity settlementIdentity);
    
    public VaR getVaRReference(final String varId);
}
