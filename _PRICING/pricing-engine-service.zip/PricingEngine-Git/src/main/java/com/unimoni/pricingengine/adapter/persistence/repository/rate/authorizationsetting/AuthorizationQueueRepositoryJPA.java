package com.unimoni.pricingengine.adapter.persistence.repository.rate.authorizationsetting;

import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationQueue;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationStatusType;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationQueueSearchRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.ColumnNameType;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

public interface AuthorizationQueueRepositoryJPA extends JPA {

    public List<AuthorizationQueue> findAllAuthorizationQueueRecords(
            final AuthorizationQueueSearchRequest searchRequest);
    
    public List<AuthorizationQueue> findByStatus(AuthorizationStatusType status);
    
    public Optional<AuthorizationQueue> findAuthorizationQueueData(String refId, AuthorizationStatusType statsType,
            VDWType vdwType, ColumnNameType columnName);
    
}
