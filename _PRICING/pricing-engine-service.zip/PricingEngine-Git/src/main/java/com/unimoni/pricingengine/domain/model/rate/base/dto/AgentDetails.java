package com.unimoni.pricingengine.domain.model.rate.base.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AgentDetails {

	private String agentId;

	public AgentDetails(@JsonProperty String agentId) {
		this.agentId = agentId;
	}
}
