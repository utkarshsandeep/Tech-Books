package com.unimoni.pricingengine.application.service.amigo.event;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class IBRCreatedEvent extends AmigoEvent {

    @Getter(value = AccessLevel.NONE)
    private static final long serialVersionUID = 1L;

    @JsonInclude(NON_NULL)
    private String agentCode;

    @JsonInclude(NON_NULL)
    private String bankCode;

    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal askValue;

    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    private BigDecimal bidValue;

    private IBRCreatedEvent(final NormalIBR normalIBR) {
        super(Type.IBR_NORMAL, normalIBR.instruments().serviceProvider(), normalIBR.instruments().product(),
                normalIBR.exchange().currency().source(), normalIBR.exchange().currency().target(),
                normalIBR.isEnabled(), normalIBR.updatedOn());
        this.askValue = normalIBR.exchange().rate().askValue();
        this.bidValue = normalIBR.exchange().rate().bidValue();
    }

    private IBRCreatedEvent(final BankWiseIBR bankWiseIBR) {
        super(Type.IBR_BANK_WISE, bankWiseIBR.instruments().serviceProvider(), bankWiseIBR.instruments().product(),
                bankWiseIBR.exchange().currency().source(), bankWiseIBR.exchange().currency().target(),
                bankWiseIBR.isEnabled(), bankWiseIBR.updatedOn());
        this.askValue = bankWiseIBR.exchange().rate().askValue();
        this.bidValue = bankWiseIBR.exchange().rate().bidValue();
        this.agentCode = bankWiseIBR.agent();
        this.bankCode = bankWiseIBR.bank();
    }

    public static IBRCreatedEvent of(final NormalIBR normalIBR) {
        return new IBRCreatedEvent(normalIBR);
    }

    public static IBRCreatedEvent of(final BankWiseIBR bankWiseIBR) {
        return new IBRCreatedEvent(bankWiseIBR);
    }
}
