package com.unimoni.pricingengine.adapter.persistence.repository.bp;


import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.bp.BranchProcess;

public interface BranchProcessRepository extends JpaRepository<BranchProcess, Long>,BranchProcessJPA {

}
