package com.unimoni.pricingengine.application.service.onboarding.model;

import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;

import lombok.Getter;

@Getter
public class BranchRateSetting {

    private RateDisplayMachenism rateDisplayMachenism;

    private Precision precision;

    private BranchRateSetting(final String rateDisplayMachenism, final String precisionType, final int precisionValue) {
        if (rateDisplayMachenism.equals("BASE_CURRENCY_TO_FOREIGN_CURRENCY")) {
            this.rateDisplayMachenism = RateDisplayMachenism.BC_TO_FC;
        }
        else if (rateDisplayMachenism.equals("FOREIGN_CURRENCY_TO_BASE_CURRENCY")) {
            this.rateDisplayMachenism = RateDisplayMachenism.FC_TO_BC;
        }
        else {
            throw new IllegalArgumentException(
                    "Invalid value from onboarding API > rateDisplayMachenism: " + rateDisplayMachenism);
        }

        this.precision = Precision.of(precisionValue, Precision.Type.valueOf(precisionType));
    }

    public static BranchRateSetting of(final String rateDisplayMachenism, final String precisionType,
            final int precisionValue) {
        return new BranchRateSetting(rateDisplayMachenism, precisionType, precisionValue);
    }
}
