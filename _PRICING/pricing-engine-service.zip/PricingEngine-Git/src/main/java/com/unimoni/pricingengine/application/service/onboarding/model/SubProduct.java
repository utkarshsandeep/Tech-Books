package com.unimoni.pricingengine.application.service.onboarding.model;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.unimoni.pricingengine.domain.model.common.dto.CodeNamePair;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor(staticName = "of")
@EqualsAndHashCode(of = { "code" })
@ToString
@ApiModel(value = "subProduct", description = "Sub Product with Service Types list")
public class SubProduct implements PairItem<String, String> {

    @ApiModelProperty(name = "code", dataType = "String", value = "Sub Product Code", example = "Account Credit")
    private String code;

    private List<ServiceType> serviceTypes;

    @Override
    public int compareTo(final PairItem<String, String> other) {
        return this.code.compareTo(other.pair().getCode());
    }

    @Override
    public CodeNamePair<String, String> pair() {
        return CodeNamePair.of(this.code, this.code);
    }

    public static List<SubProduct> of(final Map<String, Set<String>> subProductsData) {
        return subProductsData != null && !subProductsData.isEmpty()
                ? subProductsData.entrySet().stream().filter(e -> e.getKey() != null && !e.getKey().isEmpty())
                        .map(e -> SubProduct.of(e.getKey(), ServiceType.of(e.getValue()))).collect(Collectors.toList())
                : Collections.emptyList();
    }
}
