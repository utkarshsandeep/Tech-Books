package com.unimoni.pricingengine.common.util.download;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.beans.Bean;
import org.joda.beans.MetaProperty;
import org.joda.convert.StringConvert;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.supercsv.io.CsvListWriter;
import org.supercsv.io.ICsvListWriter;
import org.supercsv.prefs.CsvPreference;

import com.unimoni.pricingengine.common.exception.RateException;
import com.unimoni.pricingengine.common.exception.RateException.RateExceptionExceptionType;
import com.unimoni.pricingengine.common.util.Counter;
import com.unimoni.pricingengine.common.util.download.jodaBeans.Beans;
import com.unimoni.pricingengine.domain.model.common.dto.PageParameterizable;

import lombok.Cleanup;

@Component
public class FileDownloadHelper {

    private static StringConvert jodaConverter;

    private static final String HEADER_CONTENT_DISPOSITION = "Content-Disposition";

    private static final String HEADER_FILE_NAME = "attachment; fileName=";

    @Autowired
    public void setJodaConverter(final StringConvert jodaConverter) {
        FileDownloadHelper.jodaConverter = jodaConverter;
    }
    
    /**
     * Download All the data matching search filters, page by page
     * @param searchRequest
     * @param searchFunction
     * @param downloadFileType
     * @param fileName
     * @param downloadContext
     * @param response
     */
    public static <T extends PageParameterizable, R extends Bean> void downloadFile(final T searchRequest,
            final Function<T, List<R>> searchFunction, final DownloadFileType downloadFileType, final String fileName,
            final DownloadContext downloadContext, final HttpServletResponse response) {
        try {
            if (downloadFileType == DownloadFileType.CSV) {
                downloadAsCSV(searchRequest, searchFunction, fileName, downloadContext, response);
            }
            else {
                downloadAsExcel(searchRequest, searchFunction, fileName, downloadContext, response);
            }
        }
        catch (IOException e) {
            throw new RateException(RateExceptionExceptionType.DOWNLOAD_FILE_INTERNAL_EXCEPTION);
        }
    }

    private static <T extends PageParameterizable, R extends Bean> void downloadAsCSV(final T searchRequest,
            final Function<T, List<R>> searchFunction, final String fileName, final DownloadContext downloadContext,
            final HttpServletResponse response) throws IOException {
        List<R> firstDataSet = searchFunction.apply(searchRequest);
        if (firstDataSet.isEmpty()) {
            throw new RateException(RateExceptionExceptionType.DOWNLOAD_FILE_NO_RECORDS_FOUND_EXCEPTION);
        }

        DownloadMetaData downloadMetaData = DownloadMetaData.of(firstDataSet.get(0), downloadContext);

        response.setContentType(Encode.forJava(DownloadFileType.CSV.contentType()));
        String downloadFileName = (fileName != null ? fileName : downloadContext.defaultFileName()) + "."
                + DownloadFileType.CSV.extension();
        response.setHeader(HEADER_CONTENT_DISPOSITION, HEADER_FILE_NAME + Encode.forJava(downloadFileName));
        @Cleanup
        ICsvListWriter csvWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        csvWriter.writeHeader(downloadMetaData.header());
        writeDataSetToCSV(csvWriter, firstDataSet, downloadMetaData);
        while (searchRequest.moveToNextPage()) {
            writeDataSetToCSV(csvWriter, searchFunction.apply(searchRequest), downloadMetaData);
        }
    }

    private static void writeDataSetToCSV(final ICsvListWriter csvWriter, final List<? extends Bean> dataSet,
            final DownloadMetaData downloadMetaData) throws IOException {
        for (Bean record : dataSet) {
            List<String> rowData = rowData(record, downloadMetaData);
            // System.out.println(rowData);
            csvWriter.write(rowData); // Write one row to CSV at a time
        }
    }

    private static <T extends PageParameterizable, R extends Bean> void downloadAsExcel(final T searchRequest,
            final Function<T, List<R>> searchFunction, final String fileName, final DownloadContext downloadContext,
            final HttpServletResponse response) throws IOException {
        List<R> firstDataSet = searchFunction.apply(searchRequest);
        if (firstDataSet.isEmpty()) {
            throw new RateException(RateExceptionExceptionType.DOWNLOAD_FILE_NO_RECORDS_FOUND_EXCEPTION);
        }

        DownloadMetaData downloadMetaData = DownloadMetaData.of(firstDataSet.get(0), downloadContext);

        response.setContentType(Encode.forJava(DownloadFileType.EXCEL.contentType()));
        String downloadFileName = (fileName != null ? fileName : downloadContext.defaultFileName()) + "."
                + DownloadFileType.EXCEL.extension();
        response.setHeader(HEADER_CONTENT_DISPOSITION, HEADER_FILE_NAME + Encode.forJava(downloadFileName));

        @Cleanup
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();

        @Cleanup
        ServletOutputStream servletOutputStream = response.getOutputStream();

        @Cleanup
        Workbook workbook = new SXSSFWorkbook();

        SXSSFSheet sheet = (SXSSFSheet)workbook.createSheet("Rates");

        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        Counter counter = Counter.initialize("bean-counter");

        Row headerRow = sheet.createRow(counter.get());
        for (int col = 0; col < downloadMetaData.columnCount(); col++) {
            Cell cell = headerRow.createCell(col);
            cell.setCellValue(downloadMetaData.header()[col] == null ? "" : downloadMetaData.header()[col]);
            cell.setCellStyle(headerCellStyle);
        }

        writeDataSetToExcel(counter, workbook, sheet, firstDataSet, downloadMetaData);
        while (searchRequest.moveToNextPage()) {
            writeDataSetToExcel(counter, workbook, sheet, searchFunction.apply(searchRequest), downloadMetaData);
        }
        /*for (int col = 0; col < downloadMetaData.columnCount(); col++) {
            sheet.autoSizeColumn(col);
        }*/

        workbook.write(outStream);
        outStream.writeTo(servletOutputStream);
        servletOutputStream.flush();
    }

    private static void writeDataSetToExcel(final Counter counter, final Workbook workbook, final Sheet sheet,
            final List<? extends Bean> dataSet, final DownloadMetaData downloadMetaData) throws IOException {
        for (Bean record : dataSet) {
            List<String> rowData = rowData(record, downloadMetaData);
            Row row = sheet.createRow(counter.incrementAndGet());
            int colIdx = 0;
            for (String columnValue : rowData) {
                row.createCell(colIdx++).setCellValue(columnValue);
            }
        }
    }

    private static List<String> rowData(final Bean rootBean, final DownloadMetaData downloadMetaData) {
        Beans beans = Beans.of(rootBean);
        List<String> rowData = new ArrayList<>(downloadMetaData.columnCount());
        columnData(beans, rootBean, Counter.initialize("bean-counter"), downloadMetaData, rowData);
        return rowData;
    }

    private static void columnData(final Beans beans, final Bean bean, final Counter counter,
            final DownloadMetaData downloadMetaData, final List<String> rowData) {
        Iterator<MetaProperty<?>> itr = bean.metaBean().metaPropertyIterable().iterator();
        while (itr.hasNext()) {
            MetaProperty<?> prop = itr.next();
            if (beans.isBean(prop)) {
                columnData(beans, beans.nextBean(prop.propertyType().getName()).get(), counter, downloadMetaData,
                        rowData);
            }
            else if (prop.propertyType().isAssignableFrom(Map.class)) {
                Map<?, ?> mapAttribute = (Map<?, ?>) prop.get(beans.bean(prop.declaringType().getName()).get());
                mapAttribute.entrySet().forEach(e -> {
                    columnData(beans, beans.nextBean(e.getValue().getClass().getName()).get(), counter,
                            downloadMetaData, rowData);
                });
            }
            else if (downloadMetaData.isDownloadable(counter.get())) {
                String fieldValue = prop.getString(bean, jodaConverter);
                rowData.add(fieldValue == null ? "" : fieldValue);
                counter.increment();
            } else {
                counter.increment();
            }
        }
    }
    
    /**
     * Download the provided data set in one go
     * @param data
     * @param downloadFileType
     * @param fileName
     * @param downloadContext
     * @param response
     */
    public static <R extends Bean> void downloadFile(
            final List<R> data, final DownloadFileType downloadFileType, final String fileName,
            final DownloadContext downloadContext, final HttpServletResponse response) {
        try {
            if (downloadFileType == DownloadFileType.CSV) {
                downloadAsCSV(data, fileName, downloadContext, response);
            }
            else {
                downloadAsExcel(data, fileName, downloadContext, response);
            }
        }
        catch (IOException e) {
            throw new RateException(RateExceptionExceptionType.DOWNLOAD_FILE_INTERNAL_EXCEPTION);
        }
    }
    

    private static <R extends Bean> void downloadAsCSV(
            final List<R> data, final String fileName, final DownloadContext downloadContext,
            final HttpServletResponse response) throws IOException {
        if (data.isEmpty()) {
            throw new RateException(RateExceptionExceptionType.DOWNLOAD_FILE_NO_RECORDS_FOUND_EXCEPTION);
        }

        DownloadMetaData downloadMetaData = DownloadMetaData.of(data.get(0), downloadContext);

        response.setContentType(Encode.forJava(DownloadFileType.CSV.contentType()));
        String downloadFileName = (fileName != null ? fileName : downloadContext.defaultFileName()) + "."
                + DownloadFileType.CSV.extension();
        response.setHeader(HEADER_CONTENT_DISPOSITION, HEADER_FILE_NAME + Encode.forJava(downloadFileName));
        @Cleanup
        ICsvListWriter csvWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        csvWriter.writeHeader(downloadMetaData.header());
        writeDataSetToCSV(csvWriter, data, downloadMetaData);
    }

    private static <R extends Bean> void downloadAsExcel(
            final List<R> data, final String fileName, final DownloadContext downloadContext,
            final HttpServletResponse response) throws IOException {
        if (data.isEmpty()) {
            throw new RateException(RateExceptionExceptionType.DOWNLOAD_FILE_NO_RECORDS_FOUND_EXCEPTION);
        }

        DownloadMetaData downloadMetaData = DownloadMetaData.of(data.get(0), downloadContext);

        response.setContentType(Encode.forJava(DownloadFileType.EXCEL.contentType()));
        String downloadFileName = (fileName != null ? fileName : downloadContext.defaultFileName()) + "."
                + DownloadFileType.EXCEL.extension();
        response.setHeader(HEADER_CONTENT_DISPOSITION, HEADER_FILE_NAME + Encode.forJava(downloadFileName));

        @Cleanup
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();

        @Cleanup
        ServletOutputStream servletOutputStream = response.getOutputStream();

        @Cleanup
        Workbook workbook = new XSSFWorkbook();

        Sheet sheet = workbook.createSheet("Rates");

        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        Counter counter = Counter.initialize("bean-counter");

        Row headerRow = sheet.createRow(counter.get());
        for (int col = 0; col < downloadMetaData.columnCount(); col++) {
            Cell cell = headerRow.createCell(col);
            cell.setCellValue(downloadMetaData.header()[col]);
            cell.setCellStyle(headerCellStyle);
        }

        writeDataSetToExcel(counter, workbook, sheet, data, downloadMetaData);
        for (int col = 0; col < downloadMetaData.columnCount(); col++) {
            sheet.autoSizeColumn(col);
        }

        workbook.write(outStream);
        outStream.writeTo(servletOutputStream);
        servletOutputStream.flush();
    }
}
