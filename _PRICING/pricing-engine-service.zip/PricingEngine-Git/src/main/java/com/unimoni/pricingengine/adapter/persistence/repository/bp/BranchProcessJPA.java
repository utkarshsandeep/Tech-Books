package com.unimoni.pricingengine.adapter.persistence.repository.bp;

import java.util.EnumSet;
import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.bp.BranchProcess;
import com.unimoni.pricingengine.domain.model.bp.StatusType;
import com.unimoni.pricingengine.domain.model.common.dto.PaginationData;

public interface BranchProcessJPA extends JPA{
	public List<BranchProcess> findBranchProcessByDealId(String deal);
	
	public List<BranchProcess> findAll(PaginationData page);
	
	public BranchProcess findByDealIdAndStatus(String dealId , StatusType status);
	
	public List<BranchProcess> findByStatus(StatusType status);
	
	public List<BranchProcess> findByStatusEnumSet(EnumSet<StatusType> status);
	
    public Optional<BranchProcess> findBranchProcessByBranchProcessId(String bpId);

}
