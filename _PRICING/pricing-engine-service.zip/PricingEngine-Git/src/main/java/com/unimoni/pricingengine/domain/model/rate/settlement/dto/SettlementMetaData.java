package com.unimoni.pricingengine.domain.model.rate.settlement.dto;

import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public class SettlementMetaData {

    private int missingVaRsCount;

    private List<SettlementBasicIdentity> missingVaRs;

    private int duplicateSettlementsCount;

    private List<SettlementIdentity> duplicateSettlements;

    private int newSettlementsCount;

    private List<SettlementRateResponse> newSettlements;

    public static SettlementMetaData of(final List<SettlementBasicIdentity> missingVaRs,
            final List<SettlementIdentity> duplicateSettlements,
            final List<SettlementRateResponse> newSettlements) {
        SettlementMetaData settlementMetaData = new SettlementMetaData();
        settlementMetaData.missingVaRs = missingVaRs;
        settlementMetaData.missingVaRsCount = missingVaRs != null ? missingVaRs.size() : 0;
        settlementMetaData.duplicateSettlements = duplicateSettlements;
        settlementMetaData.duplicateSettlementsCount = duplicateSettlements != null ? duplicateSettlements.size() : 0;
        settlementMetaData.newSettlements = newSettlements;
        settlementMetaData.newSettlementsCount = newSettlements != null ? newSettlements.size() : 0;
        return settlementMetaData;
    }
}
