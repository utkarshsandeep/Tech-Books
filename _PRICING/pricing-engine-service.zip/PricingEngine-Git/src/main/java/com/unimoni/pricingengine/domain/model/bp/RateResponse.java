package com.unimoni.pricingengine.domain.model.bp;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class RateResponse {
	private Integer dealId;
	private BigDecimal IBRRate;
	private BigDecimal CountryCost;
	private BigDecimal AgentCost;

}