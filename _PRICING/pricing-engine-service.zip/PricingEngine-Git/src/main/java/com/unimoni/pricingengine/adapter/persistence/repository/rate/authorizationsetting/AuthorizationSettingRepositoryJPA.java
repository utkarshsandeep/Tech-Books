package com.unimoni.pricingengine.adapter.persistence.repository.rate.authorizationsetting;

import java.util.List;
import java.util.Optional;

import com.unimoni.pricingengine.adapter.persistence.JPA;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.AuthorizationSetting;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationRateSettingRequest;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingIdentity;
import com.unimoni.pricingengine.domain.model.rate.authorizationsetting.dto.AuthorizationSettingSearchRequest;

public interface AuthorizationSettingRepositoryJPA extends JPA {

    public List<AuthorizationSetting> findAllAuthorizationSettings(
            final AuthorizationSettingSearchRequest searchRequest);

    public Optional<AuthorizationSetting> findActiveAuthorizationByIdentity(AuthorizationSettingIdentity identity);

    public List<AuthorizationSetting> findAuthorizationSettingsByIds(List<String> ids, boolean status);

    public List<AuthorizationSetting> getRateSettingsForLayer(AuthorizationRateSettingRequest request);

}
