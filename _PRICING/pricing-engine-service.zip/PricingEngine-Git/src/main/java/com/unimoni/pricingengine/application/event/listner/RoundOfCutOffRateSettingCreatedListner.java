package com.unimoni.pricingengine.application.event.listner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.money.CurrencyUnit;
import javax.money.Monetary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.unimoni.pricingengine.adapter.rest.controller.events.AgentOnBoard;
import com.unimoni.pricingengine.application.events.RoundOffCutOffRateSettingCreatedEvent;
import com.unimoni.pricingengine.application.service.onboarding.model.MasterData;
import com.unimoni.pricingengine.common.annotation.spring.OnboardingIntegration;
import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateMetaData;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.AgentRateRequest;
import com.unimoni.pricingengine.domain.model.rate.agent.dto.CreateAgentRateRequest;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentBranchInfoResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentCurrencyCode;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentCurrencyResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardCurrencies;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentOnboardResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.AgentUpdateDeleteRequest;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.country.AgentItem;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateMetaData;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryRateRequest;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CreateCountryRateRequest;
import com.unimoni.pricingengine.domain.service.agent.AgentRateService;
import com.unimoni.pricingengine.domain.service.country.CountryRateService;

import lombok.extern.slf4j.Slf4j;

@Conditional(value = OnboardingIntegration.class)
@Component
@Slf4j
public class RoundOfCutOffRateSettingCreatedListner {

    @Autowired
    private Gson gson;

    @Autowired
    private MasterData masterData;

    @Autowired
    private AgentOnBoard agentOnBoard;

    @Autowired
    private AgentRateService agentRateService;

    @Autowired
    private CountryRateService countryRateService;

    private List<String> serviceProviders = new ArrayList<String>();

    private List<String> products = new ArrayList<String>();

    private List<String> serviceTypes = new ArrayList<String>();

    private List<String> subProductMasterList = new ArrayList<String>();

    @JmsListener(destination = "ROUND_OFF_CUT_OFF_RATE_SETTING_CREATED", containerFactory = "topicListenerFactory")
    public void onApplicationEvent(final Message jsonMessage) {

        log.info("******ROUND_OFF_CUT_OFF_RATE_SETTING_CREATED*******" + jsonMessage);
        TextMessage textMessage = (TextMessage) jsonMessage;
        String payload;
        try {
            payload = textMessage.getText();
        }
        catch (JMSException e1) {
            e1.printStackTrace();
            return;
        }
        log.info("****EVENT_PAYLOAD*****", payload);
        Integer agentId = null;
        Integer agentBranchId = null;
        Integer roundOffCutOffRateSettingId = null;

        RoundOffCutOffRateSettingCreatedEvent roundOffCutOffRateSettingCreatedEvent;

        roundOffCutOffRateSettingCreatedEvent = gson.fromJson(payload, RoundOffCutOffRateSettingCreatedEvent.class);

        agentId = (int) (long) roundOffCutOffRateSettingCreatedEvent.getAgentId();

        agentBranchId = (int) (long) roundOffCutOffRateSettingCreatedEvent.getAgentBranchId();

        roundOffCutOffRateSettingId = (int) (long) roundOffCutOffRateSettingCreatedEvent
                .getRoundOffCutOffRateSettingId();

        log.info("*****AgentId*****" + agentId);
        log.info("*****agentBranchId******" + agentBranchId);
        log.info("*****roundOffCutOffRateSettingId******" + roundOffCutOffRateSettingId);
        String agentDisplayCode = getAgentDisplayCode(agentId, agentBranchId);
        log.info("*****agentDisplayCode*****" + agentDisplayCode);

        List<Integer> listagentBranchId = new ArrayList<Integer>();

        listagentBranchId.add(agentBranchId);

        List<String> listOfBaseCurrencies = getListOfAgentBaseCurrencies(agentId, listagentBranchId);

        log.info("*****List of BaseCurrencies ******" + listOfBaseCurrencies);

        List<String> listOfForeginCurrency = masterData.getNormalForeignCurrencyPairs(serviceProviders, false).stream()
                .map(item -> item.getCode()).distinct().collect(Collectors.toList());
        log.info("******List of ForeginCurrency******" + listOfForeginCurrency);

        // Adding base currencies into foreign currencies
        Set<String> foreginAndBaseCurrencySet = new HashSet<>();
        foreginAndBaseCurrencySet.addAll(listOfForeginCurrency);
        foreginAndBaseCurrencySet.addAll(listOfBaseCurrencies);

        List<String> foreginAndBaseCurrencyList = new ArrayList<>();
        foreginAndBaseCurrencyList.addAll(foreginAndBaseCurrencySet);

        log.info("******List of ForeginCurrency and BaseCurrency*******" + foreginAndBaseCurrencyList);

        if (listOfBaseCurrencies.size() > 0) {
            log.info("***** createRecordForNormalCountry*******");
            createRecordForNormalCountry(agentId, listOfForeginCurrency, listOfBaseCurrencies, listagentBranchId,
                    foreginAndBaseCurrencyList, agentDisplayCode);
            log.info("*****createRecordForNormalAgent******");
            createRecordForNormalAgent(agentId, listOfForeginCurrency, listOfBaseCurrencies, listagentBranchId,
                    foreginAndBaseCurrencyList, agentDisplayCode);
        }
    }

    private void createRecordForNormalAgent(Integer agentId, List<String> listOfCurrencies,
            List<String> listOfBaseCurrencies, List<Integer> listagentBranchId, List<String> listOfForeginCurrency,
            String agentDisplayCode) {

        log.info("****Inside createRecordForNormalAgent method*****");

        AgentRateRequest agentRateRequest = createAgentRateMetaRequest(agentId, listOfCurrencies, listOfBaseCurrencies,
                listagentBranchId, listOfForeginCurrency, agentDisplayCode);

        log.info("******Agent Rate MetaRequest*******" + agentRateRequest);
        List<CreateAgentRateRequest> createRequests = null;

        AgentRateMetaData agentRateMetaData = agentRateService.createAgentRateMetaData(RMType.NORMAL, agentRateRequest);
        log.info("******AgentRateMetaData*****" + agentRateMetaData);

        if (agentRateMetaData.getNewAgentRatesCount() > 0) {
            createRequests = new ArrayList<CreateAgentRateRequest>();
            for (int i = 0; i < agentRateMetaData.getNewAgentRatesCount(); i++) {
                CreateAgentRateRequest createAgentRateRequest = new CreateAgentRateRequest();
                createAgentRateRequest.setCurrency(agentRateMetaData.getNewAgentRates().get(i).getCurrency());
                createAgentRateRequest.setCountryRateId(agentRateMetaData.getNewAgentRates().get(i).getCountryRateId());

                createAgentRateRequest
                        .setValueDateWises(agentRateMetaData.getNewAgentRates().get(i).getValueDateWises());
                createAgentRateRequest.setAgent(agentRateMetaData.getNewAgentRates().get(i).getAgent());
                createAgentRateRequest.setInstruments(agentRateMetaData.getNewAgentRates().get(i).getInstruments());

                createRequests.add(createAgentRateRequest);
            }
        }
        if (createRequests != null && createRequests.size() > 0) {
            log.info("*******Method call for createAgentRates**********");
            agentRateService.createAgentRates(RMType.NORMAL, createRequests);
        }

    }

    private AgentRateRequest createAgentRateMetaRequest(Integer agentId, List<String> listOfCurrencies,
            List<String> listOfBaseCurrencies, List<Integer> listagentBranchId, List<String> listOfForeginCurrency,
            String agentDisplayCode) {
        // String agentDisplayCode = agentDisplayCode(agentId);
        // List<String> serviceProviders = new ArrayList<String>();
        // List<String> products = new ArrayList<String>();
        List<String> subProducts = new ArrayList<String>();
        // List<String> serviceTypes = new ArrayList<String>();
        List<AgentDetails> listOfAgents = new ArrayList<AgentDetails>();
        // serviceProviders.add(ApplicationConstants.ALL_INSTRUMENTS);
        // products.add(ApplicationConstants.ALL_INSTRUMENTS);
        subProducts.add(ApplicationConstants.ALL_INSTRUMENTS);
        // serviceTypes.add(ApplicationConstants.ALL_INSTRUMENTS);
        serviceTypes.clear();
        serviceTypes.addAll(masterData.getAllServiceTypes(products, subProductMasterList).stream()
                .map(item -> item.getCode()).distinct().collect(Collectors.toList()));
        if (serviceTypes.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            serviceTypes.remove(ApplicationConstants.ALL_INSTRUMENTS);
        }
        AgentRateRequest agentRateRequest = new AgentRateRequest();

        for (int k = 0; k < listagentBranchId.size(); k++) {
            Integer branchId = Integer.valueOf(listagentBranchId.get(k));
            AgentUpdateDeleteRequest agentUpdateDeleteRequest = agentOnBoard.getAgentRateDisplay(agentId, branchId);
            AgentBranchInfoResponse agentBranchInfo = agentOnBoard.getAgentBranchInfo(branchId);
            RateDisplayMachenism rmd = null;
            if ("FOREIGN_CURRENCY_TO_BASE_CURRENCY".equals(agentUpdateDeleteRequest.getRateDisplayMechanism())) {
                rmd = RateDisplayMachenism.FC_TO_BC;
            }
            else if ("BASE_CURRENCY_TO_FOREIGN_CURRENCY".equals(agentUpdateDeleteRequest.getRateDisplayMechanism())) {
                rmd = RateDisplayMachenism.BC_TO_FC;
            }

            AgentDetails agent = AgentDetails.of(agentBranchInfo.branchDisplayName, rmd, AgentItem.Type.BRANCH);
            listOfAgents.add(agent);

        }
        List<CurrencyUnit> baseCurrencies = new ArrayList<CurrencyUnit>();
        for (int i = 0; i < listOfBaseCurrencies.size(); i++) {
            CurrencyUnit currency = Monetary.getCurrency(listOfBaseCurrencies.get(i));
            baseCurrencies.add(currency);
        }
        List<CurrencyUnit> foreignCurrencies = new ArrayList<CurrencyUnit>();
        for (int i = 0; i < listOfForeginCurrency.size(); i++) {
            CurrencyUnit currency = Monetary.getCurrency(listOfForeginCurrency.get(i));
            foreignCurrencies.add(currency);
        }

        agentRateRequest.setProducts(products);
        agentRateRequest.setSubProducts(subProducts);
        agentRateRequest.setServiceProviders(serviceProviders);
        agentRateRequest.setServiceTypes(serviceTypes);
        agentRateRequest.setBaseCurrencies(baseCurrencies);
        agentRateRequest.setForeignCurrencies(foreignCurrencies);
        agentRateRequest.setAgents(listOfAgents);
        return agentRateRequest;
    }

    private void createRecordForNormalCountry(Integer agentId, List<String> listOfCurrencies,
            List<String> listOfBaseCurrencies, List<Integer> listagentBranchId, List<String> listOfForeginCurrency,
            String agentDisplayCode) {

        CountryRateRequest countryRateRequest = createCountryRateMetaRequest(agentId, listOfCurrencies,
                listOfBaseCurrencies, listagentBranchId, listOfForeginCurrency, agentDisplayCode);

        log.info("*******countryRateRequest********" + countryRateRequest);

        CountryRateMetaData countryRateMetaData = countryRateService.createCountryRateMetaData(RMType.NORMAL,
                countryRateRequest);

        List<CreateCountryRateRequest> createRequests = null;

        if (countryRateMetaData.getNewCountryRatesCount() > 0) {
            createRequests = new ArrayList<CreateCountryRateRequest>();
            for (int i = 0; i < countryRateMetaData.getNewCountryRatesCount(); i++) {
                CreateCountryRateRequest createCountryRateRequest = new CreateCountryRateRequest();
                // Map<VDWType, CountryRateValueDateWiseDTO> valueDateWises = new
                // HashMap<VDWType,
                // CountryRateValueDateWiseDTO>();
                createCountryRateRequest
                        .setInstruments(countryRateMetaData.getNewCountryRates().get(i).getInstruments());
                createCountryRateRequest.setCurrency(countryRateMetaData.getNewCountryRates().get(i).getCurrency());
                createCountryRateRequest
                        .setBaseSettlementId(countryRateMetaData.getNewCountryRates().get(i).getBaseSettlementId());
                createCountryRateRequest.setForeignSettlementId(
                        countryRateMetaData.getNewCountryRates().get(i).getForeignSettlementId());
                createCountryRateRequest
                        .setValueDateWises(countryRateMetaData.getNewCountryRates().get(i).getValueDateWises());
                createCountryRateRequest.setAgent(countryRateMetaData.getNewCountryRates().get(i).getAgent());

                createRequests.add(createCountryRateRequest);
            }
        }

        if (createRequests != null && createRequests.size() > 0) {
            log.info("******Method call for createCountryRates*******");
            countryRateService.createCountryRates(RMType.NORMAL, createRequests);
        }

    }

    private CountryRateRequest createCountryRateMetaRequest(Integer agentId, List<String> listOfCurrencies,
            List<String> listOfBaseCurrencies, List<Integer> listOfBranchesForAgent, List<String> listOfForeginCurrency,
            String agentDisplayCode) {
        log.info("*****Inside createCountryRateMetaRequest******");
        // String agentDisplayCode = agentDisplayCode(agentId);
        CountryRateRequest countryRateRequest = new CountryRateRequest();
        List<String> subProducts = new ArrayList<String>();
        // List<String> serviceTypes = new ArrayList<String>();
        List<AgentDetails> listOfAgents = new ArrayList<AgentDetails>();
        // serviceProviders.add(ApplicationConstants.ALL_INSTRUMENTS);
        // products.add(ApplicationConstants.ALL_INSTRUMENTS);
        subProducts.add(ApplicationConstants.ALL_INSTRUMENTS);
        // serviceTypes.add(ApplicationConstants.ALL_INSTRUMENTS);
        serviceTypes.clear();
        serviceTypes.addAll(masterData.getAllServiceTypes(products, subProductMasterList).stream()
                .map(item -> item.getCode()).distinct().collect(Collectors.toList()));
        if (serviceTypes.contains(ApplicationConstants.ALL_INSTRUMENTS)) {
            serviceTypes.remove(ApplicationConstants.ALL_INSTRUMENTS);
        }

        for (int k = 0; k < listOfBranchesForAgent.size(); k++) {
            Integer branchId = Integer.valueOf(listOfBranchesForAgent.get(k));
            AgentUpdateDeleteRequest agentUpdateDeleteRequest = agentOnBoard.getAgentRateDisplay(agentId, branchId);
            RateDisplayMachenism rmd = null;
            log.info("Rate Display Mechanism " + agentUpdateDeleteRequest.getRateDisplayMechanism());
            if ("FOREIGN_CURRENCY_TO_BASE_CURRENCY".equals(agentUpdateDeleteRequest.getRateDisplayMechanism())) {
                rmd = RateDisplayMachenism.FC_TO_BC;
            }
            else if ("BASE_CURRENCY_TO_FOREIGN_CURRENCY".equals(agentUpdateDeleteRequest.getRateDisplayMechanism())) {
                rmd = RateDisplayMachenism.BC_TO_FC;
            }
            AgentDetails agent = AgentDetails.of(agentDisplayCode, rmd, AgentItem.Type.AGENT);
            listOfAgents.add(agent);
        }
        List<CurrencyUnit> baseCurrencies = new ArrayList<CurrencyUnit>();
        for (int i = 0; i < listOfBaseCurrencies.size(); i++) {
            CurrencyUnit currency = Monetary.getCurrency(listOfBaseCurrencies.get(i));
            baseCurrencies.add(currency);
        }
        List<CurrencyUnit> foreignCurrencies = new ArrayList<CurrencyUnit>();
        for (int i = 0; i < listOfForeginCurrency.size(); i++) {
            if (!"ZRP".equalsIgnoreCase(listOfForeginCurrency.get(i))) {
                CurrencyUnit currency = Monetary.getCurrency(listOfForeginCurrency.get(i));
                foreignCurrencies.add(currency);
            }
        }

        countryRateRequest.setProducts(products);
        countryRateRequest.setSubProducts(subProducts);
        countryRateRequest.setServiceProviders(serviceProviders);
        countryRateRequest.setServiceTypes(serviceTypes);
        countryRateRequest.setBaseCurrencies(baseCurrencies);
        countryRateRequest.setForeignCurrencies(foreignCurrencies);
        countryRateRequest.setAgents(listOfAgents);

        return countryRateRequest;
    }

    private List<String> getListOfAgentBaseCurrencies(Integer agentId, List<Integer> listOfBranchesForAgent) {
        List<String> listOfBaseCurrencies = new ArrayList<String>();

        List<ArrayList<AgentOnboardCurrencies>> listOfAgentBaseCurrencies = new ArrayList<ArrayList<AgentOnboardCurrencies>>();
        List<AgentCurrencyResponse> listOfAgentBaseCurrencyResponse = new ArrayList<AgentCurrencyResponse>();
        List<AgentCurrencyCode> listOfCurrencyCodes = new ArrayList<AgentCurrencyCode>();
        AgentCurrencyResponse agentCurrencyResponse = new AgentCurrencyResponse();

        for (Integer branchId : listOfBranchesForAgent) {
            agentCurrencyResponse = agentOnBoard.getAgentBaseCurrencies(agentId, branchId);
            listOfAgentBaseCurrencyResponse.add(agentCurrencyResponse);
        }

        for (int i = 0; i < listOfAgentBaseCurrencyResponse.size(); i++) {
            listOfAgentBaseCurrencies
                    .add((ArrayList<AgentOnboardCurrencies>) listOfAgentBaseCurrencyResponse.get(i).getData());
        }

        for (int i = 0; i < listOfAgentBaseCurrencies.size(); i++) {
            List<AgentOnboardCurrencies> listOfAgentCurrencies = listOfAgentBaseCurrencies.get(i);

            for (int j = 0; j < listOfAgentCurrencies.size(); j++) {
                ArrayList<AgentCurrencyCode> tempList = (ArrayList<AgentCurrencyCode>) listOfAgentCurrencies.get(j)
                        .getCurrencyCodes();
                listOfCurrencyCodes.addAll(tempList);
                tempList.clear();
                if (!serviceProviders.contains(listOfAgentCurrencies.get(i).getServiceProviderCode())) {
                    serviceProviders.add(listOfAgentCurrencies.get(i).getServiceProviderCode());
                }
                if (!products.contains(listOfAgentCurrencies.get(i).getProductType())) {
                    products.add(listOfAgentCurrencies.get(i).getProductType());
                }
                /*
                 * if (!serviceTypes.contains(listOfAgentCurrencies.get(i).getServiceType())) {
                 * serviceTypes.add(listOfAgentCurrencies.get(i).getServiceType()); }
                 */

                if (!subProductMasterList.contains(listOfAgentCurrencies.get(i).getSubProductType())) {
                    subProductMasterList.add(listOfAgentCurrencies.get(i).getSubProductType());
                }
            }
        }

        for (AgentCurrencyCode currencyCodes : listOfCurrencyCodes) {
            if (!listOfBaseCurrencies.contains(currencyCodes.getCode())
                    && "string".equals(currencyCodes.getCode()) != true) {
                listOfBaseCurrencies.add(currencyCodes.getCode());
            }
        }

        return listOfBaseCurrencies;
    }

    private String getAgentDisplayCode(Integer agentId, Integer agentBranchId) {
        AgentOnboardResponse agentCurrencyResponse = agentOnBoard.agentOnBoard(agentId);
        log.info("******Agent Display Code Response******" + agentCurrencyResponse);
        log.info("******Agent Display Code******" + agentCurrencyResponse.getCode());
        return agentCurrencyResponse.getCode();
    }
}
