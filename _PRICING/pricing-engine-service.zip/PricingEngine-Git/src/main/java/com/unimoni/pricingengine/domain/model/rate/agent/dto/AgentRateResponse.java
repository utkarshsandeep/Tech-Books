package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.joda.beans.Bean;
import org.joda.beans.ImmutableBean;
import org.joda.beans.JodaBeanUtils;
import org.joda.beans.MetaBean;
import org.joda.beans.MetaProperty;
import org.joda.beans.gen.BeanDefinition;
import org.joda.beans.gen.PropertyDefinition;
import org.joda.beans.impl.direct.DirectFieldsBeanBuilder;
import org.joda.beans.impl.direct.DirectMetaBean;
import org.joda.beans.impl.direct.DirectMetaProperty;
import org.joda.beans.impl.direct.DirectMetaPropertyMap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.ImmutableMap;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.common.util.download.DownloadContext;
import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.domain.model.common.dto.ViewModel;
import com.unimoni.pricingengine.domain.model.rate.RMType;
import com.unimoni.pricingengine.domain.model.rate.agent.AgentRate;
import com.unimoni.pricingengine.domain.model.rate.country.AgentDetails;
import com.unimoni.pricingengine.domain.model.rate.country.CountryRate;
import com.unimoni.pricingengine.domain.model.rate.country.dto.CountryCurrencyDTO;
import com.unimoni.pricingengine.domain.model.rate.var.VDWType;
import com.unimoni.pricingengine.domain.model.rate.var.dto.AllInstrumentsDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@BeanDefinition
@ApiModel(value = "countryRate", description = "Agent Rate")
public class AgentRateResponse implements ViewModel<String>, ImmutableBean {

    @Getter
    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "agentRateId", notes = "Record ID")
    private String agentRateId;

    @Getter
    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "countryRateId", notes = "ID of Country Layer linked with this Agent Rate For Base and Foreign Currency")
    private String countryRateId;

    @PropertyDefinition
    @ApiModelProperty(value = "agent", notes = "Agent")
    private final AgentDetails agent;

    @PropertyDefinition
    @Download(columnName = "Bank", contexts = DownloadContext.BANK_WISE_AGENT_RATE)
    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "bank", notes = "Bank")
    private final String bank;

    @Getter
    private RMType rmType;

    @PropertyDefinition
    private final CountryCurrencyDTO currency;

    @PropertyDefinition
    private final AllInstrumentsDTO instruments;

    @PropertyDefinition
    @JsonInclude(NON_EMPTY)
    private final Map<VDWType, AgentValueDateWiseDTO> valueDateWises;

    @PropertyDefinition
    @Download(columnName = "Updated On")
    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "updatedOn", notes = "Last updated timestamp with Timezone")
    private final String updatedOn;

    @PropertyDefinition
    @Download(columnName = "Status")
    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "status", notes = "Enabled or Disabled")
    private final Boolean status;

    @PropertyDefinition
    @Download(columnName = "Reason for change")
    @ApiModelProperty(value = "reason", notes = "Reason for last rate update")
    private final String reason;

    public static AgentRateResponse of(final AgentRate agentRate) {
        return new AgentRateResponse(agentRate.id(), agentRate.countryRate().id(), agentRate.agent().details(),
                agentRate.rmType().isBankWise() ? agentRate.bank().get() : null, agentRate.rmType(),
                CountryCurrencyDTO.of(agentRate.currency()), AllInstrumentsDTO.of(agentRate.instruments()),
                agentRate.valueDateWises().entrySet().stream()
                        .collect(Collectors.toMap(e -> e.getKey(), e -> AgentValueDateWiseDTO.of(e.getValue()),
                                (e1, e2) -> e1, LinkedHashMap::new)),
                DateTimeHelper.convertAndFormatZonedDateTime(agentRate.updatedOn()), agentRate.isEnabled(),
                agentRate.reason());
    }

    public static AgentRateResponse ofMetaData(final RMType rmType, final AgentRateIdentity agentRateIdentity,
            final CountryRate countryRate) {
        Map<VDWType, AgentValueDateWiseDTO> vdws = new LinkedHashMap<>();
        VDWType.all().forEach(vdwType -> {
            vdws.put(vdwType, AgentValueDateWiseDTO.byDefault(countryRate.valueDateWises().get(vdwType).agent(),
                    agentRateIdentity.getAgent().getRateDisplayMechanism()));

        });
        return new AgentRateResponse(null, countryRate.id(), agentRateIdentity.getAgent(),
                rmType.isBankWise() ? agentRateIdentity.getBank().get() : null, rmType, agentRateIdentity.getCurrency(),
                agentRateIdentity.getInstruments(), vdws, null, null, null);
    }

    @Override
    public String id() {
        return this.agentRateId;
    }

  //------------------------- AUTOGENERATED START -------------------------
  /**
   * The meta-bean for {@code AgentRateResponse}.
   * @return the meta-bean, not null
   */
  public static AgentRateResponse.Meta meta() {
    return AgentRateResponse.Meta.INSTANCE;
  }

  static {
    MetaBean.register(AgentRateResponse.Meta.INSTANCE);
  }

  /**
   * Returns a builder used to create an instance of the bean.
   * @return the builder, not null
   */
  public static AgentRateResponse.Builder builder() {
    return new AgentRateResponse.Builder();
  }

  /**
   * Restricted constructor.
   * @param builder  the builder to copy from, not null
   */
  protected AgentRateResponse(AgentRateResponse.Builder builder) {
    this.agent = builder.agent;
    this.bank = builder.bank;
    this.currency = builder.currency;
    this.instruments = builder.instruments;
    this.valueDateWises = (builder.valueDateWises != null ? ImmutableMap.copyOf(builder.valueDateWises) : null);
    this.updatedOn = builder.updatedOn;
    this.status = builder.status;
    this.reason = builder.reason;
  }

  @Override
  public AgentRateResponse.Meta metaBean() {
    return AgentRateResponse.Meta.INSTANCE;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the agent.
   * @return the value of the property
   */
  public AgentDetails getAgent() {
    return agent;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the bank.
   * @return the value of the property
   */
  public String getBank() {
    return bank;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the currency.
   * @return the value of the property
   */
  public CountryCurrencyDTO getCurrency() {
    return currency;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the instruments.
   * @return the value of the property
   */
  public AllInstrumentsDTO getInstruments() {
    return instruments;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the valueDateWises.
   * @return the value of the property
   */
  public Map<VDWType, AgentValueDateWiseDTO> getValueDateWises() {
    return valueDateWises;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the updatedOn.
   * @return the value of the property
   */
  public String getUpdatedOn() {
    return updatedOn;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the status.
   * @return the value of the property
   */
  public Boolean getStatus() {
    return status;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the reason.
   * @return the value of the property
   */
  public String getReason() {
    return reason;
  }

  //-----------------------------------------------------------------------
  /**
   * Returns a builder that allows this bean to be mutated.
   * @return the mutable builder, not null
   */
  public Builder toBuilder() {
    return new Builder(this);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj != null && obj.getClass() == this.getClass()) {
      AgentRateResponse other = (AgentRateResponse) obj;
      return JodaBeanUtils.equal(agent, other.agent) &&
          JodaBeanUtils.equal(bank, other.bank) &&
          JodaBeanUtils.equal(currency, other.currency) &&
          JodaBeanUtils.equal(instruments, other.instruments) &&
          JodaBeanUtils.equal(valueDateWises, other.valueDateWises) &&
          JodaBeanUtils.equal(updatedOn, other.updatedOn) &&
          JodaBeanUtils.equal(status, other.status) &&
          JodaBeanUtils.equal(reason, other.reason);
    }
    return false;
  }

  @Override
  public int hashCode() {
    int hash = getClass().hashCode();
    hash = hash * 31 + JodaBeanUtils.hashCode(agent);
    hash = hash * 31 + JodaBeanUtils.hashCode(bank);
    hash = hash * 31 + JodaBeanUtils.hashCode(currency);
    hash = hash * 31 + JodaBeanUtils.hashCode(instruments);
    hash = hash * 31 + JodaBeanUtils.hashCode(valueDateWises);
    hash = hash * 31 + JodaBeanUtils.hashCode(updatedOn);
    hash = hash * 31 + JodaBeanUtils.hashCode(status);
    hash = hash * 31 + JodaBeanUtils.hashCode(reason);
    return hash;
  }

  @Override
  public String toString() {
    StringBuilder buf = new StringBuilder(288);
    buf.append("AgentRateResponse{");
    int len = buf.length();
    toString(buf);
    if (buf.length() > len) {
      buf.setLength(buf.length() - 2);
    }
    buf.append('}');
    return buf.toString();
  }

  protected void toString(StringBuilder buf) {
    buf.append("agent").append('=').append(JodaBeanUtils.toString(agent)).append(',').append(' ');
    buf.append("bank").append('=').append(JodaBeanUtils.toString(bank)).append(',').append(' ');
    buf.append("currency").append('=').append(JodaBeanUtils.toString(currency)).append(',').append(' ');
    buf.append("instruments").append('=').append(JodaBeanUtils.toString(instruments)).append(',').append(' ');
    buf.append("valueDateWises").append('=').append(JodaBeanUtils.toString(valueDateWises)).append(',').append(' ');
    buf.append("updatedOn").append('=').append(JodaBeanUtils.toString(updatedOn)).append(',').append(' ');
    buf.append("status").append('=').append(JodaBeanUtils.toString(status)).append(',').append(' ');
    buf.append("reason").append('=').append(JodaBeanUtils.toString(reason)).append(',').append(' ');
  }

  //-----------------------------------------------------------------------
  /**
   * The meta-bean for {@code AgentRateResponse}.
   */
  public static class Meta extends DirectMetaBean {
    /**
     * The singleton instance of the meta-bean.
     */
    static final Meta INSTANCE = new Meta();

    /**
     * The meta-property for the {@code agent} property.
     */
    private final MetaProperty<AgentDetails> _agent = DirectMetaProperty.ofImmutable(
        this, "agent", AgentRateResponse.class, AgentDetails.class);
    /**
     * The meta-property for the {@code bank} property.
     */
    private final MetaProperty<String> _bank = DirectMetaProperty.ofImmutable(
        this, "bank", AgentRateResponse.class, String.class);
    /**
     * The meta-property for the {@code currency} property.
     */
    private final MetaProperty<CountryCurrencyDTO> _currency = DirectMetaProperty.ofImmutable(
        this, "currency", AgentRateResponse.class, CountryCurrencyDTO.class);
    /**
     * The meta-property for the {@code instruments} property.
     */
    private final MetaProperty<AllInstrumentsDTO> _instruments = DirectMetaProperty.ofImmutable(
        this, "instruments", AgentRateResponse.class, AllInstrumentsDTO.class);
    /**
     * The meta-property for the {@code valueDateWises} property.
     */
    @SuppressWarnings({"unchecked", "rawtypes" })
    private final MetaProperty<Map<VDWType, AgentValueDateWiseDTO>> _valueDateWises = DirectMetaProperty.ofImmutable(
        this, "valueDateWises", AgentRateResponse.class, (Class) Map.class);
    /**
     * The meta-property for the {@code updatedOn} property.
     */
    private final MetaProperty<String> _updatedOn = DirectMetaProperty.ofImmutable(
        this, "updatedOn", AgentRateResponse.class, String.class);
    /**
     * The meta-property for the {@code status} property.
     */
    private final MetaProperty<Boolean> _status = DirectMetaProperty.ofImmutable(
        this, "status", AgentRateResponse.class, Boolean.class);
    /**
     * The meta-property for the {@code reason} property.
     */
    private final MetaProperty<String> _reason = DirectMetaProperty.ofImmutable(
        this, "reason", AgentRateResponse.class, String.class);
    /**
     * The meta-properties.
     */
    private final Map<String, MetaProperty<?>> _metaPropertyMap$ = new DirectMetaPropertyMap(
        this, null,
        "agent",
        "bank",
        "currency",
        "instruments",
        "valueDateWises",
        "updatedOn",
        "status",
        "reason");

    /**
     * Restricted constructor.
     */
    protected Meta() {
    }

    @Override
    protected MetaProperty<?> metaPropertyGet(String propertyName) {
      switch (propertyName.hashCode()) {
        case 92750597:  // agent
          return _agent;
        case 3016252:  // bank
          return _bank;
        case 575402001:  // currency
          return _currency;
        case 310319468:  // instruments
          return _instruments;
        case -1871135024:  // valueDateWises
          return _valueDateWises;
        case -1949194246:  // updatedOn
          return _updatedOn;
        case -892481550:  // status
          return _status;
        case -934964668:  // reason
          return _reason;
      }
      return super.metaPropertyGet(propertyName);
    }

    @Override
    public AgentRateResponse.Builder builder() {
      return new AgentRateResponse.Builder();
    }

    @Override
    public Class<? extends AgentRateResponse> beanType() {
      return AgentRateResponse.class;
    }

    @Override
    public Map<String, MetaProperty<?>> metaPropertyMap() {
      return _metaPropertyMap$;
    }

    //-----------------------------------------------------------------------
    /**
     * The meta-property for the {@code agent} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<AgentDetails> agent() {
      return _agent;
    }

    /**
     * The meta-property for the {@code bank} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> bank() {
      return _bank;
    }

    /**
     * The meta-property for the {@code currency} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<CountryCurrencyDTO> currency() {
      return _currency;
    }

    /**
     * The meta-property for the {@code instruments} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<AllInstrumentsDTO> instruments() {
      return _instruments;
    }

    /**
     * The meta-property for the {@code valueDateWises} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<Map<VDWType, AgentValueDateWiseDTO>> valueDateWises() {
      return _valueDateWises;
    }

    /**
     * The meta-property for the {@code updatedOn} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> updatedOn() {
      return _updatedOn;
    }

    /**
     * The meta-property for the {@code status} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<Boolean> status() {
      return _status;
    }

    /**
     * The meta-property for the {@code reason} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> reason() {
      return _reason;
    }

    //-----------------------------------------------------------------------
    @Override
    protected Object propertyGet(Bean bean, String propertyName, boolean quiet) {
      switch (propertyName.hashCode()) {
        case 92750597:  // agent
          return ((AgentRateResponse) bean).getAgent();
        case 3016252:  // bank
          return ((AgentRateResponse) bean).getBank();
        case 575402001:  // currency
          return ((AgentRateResponse) bean).getCurrency();
        case 310319468:  // instruments
          return ((AgentRateResponse) bean).getInstruments();
        case -1871135024:  // valueDateWises
          return ((AgentRateResponse) bean).getValueDateWises();
        case -1949194246:  // updatedOn
          return ((AgentRateResponse) bean).getUpdatedOn();
        case -892481550:  // status
          return ((AgentRateResponse) bean).getStatus();
        case -934964668:  // reason
          return ((AgentRateResponse) bean).getReason();
      }
      return super.propertyGet(bean, propertyName, quiet);
    }

    @Override
    protected void propertySet(Bean bean, String propertyName, Object newValue, boolean quiet) {
      metaProperty(propertyName);
      if (quiet) {
        return;
      }
      throw new UnsupportedOperationException("Property cannot be written: " + propertyName);
    }

  }

  //-----------------------------------------------------------------------
  /**
   * The bean-builder for {@code AgentRateResponse}.
   */
  public static class Builder extends DirectFieldsBeanBuilder<AgentRateResponse> {

    private AgentDetails agent;
    private String bank;
    private CountryCurrencyDTO currency;
    private AllInstrumentsDTO instruments;
    private Map<VDWType, AgentValueDateWiseDTO> valueDateWises;
    private String updatedOn;
    private Boolean status;
    private String reason;

    /**
     * Restricted constructor.
     */
    protected Builder() {
    }

    /**
     * Restricted copy constructor.
     * @param beanToCopy  the bean to copy from, not null
     */
    protected Builder(AgentRateResponse beanToCopy) {
      this.agent = beanToCopy.getAgent();
      this.bank = beanToCopy.getBank();
      this.currency = beanToCopy.getCurrency();
      this.instruments = beanToCopy.getInstruments();
      this.valueDateWises = (beanToCopy.getValueDateWises() != null ? ImmutableMap.copyOf(beanToCopy.getValueDateWises()) : null);
      this.updatedOn = beanToCopy.getUpdatedOn();
      this.status = beanToCopy.getStatus();
      this.reason = beanToCopy.getReason();
    }

    //-----------------------------------------------------------------------
    @Override
    public Object get(String propertyName) {
      switch (propertyName.hashCode()) {
        case 92750597:  // agent
          return agent;
        case 3016252:  // bank
          return bank;
        case 575402001:  // currency
          return currency;
        case 310319468:  // instruments
          return instruments;
        case -1871135024:  // valueDateWises
          return valueDateWises;
        case -1949194246:  // updatedOn
          return updatedOn;
        case -892481550:  // status
          return status;
        case -934964668:  // reason
          return reason;
        default:
          throw new NoSuchElementException("Unknown property: " + propertyName);
      }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Builder set(String propertyName, Object newValue) {
      switch (propertyName.hashCode()) {
        case 92750597:  // agent
          this.agent = (AgentDetails) newValue;
          break;
        case 3016252:  // bank
          this.bank = (String) newValue;
          break;
        case 575402001:  // currency
          this.currency = (CountryCurrencyDTO) newValue;
          break;
        case 310319468:  // instruments
          this.instruments = (AllInstrumentsDTO) newValue;
          break;
        case -1871135024:  // valueDateWises
          this.valueDateWises = (Map<VDWType, AgentValueDateWiseDTO>) newValue;
          break;
        case -1949194246:  // updatedOn
          this.updatedOn = (String) newValue;
          break;
        case -892481550:  // status
          this.status = (Boolean) newValue;
          break;
        case -934964668:  // reason
          this.reason = (String) newValue;
          break;
        default:
          throw new NoSuchElementException("Unknown property: " + propertyName);
      }
      return this;
    }

    @Override
    public Builder set(MetaProperty<?> property, Object value) {
      super.set(property, value);
      return this;
    }

    @Override
    public AgentRateResponse build() {
      return new AgentRateResponse(this);
    }

    //-----------------------------------------------------------------------
    /**
     * Sets the agent.
     * @param agent  the new value
     * @return this, for chaining, not null
     */
    public Builder agent(AgentDetails agent) {
      this.agent = agent;
      return this;
    }

    /**
     * Sets the bank.
     * @param bank  the new value
     * @return this, for chaining, not null
     */
    public Builder bank(String bank) {
      this.bank = bank;
      return this;
    }

    /**
     * Sets the currency.
     * @param currency  the new value
     * @return this, for chaining, not null
     */
    public Builder currency(CountryCurrencyDTO currency) {
      this.currency = currency;
      return this;
    }

    /**
     * Sets the instruments.
     * @param instruments  the new value
     * @return this, for chaining, not null
     */
    public Builder instruments(AllInstrumentsDTO instruments) {
      this.instruments = instruments;
      return this;
    }

    /**
     * Sets the valueDateWises.
     * @param valueDateWises  the new value
     * @return this, for chaining, not null
     */
    public Builder valueDateWises(Map<VDWType, AgentValueDateWiseDTO> valueDateWises) {
      this.valueDateWises = valueDateWises;
      return this;
    }

    /**
     * Sets the updatedOn.
     * @param updatedOn  the new value
     * @return this, for chaining, not null
     */
    public Builder updatedOn(String updatedOn) {
      this.updatedOn = updatedOn;
      return this;
    }

    /**
     * Sets the status.
     * @param status  the new value
     * @return this, for chaining, not null
     */
    public Builder status(Boolean status) {
      this.status = status;
      return this;
    }

    /**
     * Sets the reason.
     * @param reason  the new value
     * @return this, for chaining, not null
     */
    public Builder reason(String reason) {
      this.reason = reason;
      return this;
    }

    //-----------------------------------------------------------------------
    @Override
    public String toString() {
      StringBuilder buf = new StringBuilder(288);
      buf.append("AgentRateResponse.Builder{");
      int len = buf.length();
      toString(buf);
      if (buf.length() > len) {
        buf.setLength(buf.length() - 2);
      }
      buf.append('}');
      return buf.toString();
    }

    protected void toString(StringBuilder buf) {
      buf.append("agent").append('=').append(JodaBeanUtils.toString(agent)).append(',').append(' ');
      buf.append("bank").append('=').append(JodaBeanUtils.toString(bank)).append(',').append(' ');
      buf.append("currency").append('=').append(JodaBeanUtils.toString(currency)).append(',').append(' ');
      buf.append("instruments").append('=').append(JodaBeanUtils.toString(instruments)).append(',').append(' ');
      buf.append("valueDateWises").append('=').append(JodaBeanUtils.toString(valueDateWises)).append(',').append(' ');
      buf.append("updatedOn").append('=').append(JodaBeanUtils.toString(updatedOn)).append(',').append(' ');
      buf.append("status").append('=').append(JodaBeanUtils.toString(status)).append(',').append(' ');
      buf.append("reason").append('=').append(JodaBeanUtils.toString(reason)).append(',').append(' ');
    }

  }

  //-------------------------- AUTOGENERATED END --------------------------
}
