package com.unimoni.pricingengine.adapter.rest.clients;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Bank {
    private String name;

    private Long code;

    public Bank(@JsonProperty("bankName") String name, @JsonProperty("id") Long code) {
        this.name = name;
        this.code = code;
    }

    public CodeLabelPair<String, String> bankItem() {
        return CodeLabelPair.of("" + this.code, "" + this.name);
    }

    @Override
    public String toString() {
        return "Bank [name=" + name + ", code=" + code + "]";
    }
}
