package com.unimoni.pricingengine.adapter.persistence.repository.standardcharges;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.pricingengine.domain.model.standardcharges.StandardCharge;

public interface StandardChargesRepository extends JpaRepository<StandardCharge, Long>, StandardChargesRepositoryJPA {


}
