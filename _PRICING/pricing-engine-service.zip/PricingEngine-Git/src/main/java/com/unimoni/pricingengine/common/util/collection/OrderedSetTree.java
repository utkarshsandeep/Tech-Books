package com.unimoni.pricingengine.common.util.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.springframework.util.Assert;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;
import lombok.experimental.Accessors;

public class OrderedSetTree<E extends Comparable<E>> extends AbstractTree<E> {

    private Node<E> root = null;

    private int size = 0;

    private OrderedSetTree(final E rootElement) {
        this.root = Node.root(rootElement);
        this.size++;
    }

    public static <E extends Comparable<E>> OrderedSetTree<E> of(final E rootElement) {
        Assert.notNull(rootElement, "rootElement must not be null!");
        return new OrderedSetTree<E>(rootElement);
    }

    @Override
    public Position<E> add(final Position<E> parent, final E child) {
        Assert.notNull(parent, "parent must not be null!");
        Assert.notNull(child, "child must not be null!");

        Node<E> parentNode = (Node<E>) parent;
        Node<E> childNode = Node.of(child, parentNode);
        childNode.level = parentNode.level + 1;
        parentNode.children.add(childNode);
        parentNode.numChildren++;
        this.size++;
        return childNode;
    }

    @Override
    public List<Position<E>> add(final Position<E> parent, final List<E> children) {
        Assert.notNull(parent, "parent must not be null!");
        Assert.notNull(children, "children must not be null!");
        Assert.notEmpty(children, "children must not be empty!");

        List<Position<E>> result = new ArrayList<Position<E>>(children.size());
        children.forEach(e -> {
            Node<E> parentNode = (Node<E>) parent;
            Node<E> childNode = Node.of(e, parentNode);
            childNode.level = parentNode.level + 1;
            if (parentNode.children.add(childNode)) {
                result.add(childNode);
            }
            parentNode.numChildren++;
            this.size++;
        });
        return result;
    }

    @Override
    public void replace(Position<E> position, E element) {
        Assert.notNull(position, "position must not be null!");
        Assert.notNull(element, "element must not be null!");

        Node<E> node = (Node<E>) position;
        node.element = element;
    }

    @Override
    public Iterable<Position<E>> positions(final int level) {
        Assert.notNull(level, "level must not be null!");
        return stream().filter(p -> p.isLevel(level)).collect(Collectors.toList());
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public Position<E> root() {
        return this.root;
    }

    @Override
    public Optional<Position<E>> parent(final Position<E> position) throws IllegalStateException {
        Assert.notNull(position, "position must not be null!");

        Node<E> node = (Node<E>) position;
        return Optional.ofNullable(node.parent);
    }

    /**
     * Removes the node at a position and replaces it with its child, if any.
     *
     * @param position
     * @return
     * @throws IllegalArgumentException
     */
    @Override
    public E remove(final Position<E> position) throws IllegalArgumentException {
        Assert.notNull(position, "position must not be null!");

        Node<E> node = (Node<E>) position;

        if (isRoot(position)) {
            throw new UnsupportedOperationException("Can not remove root of tree");
        }
        Node<E> parent = node.parent;
        parent.children.remove(node);
        this.size--;
        parent.numChildren--;
        int removedNodeChildCount = node.children.size();
        node.children.clear();
        this.size -= removedNodeChildCount;

        return position.element();
    }

    @Override
    public Iterator<E> iterator() {
        return new ElementIterator();
    }

    @Override
    public Iterable<Position<E>> positions() {
        return preOrder();
    }

    @Override
    public int numChildren(final Position<E> position) {
        Assert.notNull(position, "position must not be null!");

        Node<E> node = (Node<E>) position;
        return node.numChildren;
    }

    @Override
    public Iterable<Position<E>> children(final Position<E> position) {
        Assert.notNull(position, "position must not be null!");

        Node<E> node = (Node<E>) position;
        return new ArrayList<>(node.children);
    }

    // ---------------- nested Node class ----------------
    @Getter
    @Accessors(chain = true, fluent = true)
    @EqualsAndHashCode(of = "element")
    @ToString(of = { "level", "element", "numChildren" }, includeFieldNames = true)
    private static class Node<E extends Comparable<E>> implements Position<E>, Comparable<Node<E>> {

        @NonNull
        private E element;

        @Getter(value = AccessLevel.NONE)
        private Node<E> parent;

        @Getter(value = AccessLevel.NONE)
        private SortedSet<Position<E>> children = new TreeSet<>();

        private int numChildren;

        private int level;

        private Node(final E element) {
            this.element = element;
        }

        private Node(final E element, final Node<E> parent) {
            this.element = element;
            this.parent = parent;
        }

        public static <E extends Comparable<E>> Node<E> root(final E element) {
            return new Node<E>(element, null);
        }

        public static <E extends Comparable<E>> Node<E> of(final E element, final Node<E> parent) {
            return new Node<E>(element, parent);
        }

        @Override
        public E element() throws IllegalStateException {
            return this.element;
        }

        @Override
        public int compareTo(final Node<E> other) {
            return this.element.compareTo(other.element);
        }

        @Override
        public boolean isLevel(final int level) {
            return this.level == level;
        }
    }

    /**
     * This class adapts the iteration produced by positions() to return elements.
     */
    private class ElementIterator implements Iterator<E> {

        Iterator<Position<E>> positionIterator = positions().iterator();

        @Override
        public boolean hasNext() {
            return positionIterator.hasNext();
        }

        @Override
        public E next() {
            return positionIterator.next().element();
        }

        @Override
        public void remove() {
            positionIterator.remove();
        }
    }
}
