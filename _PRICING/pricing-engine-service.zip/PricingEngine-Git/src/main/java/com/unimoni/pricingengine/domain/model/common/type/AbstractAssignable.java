package com.unimoni.pricingengine.domain.model.common.type;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 
 */
@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public abstract class AbstractAssignable<CodeType extends Serializable & Comparable<CodeType>>
        implements Assignable<CodeType> {

    @Id
    @Column(name = "CODE", nullable = false, length = 20)
    protected CodeType code;

    @Override
    public CodeType code() {
        return code;
    }
}
