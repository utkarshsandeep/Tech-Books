package com.unimoni.pricingengine.domain.model.rate.base;

import static com.unimoni.pricingengine.adapter.persistence.PersistenceConstant.TableMetaData.TABLE_BANK_WISE_BASE_RATES;
import static com.unimoni.pricingengine.common.constants.ApplicationConstants.ALL_INSTRUMENTS;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.money.CurrencyUnit;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.envers.Audited;
import org.springframework.util.Assert;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.unimoni.pricingengine.application.event.listner.EntityChangeListener;
import com.unimoni.pricingengine.application.service.amigo.event.IBRUpdatedEvent;
import com.unimoni.pricingengine.application.service.event.EventPublisher;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.domain.model.builder.Builder;
import com.unimoni.pricingengine.domain.model.builder.MultiBuilder;
import com.unimoni.pricingengine.domain.model.rate.AbstractLayer;
import com.unimoni.pricingengine.domain.model.rate.BankWiseRate;
import com.unimoni.pricingengine.domain.model.rate.RateSourceType;
import com.unimoni.pricingengine.domain.model.rate.base.dto.BankRateIdentity;
import com.unimoni.pricingengine.domain.model.rate.composable.Exchange;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;
import com.unimoni.pricingengine.domain.model.rate.composable.RateInstruments;
import com.unimoni.pricingengine.domain.model.rate.ibr.BankWiseIBR;
import com.unimoni.pricingengine.domain.model.validation.RatesValidationHelper;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

@Getter
@Accessors(chain = true, fluent = true)
@NoArgsConstructor
@ToString
@Slf4j
//@formatter:off
@NamedEntityGraph(
    name = "bankWiseBaseRate",
    attributeNodes = {
        @NamedAttributeNode(value = "ibr", subgraph = "bankWiseIbr")
    },
    subgraphs = {
        @NamedSubgraph(
                name = "bankWiseIbr",
                attributeNodes = {
                    @NamedAttributeNode("vars")}
        )
    }
)
@Entity
@EntityListeners(EntityChangeListener.class)
@DiscriminatorValue("BANK_WISE_BASE")
@SecondaryTable(name = TABLE_BANK_WISE_BASE_RATES, 
    indexes = {
        @Index(name = "IDX_BANK_WISE_BASE_BANK_CODE", columnList = "BANK_CODE"),
        @Index(name = "IDX_BANK_WISE_BASE_AGENT_CODE", columnList = "AGENT_CODE"),
        @Index(name = "IDX_BANK_WISE_BASE_RATES_SERVICE_PROVIDER_CODE", columnList = "SERVICE_PROVIDER_CODE"),
        @Index(name = "IDX_BANK_WISE_BASE_RATES_PRODUCT_CODE", columnList = "PRODUCT_CODE")
    }, 
    pkJoinColumns = @PrimaryKeyJoinColumn(name = "ID"), 
    foreignKey = @ForeignKey(name = "FK_BANK_WISE_BASE_RATES_MANAGED_RATES_ID"))
// @formatter:on
@Audited
public class BankWiseBaseRate extends AbstractLayer implements BaseRate, BankWiseRate {

    @NotNull
    @Column(table = TABLE_BANK_WISE_BASE_RATES, name = "BANK_CODE", updatable = false, nullable = false, length = 100)
    private String bank;

    @NotNull
    @Column(table = TABLE_BANK_WISE_BASE_RATES, name = "AGENT_CODE", updatable = false, nullable = false, length = 100)
    private String agent;

    @NotNull
    @Embedded
    // @formatter:off
    @AttributeOverrides({ 
        @AttributeOverride(name = "serviceProvider", 
            column = @Column(table = TABLE_BANK_WISE_BASE_RATES, name = "SERVICE_PROVIDER_CODE", 
                updatable = false, nullable = false, length = 100)),
        @AttributeOverride(name = "product", 
            column = @Column(table = TABLE_BANK_WISE_BASE_RATES, name = "PRODUCT_CODE", 
                updatable = false, nullable = false, length = 100)) 
    })
    // @formatter:on
    private RateInstruments instruments;

    @NotNull
    @OneToOne(fetch = FetchType.LAZY, optional = false, cascade = CascadeType.PERSIST)
    // @formatter:off
    @JoinColumn(table = TABLE_BANK_WISE_BASE_RATES, name = "IBR_ID", unique = true, updatable = false, nullable = false, 
            foreignKey = @ForeignKey(name = "FK_BANK_WISE_BASE_RATES_IBR_ID"))
    //@formatter:on
    private BankWiseIBR ibr;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(table = TABLE_BANK_WISE_BASE_RATES, name = "RATE_SOURCE_TYPE", nullable = false, updatable = true, length = 20)
    private RateSourceType rateSourceType;

    public boolean updateRate(final BigDecimal askValue, final BigDecimal bidValue) {
        return updateRate(ExchangeRate.of(askValue, bidValue));
    }

    public boolean updateRate(final ExchangeRate rate) {
        if (exchange().updateRate(rate)) {
            this.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
            propagateRateChangeToIbr();

            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateStatus(final boolean status) {
        if (this.enabled == status) {
            return false;
        }
        else {
            this.enabled = status;

            // if(status == false) { //Propagate only when record is being disabled.
            propagateStatusChangeToIbr();
            // }

            return true;
        }
    }

    private BankWiseIBR publishToIbr() {
        return this.ibr == null ? this.ibr = BankWiseIBR.of(this) : this.ibr;
    }

    private BankWiseIBR propagateRateChangeToIbr() {
        if (this.ibr.isEnabled()) {
            if (this.ibr.updateRate(this.exchange.rate(), this.updatedOn)) {
                EventPublisher.publishAmigoEvent(IBRUpdatedEvent.bankWiseIBRForRateChange(this.ibr));
            }
            else {
                log.debug("New rate is found to be same as old, So no updates have happened");
            }
        }
        else {
            log.debug("Linked IBR record is disabled, So can not propagate rate changes");
        }
        return this.ibr;
    }

    private BankWiseIBR propagateStatusChangeToIbr() {
        if (this.ibr.updateStatus(this.enabled)) {
            EventPublisher.publishAmigoEvent(IBRUpdatedEvent.bankWiseIBRForStatusChange(this.ibr));
        }
        return this.ibr;
    }

    public BankRateIdentity identity() {
        return BankRateIdentity.of(this.exchange.currency().source(), this.exchange.currency().target(),
                this.instruments.serviceProvider(), this.instruments.product(), this.agent, this.bank);
    }

    public static AgentsBuilder of(final String bank) {
        return new BankWiseBaseRateBuilder(bank);
    }

    public interface AgentsBuilder {
        SourceCurrencyBuilder agents(final List<String> agent);
    }

    public interface SourceCurrencyBuilder {
        public TargetCurrencyBuilder from(final CurrencyUnit sourceCurrency);
    }

    public interface TargetCurrencyBuilder {
        public AskValueBuilder to(final CurrencyUnit targetCurrency);
    }

    public interface AskValueBuilder {
        public BidValueBuilder askAt(final BigDecimal askValue);
    }

    public interface BidValueBuilder {
        public RateSourceTypeBuilder bidAt(final BigDecimal bidValue);
    }
    
    public interface RateSourceTypeBuilder {

        public ServiceProviderBuilder ibrNormalRateSource();

        public ServiceProviderBuilder manualRateSource();

        public ServiceProviderBuilder rateSource(final RateSourceType rateSourceType);
    }

    public interface ServiceProviderBuilder {

        public Builder<BankWiseBaseRate> allInstruments();

        public SingleServiceProviderProductBuilder allServiceProviders();

        public SingleServiceProviderProductBuilder serviceProvider(final String serviceProvider);

        public MultipleServiceProviderProductBuilder serviceProvider(final String... serviceProviders);
    }

    public interface SingleServiceProviderProductBuilder {

        public Builder<BankWiseBaseRate> allProducts();

        public Builder<BankWiseBaseRate> product(final String product);

        public MultiBuilder<BankWiseBaseRate> product(final String... products);
    }

    public interface MultipleServiceProviderProductBuilder {

        public Builder<BankWiseBaseRate> withAllProducts();

        public MultiBuilder<BankWiseBaseRate> withProduct(final String product);

        public MultiBuilder<BankWiseBaseRate> withProduct(final String... products);
    }
    
    // -------------------------------------------------------------------------

    public static List<BankWiseBaseRate> of(final List<BankRateIdentity> identities, final BigDecimal askValue,
            final BigDecimal bidValue, final RateSourceType rateSourceType) {

        List<BankWiseBaseRate> instances = new ArrayList<>(identities.size());
        ZonedDateTime timestamp = DateTimeHelper.nowZonedDateTimeUTC();

        for (BankRateIdentity bankRateIdentity : identities) {
            RatesValidationHelper.validateAskAndBidValueForBankWise(bankRateIdentity.getSourceCurrency(),
                    bankRateIdentity.getTargetCurrency(), askValue, bidValue);
            BankWiseBaseRate bankWiseBaseRate = new BankWiseBaseRate();
            bankWiseBaseRate.bank = bankRateIdentity.getBank();
            bankWiseBaseRate.agent = bankRateIdentity.getAgent();
            bankWiseBaseRate.exchange = Exchange.of(bankRateIdentity.getSourceCurrency(),
                    bankRateIdentity.getTargetCurrency(), askValue, bidValue);
            bankWiseBaseRate.instruments = bankRateIdentity.rateInstruments();
            bankWiseBaseRate.enabled = true;
            bankWiseBaseRate.updatedOn = timestamp;
            bankWiseBaseRate.rateSourceType = rateSourceType;
            bankWiseBaseRate.publishToIbr();
            instances.add(bankWiseBaseRate);
        }
        return Collections.unmodifiableList(instances);
    }

    public void updateRateSourceType(final RateSourceType rateSourceType) {
        this.rateSourceType = rateSourceType;
    }

    public boolean isRateSourceTypeChanged(final RateSourceType rateSourceType) {
        return this.rateSourceType.equals(rateSourceType);
    }

    public static class BankWiseBaseRateBuilder implements AgentsBuilder, SourceCurrencyBuilder, TargetCurrencyBuilder,
            AskValueBuilder, BidValueBuilder, ServiceProviderBuilder, SingleServiceProviderProductBuilder,
            MultipleServiceProviderProductBuilder, Builder<BankWiseBaseRate>, MultiBuilder<BankWiseBaseRate>, RateSourceTypeBuilder {

        private String bankCode;

        private CurrencyUnit sourceCurrency;

        private CurrencyUnit targetCurrency;

        private BigDecimal askValue;

        private BigDecimal bidValue;

        private String serviceProvider;

        private ImmutableList<String> serviceProviders;

        private String product;

        private ImmutableList<String> products;

        private ImmutableList<String> agents;
        
        private RateSourceType rateSourceType;

        BankWiseBaseRateBuilder(final String bankCode) {
            Assert.isTrue(StringUtils.isNotEmpty(bankCode), "bankCode must not be null or empty");
            this.bankCode = bankCode;
        }

        @Override
        public SourceCurrencyBuilder agents(final List<String> agents) {
            this.agents = ImmutableList.copyOf(agents);
            return this;
        }

        @Override
        public TargetCurrencyBuilder from(CurrencyUnit sourceCurrency) {
            this.sourceCurrency = sourceCurrency;
            return this;
        }

        @Override
        public AskValueBuilder to(CurrencyUnit targetCurrency) {
            this.targetCurrency = targetCurrency;
            return this;
        }

        @Override
        public BidValueBuilder askAt(BigDecimal askValue) {
            this.askValue = askValue;
            return this;
        }

        @Override
        public RateSourceTypeBuilder bidAt(BigDecimal bidValue) {
            this.bidValue = bidValue;
            return this;
        }
        
        @Override
        public ServiceProviderBuilder ibrNormalRateSource() {
            this.rateSourceType = RateSourceType.IBR_NORMAL;
            return this;
        }

        @Override
        public ServiceProviderBuilder manualRateSource() {
            this.rateSourceType = RateSourceType.MANUAL;
            return this;
        }

        @Override
        public ServiceProviderBuilder rateSource(RateSourceType rateSourceType) {
            this.rateSourceType = rateSourceType;
            return this;
        }

        @Override
        public Builder<BankWiseBaseRate> allInstruments() {
            this.serviceProvider = ALL_INSTRUMENTS;
            this.product = ALL_INSTRUMENTS;
            return this;
        }

        @Override
        public SingleServiceProviderProductBuilder allServiceProviders() {
            this.serviceProvider = ALL_INSTRUMENTS;
            return this;
        }

        @Override
        public SingleServiceProviderProductBuilder serviceProvider(String serviceProvider) {
            this.serviceProvider = serviceProvider;
            return this;
        }

        @Override
        public MultipleServiceProviderProductBuilder serviceProvider(String... serviceProviders) {
            this.serviceProviders = ImmutableList.copyOf(serviceProviders);
            return this;
        }

        @Override
        public Builder<BankWiseBaseRate> allProducts() {
            this.product = ALL_INSTRUMENTS;
            return this;
        }

        @Override
        public Builder<BankWiseBaseRate> product(String product) {
            this.product = product;
            return this;
        }

        @Override
        public MultiBuilder<BankWiseBaseRate> product(String... products) {
            this.products = ImmutableList.copyOf(products);
            return this;
        }

        @Override
        public Builder<BankWiseBaseRate> withAllProducts() {
            this.product = ALL_INSTRUMENTS;
            return this;
        }

        @Override
        public MultiBuilder<BankWiseBaseRate> withProduct(String product) {
            this.product = product;
            return this;
        }

        @Override
        public MultiBuilder<BankWiseBaseRate> withProduct(String... products) {
            this.products = ImmutableList.copyOf(products);
            return this;
        }
        
        @Override
        public BankWiseBaseRate build() {
            BankWiseBaseRate bankWiseBaseRate = new BankWiseBaseRate();
            bankWiseBaseRate.bank = this.bankCode;
            bankWiseBaseRate.exchange = Exchange.of(this.sourceCurrency, this.targetCurrency, this.askValue,
                    this.bidValue);
            bankWiseBaseRate.instruments = RateInstruments.of(this.serviceProvider, this.product);
            bankWiseBaseRate.enabled = true;
            bankWiseBaseRate.updatedOn = DateTimeHelper.nowZonedDateTimeUTC();
            bankWiseBaseRate.rateSourceType = this.rateSourceType;
            bankWiseBaseRate.publishToIbr();
            return bankWiseBaseRate;
        }

        @SuppressWarnings("unchecked")
        @Override
        public List<BankWiseBaseRate> buildAll() {
            List<List<String>> combinations = Lists.cartesianProduct(serviceProviders, products, agents);
            List<BankWiseBaseRate> instances = new ArrayList<>(combinations.size());
            ZonedDateTime timestamp = DateTimeHelper.nowZonedDateTimeUTC();
            RatesValidationHelper.validateAskAndBidValueForBankWise(this.sourceCurrency, this.targetCurrency,
                    this.askValue, this.bidValue);
            Exchange exchange = Exchange.of(this.sourceCurrency, this.targetCurrency, this.askValue, this.bidValue);

            for (List<String> combination : combinations) {
                BankWiseBaseRate bankWiseBaseRate = new BankWiseBaseRate();
                bankWiseBaseRate.bank = this.bankCode;
                bankWiseBaseRate.agent = combination.get(2);
                bankWiseBaseRate.exchange = exchange;
                bankWiseBaseRate.instruments = RateInstruments.of(combination.get(0), combination.get(1));
                bankWiseBaseRate.enabled = true;
                bankWiseBaseRate.updatedOn = timestamp;
                bankWiseBaseRate.rateSourceType = this.rateSourceType;
                bankWiseBaseRate.publishToIbr();
                instances.add(bankWiseBaseRate);
            }
            return Collections.unmodifiableList(instances);
        }
    }
}
