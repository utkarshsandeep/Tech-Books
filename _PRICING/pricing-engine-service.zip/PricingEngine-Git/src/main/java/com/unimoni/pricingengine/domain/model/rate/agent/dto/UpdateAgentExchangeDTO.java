package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import java.util.Optional;

import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.settlement.dto.CostDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "updateAgentExchangeRate", description = "Settlement, Margin or Country Cost")
public class UpdateAgentExchangeDTO {

    @ApiModelProperty(name = "margin", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private CostDTO margin;
        
    @ApiModelProperty(name = "customerRate", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private CostDTO customerRate;

    @ApiModelProperty(name = "margin", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private CostDTO marginLow;
    
    @ApiModelProperty(name = "margin", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private CostDTO marginHigh;


    @ApiModelProperty(name = "margin", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private CostDTO customerLowest;
    
    @ApiModelProperty(name = "margin", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    private CostDTO maxDiscount;

    public Optional<CostDTO> margin() {
        return Optional.ofNullable(this.margin);
    }
    
    public Optional<CostDTO> customerRate() {
        return Optional.ofNullable(this.customerRate);
    }
    public Optional<CostDTO> marginLow() {
        return Optional.ofNullable(this.marginLow);
    }
    public Optional<CostDTO> marginHigh() {
        return Optional.ofNullable(this.marginHigh);
    }
    public Optional<CostDTO> customerLowest() {
        return Optional.ofNullable(this.customerLowest);
    }
    public Optional<CostDTO> maxDiscount() {
        return Optional.ofNullable(this.maxDiscount);
    }
       

}