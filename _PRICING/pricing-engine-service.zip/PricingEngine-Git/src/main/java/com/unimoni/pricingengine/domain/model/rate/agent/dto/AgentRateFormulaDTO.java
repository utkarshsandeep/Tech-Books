package com.unimoni.pricingengine.domain.model.rate.agent.dto;

import static com.unimoni.pricingengine.domain.model.rate.RateValue.validatePositive;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.RateDisplayMachenism;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.domain.model.rate.composable.Cost;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@ToString
@ApiModel(value = "agentRateFormulaDTO", description = "Formula Calculated Sell and Buy Values")
public class AgentRateFormulaDTO {

    @ApiModelProperty(name = "sellValue", dataType = "BigDecimal", value = "Sell Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @NotNull
    private BigDecimal sellValue;

    @ApiModelProperty(name = "buyValue", dataType = "BigDecimal", value = "Buy Value in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8 + " decimal points precision", required = true, example = "75.32560000")
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @NotNull
    private BigDecimal buyValue;

    public static AgentRateFormulaDTO of(final Cost settlement) {
        return of(settlement.sellValue(), settlement.buyValue());
    }

    public static AgentRateFormulaDTO zero() {
        return AgentRateFormulaDTO.of(RateValue.ZERO, RateValue.ZERO);
    }

    public Cost toModel() {
        return Cost.of(this.sellValue, this.buyValue);
    }

    public static AgentRateFormulaDTO byCustomerRateFormula(final RateDisplayMachenism rmType,
            final BigDecimal agentCostSell, final BigDecimal agentCostBuy, final BigDecimal agentMarginSell,
            final BigDecimal agentMarginBuy) {
        AgentRateFormulaDTO agentRateFormulaDTO = AgentRateFormulaDTO.zero();
        if (rmType.isBCtoFC()) {
            BigDecimal sell = agentCostSell.subtract(agentMarginSell);
            BigDecimal buy = agentCostBuy.add(agentMarginBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }
        else {
            BigDecimal sell = agentCostSell.add(agentMarginSell);
            BigDecimal buy = agentCostBuy.subtract(agentMarginBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }

        validatePositive(agentRateFormulaDTO.getBuyValue(), "Agent Buy");
        validatePositive(agentRateFormulaDTO.getSellValue(), "Agent Sell");

        return agentRateFormulaDTO;
    }

    public static AgentRateFormulaDTO byMarginFormula(final RateDisplayMachenism RDM, final BigDecimal agentCostSell,
            final BigDecimal agentCostBuy, final BigDecimal agentCustomerRateSell,
            final BigDecimal agentCustomerRateBuy) {
        AgentRateFormulaDTO agentRateFormulaDTO = AgentRateFormulaDTO.zero();
        if (RDM.isBCtoFC()) {
            BigDecimal sell = agentCostSell.subtract(agentCustomerRateSell);
            BigDecimal buy = agentCustomerRateBuy.subtract(agentCostBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }
        else {
            BigDecimal sell = agentCustomerRateSell.subtract(agentCostSell);
            BigDecimal buy = agentCostBuy.subtract(agentCustomerRateBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }

        validatePositive(agentRateFormulaDTO.getBuyValue(), "Margin Buy");
        validatePositive(agentRateFormulaDTO.getSellValue(), "Margin Sell");

        return agentRateFormulaDTO;
    }

    public static AgentRateFormulaDTO byMaxDiscountFormula(final RateDisplayMachenism RDM,
            final BigDecimal agentCustomerRateSell, final BigDecimal agentCustomerRateSeBuy,
            final BigDecimal agentMarginLowSell, final BigDecimal agentMarginLowBuy) {
        AgentRateFormulaDTO agentRateFormulaDTO = AgentRateFormulaDTO.zero();
        if (RDM.isBCtoFC()) {
            BigDecimal sell = agentCustomerRateSell.add(agentMarginLowSell);
            BigDecimal buy = agentCustomerRateSeBuy.subtract(agentMarginLowBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }
        else {
            BigDecimal sell = agentCustomerRateSell.subtract(agentMarginLowSell);
            BigDecimal buy = agentCustomerRateSeBuy.add(agentMarginLowBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }

        validatePositive(agentRateFormulaDTO.getBuyValue(), "Max Discount Buy");
        validatePositive(agentRateFormulaDTO.getSellValue(), "Max Discount Sell");

        return agentRateFormulaDTO;
    }

    public static AgentRateFormulaDTO byMarginLowFormula(final RateDisplayMachenism RDM,
            final BigDecimal agentCustomerRateSell, final BigDecimal agentCustomerRateBuy,
            final BigDecimal agentMaxDiscountSell, final BigDecimal agentMaxDiscountBuy) {
        AgentRateFormulaDTO agentRateFormulaDTO = AgentRateFormulaDTO.zero();
        if (RDM.isBCtoFC()) {
            BigDecimal sell = agentMaxDiscountSell.subtract(agentCustomerRateSell);
            BigDecimal buy = agentCustomerRateBuy.subtract(agentMaxDiscountBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }
        else {
            BigDecimal sell = agentCustomerRateSell.subtract(agentMaxDiscountSell);
            BigDecimal buy = agentMaxDiscountBuy.subtract(agentCustomerRateBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }

        validatePositive(agentRateFormulaDTO.getBuyValue(), "Margin Low Buy");
        validatePositive(agentRateFormulaDTO.getSellValue(), "Margin Low Sell");

        return agentRateFormulaDTO;
    }

    public static AgentRateFormulaDTO byMarginHighFormula(final RateDisplayMachenism rDM,
            final BigDecimal agentCustomerRateSell, final BigDecimal agentCustomerRateBuy,
            final BigDecimal agentCustomerLowestSell, final BigDecimal agentCustomerLowestBuy) {
        AgentRateFormulaDTO agentRateFormulaDTO = AgentRateFormulaDTO.zero();
        if (rDM.isBCtoFC()) {
            BigDecimal sell = agentCustomerRateSell.subtract(agentCustomerLowestSell);
            BigDecimal buy = agentCustomerRateBuy.subtract(agentCustomerLowestBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }
        else {
            BigDecimal sell = agentCustomerLowestSell.subtract(agentCustomerRateSell);
            BigDecimal buy = agentCustomerLowestBuy.subtract(agentCustomerRateBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }

        validatePositive(agentRateFormulaDTO.getBuyValue(), "Margin High Buy");
        validatePositive(agentRateFormulaDTO.getSellValue(), "Margin High Sell");

        return agentRateFormulaDTO;
    }

    public static AgentRateFormulaDTO byCustomerLowestFormula(final RateDisplayMachenism RDM,
            final BigDecimal agentCustomerRateSell, final BigDecimal agentCustomerRateBuy,
            final BigDecimal agentMarginHighSell, final BigDecimal agentMarginHighBuy) {
        AgentRateFormulaDTO agentRateFormulaDTO = AgentRateFormulaDTO.zero();
        if (RDM.isBCtoFC()) {
            BigDecimal sell = agentCustomerRateSell.subtract(agentMarginHighSell);
            BigDecimal buy = agentCustomerRateBuy.add(agentMarginHighBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }
        else {
            BigDecimal sell = agentCustomerRateSell.add(agentMarginHighSell);
            BigDecimal buy = agentCustomerRateBuy.subtract(agentMarginHighBuy);
            agentRateFormulaDTO = AgentRateFormulaDTO.of(sell, buy);
        }

        validatePositive(agentRateFormulaDTO.getBuyValue(), "Customer Lowest Buy");
        validatePositive(agentRateFormulaDTO.getSellValue(), "Customer Lowest Sell");

        return agentRateFormulaDTO;
    }
}
