package com.unimoni.pricingengine.domain.model.rate;

public interface Layer {

    // Common methods to all markup layers

    public String id();
}
