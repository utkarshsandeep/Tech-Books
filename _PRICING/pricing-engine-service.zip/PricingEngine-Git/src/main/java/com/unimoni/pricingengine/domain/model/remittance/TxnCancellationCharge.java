package com.unimoni.pricingengine.domain.model.remittance;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.pricingengine.domain.model.rate.RateValue;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal3PointsSerializer;
import com.unimoni.pricingengine.infra.config.jackson.BigDecimal8PointsSerializer;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(staticName = "of")
@ToString
@Embeddable
@org.hibernate.annotations.Immutable
public class TxnCancellationCharge {

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "refundAdditionalCharges", value = "Whether or not to refund additional charges", position = 1)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "REFUND_ADDITIONAL_CHARGES", length = 1, updatable = false)
    private Boolean refundAdditionalCharges;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "refundCardCharges", value = "Whether or not to refund card charges", position = 2)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "REFUND_CARD_CHARGES", length = 1, updatable = false)
    private Boolean refundCardCharges;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "refundCommission", value = "Whether or not to refund commission charges", position = 3)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "REFUND_COMMISSION", length = 1, updatable = false)
    private Boolean refundCommission;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "refundOtherCharges", value = "Whether or not to refund other charges", position = 4)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "REFUND_OTHER_CHARGES", length = 1, updatable = false)
    private Boolean refundOtherCharges;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @ApiModelProperty(name = "refundTax", value = "Whether or not to refund tax", position = 5)
    @org.hibernate.annotations.Type(type = "yes_no")
    @Column(name = "REFUND_TAX", length = 1, updatable = false)
    private Boolean refundTax;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal3PointsSerializer.class)
    @Column(name = "CANCELLATION_CHARGES", columnDefinition = "NUMBER(*,10)", updatable = false)
    private BigDecimal cancellationCharges;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @ApiModelProperty(name = "rate", dataType = "BigDecimal", value = "Rate calculated from Pricing Layers in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8
            + " decimal points precision", required = true, example = "12.32560000", position = 8)
    @Column(name = "RATE", columnDefinition = "NUMBER(*,10) NOT NULL ENABLE", updatable = false)
    private BigDecimal rate;

    @JsonProperty
    @JsonInclude(NON_NULL)
    @JsonSerialize(using = BigDecimal8PointsSerializer.class)
    @ApiModelProperty(name = "swiftCharge", dataType = "BigDecimal", value = "Swift Charge calculated in BigDecimal with "
            + RateValue.DECIMAL_POINTS_8
            + " decimal points precision", required = true, example = "12.32560000", position = 8)
    @Column(name = "SWIFT_CHARGES", columnDefinition = "NUMBER(*,10) NOT NULL ENABLE", updatable = false)
    private BigDecimal swiftCharges;

    private TxnCancellationCharge() {
    }

    public static TxnCancellationCharge byDefault() {
        TxnCancellationCharge txnCancellationCharge = new TxnCancellationCharge();
        txnCancellationCharge.refundAdditionalCharges = Boolean.FALSE;
        txnCancellationCharge.refundCardCharges = Boolean.FALSE;
        txnCancellationCharge.refundCommission = Boolean.FALSE;
        txnCancellationCharge.refundOtherCharges = Boolean.FALSE;
        txnCancellationCharge.refundTax = Boolean.FALSE;
        txnCancellationCharge.cancellationCharges = RateValue.ZERO;
        txnCancellationCharge.swiftCharges = RateValue.ZERO;

        return txnCancellationCharge;
    }

    public TxnCancellationCharge setRate(final BigDecimal rate) {
        this.rate = rate == null ? RateValue.ZERO : rate;
        return this;
    }

    public TxnCancellationCharge skip(final RateSkipSetting rateSkipSetting) {
        TxnCancellationCharge txnCancellationCharge = new TxnCancellationCharge();

        if (!rateSkipSetting.skipCustomerFeeOnly()) {
            txnCancellationCharge.refundAdditionalCharges = this.refundAdditionalCharges;
            txnCancellationCharge.refundCardCharges = this.refundCardCharges;
            txnCancellationCharge.refundCommission = this.refundCommission;
            txnCancellationCharge.refundOtherCharges = this.refundOtherCharges;
            txnCancellationCharge.refundTax = this.refundTax;
            txnCancellationCharge.cancellationCharges = this.cancellationCharges;
        }

        txnCancellationCharge.rate = rateSkipSetting.skipRatesOnly() ? null : this.rate;

        txnCancellationCharge.swiftCharges = rateSkipSetting.skipSwiftCharge() ? null : this.swiftCharges;

        return txnCancellationCharge;
    }
}
