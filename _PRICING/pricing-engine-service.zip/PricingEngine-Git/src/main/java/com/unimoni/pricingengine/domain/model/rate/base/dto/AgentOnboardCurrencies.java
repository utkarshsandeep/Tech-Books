package com.unimoni.pricingengine.domain.model.rate.base.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@JsonIgnoreProperties
public class AgentOnboardCurrencies {
    private List<AgentCurrencyCode> currencyCodes;
    private String agentDisplayCode;
    private Integer agentId;
    private Integer agentBranchId;
    public String agentBranchCode;
    public String agentDisplayName;
    public String productType;
    public String serviceProviderCode;
    public String serviceType;
    public String subProductType;
    

    public AgentOnboardCurrencies(@JsonProperty List<AgentCurrencyCode> currencyCodes,
            @JsonProperty String agentDisplayCode,
            @JsonProperty Integer agentId,
            @JsonProperty Integer agentBranchId,
            @JsonProperty String agentBranchCode,
            @JsonProperty String agentDisplayName,
            @JsonProperty String productType,
            @JsonProperty String serviceProviderCode,
            @JsonProperty String serviceType,
            @JsonProperty String subProductType) {
        this.currencyCodes = currencyCodes;
        this.agentDisplayCode = agentDisplayCode;
        this.agentId=agentId;
        this.agentBranchId=agentBranchId;
        this.agentBranchCode=agentBranchCode;
        this.agentDisplayCode=agentDisplayName;
        this.productType=productType;
        this.serviceProviderCode=serviceProviderCode;
        this.serviceType=serviceType;
        this.subProductType=subProductType;        
    }
}
