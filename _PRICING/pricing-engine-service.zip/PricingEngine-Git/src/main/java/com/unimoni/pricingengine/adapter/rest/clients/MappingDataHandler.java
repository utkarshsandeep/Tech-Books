package com.unimoni.pricingengine.adapter.rest.clients;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotEmpty;

public class MappingDataHandler {

    public List<MappingMasterData> spBankMappingData(List<@NotEmpty String> serviceProviders,
            List<@NotEmpty Long> banks) {

        List<MappingMasterData> mappingMasterData = new ArrayList<MappingMasterData>();
        for (String serviceProvider : serviceProviders) {
            for (Long bank : banks) {
                MappingMasterData masterData = new MappingMasterData();
                masterData.setServiceProviderCode(serviceProvider);
                masterData.setDraweeBankProductProfileId(bank);
                mappingMasterData.add(masterData);
            }

        }
        return mappingMasterData;
    }

    public List<MappingMasterData> spAgentMappingData(List<@NotEmpty String> serviceProviders,
            List<@NotEmpty Long> agents) {

        List<MappingMasterData> mappingMasterData = new ArrayList<MappingMasterData>();
        for (String serviceProvider : serviceProviders) {
            for (Long agent : agents) {
                MappingMasterData masterData = new MappingMasterData();
                masterData.setServiceProviderCode(serviceProvider);
                masterData.setAgentBranchIds(agent);
                mappingMasterData.add(masterData);
            }

        }
        return mappingMasterData;
    }

    public List<MappingMasterData> spBankProductMappingData(List<@NotEmpty String> serviceProviders,
            List<@NotEmpty Long> banks, List<@NotEmpty String> products) {
        List<MappingMasterData> mappingMasterData = new ArrayList<MappingMasterData>();
        for (String serviceProvider : serviceProviders) {
            for (Long bank : banks) {
                for (String product : products) {
                    MappingMasterData masterData = new MappingMasterData();
                    masterData.setServiceProviderCode(serviceProvider);
                    masterData.setDraweeBankProductProfileId(bank);
                    masterData.setProductType(product);
                    mappingMasterData.add(masterData);

                }
            }

        }
        return mappingMasterData;
    }

    public List<MappingMasterData> spAgentProductMappingData(List<@NotEmpty String> serviceProviders,
            List<@NotEmpty Long> agents, List<@NotEmpty String> products) {
        List<MappingMasterData> mappingMasterData = new ArrayList<MappingMasterData>();
        for (String serviceProvider : serviceProviders) {
            for (Long agent : agents) {
                for (String product : products) {
                    MappingMasterData masterData = new MappingMasterData();
                    masterData.setServiceProviderCode(serviceProvider);
                    masterData.setAgentBranchIds(agent);
                    masterData.setProductType(product);
                    mappingMasterData.add(masterData);

                }
            }

        }
        return mappingMasterData;
    }

    public List<MappingMasterData> spAgentProductSubProductMapping(List<@NotEmpty String> serviceProviders,
            List<@NotEmpty Long> agents, List<@NotEmpty String> products, List<@NotEmpty String> subProducts) {
        List<MappingMasterData> mappingMasterData = new ArrayList<MappingMasterData>();
        for (String serviceProvider : serviceProviders) {
            for (Long agent : agents) {
                for (String product : products) {
                    for (String subProduct : subProducts) {
                        MappingMasterData masterData = new MappingMasterData();
                        masterData.setServiceProviderCode(serviceProvider);
                        masterData.setAgentBranchIds(agent);
                        masterData.setProductType(product);
                        masterData.setSubProduct(subProduct);
                        mappingMasterData.add(masterData);
                    }

                }
            }

        }
        return mappingMasterData;
    }

    public List<MappingMasterData> spAgentProductSubProductServiceTypeMapping(List<@NotEmpty String> serviceProviders,
            List<@NotEmpty Long> agents, List<@NotEmpty String> products, List<@NotEmpty String> subProducts,
            List<@NotEmpty String> serviceTypes) {

        return null;
    }

    public List<MappingMasterData> spBankProductSubProductMappingData(List<@NotEmpty String> serviceProviders,
            List<@NotEmpty Long> banks, List<@NotEmpty String> products, List<@NotEmpty String> subProducts) {
        List<MappingMasterData> mappingMasterData = new ArrayList<MappingMasterData>();
        for (String serviceProvider : serviceProviders) {
            for (Long bank : banks) {
                for (String product : products) {
                    for (String subProduct : subProducts) {
                        MappingMasterData masterData = new MappingMasterData();
                        masterData.setServiceProviderCode(serviceProvider);
                        masterData.setDraweeBankProductProfileId(bank);
                        masterData.setProductType(product);
                        masterData.setSubProduct(subProduct);
                        mappingMasterData.add(masterData);

                    }
                }
            }
        }
        return mappingMasterData;
    }

}
