package com.unimoni.pricingengine.adapter.rest.controller.events;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.unimoni.pricingengine.domain.model.rate.base.dto.BankDisableDataResponse;

//EVENT:- DRAWEE_BANK_DISABLED
//@FeignClient(name = "ONBOARDING-BANK-SERVICE", url = "http://bank-onboarding-service-snap.dev.apps.ocp.uaeexchange.com/api/v1/onboarding")
@FeignClient(name = "bank-onboarding-client", url = "${onboarding.base-url.bank-onboarding}")
public interface BankDisable {

	@RequestMapping("/draweeBanks/{draweeBankId}/draweeBankProductProfiles")
	public BankDisableDataResponse bankDisable(@PathVariable(value = "draweeBankId") Integer draweeBankId);

}
