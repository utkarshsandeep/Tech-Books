package com.unimoni.pricingengine.adapter.persistence.repository.settlement;

import javax.money.CurrencyUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import com.unimoni.pricingengine.common.constants.ApplicationConstants;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate;
import com.unimoni.pricingengine.domain.model.rate.settlement.SettlementRate_;

public abstract class SettlementRateSelectExpressions {

    static Expression<CurrencyUnit> currencySelectExpression(final Root<SettlementRate> root,
            final CriteriaBuilder criteriaBuilder) {
        return criteriaBuilder.<CurrencyUnit> selectCase()
                .when(criteriaBuilder.equal(root.get(SettlementRate_.currency.getName()).get("source"),
                        ApplicationConstants.CURRENCY_UNIT_USD),
                        root.get(SettlementRate_.currency.getName()).get("target"))
                .otherwise(root.get(SettlementRate_.currency.getName()).get("source"));
    }
}
