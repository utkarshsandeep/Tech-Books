package com.unimoni.pricingengine.adapter.rest.controller.remittance;

import static com.unimoni.pricingengine.common.constants.RestConstants.PRICING_API;
import static com.unimoni.pricingengine.common.constants.RestConstants.Remittance.REMITTANCE_TRANSACTION_CANCELLATION_URI;
import static com.unimoni.pricingengine.common.constants.RestConstants.Remittance.REMITTANCE_TRANSACTION_INITIATION_URI;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.time.LocalDate;
import java.util.concurrent.ExecutionException;

import javax.money.CurrencyUnit;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Problem;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.zalando.problem.Status;

import com.unimoni.pricingengine.common.enums.standard.CountryCode;
import com.unimoni.pricingengine.common.exception.RemittanceTransactionException;
import com.unimoni.pricingengine.common.exception.RemittanceTransactionException.RemittanceTransactionExceptionType;
import com.unimoni.pricingengine.domain.model.rate.composable.AllInstruments;
import com.unimoni.pricingengine.domain.model.remittance.TxnAmount;
import com.unimoni.pricingengine.domain.model.remittance.TxnCancellationReason;
import com.unimoni.pricingengine.domain.model.remittance.dto.CancellationChargeRequest;
import com.unimoni.pricingengine.domain.model.remittance.dto.CancellationChargeResponse;
import com.unimoni.pricingengine.domain.model.remittance.dto.TransactionChargeRequest;
import com.unimoni.pricingengine.domain.model.remittance.dto.TransactionChargeResponse;
import com.unimoni.pricingengine.domain.model.standardcharges.types.BeneficiaryType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.CustomerType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.PaymentMode;
import com.unimoni.pricingengine.domain.model.standardcharges.types.SwiftChargeType;
import com.unimoni.pricingengine.domain.model.standardcharges.types.TransactionStatus;
import com.unimoni.pricingengine.domain.service.remittance.RemittanceTransactionService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "remittance-api", description = "Remittance Transaction APIs", tags = "Remittance")
@RestController
@RequestMapping(PRICING_API)
public class RemittanceTransactionController {

    @Autowired
    private RemittanceTransactionService remittanceTransactionService;

    @GetMapping(REMITTANCE_TRANSACTION_INITIATION_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-transaction-charges", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets the transaction charges at all pricing layers along with customer fee.", 
        response = TransactionChargeResponse.class, 
        notes = ""
    )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "payInCurrency", paramType = "query", 
            dataType = "String", 
            value = "Pay In Currency Code in ISO format e.g. INR", 
            example = "INR", required = true
        ),
        @ApiImplicitParam(name = "payOutCurrency", paramType = "query", 
            dataType = "String", 
            value = "Pay Out Currency Code in ISO format e.g. USD", 
            example = "USD", required = true
        ),
        @ApiImplicitParam(name = "settlementCurrency", paramType = "query", 
            dataType = "String", 
            value = "Settlement Currency Code in ISO format e.g. INR", 
            example = "INR", required = true
        ),
        @ApiImplicitParam(name = "sericeProviderCurrency", paramType = "query", 
            dataType = "String", 
            value = "Service Provider Currency Code in ISO format e.g. USD", 
            example = "USD", required = true
        ),
        @ApiImplicitParam(name = "passSettlementCurrency", paramType = "query", 
            dataType = "String", 
            value = "Pass Settlement Currency Code in ISO format e.g. USD", 
            example = "USD", required = true
        ),
        @ApiImplicitParam(name = "amount", paramType = "query", required = true,
            dataType = "String", dataTypeClass = TxnAmount.class,
            value = "Transaction amount with type such as PAYIN or PAYOUT in format: value,(PAYIN|PAYOUT) example 10500,PAYOUT", 
            example = "10500,PAYIN"
        )
    })
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = Problem.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = Problem.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters"),
            @ApiResponse(code = 412, response = Problem.class, message = "Preconditions failed: Such as required data not set at onboarding end")
        }
    )
    @Valid
    public ResponseEntity<TransactionChargeResponse> getTransactionCharges(
            @ApiParam(value = "Remittance Transaction UUID", required = true, example = "c0a86122-6995-1b8b-8169-9600a4d30006")
            @RequestParam(value = "transactionUUID", required = true) @NotEmpty final String transactionUUID, 
            @ApiParam(value = "Agent Code of Agent who has initiated or Source of the transaction", required = true, example = "AGENT-001", allowEmptyValue = false)
            @RequestParam(value = "agentCode", required = true) @NotEmpty final Long agentBranchId, 
            @ApiParam(value = "Bank code who is the banificiary or Target of the transaction", required = true, example = "BANK001", allowEmptyValue = false)
            @RequestParam(value = "bankCode", required = true) @NotEmpty final String bankCode, 
            @ApiParam(value = "Benificiary Type", type = "String", required = true, example = "All", allowableValues = "All, CORPORATE, INDIVIDUAL", allowEmptyValue = false)
            @RequestParam(value = "beneficiaryType", required = true) @NotNull final BeneficiaryType beneficiaryType, 
            @ApiParam(value = "Customer Type", type = "String", required = true, example = "CORPORATE", allowableValues = "All, CORPORATE, INDIVIDUAL", allowEmptyValue = false)
            @RequestParam(value = "customerType", required = true) @NotNull final CustomerType customerType, 
            @ApiParam(value = "Payment Mode", type = "String", required = true, example = "CASH", allowableValues = "ACCOUNT, CASH, CHEQUE, CREDIT_CARD, DEBIT_CARD, KNET, DIRECT_DEBIT, HYBRID, ACH, DRAFT, ONLINE, NFC_PAYMENT", allowEmptyValue = false)
            @RequestParam(value = "paymentMode", required = true) @NotNull final PaymentMode paymentMode, 
            @ApiParam(value = "Swift Charge Type", type = "String", required = false, example = "SHA", allowableValues = "SHA, BEN, OUR", allowEmptyValue = false)
            @RequestParam(value = "swiftChargeType", required = false) final SwiftChargeType swiftChargeType, 
            @ApiParam(value = "Country code in ISO Alpha 2 format, of the Country from where the transaction is initiated", required = true, example = "IN", allowEmptyValue = false)
            @RequestParam(value = "originatingCountry", required = true) @NotEmpty final CountryCode originatingCountry, 
            @ApiParam(value = "Country code in ISO Alpha 2 format, of the Country where the transaction is destined to", required = true, example = "US", allowEmptyValue = false)
            @RequestParam(value = "destinationCountry", required = true) @NotEmpty final CountryCode destinationCountry, 
            @ApiParam(value = "Transaction initiation date in ISO format: yyyy-MM-dd", required = true, example = "2019-03-19", allowEmptyValue = false)
            @RequestParam(value = "initiationDate", required = true) @NotNull @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) final LocalDate initiationDate, 
            @ApiParam(value = "Transaction transmission date in ISO format: yyyy-MM-dd", required = true, example = "2019-03-20", allowEmptyValue = false)
            @RequestParam(value = "transmissionDate", required = true) @NotNull @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) final LocalDate transmissionDate, 
            @ApiParam(value = "Service Provider such as UAE, UK etc.", required = true, example = "UAE", allowEmptyValue = false)
            @RequestParam(value = "serviceProvider", required = true) @NotEmpty final String serviceProvider, 
            @ApiParam(value = "Product such as Remittance, Forex etc.", required = true, example = "Remittance", allowEmptyValue = false)
            @RequestParam(value = "product", required = true) @NotEmpty final String product, 
            @ApiParam(value = "Sub product such as Account Credit, Cash payout etc.", required = true, example = "Account Credit", allowEmptyValue = false)
            @RequestParam(value = "subProduct", required = true) @NotEmpty final String subProduct, 
            @ApiParam(value = "Service type such as Flash, Normal etc.", required = true, example = "Flash", allowEmptyValue = false)
            @RequestParam(value = "serviceType", required = true) @NotEmpty final String serviceType, 
            @RequestParam(value = "payInCurrency", required = true) @NotNull CurrencyUnit payInCurrency,
            @RequestParam(value = "payOutCurrency", required = true) @NotNull CurrencyUnit payOutCurrency,
            @RequestParam(value = "settlementCurrency", required = true) @NotNull CurrencyUnit settlementCurrency,
            @RequestParam(value = "sericeProviderCurrency", required = true) @NotNull CurrencyUnit sericeProviderCurrency,
            @RequestParam(value = "passSettlementCurrency", required = true) @NotNull CurrencyUnit passSettlementCurrency,
            @RequestParam(value = "amount", required = true) @NotNull final TxnAmount amount) 
                    throws InterruptedException, ExecutionException {
        // @formatter:on

        if (initiationDate.isAfter(transmissionDate)) {
            throw new RemittanceTransactionException(
                    RemittanceTransactionExceptionType.TRANSMISSION_DATE_LESS_THAN_INITIATION_DATE, Status.BAD_REQUEST,
                    initiationDate, transmissionDate);
        }
        TransactionChargeRequest transactionChargeRequest = TransactionChargeRequest.of(transactionUUID, agentBranchId,
                bankCode, beneficiaryType, payInCurrency, payOutCurrency, settlementCurrency, sericeProviderCurrency,
                passSettlementCurrency, customerType, originatingCountry, destinationCountry, paymentMode,
                AllInstruments.of(serviceProvider, product, subProduct, serviceType), amount, initiationDate,
                transmissionDate, swiftChargeType);

        return ResponseEntity
                .ok(this.remittanceTransactionService.processTransactionInitiationRequest(transactionChargeRequest));
    }

    @GetMapping(REMITTANCE_TRANSACTION_CANCELLATION_URI)
    // @formatter:off
    @ApiOperation(nickname = "get-cancellation-charge", 
        consumes = APPLICATION_JSON_VALUE, 
        produces = APPLICATION_JSON_VALUE,
        value = "Gets the transaction cancellation charges.", 
        response = CancellationChargeResponse.class, 
        notes = ""
    )
    @ApiResponses(value = { 
            @ApiResponse(code = 200, response = Problem.class, message = "Success: All rates and charges found and successfully returned to consumer"),
            @ApiResponse(code = 400, response = Problem.class, message = "Bad Request: Input request parameters validation failed such as "
                    + "any mandatory parameter missing, currency or country code is not valid ISO code,"
                    + "charges or rates not set in Pricing for given input parameters"),
            @ApiResponse(code = 412, response = Problem.class, message = "Preconditions failed: Such as required data not set at onboarding end")
        }
    )
    @Valid
    public ResponseEntity<CancellationChargeResponse> getCancellationCharges(
            @ApiParam(value = "Remittance Transaction UUID", required = true, example = "c0a86122-6995-1b8b-8169-9600a4d30006", allowEmptyValue = false)
            @RequestParam(value = "transactionUUID", required = true) @NotEmpty final String transactionUUID, 
            @ApiParam(value = "Transaction Status such as Cancellation before Provider or Cancellation after Provider", type = "String", required = true, example = "CANCEL_BEFORE_PROVIDER", allowableValues = "CANCEL_BEFORE_PROVIDER, CANCEL_AFTER_PROVIDER", allowEmptyValue = false)
            @RequestParam(value = "transactionStatus", required = true) @NotNull final TransactionStatus transactionStatus,
            @ApiParam(value = "Reason for cancellation", required = true, example = "Customer initiated", allowEmptyValue = false)
            @RequestParam(value = "reasonForCancellation", required = true) @NotEmpty final TxnCancellationReason reasonForCancellation) throws InterruptedException, ExecutionException {
    // @formatter:on

        return ResponseEntity.ok(this.remittanceTransactionService.processTransactionCancellationRequest(
                CancellationChargeRequest.of(transactionUUID, transactionStatus, reasonForCancellation)));
    }
}
