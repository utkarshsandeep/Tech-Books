package com.unimoni.pricingengine.domain.model.rate.base.dto;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.Map;
import java.util.NoSuchElementException;

import org.joda.beans.Bean;
import org.joda.beans.ImmutableBean;
import org.joda.beans.JodaBeanUtils;
import org.joda.beans.MetaBean;
import org.joda.beans.MetaProperty;
import org.joda.beans.gen.BeanDefinition;
import org.joda.beans.gen.PropertyDefinition;
import org.joda.beans.impl.direct.DirectFieldsBeanBuilder;
import org.joda.beans.impl.direct.DirectMetaBean;
import org.joda.beans.impl.direct.DirectMetaProperty;
import org.joda.beans.impl.direct.DirectMetaPropertyMap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.common.util.DateTimeHelper;
import com.unimoni.pricingengine.common.util.download.jodaBeans.Download;
import com.unimoni.pricingengine.domain.model.common.dto.Frequency;
import com.unimoni.pricingengine.domain.model.common.dto.ViewModel;
import com.unimoni.pricingengine.domain.model.rate.base.NormalBaseRate;
import com.unimoni.pricingengine.domain.model.rate.ibr.NormalIBR;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@BeanDefinition
@ApiModel(value = "normalRateResponse", description = "View Model for normal base rate")
public class NormalRateResponse implements ViewModel<String>, ImmutableBean {

    @Getter
    @ApiModelProperty(name = "rateId", value = "Record ID", example = "0a80029c-6970-180d-8169-715e721b0001")
    @JsonInclude(NON_NULL)
    private String rateId = "";

    @Download(columnName = "Rate Provider")
    @PropertyDefinition
    @ApiModelProperty(allowEmptyValue = false, value = "Rate provider name: Manual, Thomson Reuters, Future Source", example = "Manual")
    @JsonInclude(NON_EMPTY)
    private final String rateProvider;

    @Download(columnName = "Service Provider")
    @PropertyDefinition
    @ApiModelProperty(name = "serviceProvider", value = "Service Provider name", example = "UAE")
    @JsonInclude(NON_NULL)
    private final String serviceProvider;

    @Download(columnName = "Product")
    @PropertyDefinition
    @ApiModelProperty(name = "product", value = "Product name", example = "Remittance")
    @JsonInclude(NON_NULL)
    private final String product;

    @Download(columnName = "Ric ID")
    @PropertyDefinition
    @ApiModelProperty(name = "ricId", value = "Ric ID to get rates from Rate providers such as Thomson Reuters or Future Sorce", example = "INR=")
    @JsonInclude(NON_EMPTY)
    private final String ricId;

    @PropertyDefinition
    @JsonInclude(NON_NULL)
    private final ExchangeDTO exchange;

    @Download(columnName = "Frequency")
    @PropertyDefinition
    @JsonInclude(NON_NULL)
    private final Frequency frequency;

    @Download(columnName = "Updated On")
    @PropertyDefinition
    @ApiModelProperty(name = "updatedOn", value = "Rate Last updated timestamp with timezone", example = "12-03-2019 09:07:50 (GMT)")
    @JsonInclude(NON_NULL)
    private final String updatedOn;

    @Download(columnName = "Status")
    @PropertyDefinition
    @ApiModelProperty(name = "status", value = "Enabled or Disabled", example = "true")
    @JsonInclude(NON_NULL)
    private final Boolean status;

    public static NormalRateResponse of(final NormalBaseRate normalBaseRate) {
        Frequency freq = !normalBaseRate.rateProvider().isManual()
                ? Frequency.of(normalBaseRate.frequency(), normalBaseRate.isLive())
                : null;
        return new NormalRateResponse(normalBaseRate.id(), normalBaseRate.rateProvider().name(),
                normalBaseRate.instruments().serviceProvider(), normalBaseRate.instruments().product(),
                normalBaseRate.ricId(), ExchangeDTO.of(normalBaseRate.exchange()), freq,
                DateTimeHelper.convertAndFormatZonedDateTime(normalBaseRate.updatedOn()), normalBaseRate.isEnabled());
    }

    public static NormalRateResponse of(final NormalIBR normalIBR) {
        return new NormalRateResponse(normalIBR.id(), null, normalIBR.instruments().serviceProvider(),
                normalIBR.instruments().product(), null, ExchangeDTO.of(normalIBR.exchange()), null,
                DateTimeHelper.convertAndFormatZonedDateTime(normalIBR.updatedOn()), normalIBR.isEnabled());
    }
    
    public static NormalRateResponse forSSEvents(final String rateId, final String rateProviderId,
            final String serviceProvider, final String product, final String ricId, final ExchangeDTO exchange,
            final Frequency frequency, final String updatedOn, final Boolean status) {
        return new NormalRateResponse(rateId, rateProviderId, serviceProvider, product, ricId, exchange, frequency, updatedOn, status);
    }

    @Override
    public String id() {
        return this.rateId;
    }

  //------------------------- AUTOGENERATED START -------------------------
  /**
   * The meta-bean for {@code NormalRateResponse}.
   * @return the meta-bean, not null
   */
  public static NormalRateResponse.Meta meta() {
    return NormalRateResponse.Meta.INSTANCE;
  }

  static {
    MetaBean.register(NormalRateResponse.Meta.INSTANCE);
  }

  /**
   * Returns a builder used to create an instance of the bean.
   * @return the builder, not null
   */
  public static NormalRateResponse.Builder builder() {
    return new NormalRateResponse.Builder();
  }

  /**
   * Restricted constructor.
   * @param builder  the builder to copy from, not null
   */
  protected NormalRateResponse(NormalRateResponse.Builder builder) {
    this.rateProvider = builder.rateProvider;
    this.serviceProvider = builder.serviceProvider;
    this.product = builder.product;
    this.ricId = builder.ricId;
    this.exchange = builder.exchange;
    this.frequency = builder.frequency;
    this.updatedOn = builder.updatedOn;
    this.status = builder.status;
  }

  @Override
  public NormalRateResponse.Meta metaBean() {
    return NormalRateResponse.Meta.INSTANCE;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the rateProvider.
   * @return the value of the property
   */
  public String getRateProvider() {
    return rateProvider;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the serviceProvider.
   * @return the value of the property
   */
  public String getServiceProvider() {
    return serviceProvider;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the product.
   * @return the value of the property
   */
  public String getProduct() {
    return product;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the ricId.
   * @return the value of the property
   */
  public String getRicId() {
    return ricId;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the exchange.
   * @return the value of the property
   */
  public ExchangeDTO getExchange() {
    return exchange;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the frequency.
   * @return the value of the property
   */
  public Frequency getFrequency() {
    return frequency;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the updatedOn.
   * @return the value of the property
   */
  public String getUpdatedOn() {
    return updatedOn;
  }

  //-----------------------------------------------------------------------
  /**
   * Gets the status.
   * @return the value of the property
   */
  public Boolean getStatus() {
    return status;
  }

  //-----------------------------------------------------------------------
  /**
   * Returns a builder that allows this bean to be mutated.
   * @return the mutable builder, not null
   */
  public Builder toBuilder() {
    return new Builder(this);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj != null && obj.getClass() == this.getClass()) {
      NormalRateResponse other = (NormalRateResponse) obj;
      return JodaBeanUtils.equal(rateProvider, other.rateProvider) &&
          JodaBeanUtils.equal(serviceProvider, other.serviceProvider) &&
          JodaBeanUtils.equal(product, other.product) &&
          JodaBeanUtils.equal(ricId, other.ricId) &&
          JodaBeanUtils.equal(exchange, other.exchange) &&
          JodaBeanUtils.equal(frequency, other.frequency) &&
          JodaBeanUtils.equal(updatedOn, other.updatedOn) &&
          JodaBeanUtils.equal(status, other.status);
    }
    return false;
  }

  @Override
  public int hashCode() {
    int hash = getClass().hashCode();
    hash = hash * 31 + JodaBeanUtils.hashCode(rateProvider);
    hash = hash * 31 + JodaBeanUtils.hashCode(serviceProvider);
    hash = hash * 31 + JodaBeanUtils.hashCode(product);
    hash = hash * 31 + JodaBeanUtils.hashCode(ricId);
    hash = hash * 31 + JodaBeanUtils.hashCode(exchange);
    hash = hash * 31 + JodaBeanUtils.hashCode(frequency);
    hash = hash * 31 + JodaBeanUtils.hashCode(updatedOn);
    hash = hash * 31 + JodaBeanUtils.hashCode(status);
    return hash;
  }

  @Override
  public String toString() {
    StringBuilder buf = new StringBuilder(288);
    buf.append("NormalRateResponse{");
    int len = buf.length();
    toString(buf);
    if (buf.length() > len) {
      buf.setLength(buf.length() - 2);
    }
    buf.append('}');
    return buf.toString();
  }

  protected void toString(StringBuilder buf) {
    buf.append("rateProvider").append('=').append(JodaBeanUtils.toString(rateProvider)).append(',').append(' ');
    buf.append("serviceProvider").append('=').append(JodaBeanUtils.toString(serviceProvider)).append(',').append(' ');
    buf.append("product").append('=').append(JodaBeanUtils.toString(product)).append(',').append(' ');
    buf.append("ricId").append('=').append(JodaBeanUtils.toString(ricId)).append(',').append(' ');
    buf.append("exchange").append('=').append(JodaBeanUtils.toString(exchange)).append(',').append(' ');
    buf.append("frequency").append('=').append(JodaBeanUtils.toString(frequency)).append(',').append(' ');
    buf.append("updatedOn").append('=').append(JodaBeanUtils.toString(updatedOn)).append(',').append(' ');
    buf.append("status").append('=').append(JodaBeanUtils.toString(status)).append(',').append(' ');
  }

  //-----------------------------------------------------------------------
  /**
   * The meta-bean for {@code NormalRateResponse}.
   */
  public static class Meta extends DirectMetaBean {
    /**
     * The singleton instance of the meta-bean.
     */
    static final Meta INSTANCE = new Meta();

    /**
     * The meta-property for the {@code rateProvider} property.
     */
    private final MetaProperty<String> _rateProvider = DirectMetaProperty.ofImmutable(
        this, "rateProvider", NormalRateResponse.class, String.class);
    /**
     * The meta-property for the {@code serviceProvider} property.
     */
    private final MetaProperty<String> _serviceProvider = DirectMetaProperty.ofImmutable(
        this, "serviceProvider", NormalRateResponse.class, String.class);
    /**
     * The meta-property for the {@code product} property.
     */
    private final MetaProperty<String> _product = DirectMetaProperty.ofImmutable(
        this, "product", NormalRateResponse.class, String.class);
    /**
     * The meta-property for the {@code ricId} property.
     */
    private final MetaProperty<String> _ricId = DirectMetaProperty.ofImmutable(
        this, "ricId", NormalRateResponse.class, String.class);
    /**
     * The meta-property for the {@code exchange} property.
     */
    private final MetaProperty<ExchangeDTO> _exchange = DirectMetaProperty.ofImmutable(
        this, "exchange", NormalRateResponse.class, ExchangeDTO.class);
    /**
     * The meta-property for the {@code frequency} property.
     */
    private final MetaProperty<Frequency> _frequency = DirectMetaProperty.ofImmutable(
        this, "frequency", NormalRateResponse.class, Frequency.class);
    /**
     * The meta-property for the {@code updatedOn} property.
     */
    private final MetaProperty<String> _updatedOn = DirectMetaProperty.ofImmutable(
        this, "updatedOn", NormalRateResponse.class, String.class);
    /**
     * The meta-property for the {@code status} property.
     */
    private final MetaProperty<Boolean> _status = DirectMetaProperty.ofImmutable(
        this, "status", NormalRateResponse.class, Boolean.class);
    /**
     * The meta-properties.
     */
    private final Map<String, MetaProperty<?>> _metaPropertyMap$ = new DirectMetaPropertyMap(
        this, null,
        "rateProvider",
        "serviceProvider",
        "product",
        "ricId",
        "exchange",
        "frequency",
        "updatedOn",
        "status");

    /**
     * Restricted constructor.
     */
    protected Meta() {
    }

    @Override
    protected MetaProperty<?> metaPropertyGet(String propertyName) {
      switch (propertyName.hashCode()) {
        case -787949839:  // rateProvider
          return _rateProvider;
        case 243182534:  // serviceProvider
          return _serviceProvider;
        case -309474065:  // product
          return _product;
        case 108506951:  // ricId
          return _ricId;
        case 1989774883:  // exchange
          return _exchange;
        case -70023844:  // frequency
          return _frequency;
        case -1949194246:  // updatedOn
          return _updatedOn;
        case -892481550:  // status
          return _status;
      }
      return super.metaPropertyGet(propertyName);
    }

    @Override
    public NormalRateResponse.Builder builder() {
      return new NormalRateResponse.Builder();
    }

    @Override
    public Class<? extends NormalRateResponse> beanType() {
      return NormalRateResponse.class;
    }

    @Override
    public Map<String, MetaProperty<?>> metaPropertyMap() {
      return _metaPropertyMap$;
    }

    //-----------------------------------------------------------------------
    /**
     * The meta-property for the {@code rateProvider} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> rateProvider() {
      return _rateProvider;
    }

    /**
     * The meta-property for the {@code serviceProvider} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> serviceProvider() {
      return _serviceProvider;
    }

    /**
     * The meta-property for the {@code product} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> product() {
      return _product;
    }

    /**
     * The meta-property for the {@code ricId} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> ricId() {
      return _ricId;
    }

    /**
     * The meta-property for the {@code exchange} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<ExchangeDTO> exchange() {
      return _exchange;
    }

    /**
     * The meta-property for the {@code frequency} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<Frequency> frequency() {
      return _frequency;
    }

    /**
     * The meta-property for the {@code updatedOn} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<String> updatedOn() {
      return _updatedOn;
    }

    /**
     * The meta-property for the {@code status} property.
     * @return the meta-property, not null
     */
    public final MetaProperty<Boolean> status() {
      return _status;
    }

    //-----------------------------------------------------------------------
    @Override
    protected Object propertyGet(Bean bean, String propertyName, boolean quiet) {
      switch (propertyName.hashCode()) {
        case -787949839:  // rateProvider
          return ((NormalRateResponse) bean).getRateProvider();
        case 243182534:  // serviceProvider
          return ((NormalRateResponse) bean).getServiceProvider();
        case -309474065:  // product
          return ((NormalRateResponse) bean).getProduct();
        case 108506951:  // ricId
          return ((NormalRateResponse) bean).getRicId();
        case 1989774883:  // exchange
          return ((NormalRateResponse) bean).getExchange();
        case -70023844:  // frequency
          return ((NormalRateResponse) bean).getFrequency();
        case -1949194246:  // updatedOn
          return ((NormalRateResponse) bean).getUpdatedOn();
        case -892481550:  // status
          return ((NormalRateResponse) bean).getStatus();
      }
      return super.propertyGet(bean, propertyName, quiet);
    }

    @Override
    protected void propertySet(Bean bean, String propertyName, Object newValue, boolean quiet) {
      metaProperty(propertyName);
      if (quiet) {
        return;
      }
      throw new UnsupportedOperationException("Property cannot be written: " + propertyName);
    }

  }

  //-----------------------------------------------------------------------
  /**
   * The bean-builder for {@code NormalRateResponse}.
   */
  public static class Builder extends DirectFieldsBeanBuilder<NormalRateResponse> {

    private String rateProvider;
    private String serviceProvider;
    private String product;
    private String ricId;
    private ExchangeDTO exchange;
    private Frequency frequency;
    private String updatedOn;
    private Boolean status;

    /**
     * Restricted constructor.
     */
    protected Builder() {
    }

    /**
     * Restricted copy constructor.
     * @param beanToCopy  the bean to copy from, not null
     */
    protected Builder(NormalRateResponse beanToCopy) {
      this.rateProvider = beanToCopy.getRateProvider();
      this.serviceProvider = beanToCopy.getServiceProvider();
      this.product = beanToCopy.getProduct();
      this.ricId = beanToCopy.getRicId();
      this.exchange = beanToCopy.getExchange();
      this.frequency = beanToCopy.getFrequency();
      this.updatedOn = beanToCopy.getUpdatedOn();
      this.status = beanToCopy.getStatus();
    }

    //-----------------------------------------------------------------------
    @Override
    public Object get(String propertyName) {
      switch (propertyName.hashCode()) {
        case -787949839:  // rateProvider
          return rateProvider;
        case 243182534:  // serviceProvider
          return serviceProvider;
        case -309474065:  // product
          return product;
        case 108506951:  // ricId
          return ricId;
        case 1989774883:  // exchange
          return exchange;
        case -70023844:  // frequency
          return frequency;
        case -1949194246:  // updatedOn
          return updatedOn;
        case -892481550:  // status
          return status;
        default:
          throw new NoSuchElementException("Unknown property: " + propertyName);
      }
    }

    @Override
    public Builder set(String propertyName, Object newValue) {
      switch (propertyName.hashCode()) {
        case -787949839:  // rateProvider
          this.rateProvider = (String) newValue;
          break;
        case 243182534:  // serviceProvider
          this.serviceProvider = (String) newValue;
          break;
        case -309474065:  // product
          this.product = (String) newValue;
          break;
        case 108506951:  // ricId
          this.ricId = (String) newValue;
          break;
        case 1989774883:  // exchange
          this.exchange = (ExchangeDTO) newValue;
          break;
        case -70023844:  // frequency
          this.frequency = (Frequency) newValue;
          break;
        case -1949194246:  // updatedOn
          this.updatedOn = (String) newValue;
          break;
        case -892481550:  // status
          this.status = (Boolean) newValue;
          break;
        default:
          throw new NoSuchElementException("Unknown property: " + propertyName);
      }
      return this;
    }

    @Override
    public Builder set(MetaProperty<?> property, Object value) {
      super.set(property, value);
      return this;
    }

    @Override
    public NormalRateResponse build() {
      return new NormalRateResponse(this);
    }

    //-----------------------------------------------------------------------
    /**
     * Sets the rateProvider.
     * @param rateProvider  the new value
     * @return this, for chaining, not null
     */
    public Builder rateProvider(String rateProvider) {
      this.rateProvider = rateProvider;
      return this;
    }

    /**
     * Sets the serviceProvider.
     * @param serviceProvider  the new value
     * @return this, for chaining, not null
     */
    public Builder serviceProvider(String serviceProvider) {
      this.serviceProvider = serviceProvider;
      return this;
    }

    /**
     * Sets the product.
     * @param product  the new value
     * @return this, for chaining, not null
     */
    public Builder product(String product) {
      this.product = product;
      return this;
    }

    /**
     * Sets the ricId.
     * @param ricId  the new value
     * @return this, for chaining, not null
     */
    public Builder ricId(String ricId) {
      this.ricId = ricId;
      return this;
    }

    /**
     * Sets the exchange.
     * @param exchange  the new value
     * @return this, for chaining, not null
     */
    public Builder exchange(ExchangeDTO exchange) {
      this.exchange = exchange;
      return this;
    }

    /**
     * Sets the frequency.
     * @param frequency  the new value
     * @return this, for chaining, not null
     */
    public Builder frequency(Frequency frequency) {
      this.frequency = frequency;
      return this;
    }

    /**
     * Sets the updatedOn.
     * @param updatedOn  the new value
     * @return this, for chaining, not null
     */
    public Builder updatedOn(String updatedOn) {
      this.updatedOn = updatedOn;
      return this;
    }

    /**
     * Sets the status.
     * @param status  the new value
     * @return this, for chaining, not null
     */
    public Builder status(Boolean status) {
      this.status = status;
      return this;
    }

    //-----------------------------------------------------------------------
    @Override
    public String toString() {
      StringBuilder buf = new StringBuilder(288);
      buf.append("NormalRateResponse.Builder{");
      int len = buf.length();
      toString(buf);
      if (buf.length() > len) {
        buf.setLength(buf.length() - 2);
      }
      buf.append('}');
      return buf.toString();
    }

    protected void toString(StringBuilder buf) {
      buf.append("rateProvider").append('=').append(JodaBeanUtils.toString(rateProvider)).append(',').append(' ');
      buf.append("serviceProvider").append('=').append(JodaBeanUtils.toString(serviceProvider)).append(',').append(' ');
      buf.append("product").append('=').append(JodaBeanUtils.toString(product)).append(',').append(' ');
      buf.append("ricId").append('=').append(JodaBeanUtils.toString(ricId)).append(',').append(' ');
      buf.append("exchange").append('=').append(JodaBeanUtils.toString(exchange)).append(',').append(' ');
      buf.append("frequency").append('=').append(JodaBeanUtils.toString(frequency)).append(',').append(' ');
      buf.append("updatedOn").append('=').append(JodaBeanUtils.toString(updatedOn)).append(',').append(' ');
      buf.append("status").append('=').append(JodaBeanUtils.toString(status)).append(',').append(' ');
    }

  }

  //-------------------------- AUTOGENERATED END --------------------------
}
