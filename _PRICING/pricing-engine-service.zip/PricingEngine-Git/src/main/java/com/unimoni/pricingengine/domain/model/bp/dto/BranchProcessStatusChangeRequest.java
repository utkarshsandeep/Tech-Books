package com.unimoni.pricingengine.domain.model.bp.dto;

import javax.validation.constraints.NotNull;

import com.unimoni.pricingengine.domain.model.bp.StatusType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@ApiModel(value = "branchProcessStatusUpdateRequest", description = "Update BP deal status Request")
@ToString
public class BranchProcessStatusChangeRequest {

    @NotNull
    @ApiModelProperty(name = "status", allowEmptyValue = false, dataType = "Enum", required = true)
    private StatusType status;
}
