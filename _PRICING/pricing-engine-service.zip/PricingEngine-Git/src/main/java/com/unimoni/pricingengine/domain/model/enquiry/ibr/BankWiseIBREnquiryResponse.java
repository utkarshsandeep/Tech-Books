package com.unimoni.pricingengine.domain.model.enquiry.ibr;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import javax.money.CurrencyUnit;

import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.unimoni.pricingengine.domain.model.enquiry.StreamResponse;
import com.unimoni.pricingengine.domain.model.rate.base.dto.RateDTO;
import com.unimoni.pricingengine.domain.model.rate.composable.ExchangeRate;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.ToString;

@Getter
@ApiModel(value = "bankWiseIBREnquiryResponse", description = "Bank Wise IBR enquiry response")
@ToString(callSuper = true)
public class BankWiseIBREnquiryResponse extends StreamResponse {

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Service Provider such as UAE, UK etc.", required = true, example = "UAEEXNZ#####", position = 1)
    private String serviceProvider;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Product such as Remittance, Forex etc.", required = true, example = "Remittance", position = 2)
    private String product;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Bank Code", required = true, example = "HDFCIN", position = 3)
    private String bank;

    @JsonInclude(NON_EMPTY)
    @ApiModelProperty(value = "Agent Code", required = true, example = "TRVLX#######", position = 4)
    private String agent;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Currency Code in ISO format e.g. INR", required = true, example = "INR", position = 5)
    private CurrencyUnit currency;

    @JsonInclude(NON_NULL)
    @ApiModelProperty(value = "Bankwise IBR Ask and Bid values", required = true, position = 6)
    private RateDTO rate;

    public BankWiseIBREnquiryResponse(final int identityIndex, final String serviceProvider, final String product,
            final String bank, final String agent, final CurrencyUnit currency, final ExchangeRate exchangeRate) {
        super(identityIndex);
        this.serviceProvider = serviceProvider;
        this.product = product;
        this.bank = bank;
        this.agent = agent;
        this.currency = currency;
        this.rate = RateDTO.of(exchangeRate);
    }

    private BankWiseIBREnquiryResponse(final int batchSize, final int recordCount, final int endIndex,
            final int lastIndex, final Supplier<String> linkSupplier) {
        super(batchSize, recordCount, endIndex, lastIndex, linkSupplier);
    }

    public static BankWiseIBREnquiryResponse end(final BankWiseIBREnquiryRequest enquiryRequest, final int recordCount,
            final int lastIndex, final String URI) {
        return new BankWiseIBREnquiryResponse(enquiryRequest.batchSize(), recordCount, enquiryRequest.endIndex(),
                lastIndex, () -> moreLink(enquiryRequest, lastIndex, URI));
    }

    private static String moreLink(final BankWiseIBREnquiryRequest enquiryRequest, final int lastIndex,
            final String URI) {
        final Map<String, Object> paramsMap = new LinkedHashMap<>(7);
        paramsMap.put("serviceProviders", enquiryRequest.serviceProviders().toArray());
        paramsMap.put("products", enquiryRequest.products().toArray());
        paramsMap.put("banks", enquiryRequest.banks().toArray());
        paramsMap.put("agents", enquiryRequest.agents().toArray());
        paramsMap.put("currencies", enquiryRequest.currencies().stream().map(CurrencyUnit::getCurrencyCode).toArray());
        paramsMap.put("startingIndex", lastIndex);
        paramsMap.put("batchSize", enquiryRequest.batchSize());

        String queryParameters = paramsMap.entrySet().stream().map((x) -> x.getKey() + "={" + x.getKey() + "}")
                .collect(Collectors.joining("&"));
        String uri = URI + "?" + queryParameters;
        return UriComponentsBuilder.fromUriString(uri).build().expand(paramsMap).encode().toUriString();
    }
}
