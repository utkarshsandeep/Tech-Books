package com.unimoni.pricingengine.domain.model.enquiry.settlement;

import java.util.EnumSet;
import java.util.Optional;

import javax.money.CurrencyUnit;

import com.unimoni.pricingengine.domain.model.rate.var.VDWType;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Accessors(chain = true, fluent = true)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@ToString
public class SettlementRateEnquiryIdentity {

    private int index;

    private String serviceProvider;

    private String product;

    private String subProduct;

    private String serviceType;

    private String bank;

    private String agent;

    private CurrencyUnit currency;

    private EnumSet<VDWType> valueDateWises;

    public static SettlementRateEnquiryIdentity ofNormal(final int index, final String serviceProvider,
            final String product, final String subProduct, final String serviceType, final String agent,
            final CurrencyUnit currency, final EnumSet<VDWType> valueDateWises) {
        return new SettlementRateEnquiryIdentity(index, serviceProvider, product, subProduct, serviceType, null, agent,
                currency, valueDateWises);
    }

    public static SettlementRateEnquiryIdentity ofBankWise(final int index, final String serviceProvider,
            final String product, final String subProduct, final String serviceType, final String bank,
            final String agent, final CurrencyUnit currency, final EnumSet<VDWType> valueDateWises) {
        return new SettlementRateEnquiryIdentity(index, serviceProvider, product, subProduct, serviceType, bank, agent,
                currency, valueDateWises);
    }

    public Optional<String> bank() {
        return Optional.ofNullable(this.bank);
    }
}
